# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,urlparse
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,client
type=['movie']
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
import urllib2,urllib,logging,base64,json
color=all_colors[95]
def resolve_links(url,pre_url,cook):

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Referer': pre_url,
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }
    print url
    res = requests.get(url,headers=headers,cookies=cook)
    cook2=res.cookies

    d1 = dict(cook2)

    holder=res.content
    regex='player video="(.+?)" hash="(.+?)" expire="(.+?)"'
    match=re.compile(regex).findall(holder)
 






    headers = {
    'Sec-Fetch-Mode': 'cors',
    'Origin': 'https://consistent.stream',
    'X-XSRF-TOKEN':d1['XSRF-TOKEN'],
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36',
    'Content-Type': 'application/json;charset=UTF-8',
    'Access-Control-Allow-Origin': 'XMLHttpRequest',
    'Accept': 'application/json, text/plain, */*',
    'Referer': url,
    }
    data = {'video':match[0][0],
            'referrer':pre_url,
            'key':match[0][1],
            'expire':match[0][2]}

    
    response = requests.post('https://consistent.stream/api/getVideo', headers=headers, json=data,cookies=cook2).json()
   
    return response
def resolve_movie(url):
    ids=url.split('/')
    id=ids[len(ids)-1]
   
    
    headers = {
        'pragma': 'no-cache',
        
        'accept-encoding': 'utf-8',
        'accept-language': 'he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7',
        'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36',
        'accept': 'application/json, text/plain, */*',
        'cache-control': 'no-cache',
        'authority': 'load.embed.is.vidnode.net.vidcloud.icu.movienightplayer.com',
        'referer': 'https://load.embed.is.vidnode.net.vidcloud.icu.movienightplayer.com/',
    }

    params = (
        ('1', ''),
    )

    res = requests.get('https://load.embed.is.vidnode.net.vidcloud.icu.movienightplayer.com/api/app/getToken', headers=headers, params=params).json()




    headers = {
        'pragma': 'no-cache',
        'origin': 'https://load.embed.is.vidnode.net.vidcloud.icu.movienightplayer.com',
        'accept-encoding': 'utf-8',
        'accept-language': 'he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7',
        'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36',
       
        'accept': 'application/json, text/plain, */*',
        'cache-control': 'no-cache',
        'authority': 'source.movienightplayer.com',
        'referer': 'https://load.embed.is.vidnode.net.vidcloud.icu.movienightplayer.com/',
    }



    response = requests.post('https://source.movienightplayer.com/api/getSource/%s/'%id+res['data'], headers=headers).json()
    return response
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
        global global_var,stop_all,progress
        progress='Start'
        start_time=time.time()
        print original_title
        base_link = 'http://vexmovies.org'
        User_Agent = 'Mozilla/5.0 (iPhone; CPU iPhone OS 8_4 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12H143 Safari/600.1.4'
        all_links=[]
        search_id = clean_name(original_title.lower(),1)
        start_url = '%s/?s=%s' %(base_link,search_id.replace(' ','+'))
   
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        }
        progress='requests'
        html = requests.get(start_url,headers=headers,timeout=5).content
        progress='Regex'
        Regex = re.compile('div class="boxinfo".+?href="(.+?)".+?class="tt">(.+?)<.+?class="year">(.+?)<',re.DOTALL).findall(html)
        count=0
     
        for item_url,name,date in Regex:
            progress='Links-'+str(count)
            count+=1
            if clean_name(original_title,1).lower() == clean_name(name,1).lower():
                print date
                if show_original_year in date:
                    movie_link = item_url
                    progress='requests-'+str(count)
                    res= requests.get(movie_link,headers=headers,verify=False,timeout=5)
                    cook= res.cookies
                    html=res.content
                    progress='requests2-'+str(count)
                    print movie_link
                    source = re.compile('<iframe src="(.+?)"',re.DOTALL).findall(html)[0]
                   
                    if 'consistent.stream' in source:
                        headers = {'User_Agent':User_Agent}
                        
                        
                        sources=resolve_links(source,movie_link,cook)
                        print sources
                        for link in sources['servers']:
                            
                            for link_in in link['sources']:
                               if 'consistent.stream' in link_in['src']:
                                   
                                    all_links.append((original_title.replace("%20"," "),link_in['src'],'Direct',' '))
                                    global_var=all_links
                               elif 'movienightplayer.com' in link_in['src']:
                                   continue
                                   all_links_in=resolve_movie(link_in['src'])
                                   for li in all_links_in['data']['sources']:
                                        all_links.append((original_title.replace("%20"," "),li['src'],'Direct',str(li['res'])))
                                        global_var=all_links
                               else:
                                    progress='Check-'+str(count)
                                    nam1,srv,res,check=server_data(link_in['src'],original_title)
                                
                                    if check:
                                        all_links.append((nam1.replace("%20"," "),link_in['src'],srv,res))
                                        global_var=all_links
        elapsed_time = time.time() - start_time
        progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
        return global_var