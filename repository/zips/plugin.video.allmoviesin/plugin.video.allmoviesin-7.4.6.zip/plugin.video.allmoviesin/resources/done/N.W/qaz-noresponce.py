# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,urlparse

global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,base_header
type=['movie','tv']

import urllib2,urllib,logging,base64,json
color=all_colors[41]
def check_lk(url):
    if 'fruithosts' in url:
        x=requests.get(url,headers=base_header).content
        regex='name="og:url" content="(.+?)"'
        url=re.compile(regex).findall(x)[0]
    try:
      import resolveurl
    except:
      import resolveurl_temp as resolveurl
    resolvable=resolveurl.HostedMediaFile(url).valid_url()
    if resolvable:
        return url
    else:
        return False
        
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all

    all_links=[]
    headers = {
        
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:57.0) Gecko/20100101 Firefox/57.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }
    if tv_movie=='movie':
        imdbid_data=domain_s+'api.themoviedb.org/3/movie/%s?api_key=34142515d9d23817496eeb4ff1d223d0'%id
        
        x=requests.get(imdbid_data).json()
        imdbid=x['imdb_id']
    else:
       imdbid_data=domain_s+'api.themoviedb.org/3/tv/%s?api_key=34142515d9d23817496eeb4ff1d223d0&append_to_response=external_ids'%id
      
       x=requests.get(imdbid_data).json()
       imdbid=x['external_ids']['imdb_id']
    x=requests.get('http://qazwsxedcrfvtgb.info/show/%s?os=android&version=1.2.5'%imdbid,headers=headers).json()
    print x
    for items in x['episodes']:
        if stop_all==1:
                    break
        if tv_movie=='movie':
           
           
           for in_items in x['episodes'][items][0]['items']:
           
            for links in in_items['streams']:
                name1,match_s,res,check=server_data(links['stream'],original_title)
                
                if check and 'bobmovies' not in links['stream']:
                        f_link=check_lk(links['stream'])
                        if f_link:
                            all_links.append((name1,f_link,match_s,res))
                            global_var=all_links
        else:
       
           for in_items in x['episodes'][season][int(episode)-1]['items']:
            if stop_all==1:
                    break
            for links in in_items['streams']:
                if stop_all==1:
                    break
                if 'videospider' in links['stream']:
                        links_in=links['stream']
                        headers = {
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
                            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                            'Accept-Language': 'en-US,en;q=0.5',
                            'Referer': links['stream'],
                            'Connection': 'keep-alive',
                            'Upgrade-Insecure-Requests': '1',
                            'TE': 'Trailers',
                        }
                        parsed = urlparse.urlparse(links_in)
                        params = (
                            ('key', urlparse.parse_qs(parsed.query)['key']),
                            ('video_id', urlparse.parse_qs(parsed.query)['video_id']),
                        )
    
                        response = requests.get('https://videospider.in/getvideo', headers=headers, params=params)
                        
                        regex='<iframe src="(.+?)"'
                        match=re.compile(regex).findall(response.content)
                        
                        if len(match)==0:
                             f_url=response.url
                        else:
                             f_url=match[0]
                        name1,match_s,res,check=server_data(f_url,original_title)
                        if check :
                            f_link=check_lk(f_url)
                            if f_link:
                                all_links.append((name1,f_link,match_s,res))
                                global_var=all_links
                else:
                
                    name1,match_s,res,check=server_data(links['stream'],original_title)
                 
                    if check and 'bobmovies' not in links['stream']:
                            f_link=check_lk(links['stream'])
                            if f_link:
                                all_links.append((name1,f_link,match_s,res))
                                global_var=all_links
    return global_var
    