# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['tv','movie']

import urllib2,urllib,logging,base64,json
color=all_colors[47]

def resolve_movix(link):
         from base64 import b64decode
         retUrl=' '
         try:
           decoded_uri=link.split('link=')[1].decode('base64')
           x,cook=cloudflare.request(decoded_uri)

           regex='<IFRAME SRC="(.+?)"'
           match=re.compile(regex).findall(x)[0]
           
           return match
         except:
           pass
         
         html,cook = cloudflare.request(link)
       
         ysmm = re.findall(r"var ysmm =.*\;?", html)
         if len(ysmm)<3:
           decoded_uri=link.split('link=')[1].decode('base64')
    
        
         if len(ysmm) > 0:
            ysmm = re.sub(r'var ysmm \= \'|\'\;', '', ysmm[0])

            left = ''
            right = ''

            for c in [ysmm[i:i+2] for i in range(0, len(ysmm), 2)]:
                left += c[0]
                right = c[1] + right
            
            # Additional digit arithmetic 
            encoded_uri = list(left + right)
            numbers = ((i, n) for i, n in enumerate(encoded_uri) if str.isdigit(n))
            for first, second in zip(numbers, numbers):
                xor = int(first[1]) ^ int(second[1])
                if xor < 10:
                    encoded_uri[first[0]] = str(xor)

            decoded_uri = b64decode("".join(encoded_uri).encode())[16:-16].decode()

            if re.search(r'go\.php\?u\=', decoded_uri):
                decoded_uri = b64decode(re.sub(r'(.*?)u=', '', decoded_uri)).decode()
         
         x,cook=cloudflare.request(decoded_uri)

         regex='<IFRAME SRC="(.+?)"'
         match=re.compile(regex).findall(x)[0]

         return match
def get_arab(url):
    import unjuice
    from jsunpack import unpack
    headers = {
    'authority': 'arabramadan.com',
    'pragma': 'no-cache',
    'cache-control': 'no-cache',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.87 Safari/537.36',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
    'sec-fetch-site': 'cross-site',
    'sec-fetch-mode': 'nested-navigate',
    'referer': url,
    'accept-encoding': 'utf-8',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
    
    }

    response = requests.get(url, headers=headers).content
    regex='JuicyCodes\.Run\((.+?)\)'
    rr=re.compile(regex).findall(response)[0]
    regex='"(.+?)"'
    tt=re.compile(regex).findall(rr)
    all_d=[]
    for items in tt:
        
        all_d.append(items)
   
    juice = (''.join(all_d)).decode('base64')
    uk=unpack(juice)
  
    data = re.findall('sources:(\[\{.+?\}\])',uk, re.DOTALL)[0]
   
    try:
        data = json.loads(data)
    except:
        data=data.replace('src','"src"').replace('label','"label"')
        data = json.loads(data)
    data = [(i['src'], i['label']) for i in data if data]
    headers = {
    'authority': 'zeus.arabcdn.co',
    'pragma': 'no-cache',
    'cache-control': 'no-cache',
    'accept-encoding': 'identity;q=1, *;q=0',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.87 Safari/537.36',
    'accept': '*/*',
    'sec-fetch-site': 'cross-site',
    'sec-fetch-mode': 'no-cors',
    'referer': url,
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
    
    }
    head=urllib.urlencode(headers)
    return data,head
    
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
        global global_var,stop_all,progress
        progress='Start'
        start_time=time.time()
        all_links=[]
        search_string=domain_s+'www.mvs4u.co/?s='+clean_name(original_title,1).replace(' ','+')
        headers={  'Accept-Language':'en-US,en;q=0.5',
                    'Cache-Control':'no-cache',
                    'Connection':'keep-alive',
        
                    'Pragma':'no-cache',
                    'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0'}
        progress='Cloud'
        html,cook=cloudflare_request(search_string,headers=headers)
        regex_pre='<article>(.+?)</article>'
        progress='Regex'
        match_pre=re.compile(regex_pre,re.DOTALL).findall(html)
        count=0
        
        for items in match_pre:
            progress='Links-'+str(count)
            count+=1
            if stop_all==1:
                    break
            regex='<div class="title">.+?href="(.+?)">(.+?)</.+?"year">(.+?)<'
            progress='Regex-'+str(count)
            match=re.compile(regex,re.DOTALL).findall(items)
            for link,name,year in match:
              progress='Links2-'+str(count)
              if stop_all==1:
                    break
              if clean_name(original_title,1).lower()==name.lower() and year==show_original_year:
                progress='requests-'+str(count)
                x=requests.get(link,headers=cook[1],cookies=cook[0]).content
                
                if tv_movie=='tv':
                  regex="'numerando'>%s - %s</div>.+?href='(.+?)'>"%(season,episode)
                  progress='Regex2-'+str(count)
                  match_ep=re.compile(regex,re.DOTALL).findall(x)
                  progress='requests2-'+str(count)
                  x=requests.get(match_ep[0]+'?view=1',headers=cook[1],cookies=cook[0]).content
                regex="data-url='(.+?)'"
                progress='Regex3-'+str(count)
                match2=re.compile(regex).findall(x)
                regex='class="quality">(.+?)<'
                progress='Regex4-'+str(count)
                quality=re.compile(regex).findall(x)
               
                if len(quality)>0:
                  quality_f=quality[0]
                else:
                  quality_f=' '
             
                
                for links_item in match2:
                  if stop_all==1:
                    break
                  progress='Links2-'+str(count)
                  y=requests.get(links_item,headers=cook[1],cookies=cook[0]).content
                  if '"refresh" content="0; url=' in y:
                    regex_re='url=(.+?)"'
                    match_re=re.compile(regex_re).findall(y)
                    
                    y=requests.get(match_re[0],headers=cook[1],cookies=cook[0]).content
                  regex='<iframe .+? src="(.+?)"'
                  match3=re.compile(regex).findall(y)
                  if len(match3)>0:
                      regex='//(.+?)/'
                      match_s=re.compile(regex).findall(match3[0])
                      
                      if "1080" in quality_f:
                          res="1080"
                      elif "720" in quality_f:
                          res="720"
                      elif "480" in quality_f:
                          res="480"
                      elif "hd" in quality_f.lower():
                          res="HD"
                      else:
                         res=' '
                      if 'drive.google.com' in match3[0]:
                       
                        f_links=re.compile(domain_s+'drive.google.com/file/d/(.+?)/').findall(match3[0])[0]
             
                        f_link=domain_s+'drive.google.com/file/d/%s/view'%f_links
                       
                      else:
                        f_link=match3[0]
                      
                      if 'my.mail.ru' in f_link:
                            x=requests.get(f_link,headers=cook[1],cookies=cook[0]).content
                            regex='metadataUrl":"(.+?)"'
                            match=re.compile(regex).findall(x)
                            y=requests.get('http:'+match[0],headers=cook[1],cookies=cook[0]).json()
                            for items in y['videos']:
                              if 'http:' not in items['url']:
                                n_link='http:'+items['url']
                              else:
                                n_link=items['url']
                              all_links.append((original_title,n_link,'Direct',items['key']))
                              global_var=all_links
                      elif 'clipwatching.' in f_link:
                            x=requests.get(f_link,headers=cook[1],cookies=cook[0]).content
                            if 'File was deleted' in x:
                                continue
                            regex="<script type='text/javascript'>(.+?)</script>"
                            match=re.compile(regex,re.DOTALL).findall(x)
                            
                            from jsunpack import unpack
                            data=unpack(match[0])
                            data = re.findall('sources:(\[\{.+?\}\])',data, re.DOTALL)[0]
                           
                            try:
                                data = json.loads(data)
                            except:
                                data=data.replace('file','"file"').replace('label','"label"')
                                data = json.loads(data)
                            data = [(i['file'], i['label']) for i in data if data]
                            for end_url, rez in data:
                            
                              if 'http' not in end_url:
                                n_link='http:'+end_url
                              else:
                                n_link=end_url
                              all_links.append((original_title,n_link,'Direct',rez))
                              global_var=all_links
                      elif 'arabramadan' in f_link:
                        data,head=get_arab(f_link)
                        for end_url,res in data:
                            all_links.append((original_title,end_url+"|"+head,'Direct',res))
                            global_var=all_links
                      else:
                          progress='Check-'+str(count)
                          nam1,srv,res,check=server_data(f_link,original_title)
                         
                          if check:
                              all_links.append((nam1,f_link,srv,res))
                              global_var=all_links
        elapsed_time = time.time() - start_time
        progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
        return all_links
        