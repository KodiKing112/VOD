# -*- coding: utf-8 -*-
import requests,re
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,all_colors
type=['movie']

import urllib2,urllib,logging,base64,json,PTN
color=all_colors[23]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
        global global_var,stop_all
      
        title=original_title
       


        if tv_movie=='tv':
          link=domain_s+'flixanity.io/tv-show/%s/season/%s/episode/%s'%(title.lower().replace('%20','-').replace('%3a','').replace(' ','-'),season,episode)
          
          action='getEpisodeEmb'
        else:
          link=domain_s+'flixanity.io/movie/%s/'%title.lower().replace('%20','-').replace(' ','-')
          action='getMovieEmb'
      
        x=requests.get(link).content
        
        if "var tok    = '" not in x :
         
          if tv_movie=='tv':
            link=domain_s+'flixanity.io/tv-show/%s-%s/season/%s/episode/%s'%(title.lower().replace('%20','-').replace('%3a','').replace(' ','-'),show_original_year,season,episode)
            x=requests.get(link).content
          else:
            link=domain_s+'flixanity.io/movie/%s-%s/'%(title.lower().replace('%20','-').replace(' ','-'),show_original_year)
            x=requests.get(link).content
 
        token=re.findall("var tok    = '(.+?)'",x)[0]
        lid=re.findall('elid = "(.+?)"',x)[0]
        
        
        import base64
        elid = urllib.quote(base64.encodestring(str(int(time.time()))).strip())
 
        headers = {
            #'Host': 'flixanity.mobi',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'Accept-Language': 'en-US,en;q=0.5',
            'Referer': link,
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'Authorization': 'Bearer false',
            'X-Requested-With': 'XMLHttpRequest',
            'Connection': 'keep-alive',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
        }
        
        data = [
          ('action', action),
          ('idEl', lid),
          ('token', token),
          ('nopop', ''),
          ('elid',elid),
        ]
       
        response2 = requests.post('https://flixanity.io/ajax/gonlflhyad.php', headers=headers, data=data).json()
        print link

        all_links=[]
        
        for links in response2:
          if stop_all==1:
             break
          server=response2[links]['type']

          regex='SRC="(.+?)"'
          match=re.compile(regex,re.IGNORECASE).findall(response2[links]['embed'])
          
          src=match[0]
          
          if 'openload.co' in server or 'streamango' in server:
              yy=requests.get(src).content
              regex='og:title" content="(.+?)"'
              match_n=re.compile(regex).findall(yy)
              regex_l='//(.+?)/'
              match_l=re.compile(regex_l).findall(src)
              srv=match_l[0]
              if len(match_n)>0:
                  info=(PTN.parse(match_n[0]))
                  nam1=match_n[0].replace('%20',' ')
                  if 'resolution' in info:
                      res=info['resolution']
                  else:
                      res=' '
              else:
                 nam1=original_title.replace('%20',' ')
                 res=' '
          else:
            if '1080' in server:
              res='1080'
            elif '720' in server:
              res='720'
            elif '480' in server:
              res='480'
            elif '360' in server:
              res='360'
            else:
              res='1080'
            nam1=original_title.replace('%20',' ')
            srv=server
          all_links.append((nam1,src,srv,res))
          global_var=all_links
        return global_var