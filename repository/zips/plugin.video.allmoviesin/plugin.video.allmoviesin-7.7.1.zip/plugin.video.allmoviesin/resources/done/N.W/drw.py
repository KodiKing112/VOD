import requests,re
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,all_colors
type=['movie','tv']

import urllib2,urllib,logging,base64,json
color=all_colors[85]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    all_links=[]
    import cfscrape
    scraper = cfscrape.create_scraper()
    base_link = 'http://www.ondarewatch.com/'
    search_url = base_link + 'index.php'
    search_id = clean_name(original_title.lower(),1)
    

    
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0',
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Accept-Language': 'en-US,en;q=0.5',
    'Referer': 'http://www.dailytvfix.com/search',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'X-Requested-With': 'XMLHttpRequest',
    'Connection': 'keep-alive',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    }

    data = [
      ('q', search_id),
      ('limit', '15'),
      ('timestamp', int(time.time())),
      ('verifiedCheck', ''),
    ]

    response = scraper.post('http://www.dailytvfix.com/ajax/search.php', headers=headers, data=data).json()
   

  
    for resolts in response:
        if stop_all==1:
            break

        if not clean_name(original_title,1).lower() in clean_name(resolts['title'],1).lower():
            continue
        if not show_original_year in resolts['permalink'] and tv_movie=='movie':
            continue
     
        link='http://www.dailytvfix.com'+resolts['permalink']
        if tv_movie=='tv':
           link=link+'/season/%s/episode/%s'%(season,episode)

        x=scraper.get(link,headers=headers).content
        
        match = re.compile("] = '(.+?)'",re.DOTALL).findall(x)
            
        for vid in match:
            if stop_all==1:
               break
            
            host = base64.b64decode(vid)
           
            link=re.compile('.+?="(.+?)"',re.DOTALL).findall(host)[0]
         
            if 'vev.io' not in link and 'vidzi.tv' not in link:
                name2,match_s,res,check=server_data(link,original_title)
            else:
               check=False
         
            if check :
                all_links.append((name2,link,match_s,res))
                        
                global_var=all_links
    return global_var