# -*- coding: utf-8 -*-
import logging

import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,sys,time,random
from os import listdir
from os.path import isfile, join
Addon = xbmcaddon.Addon()
import pyxbmct
import requests,json
import xbmcvfs

import socket
import  threading



global done_nextup
global all_data_imdb
global susb_data,susb_data_next
global all_s_in
global stop_window,once_fast_play
global stop_try_play,global_result
global playing_text,mag_start_time_new
global now_playing_server,stop_all,close_on_error
global stoped_play_once
global all_ok,all_broken
global string_dp
global what_to_start,done_what,whats_done
whats_done=0
what_to_start={}
done_what=0
string_dp=''
all_ok=[]
all_broken=[]
stoped_play_once=0
close_on_error=0
once_fast_play=0
global done1,done1_1,close_sources_now,done_c_get,stop_auto_play
stop_auto_play=0
done_c_get=0
close_sources_now=0
done1_1=0
done1=0
stop_all=0



logging.warning('Start')
now_playing_server=''
mag_start_time_new=0
global_result=''
playing_text=''
stop_try_play=False
stop_window=False
all_s_in=({},0,'','','')
all_data_imdb=[]
done_nextup=0
addonPath = xbmc.translatePath(Addon.getAddonInfo("path")).decode("utf-8")
libDir = os.path.join(addonPath, 'resources', 'lib')
sys.path.append( libDir)
libDir = os.path.join(addonPath, 'resources', 'lib2')
sys.path.append( libDir)
libDir = os.path.join(addonPath, 'resources', 'plugins')
sys.path.append( libDir)
libDir = os.path.join(addonPath, 'resources', 'solvers')
sys.path.append( libDir)
libDir = os.path.join(addonPath, 'resources', 'solvers','resolver')

sys.path.append( libDir)
libDir = os.path.join(addonPath, 'resources', 'solvers','torrentool')

sys.path.append( libDir)

done_dir = os.path.join(addonPath, 'resources', 'done')
sys.path.append( done_dir)

sys.path.append( libDir)
rd_dir = os.path.join(addonPath, 'resources', 'done','rd')
sys.path.append( rd_dir)

mag_dir = os.path.join(addonPath, 'resources', 'done','magnet')
sys.path.append( mag_dir)

libDir = os.path.join(addonPath, 'resources', 'scrapers')
sys.path.append( libDir)

m3_dir = os.path.join(addonPath, 'resources', 'm3u8')


BASE_LOGO=os.path.join(addonPath, 'resources', 'logos/')
tmdb_data_dir = os.path.join(addonPath, 'resources', 'tmdb_data')
debug_mode=False
if Addon.getSetting("debugmode")=='true':
  debug_mode=True



try:
    from urllib.parse import quote_from_bytes as orig_quote
except ImportError:
    from urllib import quote as orig_quote

from pen_addons import download_file,unzip,gdecom

res_table=['2160','1080','720','480','360']
red_key='ssgx54x49bkv2xk7mkghksfz'

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,fix_q,call_trakt,post_trakt,reset_trakt,cloudflare_request,base_header

import cache as  cache
import PTN as PTN

__PLUGIN_PATH__ = Addon.getAddonInfo('path')

from globals import *
from tmdb import *
from addall import addNolink,addDir3,addLink


socket.setdefaulttimeout(40.0)
logging.warning('stdb')
try:
    dbcur.execute("SELECT * FROM playback")
    dbcon.commit()
except:
  try:
    logging.warning('Crating DB')
    dbpath= xbmc.translatePath(os.path.join(Addon.getAddonInfo('profile'), 'storage.db'))
    logging.warning(dbpath)
    dbcon_old = database.connect(dbpath)
    dbcur_old = dbcon_old.cursor()
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT, ""tmdb TEXT, ""season TEXT, ""episode TEXT,""playtime TEXT,""total TEXT, ""free TEXT);" % 'playback')
    dbcur_old.execute("SELECT * FROM WatchStatus")
    match = dbcur_old.fetchall()
    logging.warning('Mathcold:'+str(len(match)))
    
    for title,season,episode,episode_d,playcm,times,duration,watched,ids in match:
        logging.warning(title)
        if times!=None:
            dbcur.execute("INSERT INTO playback Values ('%s','%s','%s','%s','%s','%s','%s');" %  ('oldtitle',title,season,episode,times,str(duration),''))
    dbcon.commit()
    try:
        dbcon_old.close()
        dbcur_old.close()
    except:
        pass
  except Exception as e:
    import linecache
    exc_type, exc_obj, tb = sys.exc_info()
    f = tb.tb_frame
    lineno = tb.tb_lineno
    filename = f.f_code.co_filename
    linecache.checkcache(filename)
    line = linecache.getline(filename, lineno, f.f_globals)

    logging.warning('ERROR IN DP:'+str(lineno)+str(e))
    logging.warning('inline:'+line)
logging.warning('estdb')
global imdb_global,search_done,silent_mode,close_all,list_index
search_done=0

list_index=999
silent_mode=False

#reload(sys)  
#sys.setdefaultencoding('utf8')

if debug_mode==False:
  reload(sys)  
  sys.setdefaultencoding('utf8')
 
imdb_global=' '


rd_sources=Addon.getSetting("rdsource")
allow_debrid = rd_sources == "true" 
ACTION_PREVIOUS_MENU 			=  10	## ESC action
ACTION_NAV_BACK 				=  92	## Backspace action
ACTION_MOVE_LEFT				=   1	## Left arrow key
ACTION_MOVE_RIGHT 				=   2	## Right arrow key
ACTION_MOVE_UP 					=   3	## Up arrow key
ACTION_MOVE_DOWN 				=   4	## Down arrow key
ACTION_MOUSE_WHEEL_UP 			= 104	## Mouse wheel up
ACTION_MOUSE_WHEEL_DOWN			= 105	## Mouse wheel down
ACTION_MOVE_MOUSE 				= 107	## Down arrow key
ACTION_SELECT_ITEM				=   7	## Number Pad Enter
ACTION_BACKSPACE				= 110	## ?
ACTION_MOUSE_LEFT_CLICK 		= 100
ACTION_MOUSE_LONG_CLICK 		= 108
def TrkBox_help(title, msg,img2="https://user-images.githubusercontent.com/19761269/63175338-6af03a80-c061-11e9-9ff3-009778fa0a9c.png"):
    class TextBoxes1(xbmcgui.WindowXMLDialog):
        def onInit(self):
            
            self.title      = 101
            self.msg        = 102
            self.scrollbar  = 103
            self.okbutton   = 201
            
            self.imagecontrol=202
            self.sync   = 203
            self.y=0
            self.showdialog()
            self.params=False
            
        def showdialog(self):
            import random
            self.getControl(self.title).setLabel(title)
            self.getControl(self.msg).setText(msg)
            self.getControl(self.imagecontrol).setImage(img2)
            self.setFocusId(self.scrollbar)
            
            xbmc.executebuiltin("Dialog.Close(busydialog)")
        def onClick(self, controlId):
            if (controlId == self.okbutton):
               
                self.close()
            if (controlId == self.sync):
                self.params=True
                self.close()
        def onAction(self, action):
            if   action == ACTION_PREVIOUS_MENU: 
               
                self.close()
            elif action == ACTION_NAV_BACK: 
                    
                    self.close()
            
            
    tb = TextBoxes1( "Trktbox.xml" , Addon.getAddonInfo('path'), 'DefaultSkin', title=title, msg=msg)
    tb.doModal()
    pr=tb.params
    del tb
    return pr
ACTION_PLAYER_STOP = 13
class UpNext(xbmcgui.WindowXMLDialog):
    item = None
    cancel = False
    watchnow = False
    
    progressStepSize = 0
    currentProgressPercent = 100

    def __init__(self, *args, **kwargs):
        logging.warning('INIT UPNEXT')
        from platform import machine
        OS_MACHINE = machine()
        self.closenow=0
        
        self.action_exitkeys_id = [10, 13]
        logging.warning('INIT UPNEXT0')
        self.progressControl = None
        if OS_MACHINE[0:5] == 'armv7':
            xbmcgui.WindowXMLDialog.__init__(self)
        else:
            xbmcgui.WindowXMLDialog.__init__(self, *args, **kwargs)
        logging.warning('INIT UPNEXT2')
        
   
    def background_task(self):
        global list_index
        t=int(self.time_c)*10
        counter_close=0
        self.progressControl = self.getControl(3014)
        e_close=0
        before_end=int(Addon.getSetting("before_end2"))*10
        counter_close2=before_end
        while(t>30):
            self.label=self.getControl(3015)
            self.label.setLabel(('פרק הבא בעוד %s שניות')%str(int(counter_close2)/10))
            
            counter_close2-=1
            if counter_close2==0:
                t=0
                break
            self.currentProgressPercent=int((counter_close2*100)/before_end)
       
            self.progressControl.setPercent(self.currentProgressPercent)
            xbmc.sleep(100)
            t-=1
            if self.closenow==1:
                break
        if self.closenow==0:
            list_index=self.list.getSelectedPosition()        
        self.close()
    def onInit(self):
        self.time_c=0
        try:
            self.time_c=xbmc.Player().getTotalTime()-xbmc.Player().getTime()
        except:
            self.time_c=30
        
        
            
        self.list = self.getControl(3000)
        self.but = self.getControl(3012)
        for it in self.item['list']:
         
          
          liz   = xbmcgui.ListItem(it.split('$$$$$$$')[0])
          self.list.addItem(liz)
       
        
        self.setFocus(self.but)
        logging.warning('INIT UPNEXT1')
        Thread(target=self.background_task).start()
        self.setInfo()
        self.prepareProgressControl()

    def setInfo(self):
        logging.warning('INIT UPNEXT2')
       
        episodeInfo = str(self.item['season']) + 'x' + str(self.item['episode']) + '.'
        if self.item['rating'] is not None:
            rating = str(round(float(self.item['rating']), 1))
        else:
            rating = None

        if self.item is not None:
            self.setProperty(
                'fanart', self.item['art'].get('tvshow.fanart', ''))
            self.setProperty(
                'landscape', self.item['art'].get('tvshow.landscape', ''))
            self.setProperty(
                'clearart', self.item['art'].get('tvshow.clearart', ''))
            self.setProperty(
                'clearlogo', self.item['art'].get('tvshow.clearlogo', ''))
            self.setProperty(
                'poster', self.item['art'].get('tvshow.poster', ''))
            self.setProperty(
                'thumb', self.item['art'].get('thumb', ''))
            self.setProperty(
                'plot', self.item['plot'])
            self.setProperty(
                'tvshowtitle', self.item['showtitle'])
            self.setProperty(
                'title', self.item['title'])
            self.setProperty(
                'season', str(self.item['season']))
            self.setProperty(
                'episode', str(self.item['episode']))
            self.setProperty(
                'seasonepisode', episodeInfo)
            self.setProperty(
                'year', str(self.item['firstaired']))
            self.setProperty(
                'rating', rating)
            self.setProperty(
                'playcount', str(self.item['playcount']))

    def prepareProgressControl(self):
        logging.warning('INIT UPNEXT3')
        # noinspection PyBroadException
        try:
            self.progressControl = self.getControl(3014)
            if self.progressControl is not None:
                self.progressControl.setPercent(self.currentProgressPercent)
        except Exception:
            pass

    def setItem(self, item):
        self.item = item

    def setProgressStepSize(self, progressStepSize):
        self.progressStepSize = progressStepSize

    def updateProgressControl(self):
        # noinspection PyBroadException
        try:
            self.currentProgressPercent = self.currentProgressPercent - self.progressStepSize
         
            self.progressControl = self.getControl(3014)
           
            if self.progressControl is not None:
                self.progressControl.setPercent(self.currentProgressPercent)
        except Exception:
            pass

    def setCancel(self, cancel):
        self.cancel = cancel

    def isCancel(self):
        return self.cancel

    def setWatchNow(self, watchnow):
        self.watchnow = watchnow

    def isWatchNow(self):
        return self.watchnow

    def onFocus(self, controlId):
        pass

    def doAction(self):
        pass

    def closeDialog(self):
        self.close()

    def onClick(self, control_id):
        global list_index
        
        if control_id == 3012:
            # watch now
            list_index=0
            self.setWatchNow(True)
            self.closenow=1
            self.close()
            
        elif control_id == 3013:
            # cancel
            list_index=888
            self.setCancel(True)
            self.closenow=1
            self.close()
        elif control_id == 3000:
            index = self.list.getSelectedPosition()        
            list_index=index
            self.closenow=1
            self.close()
        pass

    def onAction(self, action):
        
        if action == ACTION_PLAYER_STOP:
            self.closenow=1
            self.close()

def TextBox_help(title, msg,img2="https://imgc.allpostersimages.com/img/print/posters/queen-rock-group-freddie-mercury-queen-in-concert-at-wembley-stadium-london_a-G-3717628-4990875.jpg"):
    class TextBoxes(xbmcgui.WindowXMLDialog):
        def onInit(self):
            
            self.title      = 101
            self.msg        = 102
            self.scrollbar  = 103
            self.okbutton   = 201
            self.imagecontrol=202
            self.y=0
            self.showdialog()

        def showdialog(self):
            import random
            self.getControl(self.title).setLabel(title)
            self.getControl(self.msg).setText(msg)
            self.getControl(self.imagecontrol).setImage(img2)
            self.setFocusId(self.scrollbar)
            all_op=['fJ9rUzIMcZQ','HgzGwKwLmgM','RNoPdAq666g','9f06QZCVUHg','s6TtwR2Dbjg','yt7tUJIK9FU','NJsa6-y4sDs','Nq8TasNsgKw','0pibtxAO00I','jkPl0e8DlKc','WQnAxOQxQIU']
            random.shuffle(all_op)
            from youtube_ext import get_youtube_link2
            if all_op[0]!=None:
              try:
                f_play= get_youtube_link2('https://www.youtube.com/watch?v='+all_op[0]).replace(' ','%20')
                xbmc.Player().play(f_play,windowed=True)
            
              except Exception as e:
                    pass
            xbmc.executebuiltin("Dialog.Close(busydialog)")
        def onClick(self, controlId):
            if (controlId == self.okbutton):
                xbmc.Player().stop()
                self.close()
        
        def onAction(self, action):
            if   action == ACTION_PREVIOUS_MENU: 
                xbmc.Player().stop()
                self.close()
            elif action == ACTION_NAV_BACK: 
                    xbmc.Player().stop()
                    self.close()
            
            
    tb = TextBoxes( "Textbox.xml" , Addon.getAddonInfo('path'), 'DefaultSkin', title=title, msg=msg)
    tb.doModal()
    del tb
    
# You can add \n to do line breaks
CONTACT        = 'מה המצב'
#Images used for the contact window.  http:// for default icon and fanart
CONTACTICON    = 'https://i.redd.it/vy5sp4xvhfe01.png'
CONTACTFANART  = 'http://'
ADDONTITLE     = 'Victory' 
COLOR1         = 'gold'
COLOR2         = 'white'
COLOR3         = 'red'
COLOR3         = 'blue'
# Primary menu items   / %s is the menu item and is required
THEME1         = '[COLOR '+COLOR2+']%s[/COLOR]'
# Build Names          / %s is the menu item and is required
THEME2         = '[COLOR '+COLOR2+']%s[/COLOR]'
# Alternate items      / %s is the menu item and is required
THEME3         = '[COLOR '+COLOR1+']%s[/COLOR]'
# Current Build Header / %s is the menu item and is required 
THEME4         = '[COLOR '+COLOR1+']%s[/COLOR] [COLOR '+COLOR2+']גירסת בילד:[/COLOR]'
# Current Theme Header / %s is the menu item and is required
THEME5         = '[COLOR '+COLOR1+']Current Theme:[/COLOR] [COLOR '+COLOR2+']%s[/COLOR]'
ACTION_PREVIOUS_MENU = 10
ACTION_SELECT_ITEM = 7
ACTION_MOVE_UP = 3
ACTION_MOVE_DOWN = 4
ACTION_STEP_BACK = 21
ACTION_NAV_BACK = 92
ACTION_MOUSE_RIGHT_CLICK = 101
ACTION_MOUSE_MOVE = 107
ACTION_BACKSPACE = 110
KEY_BUTTON_BACK = 275 
def get_new_error():
        import glob,xbmc,logging
        folder = xbmc.translatePath('special://logpath')
        logSelect=[]
        nameSelect=[]
        for file in glob.glob(folder+'/*.log'):
            try:nameSelect.append(file.rsplit('\\', 1)[1].upper())
            except:nameSelect.append(file.rsplit('/', 1)[1].upper())
            logSelect.append(file)
        file = open(logSelect[0], 'r') 
        home1=xbmc.translatePath("special://home/")
        home2=xbmc.translatePath("special://home/").replace('\\','\\\\')
        home3=xbmc.translatePath("special://xbmc/")
        home4=xbmc.translatePath("special://xbmc/").replace('\\','\\\\')
        home5=xbmc.translatePath("special://masterprofile/")
        home6=xbmc.translatePath("special://masterprofile/").replace('\\','\\\\')
        home7=xbmc.translatePath("special://profile/")
        home8=xbmc.translatePath("special://profile/").replace('\\','\\\\')
        home9=xbmc.translatePath("special://temp/")
        home10=xbmc.translatePath("special://temp/").replace('\\','\\\\')
        file_data=file.read().replace(home1,'').replace(home2,'').replace(home3,'').replace(home4,'').replace(home5,'').replace(home6,'').replace(home7,'').replace(home8,'').replace(home9,'').replace(home10,'')
        match=re.compile('Error Type:(.+?)-->End of Python script error report<--',re.DOTALL).findall(file_data)
        match2=re.compile('CAddonInstallJob(.+?)$', re.M).findall(file_data)
        match3=re.compile('ERROR: WARNING:root:(.+?)$', re.M).findall(file_data)
        x=0
        y=0
        z=0
        n=0
        line_numbers=[]
        file = open(logSelect[0], 'r') 
        file_data=file.readlines() 
        match_final=[]

        for  line in (file_data):
         
         if 'Error Type:' in line:
          match_final.append(match[x])
          x=x+1
          line_numbers.append(n)
         elif 'CAddonInstallJob' in line:
          match_final.append(match2[y])
          y=y+1
         '''
         elif 'ERROR: WARNING:root:' in line:
          logging.warning(z)
          match_final.append(match3[z])
          z=z+1
         '''

        for items in match_final:
            text_lines=items.splitlines()
            txt_all=''

            for line in text_lines:
                text_new1=line.strip()
                if ':' in text_new1:
                 y=0
                 text_new2=''
                 for value in text_new1.split(':'):

                   if y==0:
                     text_new2=text_new2+'[COLOR aqua]'+value+'[/COLOR]'
                   else:
                     text_new2=text_new2+value
                   y=y+1
                 text_new=text_new2
                else:
                 text_new=line
                txt_all=txt_all+text_new+'\n'
  
        return txt_all
#get_new_error()
def contact(title='',msg=""):
	class MyWindow(xbmcgui.WindowXMLDialog):
		def __init__(self, *args, **kwargs):
			self.title = THEME3 % kwargs["title"]
			self.image = kwargs["image"]
			self.fanart = kwargs["fanart"]
			self.msg = THEME2 % kwargs["msg"]

		def onInit(self):
			self.fanartimage = 101
			self.titlebox = 102
			self.imagecontrol = 103
			self.textbox = 104
			self.scrollcontrol = 105
			self.button = 199
			self.showdialog()

		def showdialog(self):
			self.getControl(self.imagecontrol).setImage(self.image)
			self.getControl(self.fanartimage).setImage(self.fanart)
			self.getControl(self.fanartimage).setColorDiffuse('9FFFFFFF')
			self.getControl(self.textbox).setText(self.msg)
			self.getControl(self.titlebox).setLabel(self.title)
            
	
		
            
			self.setFocusId(self.button)
			
		def onAction(self,action):
			if   action == ACTION_PREVIOUS_MENU: self.close()
			elif action == ACTION_NAV_BACK: self.close()

	cw = MyWindow( "Contact.xml" , Addon.getAddonInfo('path'), 'DefaultSkin', title=title, fanart=CONTACTFANART, image=CONTACTICON, msg=msg)
	cw.doModal()
	del cw
FILENAME='contextmenu.xml'
ACTION_BACK          = 92
ACTION_PARENT_DIR    = 9
ACTION_PREVIOUS_MENU = 10
ACTION_CONTEXT_MENU  = 117
ACTION_C_KEY         = 122

ACTION_LEFT  = 1
ACTION_RIGHT = 2
ACTION_UP    = 3
ACTION_DOWN  = 4

class ContextMenu(xbmcgui.WindowXMLDialog):

    def __new__(cls, addonID, menu,icon,fan,txt):
        FILENAME='contextmenu.xml'
        return super(ContextMenu, cls).__new__(cls, FILENAME,Addon.getAddonInfo('path'), 'DefaultSkin')
        

    def __init__(self, addonID, menu,icon,fan,txt):
        super(ContextMenu, self).__init__()
        self.menu = menu
        self.imagecontrol=101
        self.bimagecontrol=5001
        self.txtcontrol=2
        self.icon=icon
        self.fan=fan
        self.text=txt
    def onInit(self):
        line   = 38
        spacer = 20
        delta  = 0 

        nItem = len(self.menu)
        if nItem > 16:
            nItem = 16
            delta = 1
        self.getControl(self.imagecontrol).setImage(self.icon)
        self.getControl(self.bimagecontrol).setImage(self.fan)
        self.getControl(self.txtcontrol).setText(self.text)
        height = (line+spacer) + (nItem*line)
        height=1100
        self.getControl(5001).setHeight(height)
            
        self.list = self.getControl(3000)
        self.list.setHeight(height)

        newY = 360 - (height/2)

        self.getControl(5000).setPosition(self.getControl(5000).getX(), 0)

        self.params    = None
        self.paramList = []
        #txt='[COLOR deepskyblue]'+name.replace('-',' ').replace('%20',' ').strip()+'[/COLOR]\nServer: '+server+' Subs: '+str(pre_n)+'  Quality:[COLOR gold] ◄'+q+'► [/COLOR]Provider: [COLOR lightblue]'+supplay+'[/COLOR] Size:[COLOR coral]'+size+'[/COLOR]$$$$$$$'+link
        #import textwrap
        for item in self.menu:
            self.paramList.append(item[6])
            
            if len(item[0])>60:
            #    item[0]="\n".join(textwrap.wrap(item[0],60))
                 item[0]=item[0][0:60]+'\n'+item[0][60:len(item[0])]
            add_rd=''
            
         
            if item[7]:
                add_rd='[COLOR gold]RD- [/COLOR]'
            title =add_rd+'[COLOR deepskyblue][B]'+item[0] +'[/B][/COLOR]'
            if len(item[1].strip())<2:
                item[1]='--'
            if len(item[2].strip())<2:
                item[2]='--'
            if len(item[3].strip())<2:
                item[3]='--'
            if len(item[4])<2:
                item[4]='--'
            if len(item[5])<2:
                item[5]='--'
            server=item[1]
            pre_n='[COLOR khaki]'+item[2]+'[/COLOR]'
            q=item[3]
            supplay='[COLOR lightblue]'+item[4]+'[/COLOR]'
            size='[COLOR coral]'+item[5]+'[/COLOR]'
            link=item[6]
            
            
            liz   = xbmcgui.ListItem(title)
            liz.setProperty('server', server)
            liz.setProperty('pre',pre_n)
            liz.setProperty('Quality', q)
            liz.setProperty('supply', supplay)
            liz.setProperty('size', size)
            
            self.list.addItem(liz)

        self.setFocus(self.list)

           
    def onAction(self, action):  
        actionId = action.getId()

        if actionId in [ACTION_CONTEXT_MENU, ACTION_C_KEY]:
            self.params = 888
            xbmc.sleep(100)
            return self.close()

        if actionId in [ACTION_PARENT_DIR, ACTION_PREVIOUS_MENU, ACTION_BACK]:
            self.params = 888
            return self.close()


    def onClick(self, controlId):
        if controlId != 3001:
            index = self.list.getSelectedPosition()        
            try:    self.params = index
            except: self.params = None

        self.close()
        

    def onFocus(self, controlId):
        pass
#from youtube_ext import get_youtube_link4

#logging.warning( get_youtube_link4('YhWoOI8MaME'))
def get_trailer_site(id):
    all_t=[]
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:67.0) Gecko/20100101 Firefox/67.0',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.5',
        'Referer': 'https://www.themoviedb.org/movie/'+id,
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }

    params = (
        ('translate', 'false'),
        ('language', 'he-IL'),
    )

    response = requests.get('https://www.themoviedb.org/movie/%s/remote/media_panel/videos'%id, headers=headers, params=params).content
    regex='play_trailer" href="/video/play\?key=(.+?)"'
    video_ids=re.compile(regex).findall(response)
    for v_id in video_ids:
        all_t.append(v_id)
    if len(all_t)>0:
        vid_num=random.randint(0,len(all_t)-1)
        logging.warning('Alternate Trailer')
        return all_t[vid_num]
    else:
      return 0
    
def get_trailer_f(id,tv_movie):
    import random
    try:
        html_t='99'
        logging.warning('Get Trailer')
        if tv_movie=='movie':
          url_t='http://api.themoviedb.org/3/movie/%s/videos?api_key=34142515d9d23817496eeb4ff1d223d0&language=heb'%id
        else:
          url_t='http://api.themoviedb.org/3/tv/%s/videos?api_key=34142515d9d23817496eeb4ff1d223d0&language=heb'%id
        html_t=requests.get(url_t).json()
        
        if 'results' not in html_t:
            video_id=get_trailer_site(id)
        else:
            if len(html_t['results'])==0:
                if tv_movie=='movie':
                  url_t='http://api.themoviedb.org/3/movie/%s/videos?api_key=34142515d9d23817496eeb4ff1d223d0'%id
                else:
                  url_t='http://api.themoviedb.org/3/tv/%s/videos?api_key=34142515d9d23817496eeb4ff1d223d0'%id
                html_t=requests.get(url_t).json()
            
            if len(html_t['results'])>0:
                vid_num=random.randint(0,len(html_t['results'])-1)
            else:
              return 0
            video_id=(html_t['results'][vid_num]['key'])
            #from pytube import YouTube
            #playback_url = YouTube(domain_s+'www.youtube.com/watch?v='+video_id).streams.first().download()
        playback_url = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % video_id
        from youtube_ext import get_youtube_link4
        if video_id!=None:
            
          try:
            return get_youtube_link4(video_id).replace(' ','%20')
          except Exception as e:
            logging.warning(e)
            return ''
        else:
            return ''
        return playback_url
    except Exception as e:
        import linecache
        exc_type, exc_obj, tb = sys.exc_info()
        f = tb.tb_frame
        lineno = tb.tb_lineno
        filename = f.f_code.co_filename
        linecache.checkcache(filename)
        line = linecache.getline(filename, lineno, f.f_globals)
        xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'No Trailer...Line:'+str(lineno)+' E:'+str(e))).encode('utf-8'))
        logging.warning('ERROR IN Trailer play:'+str(lineno))
        logging.warning('inline:'+line)
        logging.warning(e)
        logging.warning(html_t)
        logging.warning('BAD Trailer play')
        return ''
class ContextMenu_new(xbmcgui.WindowXMLDialog):
    
    def __new__(cls, addonID, menu,icon,fan,txt):
        FILENAME='contextmenu_new.xml'
        return super(ContextMenu_new, cls).__new__(cls, FILENAME,Addon.getAddonInfo('path'), 'DefaultSkin')
        

    def __init__(self, addonID, menu,icon,fan,txt):
        super(ContextMenu_new, self).__init__()
        self.menu = menu
        self.imagecontrol=101
        self.bimagecontrol=5001
        self.txtcontrol=2
        self.icon=icon
        self.fan=fan
        self.text=txt
    
    def onInit(self):
        line   = 38
        spacer = 20
        delta  = 0 

        nItem = len(self.menu)
        if nItem > 16:
            nItem = 16
            delta = 1
        self.getControl(self.imagecontrol).setImage(self.icon)
        self.getControl(self.bimagecontrol).setImage(self.fan)
        self.getControl(self.txtcontrol).setText(self.text)
        height = (line+spacer) + (nItem*line)
        height=1100
        self.getControl(5001).setHeight(height)
            
        self.list = self.getControl(3000)
        self.list.setHeight(height)

        newY = 360 - (height/2)

        self.getControl(5000).setPosition(self.getControl(5000).getX(), 0)
        
       
        
        self.params    = None
        self.paramList = []
        #txt='[COLOR deepskyblue]'+name.replace('-',' ').replace('%20',' ').strip()+'[/COLOR]\nServer: '+server+' Subs: '+str(pre_n)+'  Quality:[COLOR gold] ◄'+q+'► [/COLOR]Provider: [COLOR lightblue]'+supplay+'[/COLOR] Size:[COLOR coral]'+size+'[/COLOR]$$$$$$$'+link
        #import textwrap
        for item in self.menu:
            self.paramList.append(item[6])
            '''
            info=(PTN.parse(item[0]))
            if 'excess' in info:
                if len(info['excess'])>0:
                    item[0]='.'.join(info['excess'])
            '''
            
                
            if len(item[0])>45 and '►►►' not in item[0]:
            #    item[0]="\n".join(textwrap.wrap(item[0],60))
                 item[0]=item[0][0:45]+'\n'+item[0][45:len(item[0])]
            title ='[COLOR deepskyblue][B]'+item[0] +'[/B][/COLOR]'
            if len(item[1].strip())<2:
                item[1]='--'
            if len(item[2].strip())<2:
                item[2]='--'
            if len(item[3].strip())<2:
                item[3]='--'
            if len(item[4])<2:
                item[4]='--'
            if len(item[5])<2:
                item[5]='--'
            server=item[1]
            pre_n='[COLOR khaki]'+item[2]+'[/COLOR]'
            q=item[3]
            supplay='[COLOR lightblue]'+item[4]+'[/COLOR]'
            size='[COLOR coral]'+item[5]+'[/COLOR]'
            link=item[6]
            
            if item[7]==True or ('magnet' in server and allow_debrid):
                supplay='[COLOR yellow][I]RD - '+supplay+'[/I][/COLOR]'
          
            if '►►►' in item[0]:
                
                title=''
                supplay=item[0]
           
            
                
            liz   = xbmcgui.ListItem(title)
            liz.setProperty('server', server)
            liz.setProperty('pre',pre_n)
            liz.setProperty('Quality', q)
            liz.setProperty('supply', supplay)
            liz.setProperty('size', size)
            
            if '►►►' not in item[0]:
                liz.setProperty('server_v','100')
            if item[7]==True or ('magnet' in server and allow_debrid):
                liz.setProperty('rd', '100')
            if 'magnet' in server:
                liz.setProperty('magnet', '100')
            self.list.addItem(liz)

        self.setFocus(self.list)

           
    def onAction(self, action):  
        actionId = action.getId()

        if actionId in [ACTION_CONTEXT_MENU, ACTION_C_KEY]:
            self.params = 888
            xbmc.sleep(100)
            return self.close()

        if actionId in [ACTION_PARENT_DIR, ACTION_PREVIOUS_MENU, ACTION_BACK]:
            self.params = 888
            return self.close()


    def onClick(self, controlId):
        if controlId != 3001:
            index = self.list.getSelectedPosition()        
            try:    self.params = index
            except: self.params = None
        else:
            self.params = 888
        self.close()
        

    def onFocus(self, controlId):
        pass
class ContextMenu_new2(xbmcgui.WindowXMLDialog):
    
    def __new__(cls, addonID, menu,icon,fan,txt):
        FILENAME='contextmenu_new2.xml'
        if Addon.getSetting("new_window_type2")=='4':
            FILENAME='contextmenu_new3.xml'
        return super(ContextMenu_new2, cls).__new__(cls, FILENAME,Addon.getAddonInfo('path'), 'DefaultSkin')
        

    def __init__(self, addonID, menu,icon,fan,txt):
        global playing_text
        super(ContextMenu_new2, self).__init__()
        self.menu = menu
        self.auto_play=0
        self.params    = 666666
        self.imagecontrol=101
        self.bimagecontrol=5001
        self.txtcontrol=2
        self.tick_label=6001
        self.icon=icon
        self.fan=fan
        self.text=txt
        playing_text=''
        self.tick=60
        self.done=0
        self.story_gone=0
        self.count_p=0
        self.keep_play=''
        self.tick=60
        self.s_t_point=0
        self.start_time=time.time()
    def background_work(self):
        global playing_text,mag_start_time_new,now_playing_server,done1_1
        tick=0
        tick2=0
        changed=1
        vidtime=0
        while(1):
            
            all_t=[]
            for thread in threading.enumerate():
                if ('tick_time' in thread.getName()) or ('background_task' in thread.getName()) or ('get_similer' in thread.getName()) or ('MainThread' in thread.getName()) or ('sources_s' in thread.getName()):
                    continue
                
                if (thread.isAlive()):
                    all_t.append( thread.getName())
            self.getControl(606).setLabel(','.join(all_t))
            if  xbmc.getCondVisibility('Window.IsActive(busydialog)'):
                self.getControl(102).setVisible(True)
                if tick2==1:
                    self.getControl(505).setVisible(True)
                    tick2=0
                else:
                    self.getControl(505).setVisible(False)
                    tick2=1
            else:
                self.getControl(102).setVisible(False)
                self.getControl(505).setVisible(False)
            if len(playing_text)>0 or  self.story_gone==1 :
                changed=1
                vidtime=0
                if xbmc.Player().isPlaying():
                    vidtime = xbmc.Player().getTime()
                
                t=time.strftime("%H:%M:%S", time.gmtime(vidtime))
                
                if len(playing_text)==0:
                    playing_text=self.keep_play
                try:
                    self.keep_play=playing_text
                    self.getControl(self.txtcontrol).setText(t+'\n'+playing_text.split('$$$$')[0]+'\n'+now_playing_server.split('$$$$')[0]+'\n'+now_playing_server.split('$$$$')[1])
                    if vidtime == 0:
                        if tick==1:
                            self.getControl(303).setVisible(True)
                            tick=0
                        else:
                            self.getControl(303).setVisible(False)
                            tick=1
                except Exception as e:
                    logging.warning('Skin ERR:'+str(e))
                    self.params = 888
                    self.done=1
                    logging.warning('Close:4')
                    xbmc.executebuiltin( "XBMC.Action(Fullscreen)" )
                    done1_1=3
                    self.close()
                    pass
            
            elif changed==1:
                    changed=0
                
                    self.getControl(303).setVisible(False)
                    self.getControl(self.txtcontrol).setText(self.text)
            
            if self.done==1:
                break
            if xbmc.Player().isPlaying():
                self.tick=60
                self.count_p+=1
                self.st_time=0
                
                vidtime = xbmc.Player().getTime()
                if self.s_t_point==0:
                    
                    
                    if vidtime > 0:
                        self.getControl(3000).setVisible(False)
                        self.getControl(self.imagecontrol).setVisible(False)
                        self.getControl(505).setVisible(False)
                        self.getControl(909).setPosition(1310, 40)
                        self.getControl(2).setPosition(1310, 100)
                        self.s_t_point=1
                        self.getControl(303).setVisible(False)
                        self.story_gone=1
                        logging.warning('Change seek Time:'+str(mag_start_time_new))
                        try:
                            if int(float(mag_start_time_new))>0:
                                xbmc.Player().seekTime(int(float(mag_start_time_new)))
                        except:
                            pass
                
                if vidtime > 0:
                    playing_text=''
     
                try:
                    value_d=(vidtime-(int(float(mag_start_time_new)))) 
                except:
                    value_d=vidtime
                play_time=int(Addon.getSetting("play_full_time"))
                if value_d> play_time and self.s_t_point>0:
                    self.params = 888
                    self.done=1
                    logging.warning('Close:1')
                    xbmc.executebuiltin( "XBMC.Action(Fullscreen)" )
                    done1_1=3
                    self.close()
              
                if self.count_p>(play_time+30) :
                   if Addon.getSetting("play_first")!='true':
                   
                    self.params = 888
                    self.done=1
                    logging.warning('Close:3')
                    xbmc.executebuiltin( "XBMC.Action(Fullscreen)" )
                    done1_1=3
                    self.close()
            else:
                self.count_p=0
                self.s_t_point=0
                self.getControl(3000).setVisible(True)
         
                #self.getControl(505).setVisible(True)
                self.getControl(self.imagecontrol).setVisible(True)
                self.story_gone=0
                self.getControl(2).setPosition(1310, 700)
                self.getControl(909).setPosition(1310, 10)
            xbmc.sleep(1000)
    def tick_time(self):
        global done1_1
        while(self.tick)>0:
            self.getControl(self.tick_label).setLabel(str(self.tick))
            self.tick-=1
            
            if self.params == 888:
                break
            xbmc.sleep(1000)
        if self.params != 888:
            self.params = 888
            self.done=1
            logging.warning('Close:93')
            xbmc.executebuiltin( "XBMC.Action(Fullscreen)" )
            done1_1=3
            self.close()
    def fill_table(self,all_his_links):
        logging.warning('Start Fill')
        count=0
        self.paramList = []
        all_liz_items=[]
        try:
            for item in self.menu:
                self.getControl(202).setLabel(str(((count*100)/len(self.menu))) + '% אנא המתן ')
                count+=1
                self.paramList.append(item[6])
                '''
                info=(PTN.parse(item[0]))
                if 'excess' in info:
                    if len(info['excess'])>0:
                        item[0]='.'.join(info['excess'])
                '''
                golden=False
                if 'Cached ' in item[0]:
                    golden=True
                item[0]=item[0].replace('Cached ','')
                if len(item[0])>45 and '►►►' not in item[0]:
                #    item[0]="\n".join(textwrap.wrap(item[0],60))
                     item[0]=item[0][0:45]+'\n'+item[0][45:len(item[0])]
                title ='[COLOR deepskyblue][B]'+item[0] +'[/B][/COLOR]'
                if len(item[1].strip())<2:
                    item[1]='--'
                if len(item[2].strip())<2:
                    item[2]='--'
                if len(item[3].strip())<2:
                    item[3]='--'
                if len(item[4])<2:
                    item[4]='--'
                if len(item[5])<2:
                    item[5]='--'
                server=item[1]
                pre_n='[COLOR khaki]'+item[2]+'[/COLOR]'
                q=item[3]
                supplay='[COLOR lightblue]'+item[4]+'[/COLOR]'
                size='[COLOR coral]'+item[5]+'[/COLOR]'
                link=item[6]
                
                if item[7]==True or ('magnet' in server and allow_debrid):
                    supplay='[COLOR yellow][I]RD - '+supplay+'[/I][/COLOR]'
              
                if '►►►' in item[0]:
                    
                    title=''
                    supplay=item[0]
               
                
                if q=='2160':
                    q='4k'
                liz   = xbmcgui.ListItem(title)
                liz.setProperty('server', server)
                liz.setProperty('pre',pre_n)
                liz.setProperty('Quality', q)
                liz.setProperty('supply', supplay)
                liz.setProperty('size', size)
                if item[6].encode('base64') in all_his_links:
                    liz.setProperty('history','100')
                if '►►►' not in item[0]:
                    liz.setProperty('server_v','100')
                if item[7]==True or ('magnet' in server and allow_debrid):
                    liz.setProperty('rd', '100')
                if golden:
                    liz.setProperty('magnet', '200')
                
                elif 'magnet' in server:
                    liz.setProperty('magnet', '100')
                all_liz_items.append(liz)
            logging.warning(' Done Loading')
            self.getControl(202).setLabel('')
            self.list.addItems(all_liz_items)

            self.setFocus(self.list)
        except Exception as e:
            logging.warning('Fill error:'+str(e))
        
    def onInit(self):
        xbmc.Player().stop()
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        dbcur.execute("SELECT * FROM historylinks")
        all_his_links_pre = dbcur.fetchall()
        all_his_links=[]
        for link,status,option in all_his_links_pre:
            all_his_links.append(link)
        thread=[]
        thread.append(Thread(self.background_work))
        thread[len(thread)-1].setName('background_task')
        thread.append(Thread(self.tick_time))
        thread[len(thread)-1].setName('tick_time')
        thread.append(Thread(self.fill_table,all_his_links))
        thread[len(thread)-1].setName('fill_table')
        
        thread[0].start()
        thread[1].start()
        thread[2].start()
        line   = 38
        spacer = 20
        delta  = 0 
        
        nItem = len(self.menu)
        if nItem > 16:
            nItem = 16
            delta = 1
        self.getControl(self.imagecontrol).setImage(self.icon)
        self.getControl(self.bimagecontrol).setImage(self.fan)
        if len(playing_text)==0:
            self.getControl(self.txtcontrol).setText(self.text)
        height = (line+spacer) + (nItem*line)
        height=1100
        self.getControl(5001).setHeight(height)
            
        self.list = self.getControl(3000)
        self.list.setHeight(height)

        newY = 360 - (height/2)

        self.getControl(5000).setPosition(self.getControl(5000).getX(), 0)
        
       
        
        
        
        #txt='[COLOR deepskyblue]'+name.replace('-',' ').replace('%20',' ').strip()+'[/COLOR]\nServer: '+server+' Subs: '+str(pre_n)+'  Quality:[COLOR gold] ◄'+q+'► [/COLOR]Provider: [COLOR lightblue]'+supplay+'[/COLOR] Size:[COLOR coral]'+size+'[/COLOR]$$$$$$$'+link
        #import textwrap
        
        
        
        logging.warning('Loading')
        
        
            
           
    def played(self):
        self.params =7777
    def onAction(self, action):  
        global done1_1
        actionId = action.getId()
        #logging.warning('actionId:'+str(actionId))
        self.tick=60
        #logging.warning('ACtion:'+ str(actionId))
        if actionId in [ACTION_LEFT,ACTION_RIGHT ,ACTION_UP,ACTION_DOWN ]:
            self.getControl(3000).setVisible(True)
           
            
            #self.getControl(505).setVisible(True)
            self.getControl(self.imagecontrol).setVisible(True)
            self.story_gone=0
            self.getControl(2).setPosition(1310, 700)
            self.getControl(909).setPosition(1310, 10)
            
            
        if actionId in [ACTION_CONTEXT_MENU, ACTION_C_KEY]:
            logging.warning('Close:5')
            self.params = 888
            xbmc.sleep(100)
            xbmc.executebuiltin( "XBMC.Action(Fullscreen)" )
            self.done=1
            done1_1=3
            return self.close()

        if actionId in [ACTION_PARENT_DIR, ACTION_PREVIOUS_MENU, ACTION_BACK,ACTION_NAV_BACK]:
            self.params = 888
            logging.warning('Close:6')
            xbmc.executebuiltin( "XBMC.Action(Fullscreen)" )
            self.done=1
            done1_1=3
            return self.close()

    def wait_for_close(self):
        global done1_1
        timer=0
        while(done1!=1):
                if timer>10:
                    break
                timer+=1
                self.params = 888
                self.done=1
                xbmc.sleep(200) 
        done1_1=3
        self.close()
    def onClick(self, controlId):
        global playing_text,done1_1
        self.tick=60
        
        if controlId != 3001:
            '''
            self.getControl(3000).setVisible(False)
            self.getControl(102).setVisible(False)
            self.getControl(505).setVisible(False)
            self.getControl(909).setPosition(1310, 40)
            self.getControl(2).setPosition(1310, 100)
            self.getControl(self.imagecontrol).setVisible(False)
            self.getControl(303).setVisible(False)
            self.story_gone=1
            '''
            index = self.list.getSelectedPosition()        
            
            try:    
                self.params = index
                logging.warning('Clicked:'+str(controlId)+':'+str(index))
            except:
                self.params = None
            #playing_text=''
            xbmc.executebuiltin( "XBMC.Action(Fullscreen)" )
           
            return self.params
        else:
            logging.warning('Close:7')
            self.params = 888
            self.done=1
            #while(done1==0):
            #    self.params = 888
            #    self.done=1
            #    xbmc.sleep(100) 
            thread=[]
            thread.append(Thread(self.wait_for_close))
            thread[len(thread)-1].setName('closing_task')
            thread[0].start()
            xbmc.executebuiltin( "XBMC.Action(Fullscreen)" )
            logging.warning('Clicked CLosing')
            #self.close()
        
    def close_now(self):
        global done1_1
        logging.warning('Close:8')
        self.params = 888
        self.done=1
        xbmc.executebuiltin( "XBMC.Action(Fullscreen)" )
        xbmc.sleep(1000)
        logging.warning('Close now CLosing')
        done1_1=3
        self.close()
    def onFocus(self, controlId):
        pass
        
class sources_search(xbmcgui.WindowXMLDialog):
    
    def __new__(cls, addonID,id,tv_movie,name):
        FILENAME='sources_s.xml'
        return super(sources_search, cls).__new__(cls, FILENAME,Addon.getAddonInfo('path'), 'DefaultSkin')
        

    def __init__(self, addonID,fan,tv_movie,name):
        super(sources_search, self).__init__()
       
        self.onint=False
        self.imagecontrol=101
        self.bimagecontrol=5001
        self.txtcontrol=2
        self.close_tsk=0
        self.tv_movie=tv_movie
        self.id=id
        self.name=name
        self.progress=32
        self.progress2=33
        self.label=34
        self.label2=35
        self.label3=36
        self.label4=37
        
        self.progress3=40
        self.progress4=43
        self.label5=38
        self.label6=41
        self.label7=39
        self.label8=42
        
        self.label9=44
        self.label10=45
        self.label11=46
        self.label12=47
        self.label13=48
        self.label14=49
        self.label15=50
        
        self.image_movie=51
        self.label_movie=52
        self.txt_movie=53
        
        self.label16=54
        self.progress5=55
        
        self.label17=56
        self.all_ids_done=0
        self.label18=57
        self.label19=58
        self.label20=59
        
        self.label21=60
        self.progress6=61
        self.label22=62
        self.timer_close=0
        self.all_ids=[]
        xbmc.Player().stop()
        Thread(target=self.background_task).start()
        Thread(target=self.get_similer).start()
    def get_similer(self):
        while self.onint==False:
            xbmc.sleep(100)
        if len(id)>1 and '%' not in id :
            self.getControl(self.label22).setLabel('Getting similar')
            url=domain_s+'api.themoviedb.org/3/%s/%s/recommendations?api_key=34142515d9d23817496eeb4ff1d223d0&language=heb&page=1'%(self.tv_movie,self.id.replace('\n',''))
            self.html=get_html(url)
          
            all_data_int=[]
            self.all_ids=[]
            self.all_ids_done=0
            for items in self.html['results']:
                
                if self.tv_movie=='movie':
                    title=items['title']
                else:
                    title=items['name']
                self.all_ids.append((items['id'],title))
                rating=''
                if items['vote_average']!=None:
                    rating='[COLOR khaki]'+str(items['vote_average'])+'[/COLOR]'
                all_data_int.append((title,items['backdrop_path'],'Rating-(' + rating+')\n'+items['overview']))
            self.all_ids_done=1
            all_was=[]
            while(1):
                count=0
                while all_data_int[0][1] in all_was:
                    random.shuffle(all_data_int)
                    count+=1
                    if count>15:
                        break
                if all_data_int[0][1]!=None:
                    all_was.append(all_data_int[0][1])
                    self.getControl(self.image_movie).setImage(domain_s+'image.tmdb.org/t/p/original/'+all_data_int[0][1])
                    self.getControl(self.label_movie).setLabel(all_data_int[0][0])
                    self.getControl(self.txt_movie).setText(all_data_int[0][2])
                
                
                xbmc.sleep(10000)
                if self.close_tsk>0:
                    break
    def background_task(self):
        global all_s_in
        
        start_time=time.time()
        if self.tv_movie=='movie':
            src_ena=Addon.getSetting("fav_search_time_en")
        else:
            src_ena=Addon.getSetting("fav_search_time_en_tv")
        if fav_status=='true' and src_ena=='true':
           if self.tv_movie=='movie':
             max_time=int(Addon.getSetting("fav_search_time"))
           else:
             max_time=int(Addon.getSetting("fav_search_time_tv"))
        else:
           max_time=int(Addon.getSetting("time_s"))
        counter_close=0
        while(1):
            
            if self.onint:
              all_al=[]
              for thread in threading.enumerate():
                        if (thread.isAlive()):
                            all_al.append(thread.getName())
              #self.getControl(self.txt_movie).setText('\n'.join(all_al))
              try:
                elapsed_time = time.time() - start_time
                #self.getControl(self.label17).setLabel('Hellpw')
                
                if self.timer_close==1:
                   self.getControl(self.label17).setLabel('סוגר אנא המתן'+' '+all_s_in[2])
                else:
                    self.getControl(self.label17).setLabel(time.strftime("%H:%M:%S", time.gmtime(elapsed_time)))
                prect=int(100*(elapsed_time/max_time))
                self.getControl(self.progress6).setPercent(prect)
                self.getControl(self.label21).setLabel(str(prect)+'%')
                    
                count_hebrew=0
                count_magnet=0
                count_regular=0
                if len(all_s_in[0])>0:
                    txt=[]
                    txt2=[]
                    
                    for names in all_s_in[0]:
                        if names=='magnet':
                            continue
                        if len(all_s_in[0][names]['links'])>0:
                            color='lightgreen'
                            txt.append('[COLOR %s]'%color+names+' - '+str(len(all_s_in[0][names]['links']))+'[/COLOR]-'+all_s_in[0][names]['progress'])
                        else:
                            color='red'
                            txt2.append('[COLOR %s]'%color+names+' - '+str(len(all_s_in[0][names]['links']))+'[/COLOR]-'+all_s_in[0][names]['progress'])
                        
                        if all_s_in[0][names]['subs']==True:
                            count_hebrew=count_hebrew+len(all_s_in[0][names]['links'])
                        elif 'magnet' in names:
                            count_magnet=count_magnet+len(all_s_in[0][names]['links'])
                        else:
                            count_regular=count_regular+len(all_s_in[0][names]['links'])
                        
                    self.getControl(self.txtcontrol).setText('\n'.join(txt)+'\n'+'\n'.join(txt2))
                if count_regular>0:
                    self.getControl(self.label18).setLabel(str(count_regular))
                if count_magnet>0:
                    self.getControl(self.label19).setLabel(str(count_magnet))
                if count_hebrew>0:
                    self.getControl(self.label20).setLabel(str(count_hebrew))
                
                if all_s_in[3]==1:
                    self.getControl(self.progress).setPercent(all_s_in[1])
                    self.getControl(self.label3).setLabel(str(all_s_in[1])+'%')
                    self.getControl(self.label).setLabel('Collecting Files:'+all_s_in[2])
                elif all_s_in[3]==2:
                    self.getControl(self.progress2).setPercent(all_s_in[1])
                    self.getControl(self.label4).setLabel(str(all_s_in[1])+'%')
                    self.getControl(self.label2).setLabel('Sources: '+all_s_in[2])
                    
                    
                    self.getControl(self.progress).setPercent(100)
                    self.getControl(self.label3).setLabel('100%')
                    self.getControl(self.label).setLabel('Collecting Files: Done')
                elif all_s_in[3]==3:
                    
                    
                    self.getControl(self.progress5).setPercent(all_s_in[1])
                    self.getControl(self.label16).setLabel(str(all_s_in[1])+'%')
                  
                    
                    
                    self.getControl(self.progress2).setPercent(100)
                    self.getControl(self.label4).setLabel('100%')
                    self.getControl(self.label2).setLabel('Sources: Done')
                    
                if len(all_s_in[4])>0:
                    regex="4K: (.+?) 1080: (.+?) 720: (.+?) 480: (.+?) Rest: (.+?)  T: (.+?) '.+?SUB: (.+?)\["
                    match=re.compile(regex).findall(all_s_in[4])
                    for res4k,res1080,res720,res480,resuk,total,subs in match:
                        self.getControl(self.label9).setLabel(res4k)
                        self.getControl(self.label10).setLabel(res1080)
                        self.getControl(self.label11).setLabel(res720)
                        self.getControl(self.label12).setLabel(res480)
                        self.getControl(self.label13).setLabel(resuk)
                        self.getControl(self.label14).setLabel(subs)
                        self.getControl(self.label15).setLabel(total)
                avg=0
                counter=0
                all_c=[]
                for i in range(0,8):
                    prec=float(xbmc.getInfoLabel('System.CoreUsage(%s)'%str(i)))
                    if prec>0.0:
                        all_c.append(str(int(prec))+'%')
                    if prec>0:
                        avg+=int(prec)
                        counter+=1
                if counter==0:
                    counter=1
                avg_f=int(float(avg/counter))
                try:
                    self.getControl(self.progress3).setPercent(int(xbmc.getInfoLabel('System.CpuUsage').replace('%','')))
                except:
                    self.getControl(self.progress3).setPercent(avg_f)
                self.getControl(self.label7).setLabel(str(avg_f)+'%')
                self.getControl(self.label5).setLabel(str(len(all_c))+'.Cpu:'+','.join(all_c))
                
                self.getControl(self.progress4).setPercent(int(xbmc.getInfoLabel('System.Memory(used.percent)').replace('%','')))
                self.getControl(self.label8).setLabel(str(xbmc.getInfoLabel('System.Memory(used.percent)')))
                
                
              except Exception as e:
                import linecache
                exc_type, exc_obj, tb = sys.exc_info()
                f = tb.tb_frame
                lineno = tb.tb_lineno
                logging.warning('Error in search S: '+str(e)+' '+str(lineno))
            if self.timer_close==1:
                    counter_close+=1
            if all_s_in[3]==4 or counter_close>30:
                if Addon.getSetting("video_in_s_wait")=='true' and Addon.getSetting("video_in_sources")=='true':
                    while(xbmc.Player().isPlaying()):
                        xbmc.sleep(100)
                xbmc.Player().stop()
                self.close_tsk=1
                
                self.close()
                break
            xbmc.sleep(1000)
            if self.close_tsk>0:
                break
    def onInit(self):
        line   = 38
        spacer = 20
        delta  = 0 

        
        self.getControl(self.label).setLabel('Collecting Files:')
        self.getControl(self.label2).setLabel('Sources: ')
        
        self.getControl(self.label5).setLabel('Cpu')
        self.getControl(self.label6).setLabel('Mem ')
        self.setFocus(self.getControl(3002))
        self.onint=True
        logging.warning('Trailer')
        if Addon.getSetting("video_in_sources")=='true':
            if Addon.getSetting("video_type_in_s")=='1':
                while self.all_ids_done==0:
                    xbmc.sleep(100)
                
                if (len(self.all_ids))>0: 
                    random.shuffle(self.all_ids)
                    logging.warning(self.all_ids)
                    id_to_send=self.all_ids[0][0]
                    title_to_send=self.all_ids[0][1]
                else:
                    id_to_send=self.id
                    title_to_send=self.name
            else:
                id_to_send=self.id
                title_to_send=self.name
            try:
                self.getControl(self.label22).setLabel('get link')
                link_m=get_trailer_f(id_to_send,self.tv_movie)
                self.getControl(self.label22).setLabel(title_to_send)
                if link_m!='':
                    try:
                        xbmc.Player().play(link_m, windowed=True)
                    except:
                        pass
            except:
                pass
    def onAction(self, action):
        global stop_window
        
        actionId = action.getId()

        if actionId in [ACTION_CONTEXT_MENU, ACTION_C_KEY]:
            self.params = 888
            xbmc.sleep(100)
            stop_window=True
            self.timer_close=1
            xbmc.Player().stop()
            #return self.close()

        if actionId in [ACTION_PARENT_DIR, ACTION_PREVIOUS_MENU, ACTION_BACK]:
            self.params = 888
            xbmc.sleep(100)
            stop_window=True
            xbmc.Player().stop()
            self.timer_close=1
            #return self.close()


    def onClick(self, controlId):
        global stop_window
        stop_window=True
        self.timer_close=1
        #self.close_tsk=1
        
        xbmc.Player().stop()
        #self.close()
        

    def onFocus(self, controlId):
        pass
def monitor_play():
    global stoped_play_once,all_s_in,once_fast_play
    logging.warning('In monitor Play')
    once=0
    while(1):
        
        if all_s_in[3]!=4:
            
            if not xbmc.Player().isPlaying():
                if once==0:
                    xbmc.executebuiltin("Dialog.Open(busydialog)")
                    logging.warning('Stop super')
                    xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'המתן כבר יופיעו המקורות'.decode('utf8'))).encode('utf-8'))
                    dp = xbmcgui . DialogProgress ( )
                    dp.create('אנא המתן','מחפש מקורות', '','')
                    dp.update(0, 'אנא המתן','מחפש מקורות', '' )
                    once=1
                dp.update(all_s_in[1], 'אנא המתן',all_s_in[2], all_s_in[4] )
                if dp.iscanceled():
                 stop_window=True
                 
                
                once_fast_play=0;
                stoped_play_once=1
                
       
        else:
            break
        xbmc.sleep(100)
    if once==1:
    
        dp.close()
    xbmc.executebuiltin("Dialog.Close(busydialog)")
class sources_search2(xbmcgui.WindowXMLDialog):
    
    def __new__(cls, addonID,id,tv_movie,type):
        if Addon.getSetting("new_server_dp_option")=='4':
            FILENAME='sources_s3.xml'
        else:
            FILENAME='sources_s2.xml'
        return super(sources_search2, cls).__new__(cls, FILENAME,Addon.getAddonInfo('path'), 'DefaultSkin')
        

    def __init__(self, addonID,id,tv_movie,type):
        super(sources_search2, self).__init__()
        
        if tv_movie=='movie':
            fav_search_f=Addon.getSetting("fav_search_f")
            fav_servers_en=Addon.getSetting("fav_servers_en")
            fav_servers=Addon.getSetting("fav_servers")
           
            google_server= Addon.getSetting("google_server")
            rapid_server=Addon.getSetting("rapid_server")
            direct_server=Addon.getSetting("direct_server")
            heb_server=Addon.getSetting("heb_server")
        else:
            fav_search_f=Addon.getSetting("fav_search_f_tv")
            fav_servers_en=Addon.getSetting("fav_servers_en_tv")
            fav_servers=Addon.getSetting("fav_servers_tv")
            google_server= Addon.getSetting("google_server_tv")
            rapid_server=Addon.getSetting("rapid_server_tv")
            direct_server=Addon.getSetting("direct_server_tv")
            heb_server=Addon.getSetting("heb_server_tv")
        
        if  fav_search_f=='true' and fav_servers_en=='true' and (len(fav_servers)>0 or heb_server=='true' or google_server=='true' or rapid_server=='true' or direct_server=='true'):
            self.fav_status='true'
        else:
            self.fav_status='false'
        self.full=0
        self.onint=False
        self.poster=1
        self.timer_close=0
        self.changed_poster=2
        self.all_ids=[]
        self.close_tsk=0
        self.type=type
        self.titlein=4
        self.titlein2=5
        self.txt_movie=6
        self.genere=7
        self.progress=8
        self.labelpre=9
        self.labelResult=10
        self.timelabel=11
        self.recomlabel=13
        self.labelstatus=14
        xbmc.Player().stop()
        self.id=id
        self.st_init=0
        self.tv_movie=tv_movie
        thread=[]
        thread.append(Thread(self.background_task))
        thread[len(thread)-1].setName('background_task')
        thread.append(Thread(self.get_similer))
        thread[len(thread)-1].setName('get_similer')
        for td in thread:
            td.start()
        #Thread(target=self.background_task).start()
        
        #Thread(target=self.get_similer).start()
    def get_similer(self):
        global all_s_in,global_result,stop_window,once_fast_play,close_sources_now
        while  self.st_init==0:
            xbmc.sleep(100)
        logging.warning('Start Similar')
        start_time=time.time()
        counter_close=0
        tick=0
        tick_global=0
        pre_state=0
        while(1):
                if once_fast_play==1:
                    if xbmc.Player().isPlaying():
                        vidtime = xbmc.Player().getTime()
                        if vidtime > 2:
                            
                            xbmc.executebuiltin("Dialog.Close(busydialog)")
                            logging.warning('Start monitor Thread')
                            thread=[]
                            thread.append(Thread(monitor_play))
                            thread[len(thread)-1].setName('monitor_play')
                            thread[0].start()
                            self.close_tsk=1
                            self.close()
                if self.timer_close==1:
                    self.getControl(self.genere).setLabel('סוגר אנא המתן'+' '+all_s_in[2])
                    counter_close+=1
                    if tick==0:
                        self.getControl(self.genere).setVisible(True)
                        tick=1
                    else:
                        self.getControl(self.genere).setVisible(False)
                        tick=0
            
                try:
                        
                        if pre_state==1 and all_s_in[3]==2:
                            logging.warning('reset time')
                            start_time=time.time()
                        pre_state=all_s_in[3]
                        self.getControl(self.labelpre).setLabel(str(all_s_in[1])+'% '+str(all_s_in[3])+'/4')
                        if 'Playing' in global_result:
                            if tick_global==1:
                                tick_global=0
                                self.getControl(self.labelResult).setLabel(global_result)
                            else:
                                tick_global=1
                                self.getControl(self.labelResult).setLabel('')
                        else:
                            self.getControl(self.labelResult).setLabel(global_result)
                        self.getControl(self.progress).setPercent(all_s_in[1])
                        all_t=[]
                        for thread in threading.enumerate():
                            if ('background_task' in thread.getName()) or ('get_similer' in thread.getName()) or ('MainThread' in thread.getName()) or ('sources_s' in thread.getName()):
                                continue
                            if (thread.isAlive()):
                                all_t.append( thread.getName())
                        if len(all_t)>10:
                            tt=' שרתים שנותרו:'+str(len(all_t))
                        else:
                            tt=','.join(all_t)
                        self.getControl(self.labelstatus).setLabel(tt)
                        elapsed_time = time.time() - start_time
                        self.getControl(self.timelabel).setLabel(time.strftime("%H:%M:%S", time.gmtime(elapsed_time)))
                        
                        if tv_movie=='movie':
                            src_ena=Addon.getSetting("fav_search_time_en")
                        else:
                            src_ena=Addon.getSetting("fav_search_time_en_tv")
                        if self.fav_status=='true' and src_ena=='true':
                           if tv_movie=='movie':
                              max_time=int(Addon.getSetting("fav_search_time"))
                           else:
                             max_time=int(Addon.getSetting("fav_search_time_tv"))
                        else:
                           max_time=int(Addon.getSetting("time_s"))
                        if elapsed_time>max_time:
                            self.onClick(3001)
                        if self.close_tsk==1:
                            break
                except Exception as e:
                    logging.warning('Error In Skin:'+str(e))
                    
                counter_now=False
                if Addon.getSetting("video_in_s_wait")=='true' and Addon.getSetting("video_in_sources")=='true' and Addon.getSetting("super_fast")=='false':
                       if not xbmc.Player().isPlaying() and counter_close>30:
                            counter_now=True
                elif counter_close>30:
                        counter_now=True
                
                if all_s_in[3]==4 or counter_now or close_on_error==1 or close_sources_now==1:
                 
                    
                    if Addon.getSetting("video_in_s_wait")=='true' and Addon.getSetting("video_in_sources")=='true' and Addon.getSetting("super_fast")=='false':
                      
                        logging.warning('Closing:'+str(xbmc.Player().isPlaying()))
                        self.getControl(self.labelstatus).setLabel('ממתין לסיום הטריילר')
                        while(xbmc.Player().isPlaying()):
                            xbmc.sleep(100)
                    logging.warning('once_fast_play22: '+str(once_fast_play))
                    if once_fast_play==0 and close_sources_now==0:
                        xbmc.Player().stop()
                    self.close_tsk=1
                    stop_window=True
                    self.close()
                    break
                xbmc.sleep(500)
        return 0
    def get_review(self,nm):
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0',
                'Accept': '*/*',
                'Accept-Language': 'en-US,en;q=0.5',
                'Connection': 'keep-alive',
                'accept-encoding': 'utf-8',
                'Pragma': 'no-cache',
                'Cache-Control': 'no-cache',
            }

            params = (
                ('s', nm),
                ('t', 'movie'),
            )
            logging.warning(params)
            response = requests.get('https://www.seret.co.il/searchAUAjax.asp', headers=headers, params=params).content
            regex="changeLocation\('(.+?)'"
            m=re.compile(regex).findall(response)[0]
            x= requests.get(m, headers=headers).content.decode('windows-1255').encode('utf8')
            '''
            try:
                import chardet
                encoding = chardet.detect(x)['encoding']
                logging.warning('encoding:'+str(encoding))
            except Exception as e:
                logging.warning('encoding:'+str(e))
            '''
            regex='"DarkGreenStrong14"><i>(.+?)<.+?"vspace5"></span>(.+?)<.+?<b>(.+?)</b>.+?ביקורות »</a>(.+?)<'
            m=re.compile(regex).findall(x)
            all_txt=[]
            for hd,pl,we,rev in m:
                
                all_txt.append(('[B][I]'+hd+'[/B][/I]\n'+pl+'\n'+'[B][I]'+we+'[/B][/I] \n '+rev+'\n'))
            self.getControl(66).setText('\n'.join(all_txt))
            if len(all_txt)==0:
                self.getControl(6).setWidth(1800)
                self.getControl(self.txt_movie).setText(self.html['overview'])
        except:
            self.getControl(6).setWidth(1800)
            self.getControl(self.txt_movie).setText(self.html['overview'])
    def background_task(self):
       global close_on_error
       xbmc.Player().stop()
       if self.type=='find_similar':
           
            url=domain_s+'api.themoviedb.org/3/%s/%s/recommendations?api_key=34142515d9d23817496eeb4ff1d223d0&language=heb&page=1'%(self.tv_movie,self.id.replace('\n',''))
            self.html=get_html(url)

            all_data_int=[]
            self.all_ids=[]
            self.all_ids_done=0
            for items in self.html['results']:
                
               
                all_data_int.append(items['id'])
            random.shuffle(all_data_int)
            self.id=all_data_int[0]
       if self.type=='find_similar' and Addon.getSetting("video_in_sources")=='true':
            
            link_m=get_trailer_f(self.id,self.tv_movie)
            
            if link_m!='':
                try:
                    xbmc.Player().play(link_m, windowed=True)
                except:
                    pass
        
       url='https://api.themoviedb.org/3/%s/%s?api_key=34142515d9d23817496eeb4ff1d223d0&language=heb&include_image_language=ru,null&append_to_response=images'%(self.tv_movie,self.id)
    
       self.html=requests.get(url).json()
       if self.tv_movie=='movie':
           thread=[]
           thread.append(Thread(self.get_review,self.html['original_title']))
                
           thread[0].start()
       else:
            self.getControl(6).setWidth(1800)
       while  self.st_init==0:
            xbmc.sleep(100)
       all_img=[]
       for items in self.html['images']['backdrops']:
                all_img.append(domain_s+'image.tmdb.org/t/p/original/'+items['file_path'])
                self.getControl(self.changed_poster).setImage(domain_s+'image.tmdb.org/t/p/original/'+items['file_path'])
       random.shuffle(all_img)
       
       genres_list=[]
       genere=''
       if 'genres' in self.html:
            for g in self.html['genres']:
                  genres_list.append(g['name'])
            
            try:genere = u' / '.join(genres_list)
            except:genere=''
       
        
        
       fan=domain_s+'image.tmdb.org/t/p/original/'+self.html['backdrop_path']
       self.getControl(self.poster).setImage(fan)
       if 'title' in self.html:
        title_n=self.html['title']
       else:
        title_n=self.html['name']
       self.getControl(self.titlein).setLabel('[B]'+title_n+'[/B]')
       if 'tagline' in self.html:
        tag=self.html['tagline']
       else:
        tag=self.html['status']
       self.getControl(self.titlein2).setLabel('[I]'+tag+'[/I]')
        
       self.getControl(self.genere).setLabel(genere)
        
       self.getControl(self.txt_movie).setText(self.html['overview'])
       if self.type=='find_similar':
        self.getControl(self.recomlabel).setLabel('[B][I]מומלץ לפעם הבאה..[/I][/B]')
       while(1):
            for items in all_img:
               
                self.getControl(self.changed_poster).setImage(items)
                xbmc.sleep(10000)
            if self.close_tsk==1 or close_on_error==1:
                break
            xbmc.sleep(100)
            
       return 0
    def onInit(self):
        self.st_init=1
        
        
        self.setFocus(self.getControl(3002))
        if self.type!='find_similar' and Addon.getSetting("video_in_sources")=='true':
            
            link_m=get_trailer_f(self.id,self.tv_movie)
            
            if link_m!='':
                try:
                    xbmc.Player().play(link_m, windowed=True)
                except:
                    pass
            
            
        
        #self.getControl(self.title).setLabel(self.html['original_title'])
        
        
       
       
       
    def onAction(self, action):
        global stop_window,once_fast_play
        
        actionId = action.getId()

        if actionId in [ACTION_CONTEXT_MENU, ACTION_C_KEY]:
            self.params = 888
            xbmc.sleep(100)
            stop_window=True
            #self.close_tsk=1
            self.timer_close=1
            if once_fast_play==0:
                xbmc.Player().stop()
            #return self.close()

        if actionId in [ACTION_PARENT_DIR, ACTION_PREVIOUS_MENU, ACTION_BACK]:
            self.params = 888
            xbmc.sleep(100)
            stop_window=True
            #self.close_tsk=1
            self.timer_close=1
            if once_fast_play==0:
                xbmc.Player().stop()
            #return self.close()

    
    def onClick(self, controlId):
        global stop_window,once_fast_play
        stop_window=True
        #self.close_tsk=1
        self.timer_close=1
        if once_fast_play==0:
            xbmc.Player().stop()
        #self.close()
        
    
    def onFocus(self, controlId):
        pass 

def trd_sendy(headers,data):
    response='(flood-protection)'
    logging.warning('Trying to Send')
    while '(flood-protection)' in response:
        response = requests.post('http://anonymouse.org/cgi-bin/anon-email.cgi', headers=headers, data=data).content
        time.sleep(61)
    logging.warning('Send Succesfull')
def sendy(msg,header,type):
    return 0
    import requests

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:66.0) Gecko/20100101 Firefox/66.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'Referer': 'http://anonymouse.org/cgi-bin/anon-email.cgi',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
    }

    data = {
      'to':type+ 'QG1haWxkdS5kZQ=='.decode('base64'),
      'subject': header,
      'text': msg
    }
    thread=[]
    thread.append(Thread(trd_sendy,headers,data))
            
    thread[0].start()
    
   
        
    
    return 'ok'
class wizard(xbmcgui.WindowXMLDialog):
    
    def __new__(cls, addonID,list_of_play,fast_link):
        FILENAME='wizard.xml'
        return super(wizard, cls).__new__(cls, FILENAME,Addon.getAddonInfo('path'), 'DefaultSkin')
        

    def __init__(self, addonID,plot):
        super(wizard, self).__init__()
        self.plot=plot
       
        Thread(target=self.background_task).start()
        
   
    def background_task(self):
       timer=30
       while timer>0:
        timer-=1
        xbmc.sleep(1000)
       self.close()
       
    def onInit(self):
        
        self.getControl(3).setVisible(False)
        self.getControl(4).setVisible(False)
        
        self.listin = self.getControl(3000)
        selected_one=[]
        self.all_ones=[]
        index=0
        
   

    def onFocus(self, controlId):
        pass
'''
list=[]
list.append(('1080','Rapidvideo','Rampge.1080','www'))
list.append(('1080','Vummo','Rampge.1080.ll','www'))
list.append(('1080','Sertil','Rampge.1080','www'))
list.append(('1080','Rapidvideo','Rampge.1080','www'))
list.append(('1080','Vummo','Rampge.1080.ll','www'))
list.append(('1080','Sertil','Rampge.1080','www'))
list.append(('1080','Rapidvideo','Rampge.1080','www'))
list.append(('1080','Vummo','Rampge.1080.ll','www'))
list.append(('1080','Sertil','Rampge.1080','www'))
list.append(('1080','Rapidvideo','Rampge.1080','www'))
list.append(('1080','Vummo','Rampge.1080.ll','www'))
list.append(('1080','Sertil','Rampge.1080','www'))

menu = wizard('plugin.video.allmoviesin', list)
menu.doModal()

del menu
'''
class run_link(xbmcgui.WindowXMLDialog):
    
    def __new__(cls, addonID):
        FILENAME='run.xml'
        return super(run_link, cls).__new__(cls, FILENAME,Addon.getAddonInfo('path'), 'DefaultSkin')
        

    def __init__(self, addonID):
        super(run_link, self).__init__()
        self.menu = menu
        self.imagecontrol=101
        self.bimagecontrol=5001
        self.txtcontrol=2
        self.close_tsk=0
        

        self.progress=32
        self.progress2=33
        self.label=34
        self.label2=35
        self.label3=36
        self.label4=37
        
        self.progress3=40
        self.progress4=43
        self.label5=38
        self.label6=41
        self.label7=39
        self.label8=42
        
        self.label9=44
        self.label10=45
        self.label11=46
        self.label12=47
        self.label13=48
        self.label14=49
        self.label15=50
        
        self.image_movie=51
        self.label_movie=52
        self.txt_movie=53
        
        self.label16=54
        self.progress5=55
        
        self.label17=56
        
        self.label18=57
        self.label19=58
        self.label20=59
        
        self.label21=60
        self.progress6=61
        
        Thread(target=self.background_task).start()
       
    
    def background_task(self):
        global all_s_in
        
        start_time=time.time()
       
        while(1):
              try:
                elapsed_time = time.time() - start_time
                #self.getControl(self.label17).setLabel('Hellpw')
                self.getControl(400).setLabel(time.strftime("%H:%M:%S", time.gmtime(elapsed_time)))
                #prect=int(100*(elapsed_time/max_time))
                #self.getControl(self.progress6).setPercent(prect)
                #self.getControl(self.label21).setLabel(str(prect)+'%')
                    
               
                
                self.getControl(self.progress3).setPercent(int(xbmc.getInfoLabel('System.CpuUsage').replace('%','')))
                self.getControl(self.label7).setLabel(str(xbmc.getInfoLabel('System.CpuUsage')))
               
                
                self.getControl(self.progress4).setPercent(int(xbmc.getInfoLabel('System.Memory(used.percent)').replace('%','')))
                self.getControl(self.label8).setLabel(str(xbmc.getInfoLabel('System.Memory(used.percent)')))
                
                
           
           
                xbmc.sleep(1000)
                if self.close_tsk>0:
                    break
              except Exception as e:
                logging.warning('Skin Error:'+str(e))
                pass
    def onInit(self):
        line   = 38
        spacer = 20
        delta  = 0 

        
        
        
        self.getControl(self.label5).setLabel('Cpu')
        self.getControl(self.label6).setLabel('Mem ')
        self.setFocus(self.getControl(3002))
           
    def onAction(self, action):
        global stop_window
        
        actionId = action.getId()

        if actionId in [ACTION_CONTEXT_MENU, ACTION_C_KEY]:
            self.params = 888
            xbmc.sleep(100)
            stop_window=True
            return self.close()

        if actionId in [ACTION_PARENT_DIR, ACTION_PREVIOUS_MENU, ACTION_BACK]:
            self.params = 888
            return self.close()


    def onClick(self, controlId):
        global stop_window
        stop_window=True
        self.close_tsk=1
        self.close()
        

    def onFocus(self, controlId):
        pass
menu=[]

name='Back to the future'
server='magnet_api'
pre_n=80
q='1080'
supplay='Google'
size='1.2 G'
link='www.demo.com'


'''
menu.append([name.replace('-',' ').replace('%20',' ').strip(), server,str(pre_n),q,supplay,size,link])
menu.append([name.replace('-',' ').replace('%20',' ').strip(), server,str(pre_n),q,supplay,size,link])
menu = ContextMenu('plugin.video.allmoviesin', menu)
menu.doModal()
param = menu.params
del menu
'''
def get_html(url):
    headers = {
        
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
    }
    html=requests.get(url,headers=headers)
    try:
        html=json.loads(html.content)
    except:
        html=html.content
    return html
    
class Chose_ep(xbmcgui.WindowXMLDialog):

    def __new__(cls, addonID, heb_name,name, id,season,episode,dates,original_title,next_season):
        FILENAME='chose_ep.xml'
        return super(Chose_ep, cls).__new__(cls, FILENAME,Addon.getAddonInfo('path'), 'DefaultSkin')
        

    def __init__(self, addonID,heb_name,name, id,season,episode,dates,original_title,next_season):
        super(Chose_ep, self).__init__()
        self.menu = menu
        self.labelcontrol1=1020
        self.labelcontrol2=1021
        self.imagecontrol=101
        self.bimagecontrol=5001
        self.txtcontrol=2
        self.season=season
        self.next_season=next_season
        self.original_title=original_title
        self.id=id
        self.episode=episode
        self.heb_name=heb_name
        self.name=name
        self.dates=dates
        self.imagess=[]
        self.plotss=[]
        self.labelss=[]
        self.labelss1=[]
    def onInit(self):
        url='https://api.themoviedb.org/3/tv/%s/season/%s?api_key=34142515d9d23817496eeb4ff1d223d0&language=heb'%(self.id,self.season)
        
        html=cache.get(get_html,24,url, table='posters')
        if 'episodes' not in html:
            html=cache.get(get_html,0,url, table='posters')
        try:
            maste_image=domain_s+'image.tmdb.org/t/p/original/'+html['poster_path']
        except:
            maste_image=''
        if 'overview' in html:
            master_plot=html['overview']
        else:
            master_plot=' '
        if 'name' in html:
            master_name=html['name']
        else:
            master_name=self.heb_name
        
        dbcur.execute("SELECT * FROM AllData WHERE original_title = '%s' AND type='%s' AND season='%s' AND episode = '%s'"%(self.original_title.replace("'","%27"),'tv',self.season,str(int(self.episode)+1)))
     
        match = dbcur.fetchone()
        color_next='white'
        if match!=None:
           color_next='magenta'
        
        dbcur.execute("SELECT * FROM AllData WHERE original_title = '%s' AND type='%s' AND season='%s' AND episode = '%s'"%(self.original_title.replace("'","%27"),'tv',self.season,str(int(self.episode))))
     
        match = dbcur.fetchone()
        color_current='white'
        
        if match!=None:
           color_current='magenta'
           
           
        dbcur.execute("SELECT * FROM AllData WHERE original_title = '%s' AND type='%s' AND season='%s' AND episode = '%s'"%(self.original_title.replace("'","%27"),'tv',self.season,str(int(self.episode)-1)))
     
        match = dbcur.fetchone()
        color_prev='white'
        if match!=None:
           color_prev='magenta'
           
        height=1100
        self.getControl(5001).setHeight(height)
            
        self.list = self.getControl(3000)
        self.list.setHeight(height)

        newY = 360 - (height/2)

        self.getControl(5000).setPosition(self.getControl(5000).getX(), 0)

        self.params    = None
        self.paramList = []
        #txt='[COLOR deepskyblue]'+name.replace('-',' ').replace('%20',' ').strip()+'[/COLOR]\nServer: '+server+' Subs: '+str(pre_n)+'  Quality:[COLOR gold] ◄'+q+'► [/COLOR]Provider: [COLOR lightblue]'+supplay+'[/COLOR] Size:[COLOR coral]'+size+'[/COLOR]$$$$$$$'+link
        #import textwrap
        all_d=json.loads(urllib.unquote_plus(self.dates))
        logging.warning(all_d)
        if len(all_d)<2:
            all_d=['','','']
        if self.next_season==1:
            #next ep
            url='https://api.themoviedb.org/3/tv/%s/season/%s?api_key=34142515d9d23817496eeb4ff1d223d0&language=heb'%(self.id,str(int(self.season)+1))
        
            html2=cache.get(get_html,24,url, table='posters')
            
            if 1:#len(html['season'])>int(self.season):
                items=html2['episodes'][0]
                title='[COLOR %s]'%color_next+items['name']+'[/COLOR] '
                
                plot='[COLOR khaki]'+items['overview']+'[/COLOR]'
                image=maste_image
                if items['still_path']!=None:
                    image=domain_s+'image.tmdb.org/t/p/original/'+items['still_path']
                self.imagess.append(image)
                title=title+ ' פרק - '+str(1)+' '
                self.labelss.append(title)
                liz   = xbmcgui.ListItem(title)
                liz.setProperty('title_type', 'נגן את פרק העונה הבאה  ')
                self.labelss1.append('נגן את פרק העונה הבאה')
                
                liz.setProperty('image', image)
                liz.setProperty('discription',plot)
                self.plotss.append(plot)
                if '◄' in self.name:
                    liz.setProperty('pre', '100')

                
                self.list.addItem(liz)
            #prev ep
            items=html['episodes'][int(self.episode)-2]
            title='[COLOR %s]'%color_prev+items['name']+'[/COLOR] '
            plot='[COLOR khaki]'+items['overview']+'[/COLOR]'
            image=maste_image
            if items['still_path']!=None:
                image=domain_s+'image.tmdb.org/t/p/original/'+items['still_path']
            self.imagess.append(image)
            title=title+ '  פרק - '+str(int(self.episode)-1)+' '
            self.labelss.append(title)
            liz   = xbmcgui.ListItem(title)
            liz.setProperty('title_type', 'נגן פרק קודם - '+all_d[0])
            self.labelss1.append( 'נגן פרק קודם - '+all_d[0])
            liz.setProperty('image', image)
            liz.setProperty('discription',plot)
            self.plotss.append(plot)
          

            
            self.list.addItem(liz)
            
            

            
            #episodes
            
            title=master_name
            self.labelss.append(title)
            liz   = xbmcgui.ListItem(title)
            liz.setProperty('title_type', 'פתח את פרקי העונה')
            self.labelss1.append('פתח את פרקי העונה')
            liz.setProperty('image', maste_image)
            self.imagess.append(maste_image)
            liz.setProperty('discription',master_plot)
            self.plotss.append(master_plot)

            self.list.addItem(liz)
            
            #season ep
            
            title=self.heb_name
            self.labelss.append(title)
            liz   = xbmcgui.ListItem(title)
            liz.setProperty('title_type', 'פתח את בחירת העונה')
            self.labelss1.append('פתח את בחירת העונה')
            liz.setProperty('image', maste_image)
            self.imagess.append(maste_image)
            liz.setProperty('discription',master_plot)
            self.plotss.append(master_plot)

            self.list.addItem(liz)
        elif all_d[0]==0:
            #next ep
            if len(html['episodes'])>int(self.episode):
                items=html['episodes'][int(self.episode)]
                title='[COLOR %s]'%color_next+items['name']+'[/COLOR] '
                
                plot='[COLOR khaki]'+items['overview']+'[/COLOR]'
                image=maste_image
                if items['still_path']!=None:
                    image=domain_s+'image.tmdb.org/t/p/original/'+items['still_path']
                self.imagess.append(image)
                title=title+ ' פרק - '+str(int(self.episode)+1)+' '
                self.labelss.append(title)
                liz   = xbmcgui.ListItem(title)
                liz.setProperty('title_type', 'נגן את הפרק הבא - '+all_d[2])
                self.labelss1.append('נגן את הפרק הבא - '+all_d[2])
                
                liz.setProperty('image', image)
                liz.setProperty('discription',plot)
                self.plotss.append(plot)
                if '◄' in self.name:
                    liz.setProperty('pre', '100')

                
                self.list.addItem(liz)
            else:
                liz   = xbmcgui.ListItem(' פרק '+str(int(self.episode)+1))
                liz.setProperty('title_type', 'נגן את הפרק הבא - '+all_d[2])
                self.labelss1.append('נגן את הפרק הבא - '+all_d[2])
                
                liz.setProperty('image', '')
                liz.setProperty('discription','')
                self.plotss.append('')
                if '◄' in self.name:
                    liz.setProperty('pre', '100')

                
                self.list.addItem(liz)
            #current ep
            items=html['episodes'][int(self.episode)-1]
            title='[COLOR %s]'%color_current+items['name']+'[/COLOR] '
            plot='[COLOR khaki]'+items['overview']+'[/COLOR]'
            image=maste_image
            if items['still_path']!=None:
                image=domain_s+'image.tmdb.org/t/p/original/'+items['still_path']
            self.imagess.append(image)
            title=title+ ' פרק - '+self.episode+' '
            self.labelss.append(title)
     
                
            
            liz   = xbmcgui.ListItem(title)
            liz.setProperty('title_type', 'נגן פרק נוכחי - '+all_d[1])
            self.labelss1.append('נגן פרק נוכחי - '+all_d[1])
            liz.setProperty('image', image)
            liz.setProperty('discription',plot)
            self.plotss.append(plot)
            if '▲' in self.name:
                liz.setProperty('pre', '100')

            self.list.addItem(liz)
            

            
            #episodes
            
            title=master_name
            self.labelss.append(title)
            liz   = xbmcgui.ListItem(title)
            liz.setProperty('title_type', 'פתח את פרקי העונה')
            self.labelss1.append('פתח את פרקי העונה')
            liz.setProperty('image', maste_image)
            self.imagess.append(maste_image)
            liz.setProperty('discription',master_plot)
            self.plotss.append(master_plot)

            self.list.addItem(liz)
            
            #season ep
            
            title=self.heb_name
            self.labelss.append(title)
            liz   = xbmcgui.ListItem(title)
            liz.setProperty('title_type', 'פתח את בחירת העונה')
            self.labelss1.append('פתח את בחירת העונה')
            liz.setProperty('image', maste_image)
            self.imagess.append(maste_image)
            liz.setProperty('discription',master_plot)
            self.plotss.append(master_plot)

            self.list.addItem(liz)
            #choise=['נגן את הפרק הבא - '+all_d[2],'נגן פרק נוכחי - '+all_d[1],'פתח את פרקי העונה','פתח את בחירת העונה']
        elif all_d[2]==0:
            
            
            #current ep
            items=html['episodes'][int(self.episode)-1]
            title='[COLOR %s]'%color_current+items['name']+'[/COLOR] '
            plot='[COLOR khaki]'+items['overview']+'[/COLOR]'
            image=maste_image
            if items['still_path']!=None:
                image=domain_s+'image.tmdb.org/t/p/original/'+items['still_path']
            self.imagess.append(image)
            title=title+ ' פרק - '+self.episode+' '
                
            
                
            self.labelss.append(title)
            liz   = xbmcgui.ListItem(title)
            liz.setProperty('title_type', 'נגן פרק נוכחי - '+all_d[1])
            self.labelss1.append('נגן פרק נוכחי - '+all_d[1])
            liz.setProperty('image', image)
            liz.setProperty('discription',plot)
            self.plotss.append(plot)
            if '▲' in self.name:
                liz.setProperty('pre', '100')

            self.list.addItem(liz)
            
            #prev ep
            items=html['episodes'][int(self.episode)-2]
            title='[COLOR %s]'%color_prev+items['name']+'[/COLOR]'
            plot='[COLOR khaki]'+items['overview']+'[/COLOR]'
            image=maste_image
            if items['still_path']!=None:
                image=domain_s+'image.tmdb.org/t/p/original/'+items['still_path']
            self.imagess.append(image)
            title=title+ ' פרק - '+str(int(self.episode)-1)+' '
            self.labelss.append(title)
            liz   = xbmcgui.ListItem(title)
            liz.setProperty('title_type', 'נגן פרק קודם - '+all_d[0])
            self.labelss1.append( 'נגן פרק קודם - '+all_d[0])
            liz.setProperty('image', image)
            liz.setProperty('discription',plot)
            self.plotss.append(plot)
          

            
            self.list.addItem(liz)
            
            
            #episodes
            
            title=master_name
            self.labelss.append(title)
            liz   = xbmcgui.ListItem(title)
            liz.setProperty('title_type', 'פתח את פרקי העונה')
            self.labelss1.append('פתח את פרקי העונה')
            liz.setProperty('image', maste_image)
            self.imagess.append(maste_image)
            liz.setProperty('discription',master_plot)
            self.plotss.append(master_plot)

            self.list.addItem(liz)
            #season ep
            
            title=self.heb_name
            self.labelss.append(title)
            liz   = xbmcgui.ListItem(title)
            liz.setProperty('title_type', 'פתח את בחירת העונה')
            self.labelss1.append('פתח את בחירת העונה')
            liz.setProperty('image', maste_image)
            self.imagess.append(maste_image)
            liz.setProperty('discription',master_plot)
            self.plotss.append(master_plot)
 

            self.list.addItem(liz)
            #choise=['נגן פרק נוכחי - '+all_d[1],'נגן פרק קודם - '+all_d[0],'פתח את פרקי העונה','פתח את בחירת העונה']
        else:
            #next ep.
            logging.warning(len(html['episodes']))
            logging.warning(self.episode)
            if len(html['episodes'])>int(self.episode):
           
                items=html['episodes'][int(self.episode)]
                title='[COLOR %s]'%color_next+items['name']+'[/COLOR]'
                
                plot='[COLOR khaki]'+items['overview']+'[/COLOR]'
                image=maste_image
                if items['still_path']!=None:
                    image=domain_s+'image.tmdb.org/t/p/original/'+items['still_path']
                self.imagess.append(image)
                title=title+ ' פרק - '+str(int(self.episode)+1)+' '
            
                self.labelss.append(title)
                liz   = xbmcgui.ListItem(title)
                if 'magenta' not in all_d[2]:
                
                    liz.setProperty('title_type', 'נגן את הפרק הבא - '+all_d[2])
                    self.labelss1.append('נגן את הפרק הבא - '+all_d[2])
                else:
                    liz.setProperty('title_type', '[COLOR magenta]'+'נגן את הפרק הבא - '+'[/COLOR]'+all_d[2])
                    self.labelss1.append('[COLOR magenta]'+'נגן את הפרק הבא - '+'[/COLOR]'+all_d[2])
                liz.setProperty('image', image)
                liz.setProperty('discription',plot)
                self.plotss.append(plot)
                if '◄' in self.name:
                    liz.setProperty('pre', '100')

                
                self.list.addItem(liz)
            else:
                liz   = xbmcgui.ListItem(' פרק '+str(int(self.episode)+1))
                liz.setProperty('title_type', 'נגן את הפרק הבא - '+all_d[2])
                self.labelss1.append('נגן את הפרק הבא - '+all_d[2])
                
                liz.setProperty('image', '')
                liz.setProperty('discription','')
                self.plotss.append('')
                if '◄' in self.name:
                    liz.setProperty('pre', '100')

                
                self.list.addItem(liz)
            #current ep
            if len(html['episodes'])>(int(self.episode)-1):
                items=html['episodes'][int(self.episode)-1]
                title='[COLOR %s]'%color_current+items['name']+'[/COLOR]'
                plot='[COLOR khaki]'+items['overview']+'[/COLOR]'
                image=maste_image
                if items['still_path']!=None:
                    image=domain_s+'image.tmdb.org/t/p/original/'+items['still_path']
                self.imagess.append(image)
                title=title+ ' פרק - '+str(int(self.episode))+' '
                    
            else:
                title=' פרק - '+self.episode+' '
                plot=''
                image=maste_image
            self.labelss.append(title)
            liz   = xbmcgui.ListItem(title)
            liz.setProperty('title_type', 'נגן פרק נוכחי - '+all_d[1])
            self.labelss1.append('נגן פרק נוכחי - '+all_d[1])
            liz.setProperty('image', image)
            liz.setProperty('discription',plot)
            self.plotss.append(plot)
            if '▲' in self.name:
                liz.setProperty('pre', '100')

            self.list.addItem(liz)
            
            #prev ep
            if len(html['episodes'])>(int(self.episode)-2):
                items=html['episodes'][int(self.episode)-2]
                title='[COLOR %s]'%color_prev+items['name']+'[/COLOR]'
                plot='[COLOR khaki]'+items['overview']+'[/COLOR]'
                image=maste_image
                if items['still_path']!=None:
                    image=domain_s+'image.tmdb.org/t/p/original/'+items['still_path']
                self.imagess.append(image)
                title=title+ ' פרק - '+str(int(self.episode)-1)+' '
                self.labelss.append(title)
            else:
                title=' פרק - '+str(int(self.episode)-1)+' '
                plot=''
                image=maste_image
            liz   = xbmcgui.ListItem(title)
            liz.setProperty('title_type', 'נגן פרק קודם - '+all_d[0])
            self.labelss1.append('נגן פרק קודם - '+all_d[0])
            liz.setProperty('image', image)
            liz.setProperty('discription',plot)
            self.plotss.append(plot)
          

            
            self.list.addItem(liz)
                
            #episodes
            
            title=master_name
            self.labelss.append(title)
            liz   = xbmcgui.ListItem(title)
            liz.setProperty('title_type', 'פתח את פרקי העונה')
            self.labelss1.append('פתח את פרקי העונה')
            liz.setProperty('image', maste_image)
            self.imagess.append(maste_image)
            liz.setProperty('discription',master_plot)
            self.plotss.append(master_plot)

            self.list.addItem(liz)
            #season ep
            
            title=self.heb_name
            self.labelss.append(title)
            liz   = xbmcgui.ListItem(title)
            liz.setProperty('title_type', 'פתח את בחירת העונה')
            self.labelss1.append('פתח את בחירת העונה')
            liz.setProperty('image', maste_image)
            self.imagess.append(maste_image)
            liz.setProperty('discription',master_plot)
            self.plotss.append(master_plot)

            self.list.addItem(liz)
            

            '''
            if 'magenta' not in all_d[2]:
                 choise=['נגן את הפרק הבא - '+all_d[2],'נגן פרק נוכחי - '+all_d[1],'נגן פרק קודם - '+all_d[0],'פתח את פרקי העונה','פתח את בחירת העונה']
            else:
                 choise=['[COLOR magenta]'+'נגן את הפרק הבא - '+'[/COLOR]'+all_d[2],'נגן פרק נוכחי - '+all_d[1],'נגן פרק קודם - '+all_d[0],'פתח את פרקי העונה','פתח את בחירת העונה']
            '''



        self.setFocus(self.list)
        self.getControl(self.imagecontrol).setImage(self.imagess[0])
        self.getControl(self.bimagecontrol).setImage(maste_image)
        self.getControl(self.txtcontrol).setText(self.plotss[0])
        
        self.getControl(self.labelcontrol1).setLabel (self.labelss1[0])
        self.getControl(self.labelcontrol2).setLabel (self.labelss[0])
           
    def onAction(self, action):  
        actionId = action.getId()
        try:
            self.getControl(self.imagecontrol).setImage(self.imagess[self.list.getSelectedPosition()])
            self.getControl(self.txtcontrol).setText(self.plotss[self.list.getSelectedPosition()])
            self.getControl(self.labelcontrol1).setLabel (self.labelss1[self.list.getSelectedPosition()])
            self.getControl(self.labelcontrol2).setLabel (self.labelss[self.list.getSelectedPosition()])
        except:
            pass
        if actionId in [ACTION_CONTEXT_MENU, ACTION_C_KEY]:
            self.params = -1
            xbmc.sleep(100)
            return self.close()

        if actionId in [ACTION_PARENT_DIR, ACTION_PREVIOUS_MENU, ACTION_BACK]:
            self.params = -1
            return self.close()


    def onClick(self, controlId):
        
        if controlId != 3001:
        
            index = self.list.getSelectedPosition()        
            
           
            #self.getControl(self.txtcontrol).setText(self.plotss[index])
            try:    self.params = index
            except: self.params = None

        self.close()
        

    def onFocus(self, controlId):
        pass



def unzip(file,path):
       
        from zfile import ZipFile
        
        
        zip_file = file
        ptp = 'Masterpenpass'
        zf=ZipFile(zip_file)
        logging.warning('Extracting')
        listOfFileNames = zf.namelist()
        # Iterate over the file names
        for fileName in listOfFileNames:
            logging.warning(fileName)
        #zf.setpassword(bytes(ptp))
        #with ZipFile(zip_file) as zf:
        #zf.extractall(path)
        with ZipFile(zip_file, 'r') as zipObj:
           # Extract all the contents of zip file in current directory
           zipObj.extractall(path)
   
### fix setting####
def check_updated():
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
    'Accept': '*/*',
    'Accept-Language': 'en-US,en;q=0.5',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'X-Requested-With': 'XMLHttpRequest',
    'Connection': 'keep-alive',
    'Referer': 'https://www.strawpoll.me/4253672',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    'TE': 'Trailers',
    }
    
    with_rd='79827556'
    no_rd='79827559'
    if Addon.getSetting("rdsource")=='true':
        res=with_rd
    else:
        res=no_rd
    data = {
     
      'options': res
    }

    response = requests.post('https://www.strawpoll.me/4253672', headers=headers, data=data)
    #logging.warning(response)
def fix_setting(force=False):
    
    
    
    from shutil import copyfile
    version = Addon.getAddonInfo('version')
    ms=False
    if not os.path.exists(os.path.join(user_dataDir, 'version.txt')):
        ms=True
    else:
        file = open(os.path.join(user_dataDir, 'version.txt'), 'r') 
        file_data= file.readlines()
        file.close()
        if version not in file_data:
          ms=True
    if force==True:
        ms=True
    if ms:
        current_folder = os.path.dirname(os.path.realpath(__file__))
        change_log=os.path.join(current_folder,'changelog.txt')
        file = open(change_log, 'r') 
        news= file.read()
        file.close()
        sendy('Updated to version:'+version,'Update Vik','vikupdate')
        
        contact(title='ברוכים הבאים לגרסה -'+version ,msg=news)
        file = open(os.path.join(user_dataDir, 'version.txt'), 'w') 
        file.write(version)
        file.close()
        ClearCache()
        all_direct,all_google,all_rapid,all_heb=cache.get(get_server_types,0,'tv',  table='servers')
        all_direct,all_google,all_rapid,all_heb=cache.get(get_server_types,0,'movie', table='servers')
        '''
        window = whats_new('ברוכים הבאים לגרסה -'+version,'https://images-na.ssl-images-amazon.com/images/I/81WHLIZIBSL._SY679_.jpg',news)
        window.doModal()
        file = open(os.path.join(user_dataDir, 'version.txt'), 'w') 
        file.write(version)
        file.close()
        del window
        '''
    if not os.path.exists(os.path.join(user_dataDir, '4.0.0')):
        ok=xbmcgui.Dialog().yesno(("איפוס הגדרות"),('לאפס הגדרות ויקטורי?'))
        if ok:
                f_play=(os.path.join(addonPath, 'resources', 'victory.mpeg'))
                #xbmc.Player().play(f_play,windowed=True)
                if os.path.exists(os.path.join(addonPath, 'resources', 'settings.xml')):
                  os.remove(os.path.join(addonPath, 'resources', 'settings.xml'))
                if os.path.exists(os.path.join(user_dataDir, 'settings.xml')):
                  os.remove(os.path.join(user_dataDir, 'settings.xml'))
                copyfile(os.path.join(addonPath, 'resources', 'settings_base.xml'),os.path.join(addonPath, 'resources', 'settings.xml'))
                s_file= os.path.join(addonPath, 'resources', 'settings.xml')
                file = open(s_file, 'r') 
                file_data= file.read()
                file.close()
                onlyfiles = [f for f in listdir(done_dir) if isfile(join(done_dir, f))]
               
                onlyfiles=onlyfiles+[f for f in listdir(mag_dir) if isfile(join(mag_dir, f))]
                
                add_data_mag=''
                found=0
                
                for files in onlyfiles:
                 
                 
                  if 'magnet' in files and files !='general.py' and '.pyc' not in files and '.pyo' not in files and '__init__' not in files and files !='resolveurl_temp.py' and files!='cloudflare.py' and files!='Addon.py' and files!='cache.py':
                   
                   
                   files=files.replace('.py','')
                   f_txt=files
                  
                   
                  
                   if ('<setting id="%s" label="מקורות מ %s" type="bool" default="true" />'%(files,f_txt)) not in file_data:
                    add_data_mag=add_data_mag+'\n'+'	<setting id="%s" label="מקורות מ %s" type="bool" default="true" />'%(files,files)
                    
                    found=1

                    
                onlyfiles = [f for f in listdir(rd_dir) if isfile(join(rd_dir, f))]
                
                add_data_rd=''
                found=0
                for files in onlyfiles:
                 
                 
                  if files !='general.py' and '.pyc' not in files and '.pyo' not in files and '__init__' not in files and files !='resolveurl_temp.py' and files!='cloudflare.py' and files!='Addon.py' and files!='cache.py':
                   
                   
                   files=files.replace('.py','')
                   f_txt=files
                  
                   
                   
                   if ('<setting id="%s" label="מקורות מ %s" type="bool" default="true" />'%(files,f_txt)) not in file_data:
                    add_data_rd=add_data_rd+'\n'+'	<setting id="%s" label="מקורות מ %s" type="bool" default="true" />'%(files,files)
                    
                    found=1
                
                onlyfiles = [f for f in listdir(done_dir) if isfile(join(done_dir, f))]
               
                onlyfiles=onlyfiles+[f for f in listdir(mag_dir) if isfile(join(mag_dir, f))]
                add_data=''
                found=0
                all_t_time={}
                for i in range(0,2):
                    if i==0:
                        libDir = os.path.join(addonPath, 'resources', 'report_tv.txt')
                    else:
                        libDir = os.path.join(addonPath, 'resources', 'report_movie.txt')
                    logging.warning(libDir)
                    file = open(libDir, 'r') 
                    file_data_report= file.read()
                    file.close()
                    regex='Start(.+?)END'
                  
                    m=re.compile(regex,re.DOTALL).findall(file_data_report)
                   
                    
                    for items in m:
                        regex='\[(.+?)\].+?\{(.+?)\}<(.+?)>'
                        m2=re.compile(regex,re.DOTALL).findall(items)
                        for sname,stype,t_time in m2:
                            all_t_time[sname]=t_time
                    logging.warning(all_t_time)
                for files in onlyfiles:
                     
                 
                  if 'magnet' not in files and files !='general.py' and files !='magnet.py'  and '.pyc' not in files and '.pyo' not in files and '__init__' not in files and files !='resolveurl_temp.py' and files!='cloudflare.py' and files!='Addon.py' and files!='cache.py':
                   
                   f = open(join(done_dir,files), 'r')
                   file_data_test = f.read()
                   f.close()
                   regex="type=\[(.+?)\]"
              
                   match=re.compile(regex).findall(file_data_test)[0]

                   files=files.replace('.py','')
                   f_txt=files
                   if 'tv' not in match:
                        f_txt=f_txt+' [COLOR aqua] (רק סרטים) [/COLOR] '
                   if 'movie' not in match:
                        f_txt=f_txt+' [COLOR pink] (רק סדרות) [/COLOR] '
                   if 'subs' in match:
                        f_txt=f_txt+' [COLOR yellow] (תרגום מובנה) [/COLOR] '
                   if files in all_t_time:
                       if all_t_time[files]!='999':
                            f_txt=f_txt+'[COLOR khaki] <%s sec> [/COLOR]'%all_t_time[files]
                   if ('<setting id="%s" label="מקורות מ %s" type="bool" default="true" />'%(files,f_txt)) not in file_data:
                    add_data=add_data+'\n'+'	<setting id="%s" label="מקורות מ %s" type="bool" default="true" />'%(files,f_txt)
                    
                    found=1
                if found==1:
                  add_data=add_data+'\n'+'	#end#'
                  add_data_rd=add_data_rd+'\n'+'	#endRD#'
                  add_data_mag=add_data_mag+'\n'+'	#endTOR#'
                  file = open(s_file, 'w') 
                  file_data=file_data.replace('#end#',add_data)
                  file_data=file_data.replace('#endRD#',add_data_rd)
                  file_data=file_data.replace('#endTOR#',add_data_mag)
                  file.write(file_data)
                  file.close()
        file = open(os.path.join(user_dataDir, '4.0.0'), 'w') 
         
        file.write(str(version))
        file.close()
        


def PrintException():
    import linecache
    exc_type, exc_obj, tb = sys.exc_info()
    f = tb.tb_frame
    lineno = tb.tb_lineno
    filename = f.f_code.co_filename
    linecache.checkcache(filename)
    line = linecache.getline(filename, lineno, f.f_globals)
   
    return ( 'EXCEPTION IN ({}, LINE {} "{}"): {}'.format(filename, lineno, line.strip(), exc_obj))


def ClearCache():
    from storage import Storage
    import shutil
    cache.clear(['cookies', 'pages','posters'])
    Storage.open("parsers").clear()
    storage_path = os.path.join(xbmc.translatePath("special://temp"), ".storage")
    if os.path.isdir(storage_path):
        for f in os.listdir(storage_path):
            if re.search('.cache', f):
                os.remove(os.path.join(storage_path, f))

    cookies_path = xbmc.translatePath("special://temp")
    if os.path.isdir(cookies_path):
        for f in os.listdir(cookies_path):
            if re.search('.jar', f):
                os.remove(os.path.join(cookies_path, f))
    '''
    dataDir=os.path.join(user_dataDir,'cache_f','avegner')
    if  os.path.exists(dataDir):
        shutil.rmtree(dataDir)

    dataDir=os.path.join(user_dataDir,'cache_f','ghost')
    if  os.path.exists(dataDir):
        shutil.rmtree(dataDir)
    dataDir=os.path.join(user_dataDir,'cache_f','orn')
    if  os.path.exists(dataDir):
        shutil.rmtree(dataDir)
    dataDir=os.path.join(user_dataDir,'cache_f','dragon')
    if  os.path.exists(dataDir):
        shutil.rmtree(dataDir)
    dataDir=os.path.join(user_dataDir,'cache_f','ornm')
    if  os.path.exists(dataDir):
        shutil.rmtree(dataDir)
    dataDir=os.path.join(user_dataDir,'cache_f','mosh')
    if  os.path.exists(dataDir):
        shutil.rmtree(dataDir)
    '''
    xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'נוקה'.decode('utf8'))).encode('utf-8'))



#xbmc.executebuiltin(('Container.update("plugin://plugin.video.youtube/kodion/search/query/?q=venom")'))

        
class sources_window(pyxbmct.AddonDialogWindow):
    
    def __init__(self, title='',list=[],time_c=10,img=' ',txt=''):
        global list_index
        self.list_o=list
        super(sources_window, self).__init__('בחר מקור - '+' סה"כ מקורות:'+str(len(self.list_o)))
        
        self.title='בחר מקור'
        wd=int(1250)
        hd=int(700)
        px=int(10)
        py=int(10)
        list_index=888
        self.setGeometry(wd, hd, 10, 4,pos_x=px, pos_y=py)
        self.time_c=time_c
        self.img=img
        self.txt=txt
        self.set_info_controls()
        self.set_active_controls()
        self.set_navigation()
        # Connect a key action (Backspace) to close the window..
        self.connect(pyxbmct.ACTION_PREVIOUS_MENU, self.click_c)
        self.connect(pyxbmct.ACTION_NAV_BACK, self.click_c)
        
        
        
        #Thread(target=self.background_task).start()

    def set_info_controls(self):
      
      
         # Label
        #self.label = pyxbmct.Label('סה"כ מקורות:'+str(len(self.list_o)))
        #self.placeControl(self.label,  10, 2, 3, 1)
        self.image = pyxbmct.Image( self.img)
        self.placeControl(self.image, 0, 0, 2, 1)
        self.textbox = pyxbmct.TextBox()
        
        self.placeControl(self.textbox, 0,1, 2, 3)
        self.textbox.setText(self.txt)
        # Set auto-scrolling for long TexBox contents
        self.textbox.autoScroll(1000, 1000, 1000)
       
    def click_list(self):
        global list_index
        list_index=self.list.getSelectedPosition()
        
       
        logging.warning('Return Clicked')
        
        self.close()
    def click_c(self):
        logging.warning('Clicked Close')
        global list_index
        list_index=888
        current_list_item=''
        #self.setGeometry(400, 400, 10, 4,pos_x=px, pos_y=py)
        self.close()
    def set_active_controls(self):
     
      
        # List

        self.list = pyxbmct.List(font='font18', _imageWidth=75, _imageHeight=75, _itemTextXOffset=5, _itemTextYOffset=2, _itemHeight=55, _space=2, _alignmentY=4)
        self.placeControl(self.list, 2, 0,9, 4)
        # Add items to the list
        items = self.list_o
        n_items=[]
        a_links=[]
        icon_2160='http://www.dexonsystems.com/upload/public/images/DexonOthers/4k-uhd-logo-png.PNG'
        icon_1080='https://www.incehesap.com/resim/content/Webcam/Logitech_c920/Logitech_c920_9.png'
        icon_720='http://cctv.pcstown.com/ebay/bimg/New%20Wifi%20Cam/hd720p.png'
        icon_480='https://cdn3.iconfinder.com/data/icons/video-icons-2/299/480p-512.png'
        icon_360='https://cdn4.iconfinder.com/data/icons/proglyphs-multimedia/512/Standard_Definition-512.png'
        icon_un='https://cdn0.iconfinder.com/data/icons/basic-uses-symbol-vol-2/100/Help_Need_Suggestion_Question_Unknown-512.png'
        for it in items:
          if '$$$$$$$' not in it:
            text_i=it
            a_links.append(it)
          else:
              text_i=it.split('$$$$$$$')[0]
              a_links.append(it.split('$$$$$$$')[1])
          n_items.append(text_i)
          
          if '2160' in text_i:
            icon_q=icon_2160
          elif '1080' in text_i:
            icon_q=icon_1080
          elif '720' in text_i:
            icon_q=icon_720
          elif '480' in text_i:
            icon_q=icon_480
          elif '360' in text_i:
            icon_q=icon_360
          else:
            icon_q=icon_un
          
          
          item = xbmcgui.ListItem(label=text_i, iconImage=icon_q, thumbnailImage=icon_q)

          
          self.list.addItem(item)

        #self.list.addItems(n_items)
        # Connect the list to a function to display which list item is selected.
        self.connect(self.list, self.click_list)
        
        # Connect key and mouse events for list navigation feedback.
        
     
        
        self.button = pyxbmct.Button('Close')
        self.placeControl(self.button, 9, 3)
        # Connect control to close the window.
        self.connect(self.button, self.click_c)

    def set_navigation(self):
        # Set navigation between controls
        self.list.controlRight(self.button)
        self.list.controlLeft(self.button)
        #self.list.controlDown(self.button)
        self.button.controlUp(self.list)
        self.button.controlLeft(self.list)
        self.button.controlRight(self.list)
        # Set initial focus
        self.setFocus(self.list)
        
    def slider_update(self):
        # Update slider value label when the slider nib moves
        try:
            if self.getFocus() == self.slider:
                self.slider_value.setLabel('{:.1F}'.format(self.slider.getPercent()))
        except (RuntimeError, SystemError):
            pass

    def radio_update(self):
        # Update radiobutton caption on toggle
        if self.radiobutton.isSelected():
            self.radiobutton.setLabel('On')
        else:
            self.radiobutton.setLabel('Off')

    def list_update(self):
        # Update list_item label when navigating through the list.
        try:
            if self.getFocus() == self.list:
                self.list_item_label.setLabel(self.list.getListItem(self.list.getSelectedPosition()).getLabel())
            else:
                self.list_item_label.setLabel('')
        except (RuntimeError, SystemError):
            pass

    def setAnimation(self, control):
        # Set fade animation for all add-on window controls
        control.setAnimations([('WindowOpen', 'effect=fade start=0 end=100 time=1',),
                                ('WindowClose', 'effect=fade start=100 end=0 time=1',)])

class Thread(threading.Thread):
    def __init__(self, target, *args):
       
        self._target = target
        self._args = args
        
        
        threading.Thread.__init__(self)
        
    def run(self):
        
        self._target(*self._args)
        
tv_images={u'\u05d0\u05e7\u05e9\u05df \u05d5\u05d4\u05e8\u05e4\u05ea\u05e7\u05d0\u05d5\u05ea': 'http://stavarts.com/wp-content/uploads/2017/10/%D7%A9%D7%99%D7%A9%D7%99-%D7%94%D7%A8%D7%A4%D7%AA%D7%A7%D7%90%D7%95%D7%AA-%D7%AA%D7%A9%D7%A2%D7%B4%D7%97-%D7%A8%D7%90%D7%92%D7%A0%D7%90%D7%A8%D7%95%D7%A7_Page_1.jpg', u'\u05de\u05e1\u05ea\u05d5\u05e8\u05d9\u05df': 'http://avi-goldberg.com/wp-content/uploads/5008202002.jpg', u'\u05d9\u05dc\u05d3\u05d9\u05dd': domain_s+'i.ytimg.com/vi/sN4xfdDwjHk/maxresdefault.jpg', u'\u05de\u05e2\u05e8\u05d1\u05d5\u05df': domain_s+'i.ytimg.com/vi/Jw1iuGaNuy0/hqdefault.jpg', u'\u05e4\u05e9\u05e2': 'http://www.mapah.co.il/wp-content/uploads/2012/09/DSC_1210.jpg', u'\u05e8\u05d9\u05d0\u05dc\u05d9\u05d8\u05d9': 'http://blog.tapuz.co.il/oferD/images/%7B2D0A8A8A-7F57-4C8F-9290-D5DB72F06509%7D.jpg', u'\u05de\u05e9\u05e4\u05d7\u05d4': 'http://kaye7.school.org.il/photos/family.jpg', u'\u05e1\u05d1\u05d5\u05df': 'http://www.myliberty.co.il/media/com_hikashop/upload/2-1.jpg', u'\u05d7\u05d3\u05e9\u05d5\u05ea': domain_s+'shaza10.files.wordpress.com/2010/11/d790d795d79cd7a4d79f-d797d793d7a9-d797d793d7a9d795d7aa-10-d7a6d799d79cd795d79d-d7aad795d79ed7a8-d7a4d795d79cd798d799d79f03.jpg', u'\u05e7\u05d5\u05de\u05d3\u05d9\u05d4': domain_s+'upload.wikimedia.org/wikipedia/he/e/ef/Le_Tout_Nouveau_Testament.jpg', u'\u05d0\u05e0\u05d9\u05de\u05e6\u05d9\u05d4': 'http://www.printime.co.il/image/users/16584/ftp/my_files/smileynumbers1we.jpg', u'\u05de\u05d3\u05e2 \u05d1\u05d3\u05d9\u05d5\u05e0\u05d9 \u05d5\u05e4\u05e0\u05d8\u05d6\u05d9\u05d4': domain_s+'media.getbooks.co.il/catalog/product/cache/1/image/9df78eab33525d08d6e5fb8d27136e95/s/h/shemharuach_getbooks-copy.jpg', u'\u05d3\u05e8\u05de\u05d4': 'http://www.yorav.co.il/images/moshe+erela/2007/dram.JPG', u'\u05d3\u05d5\u05e7\u05d5\u05de\u05e0\u05d8\u05e8\u05d9': 'http://img.mako.co.il/2017/03/28/704104_I.jpg', u'\u05de\u05dc\u05d7\u05de\u05d4 \u05d5\u05e4\u05d5\u05dc\u05d9\u05d8\u05d9\u05e7\u05d4': domain_s+'dannyorbach.files.wordpress.com/2013/05/berlinsynagoge.jpg', u'\u05d3\u05d9\u05d1\u05d5\u05e8\u05d9\u05dd': 'http://www.news1.co.il/uploadimages/NEWS1-556713283061982.jpg'}
movie_images={u'\u05de\u05d5\u05e1\u05d9\u05e7\u05d4': 'http://www.blich.ramat-gan.k12.il/sites/default/files/files/music.jpg', u'\u05e1\u05e8\u05d8 \u05d8\u05dc\u05d5\u05d9\u05d6\u05d9\u05d4': domain_s+'i.ytimg.com/vi/hFc1821MSoA/hqdefault.jpg', u'\u05d4\u05e8\u05e4\u05ea\u05e7\u05d0\u05d5\u05ea': domain_s+'upload.wikimedia.org/wikipedia/he/3/38/%D7%94%D7%A8%D7%A4%D7%AA%D7%A7%D7%90%D7%95%D7%AA_%D7%91%D7%A8%D7%A0%D7%A8%D7%93_%D7%95%D7%91%D7%99%D7%90%D7%A0%D7%A7%D7%94_%D7%9B%D7%A8%D7%96%D7%94_%D7%A2%D7%91%D7%A8%D7%99%D7%AA.png', u'\u05de\u05e1\u05ea\u05d5\u05e8\u05d9\u05df': 'http://avi-goldberg.com/wp-content/uploads/5008202002.jpg', u'\u05de\u05e2\u05e8\u05d1\u05d5\u05df': domain_s+'i.ytimg.com/vi/Jw1iuGaNuy0/hqdefault.jpg', u'\u05de\u05dc\u05d7\u05de\u05d4': 'http://images.nana10.co.il/upload/mediastock/img/16/0/208/208383.jpg', u'\u05e4\u05e9\u05e2': 'http://www.mapah.co.il/wp-content/uploads/2012/09/DSC_1210.jpg', u'\u05e4\u05e0\u05d8\u05d6\u05d9\u05d4': 'http://blog.tapuz.co.il/beinhashurot/images/1943392_142.jpg', u'\u05de\u05e9\u05e4\u05d7\u05d4': 'http://kaye7.school.org.il/photos/family.jpg', u'\u05e7\u05d5\u05de\u05d3\u05d9\u05d4': domain_s+'upload.wikimedia.org/wikipedia/he/e/ef/Le_Tout_Nouveau_Testament.jpg', u'\u05d0\u05e0\u05d9\u05de\u05e6\u05d9\u05d4': 'http://www.printime.co.il/image/users/16584/ftp/my_files/smileynumbers1we.jpg', u'\u05d3\u05e8\u05de\u05d4': 'http://www.yorav.co.il/images/moshe+erela/2007/dram.JPG', u'\u05d4\u05e1\u05d8\u05d5\u05e8\u05d9\u05d4': domain_s+'medicine.ekmd.huji.ac.il/schools/occupationaltherapy/He/about/PublishingImages/%d7%aa%d7%9e%d7%95%d7%a0%d7%94%207.jpg', u'\u05e8\u05d5\u05de\u05e0\u05d8\u05d9': domain_s+'i.ytimg.com/vi/oUon62EIInc/maxresdefault.jpg', u'\u05d3\u05d5\u05e7\u05d5\u05de\u05e0\u05d8\u05e8\u05d9': 'http://img.mako.co.il/2017/03/28/704104_I.jpg', u'\u05d0\u05d9\u05de\u05d4': 'http://up203.siz.co.il/up2/y12o20immdyw.jpg', u'\u05de\u05d5\u05ea\u05d7\u05df': 'http://www.brz.co.il/wp-content/uploads/2014/06/11-350x350.jpg', u'\u05de\u05d3\u05e2 \u05d1\u05d3\u05d9\u05d5\u05e0\u05d9': domain_s+'upload.wikimedia.org/wikipedia/commons/c/cc/4pen.jpg', u'\u05d0\u05e7\u05e9\u05df': domain_s+'www.renne.co.il/wp-content/uploads/2017/07/actionsign.jpg'}

def get_custom_params(item):
        param=[]
        item=item.split("?")
        if len(item)>=2:
          paramstring=item[1]
          
          if len(paramstring)>=2:
                params=item[1]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     
def get_params():
        param=[]

        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     


def save_to_fav(plot):

    
    

    file_data=[]
    change=0
    cache.clear(['save_file'])
    if os.path.exists(save_file):
        f = open(save_file, 'r')
        file_data = f.readlines()
        f.close()
    
    if plot+'\n' not in file_data:
      file_data.append(plot)
      change=1
    for i in range (len(file_data)-1,0,-1):
         file_data[i]=file_data[i].replace('\n','')
         if len(file_data[i])<3:
          
          file_data.pop(i)
          change=1
    if change>0:
       
          file = open(save_file, 'w')
          file.write('\n'.join(file_data))
          file.close()
          xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'נשמר')).encode('utf-8'))

def get_tv_poster():


      import random
      all_img=[]
      url=domain_s+'api.themoviedb.org/3/tv/on_the_air?api_key=34142515d9d23817496eeb4ff1d223d0&language=en-US'
      x=requests.get(url).json()
      for items in x['results']:
          if 'backdrop_path' in items:
             if items['backdrop_path']==None:
              fan=' '
             else:
              fan=domain_s+'image.tmdb.org/t/p/original/'+items['backdrop_path']
              all_img.append(fan)
      random.shuffle(all_img)
      return all_img
def get_movie_poster():


      import random
      all_img=[]
      url=domain_s+'api.themoviedb.org/3/movie/now_playing?api_key=34142515d9d23817496eeb4ff1d223d0&language=en-US'
      x=requests.get(url).json()
      
      for items in x['results']:
          if 'backdrop_path' in items:
             if items['backdrop_path']==None:
              fan=' '
              all_img.append(fan)
             else:
              fan=domain_s+'image.tmdb.org/t/p/original/'+items['backdrop_path']
              all_img.append(fan)
          elif 'poster_path' in items:
            if items['poster_path']==None:
              fan=' '
              all_img.append(fan)
            else:
              fan=domain_s+'image.tmdb.org/t/p/original/'+items['poster_path']
              all_img.append(fan)
      random.shuffle(all_img)
      return all_img
def kids_world():
    tmdb_data_dir = os.path.join(addonPath, 'resources', 'tmdb_data')
    tmdb_cacheFile = os.path.join(tmdb_data_dir, 'youtube.db')
    dbcon = database.connect(tmdb_cacheFile)
    dbcur = dbcon.cursor()
    match=[('0')]
    match_tv=[('0')]
    try:
        dbcur.execute("SELECT * FROM updated where type='movies'")
        match = dbcur.fetchall()
        logging.warning(match)
        dbcur.execute("SELECT * FROM updated where type='tv'")
        match_tv = dbcur.fetchall()
        logging.warning(match)
    except:
        pass
    if len(match)==0:
        match=[('0')]
    if len(match_tv)==0:
        match_tv=[('0')]
    dbcur.close()
    dbcon.close()
    addDir3('סרטים מדובבים'.decode('utf8'),'0',11,domain_s+'www.flatpanelshd.com/pictures/despicableme2-1l.jpg','http://4k.com/wp-content/uploads/2014/11/toystory3_img10_720-790x442.jpg','סרטים מדובבים'.decode('utf8'),generes=match[0][0])
    addDir3('סדרות'.decode('utf8'),'www',45,'https://s11460.pcdn.co/wp-content/uploads/2016/02/travel_movies_for_kids_ratatouille.png','https://www.slashfilm.com/wp/wp-content/images/Astro-Boy.jpg','ילדים'.decode('utf8'),generes=match_tv[0][0])
    addDir3('סדרות לקטנטנים'.decode('utf8'),'www',48,'http://shiny4kwallpapers.com/Uploads/25-1-2017/328/thumb2-kids-snoopy-3d-animation-characters-the-peanuts.jpg','https://www.scienceabc.com/wp-content/uploads/2017/09/Childrans-watching-tv.jpg','קטנטנים'.decode('utf8'))
    addDir3('קדימונים לילדים'.decode('utf8'),'www',51,'https://imagesvc.timeincapp.com/v3/mm/image?url=https%3A%2F%2Fewedit.files.wordpress.com%2F2017%2F11%2Fanimationsplit.jpg%3Fw%3D2000&w=700&q=85','https://cdn1.thr.com/sites/default/files/imagecache/list_landscape_960x541/2017/08/coco_ferdinand_the_star_lego_ninjago_my_little_pony_-_split_-_publicity_-_h_2017_1.jpg','טרליירים'.decode('utf8'))
    addDir3('אנימה'.decode('utf8'),'www',52,'http://k07.kn3.net/4B4EFECF0.png','https://www.anime-spin.net/uploads/editor/kg81rxz.jpg','אנימה יפנים עם כתוביות בעברית'.decode('utf8'))
    addDir3('מצויירים באנגלית'.decode('utf8'),'www',58,'https://lh3.googleusercontent.com/oKtwR6_ZuDLhRmctqQ-HOVpHIf-KixoXSrWewH_2U7JX3d5JtA2A8a3dZc6MrAETl_7a=h253','https://images.wallpaperscraft.com/image/girls_und_panzer_nishizumi_miho_tank_hill_girl_100910_3840x2160.jpg','מצויירים באנגלית'.decode('utf8'))
    addDir3('מצויירים באנגלית מקור נוסף'.decode('utf8'),'www',68,'http://www.cartoon-media.eu/files/library/Cartoon-Movie/2018/JungleBunch_square.jpg?thumb=media-pt','http://digitalspyuk.cdnds.net/16/31/980x490/landscape-1470221630-cartoon-heroes.jpg','מצויירים באנגלית'.decode('utf8'))
    addLink('ערוץ סדרות ילדים','מדובב',94,False,iconimage='http://www.webtechlearning.com/wp-content/uploads/2014/04/Best-Animation.jpg',fanart='https://marionettestudio.com/wp-content/uploads/2016/11/22-despicable-me-2-animation-movie.jpg',description='ערוץ סדרות ילדים')
    
    addDir3('[COLOR yellow][I]חיפוש סרטים מדובבים[/I][/COLOR]'.decode('utf8'),'search',11,'http://2.bp.blogspot.com/-vDRXO2qGAFc/UyCAFd2LAPI/AAAAAAAAEco/pIfXWlRJG6Q/s1600/images+(9).jpg',domain_s+'i.pinimg.com/originals/c1/cb/ed/c1cbede7238494e7878f7107ed478d79.jpg','חיפוש סרטים מדובבים'.decode('utf8'))
    addDir3('[COLOR yellow][I]חיפוש סדרה מדובבת[/I][/COLOR]'.decode('utf8'),'search',45,'https://image.shutterstock.com/image-vector/modern-children-education-logo-happy-260nw-528357007.jpg','http://www.bhmpics.com/download/storks_4k_kids-2560x1440.jpg','חיפוש סדרה מדובבת'.decode('utf8'))
class SelectorDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        xbmcgui.WindowXMLDialog.__init__(self)
        self.title = kwargs['title']
        self.list_items=kwargs['list']
        self.f_list=[]
        self.steps = kwargs['steps']
       

        self.items = []
        self.selection = None
        self.insideIndex = -1
        self.completed_steps = 0
        xbmc.executebuiltin('Action(FullScreen)')
  
       

    def get_selection(self):
        """ get final selection """
        return self.selection

    def onInit(self):

        
        self.list = self.getControl(450)
        self.list.controlLeft(self.list)
        self.list.controlRight(self.list)

      
     
    
        self.setFocus(self.list)
        self._inside_root(select=1)
       

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216, 247, 257, 275, 61467, 61448,):
            if self.insideIndex == -1:
                self.close()
            else:
                self._inside_root(select=self.insideIndex)

    def onClick(self, controlID):
     
        
            num = self.list.getSelectedPosition()

            if num >= 0:
                if self.insideIndex == -1:
                    
                
                    self._inside(num)
                    self.selection=self.f_list[self.insideIndex]
                    self.close()

    def onFocus(self, controlID):
        if controlID in (3, 61):
            self.setFocus(self.list)

    def _inside_root(self, select=-1):
       
            #logging.warning(self.items)
            all_links=[]
            
            
            for items in self.list_items:
                    listitem = xbmcgui.ListItem(items)
                    self.list.addItem(listitem)
                    self.f_list.append(items)
            if select >= 0:
                self.list.selectItem(select)
            self.insideIndex = -1
    def _inside(self, num):
        if num == -1:
            self._inside_root(select=self.insideIndex)
            return

        if 1:#with self.lock:
            

            self.insideIndex = num
def main_menu():
      
      
      if len(sys.argv)<2:
       return 0
      dbcur.execute("SELECT COUNT(*) FROM AllData")
      fix_setting()
      match = dbcur.fetchone()
      level_index=(match[0]/100)
      if level_index>9:
        level_index=9
      logging.warning('level_index')
      logging.warning(level_index)
      addDir3('סרטים'.decode('utf8'),'www',13,BASE_LOGO+'m.png','http://hdqwalls.com/wallpapers/avengers-infinity-war-2018-poster-fan-made-62.jpg','סרטים'.decode('utf8'))
      addDir3('סדרות'.decode('utf8'),'www',14,BASE_LOGO+'s.png','https://i.imgur.com/a174Ipu.jpg','סדרות'.decode('utf8'))
      #addDir3('בא לי פרק'.decode('utf8'),'www',121,BASE_LOGO+'p.png','http://tve-static-eonline.nbcuni.com/prod/image/245/223/NightlyPop_S1_Desktop_FeaturedMain_3000x1688_1500x844_1425465411960.jpg','סרטים סדרות תרגום מובנה'.decode('utf8'))
      #addDir3('[COLOR olive][I]אלי סרטים[/I][/COLOR]'.decode('utf8'),'https://elie52tv.blogspot.com/',87,'https://yt3.ggpht.com/a-/AN66SAyXUDeW4O2XUbOzhQJI7aGjWqiQa68I9Ipl_g=s900-mo-c-c0xffffffff-rj-k-no','https://wallpapercave.com/wp/L9N1zGk.jpg','סדרות אחרונות תרגום מובנה'.decode('utf8'))
      addDir3('[COLOR olive][I]איפה הייתי...[/I][/COLOR]'.decode('utf8'),'https://elie52tv.blogspot.com/',158,'https://d2tml28x3t0b85.cloudfront.net/tracks/artworks/000/036/487/original/a03290.jpeg?1447873412','https://i.ytimg.com/vi/6vttDJZX_WU/maxresdefault.jpg','סרטים וסדרות שלא ראית עד הסוף...'.decode('utf8'))
      addDir3('[COLOR khaki]NBA[/COLOR]','https://www.nbafullhd.com',105,BASE_LOGO+'nba.png','https://cdn.nba.net/nba-drupal-prod/2017-08/SEO-image-NBA-logoman.jpg','NBA'.decode('utf8'))
      
      
      addDir3('[COLOR pink][I]פינת הילדים[/I][/COLOR]'.decode('utf8'),'www',44,BASE_LOGO+'k.png','https://www.desktopbackground.org/download/o/2013/09/27/645377_kids-kung-fu-panda-3-movie-4k-wallpapers_3840x2160_h.jpg','ילדים'.decode('utf8'))
      addDir3('לפי שחקן'.decode('utf8'),'www',72,BASE_LOGO+'ac.png','https://hdqwalls.com/download/avengers-infinity-war-imax-poster-na-2048x1152.jpg','לפי שחקן'.decode('utf8'))
      
      addDir3('חיפוש'.decode('utf8'),'www',15,BASE_LOGO+'se.png','https://geek-prime.com/wp-content/uploads/2014/02/Victory-2-4k-hd-wallpaper-invasion-ghaul.jpg','חיפוש'.decode('utf8'))
      addDir3('[COLOR orange][I]Live Sports[/I][/COLOR]'.decode('utf8'),'www',141,BASE_LOGO+'sport.png','https://scotch-res.cloudinary.com/image/upload/w_900,q_auto:good,f_auto/v1549206813/gyxlxwotow6xxysb527u.png','Live'.decode('utf8'))
      addDir3('[COLOR orange][I]ערוצים מהעולם[/I][/COLOR]'.decode('utf8'),'www',143,'https://upload.wikimedia.org/wikipedia/en/7/76/Channels_TV.jpg','http://smart-living-technology.com/wp-content/uploads/2018/07/HD-Antenna-Channels-modal_03.jpg','Live'.decode('utf8'))
      
      addDir3('[COLOR orange][I]רשימות JEN[/I][/COLOR]'.decode('utf8'),'www',42,BASE_LOGO+'jen.png','https://geek-prime.com/wp-content/uploads/2014/02/Victory-2-4k-hd-wallpaper-invasion-ghaul.jpg','חיפוש'.decode('utf8'))
      
      
      addDir3('[COLOR lightcoral][I]רשימות M3u8[/I][/COLOR]'.decode('utf8'),'www',55,BASE_LOGO+'m3u.png','https://indianapublicmedia.org/wp-content/themes/ipm-aux-services/images/services/transmission.jpg','חיפוש'.decode('utf8'))
      addDir3('[COLOR deepskyblue][I]Acestream[/I][/COLOR]'.decode('utf8'),'www',76,BASE_LOGO+'ace.png','https://i.pinimg.com/originals/6b/18/31/6b1831503dc0e0470b2bf1e1b5df978f.jpg','Acestream'.decode('utf8'))
      
      addDir3('[COLOR yellow][I]4K אמיתי[/I][/COLOR]'.decode('utf8'),'www',160,'https://i.ytimg.com/vi/mkggXE5e2yk/maxresdefault.jpg','https://i.ytimg.com/vi/NPo1WRnP8TI/maxresdefault.jpg','כנסו לראות איך נראה 4K אמיתי'.decode('utf8'))
      
      addDir3('חיפוש טורנטים ידני'.decode('utf8'),'all',111,BASE_LOGO+'tor.png','https://www.devilhax.com/wp-content/uploads/2018/06/Top-23-Torrent-Sites-list-which-works.png','חיפוש טורנטים ידני'.decode('utf8'))
      
      addDir3('מועדפים'.decode('utf8'),'all',18,BASE_LOGO+'fav.png',BASE_LOGO+'fav.png','מועדפים'.decode('utf8'))
      if Addon.getSetting("use_trak")=='true':
        addDir3('רשימות Trakt'.decode('utf8'),'www',29,'http://koditips.com/wp-content/uploads/trakt-api-key.png',domain_s+'www.mjdtech.net/content/images/2016/02/traktfeat.jpg','רשימות Trakt')
      addDir3('[COLOR khaki][I]תיקון כל בעיות קודי 18[/I][/COLOR]'.decode('utf8'),'www',139,'https://upload.wikimedia.org/wikipedia/commons/6/68/No_18.png','https://iwf1.com/wordpress/wp-content/uploads/2017/02/Fix-Kodi-17-crashes-due-to-incompatible-add-ons.jpg','תיקון כל בעיות קודי 18'.decode('utf8'))
      
      #addDir3('ערוצי סרטים וסדרות'.decode('utf8'),'www',38,BASE_LOGO+'chan.jpg','https://i1.wp.com/socialperiodico.it/wp-content/uploads/2017/01/shadowhunters.jpg?fit=1600%2C900&ssl=1','ערוצי סרטים וסדרות')
      
      addNolink('ניקוי מטמון','www',16,False,iconimage=BASE_LOGO+'cach.png',fanart=domain_s+'digitalart.io/storage/artworks/1264/pacific-rim-wallpaper-striker.jpeg')
      addNolink('[COLOR khaki][I]שחזור מגיבוי קודם[/I][/COLOR]','www',89,False,iconimage=BASE_LOGO+'rest.png',fanart='https://hiverhq.com/blog/wp-content/uploads/2014/11/best-backup-tools-for-Google-Apps-and-Gmail-1.jpg')
      addNolink('רשימת שינויים','www',100,False,iconimage=BASE_LOGO+'chang.png',fanart='https://one2onenetwork.com/wp-content/uploads/2011/06/things-to-change-t2c-list.jpg')
      addDir3('[COLOR yellow][I]בדיקת שרתים[/I][/COLOR]'.decode('utf8'),'www',98,BASE_LOGO+'serv.png','https://wallpaperstock.net/wallpapers/thumbs1/8901wide.jpg','בדיקת שרתים'.decode('utf8'))
      addNolink('פתח הגדרות','www',24,False,iconimage=BASE_LOGO+'sett.png',fanart=domain_s+'www.wanderlustworker.com/wp-content/uploads/2014/05/setting-smarter-goals.jpg')
      plot='[COLOR gold]'+'אתה כרגע בשלב '+str(level_index+1)+'\n'+'עד עכשיו צפית ב '+str(match[0]) +' סרטים ופרקים '+' תמשיך ככה.... '+'[/COLOR]'+'\nעוד ' +str((100*(level_index+1))-int(match[0]))+' כדי לעבור לשלב הבא :-)'
      addLink('[COLOR khaki][I]'+'הדירוג שלי'+'[/I][/COLOR]',level_movies[level_index],35,False,iconimage=level_images[level_index],fanart=level_fanart[level_index],description=plot)
      addDir3('[COLOR skyblue][I]אחרונים שהופעלו[/I][/COLOR]'.decode('utf8'),'www',49,BASE_LOGO+'last.png','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQgZlTxhsnI3lZ9gzBokPvapZG1W3S-_G1UNCohkK5il9r5myUF','אחרונים שהופעלו'.decode('utf8'))
def bali_perek():
    addDir3('[COLOR lightblue][I]תוכן ישראלי[/I][/COLOR]'.decode('utf8'),'www',81,'https://www.vectorportal.com/img_novi/Israel-flag-paint-publicdom.jpg','https://images1.ynet.co.il//PicServer5/2017/10/11/8084192/808365901002380640360no.jpg','סרטים וסדרות ישראליות חדשות (שים לב מקורות יהיו רק לתוכן חדש... סורי'.decode('utf8'))
    addDir3('[COLOR burlywood][I]מקום חדש[/I][/COLOR]'.decode('utf8'),'www',84,'https://static1.squarespace.com/static/56a13391d8af108f38f826ff/56a2139a1f403921c70b6ec3/5afad0da758d462161632695/1529762605167/JANE_NEWLAND_FRENCHSKYBLUE+web.jpg?format=300w','http://jeff-thomas.net/wp-content/uploads/2016/01/Lookout-1.jpg','סדרות תרגום מובנה, סדרות ישראליות, אירועי האבקות'.decode('utf8'))
    addDir3('[COLOR lightgreen][I]הסתדרתי[/I][/COLOR]'.decode('utf8'),'www',122,'https://imgrosetta.mynet.com.tr/file/1876748/728xauto.jpg','https://mir-s3-cdn-cf.behance.net/project_modules/max_1200/4364f842552409.57d01512b4a87.jpg','סדרות תרגום מובנה, סדרות ישראליות, '.decode('utf8'))
def movies_menu():
      import datetime
      #all_img=get_movie_poster()
      now = datetime.datetime.now()
      link_url='https://www.youtube.com/results?search_query=%D7%98%D7%A8%D7%99%D7%99%D7%9C%D7%A8+%D7%9E%D7%AA%D7%95%D7%A8%D7%92%D7%9D+{0}&page=1'.format( str(now.year))
    
      all_img=cache.get(get_movie_poster,24, table='posters')
                                                                                            
      addDir3('סגנונות'.decode('utf8'),'http://api.themoviedb.org/3/genre/movie/list?api_key=34142515d9d23817496eeb4ff1d223d0&language=he&page=1',2,BASE_LOGO+'generes_m.png',all_img[0],'סרטים'.decode('utf8'))
      addDir3('סרטים פופולרים'.decode('utf8'),'http://api.themoviedb.org/3/movie/popular?api_key=34142515d9d23817496eeb4ff1d223d0&language=he&page=1',3,BASE_LOGO+'pop.png',all_img[4],'סרטים פופולרים'.decode('utf8'))
      if Addon.getSetting("unfilter_test")=='998':
        search_entered=''
    

        keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש כאן')
        keyboard.doModal()
        if keyboard.isConfirmed():
                search_entered = keyboard.getText()
                if search_entered=='554':
                    addDir3('Hidden'.decode('utf8'),'http://api.tmdb.org/3/discover/movie?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&certification=NC-17&certification_country=US&sort_by=vote_average.des&sort_by=popularity.desc&language=he&page=1',3,BASE_LOGO+'pop.png',all_img[4],'סרטים פופולרים'.decode('utf8'))
      
      addDir3('כתוביות מובנות בקליק'.decode('utf8'),'http://api.themoviedb.org/3/movie/popular?api_key=34142515d9d23817496eeb4ff1d223d0&language=he&page=1',144,'https://i0.wp.com/everydayelectronics.com/wp-content/uploads/2018/12/PhotoGrid_1544751030857.png?fit=1400%2C787&ssl=1',all_img[18],'כתוביות מובנות בקליק'.decode('utf8'))
      
      addDir3('אחרוני המאסטרים'.decode('utf8'),'0',147,'https://www.discshop.se/img/omslag/front_large/3/78583.jpg',all_img[19],'סרטים אחרונים שהועלו ע"י המאסטרים'.decode('utf8'))
      
      addDir3('One Click'.decode('utf8'),'movie',155,'https://d1yjjnpx0p53s8.cloudfront.net/imagotipo_base_0.jpg?3DHWwoLmtUZS8h6XdueCrU4Cy1CZVZmD',all_img[2],'Once click movies'.decode('utf8'),data='1')
      
      
      addDir3('כל אוספי הסרטים'.decode('utf8'),'0',149,'https://img.creativemark.co.uk/uploads/images/353/12353/largeImg.png',all_img[1],'מארזי סרטים'.decode('utf8'))
      
      addDir3('פופלרים ב20 שנה האחרונות'.decode('utf8'),'movie',133,BASE_LOGO+'20.png',all_img[11],'סרטים פופולרים'.decode('utf8'),data='20',original_title='1')
      
      addDir3('פופולרים ב10 שנים האחרונות'.decode('utf8'),'movie',133,'https://previews.123rf.com/images/fsettler/fsettler1206/fsettler120600010/14239678-favorite-movie-icon.jpg',all_img[12],'סרטים פופולרים'.decode('utf8'),data='10',original_title='1')
      
      addDir3('[COLOR red]הסרטים החמים[/COLOR]'.decode('utf8'),'http://api.themoviedb.org/3/trending/movie/week?api_key=34142515d9d23817496eeb4ff1d223d0&language=he&page=1',3,BASE_LOGO+'hot.png',all_img[13],'הסרטים הלוהטים'.decode('utf8'))
      addDir3('[COLOR khaki]בקולנוע[/COLOR]'.decode('utf8'),'http://api.themoviedb.org/3/movie/now_playing?api_key=34142515d9d23817496eeb4ff1d223d0&language=he&page=1',3,BASE_LOGO+'thea.png',all_img[10],'סרטים בקולנוע'.decode('utf8'))
      addDir3('[COLOR lightbrown]דוקומנטרי עם כתוביות[/COLOR]'.decode('utf8'),'www',125,BASE_LOGO+'doco.png',all_img[12],'דוקומנטרי עם כתוביות'.decode('utf8'))
      addDir3('[COLOR gold]טריילרים עם כתוביות[/COLOR]'.decode('utf8'),link_url,116,BASE_LOGO+'tre.png',all_img[11],'טריילרים עם כתוביות'.decode('utf8'))
      addDir3('כתוביות אחרונות'.decode('utf8'),'www',80,BASE_LOGO+'sub.png','https://youprogrammer.com/wp-content/uploads/2018/01/MOvies-subtitle-download-sites.png','כתוביות אחרונות'.decode('utf8'))
      
      addDir3('כתוביות לפי שנים'.decode('utf8'),'years',80,BASE_LOGO+'subyear.png','https://zenithwebsite.com/images/Portweb/doofreemovie-EX1.jpg','כתוביות לפי שנים'.decode('utf8'))
      addDir3('סרטים לפי שנים'.decode('utf8'),'movie_years&page=1',3,BASE_LOGO+'movy.png',all_img[2],'סרטים לפי שנים'.decode('utf8'))
      addDir3('[COLOR gold][I]מבוסס על סיפור אמיתי[/I][/COLOR]'.decode('utf8'),'https://www.imdb.com/search/title?genres=biography&sort=num_votes,desc&explore=title_type,genres',114,BASE_LOGO+'true.png',all_img[14],'סרטים שחייבים לראות'.decode('utf8'),isr=0)
      
      addDir3('[COLOR gold][I]זוכי אוסקר לסרט הטוב ביותר[/I][/COLOR]'.decode('utf8'),'https://www.imdb.com/search/title?count=100&groups=oscar_best_picture_winners&sort=year,desc&ref_=nv_ch_osc',114,BASE_LOGO+'oscarm.png',all_img[16],'סרטים זוכי אוסקר'.decode('utf8'),isr=0)
      
      addDir3('[COLOR gold][I]זוכי אוסקר שחקן הטוב ביותר[/I][/COLOR]'.decode('utf8'),'https://www.imdb.com/list/ls068045646/?sort=list_order,asc&mode=detail&page=1',134,BASE_LOGO+'oscarp.png',all_img[17],'סרטים זוכי אוסקר'.decode('utf8'),isr=0)
      
      
      addDir3('[COLOR aqua]סרטים ישראלים[/COLOR]'.decode('utf8'),'www',57,BASE_LOGO+'isr.png','https://www.israelhayom.co.il/sites/default/files/styles/566x349/public/images/articles/2017/08/22/15034285934653_b.jpg','סרטים ישראלים'.decode('utf8'),isr=1)
      addDir3('[COLOR blue]סרטי מורידים[/COLOR]'.decode('utf8'),'0',130,BASE_LOGO+'mordi.png','https://images1.calcalist.co.il/PicServer2/20122005/329369/20_l.jpg','סרטי מורידים'.decode('utf8'),isr=0)
      
      addDir3('[COLOR red]סרטים לפי אולפן[/COLOR]'.decode('utf8'),'movie',112,BASE_LOGO+'ulpan.png','https://cdn-static.denofgeek.com/sites/denofgeek/files/styles/main_wide/public/2016/04/movlic_studios_1.jpg?itok=ih8Z7wOk','סרטים לפי אולפן כמו MARVEL ,DC ...'.decode('utf8'))
      
      addDir3('[COLOR gold][I]הכי פופולריות של IMDB[/I][/COLOR]'.decode('utf8'),'https://www.imdb.com/chart/moviemeter?ref_=nv_mv_mpm',114,BASE_LOGO+'imdbp.png',all_img[15],'סרטים שחייבים לראות'.decode('utf8'),isr=0)
      
      addDir3('סרטים מועדפים'.decode('utf8'),'movies',18,BASE_LOGO+'fav.png','http://4.bp.blogspot.com/-8q4ops3bX_0/T0TWUOu5ETI/AAAAAAAAA1A/AQMDv0Sv4Cs/s1600/logo1.gif','מועדפים'.decode('utf8'))
      addDir3('נצפה לאחרונה'.decode('utf8'),'movie',91,domain_s+'images.gr-assets.com/books/1485469752l/33260180.jpg',all_img[7],'סרטים אחרונים שנצפו'.decode('utf8'),isr=0)
      dbcur.execute("SELECT * FROM lastlinkmovie WHERE o_name='f_name'")

      match = dbcur.fetchone()
      if match!=None:
       f_name,name,url,iconimage,fanart,description,data,season,episode,original_title,saved_name,heb_name,show_original_year,eng_name,isr,prev_name,id=match
       try:
           if url!=' ':
             if 'http' not  in url:
           
               url=url.decode('base64')
              
             addLink('[COLOR yellow][I]הפעל לינק אחרון שהופעל[/I][/COLOR]', 'latest_movie',5,False,iconimage,fanart,description,data=show_original_year,original_title=original_title,season=season,episode=episode,id=id,saved_name=saved_name,prev_name=prev_name,eng_name=eng_name,heb_name=heb_name,show_original_year=show_original_year)
       except  Exception as e:
         logging.warning(e)
         pass
      
      addDir3('חפש סרט'.decode('utf8'),'http://api.themoviedb.org/3/search/movie?api_key=34142515d9d23817496eeb4ff1d223d0&query=%s&language=he&append_to_response=origin_country&page=1',3,domain_s+'cellcomtv.cellcom.co.il/globalassets/cellcomtv/content/sratim/pets-secret-life/480x543-template.jpg','http://www.videomotion.co.il/wp-content/uploads/whatwedo-Pic-small.jpg','חפש סרט'.decode('utf8'))
      addDir3('[COLOR lightblue]חיפושים קודמים[/COLOR]'.decode('utf8'),'movie',151,domain_s+'img.wcdn.co.il/f_auto,w_700,t_18/1/0/7/2/1072572-46.jpg',domain_s+'f.frogi.co.il/news/640x300/010170efc8f.jpg','חיפושים קודמים'.decode('utf8'))
      addDir3('בחירת תוכן מתקדם'.decode('utf8'),'advance_movie',3,'https://filmgator.com/black/pics/tour_search.png','https://cdn0.tnwcdn.com/wp-content/blogs.dir/1/files/2010/03/movies.jpg','חיפוש מתקדם'.decode('utf8'))
      addDir3('[I]מומלצים עבורך[/I]'.decode('utf8'),'movie',26,domain_s+'i.pinimg.com/564x/fc/79/15/fc79150482303ac1d7e4d7133c8c5d6e--candida-overgrowth-candida-diet.jpg',all_img[14],'סרטים מומלצים עבורך לפי הסטוריית הצפייה שלך'.decode('utf8'),isr=0)
      addDir3('[I]שחרורי HD אחרונים[/I]'.decode('utf8'),domain_s+'www.dvdsreleasedates.com/movies/',28,domain_s+'seeklogo.com/images/F/Full_HD_1080-logo-EF7336DA95-seeklogo.com.png',all_img[5],'שחרורי HD אחרונים'.decode('utf8'),isr=0)
      
      addDir3('[COLOR gold]תן לי באיכות[/COLOR]'.decode('utf8'),domain_s+'www.mehlizmovieshd.com/genre/4k-2160p-movies/',10,'http://cdn.techgyd.com/150-Most-Amazing-4K-Wallpaper-for-your-Devices-42.jpg',domain_s+'i.ytimg.com/vi/vrbaJ1_FPq0/maxresdefault.jpg','סרטי 4K'.decode('utf8'))
def tv_neworks():
    if Addon.getSetting("order_networks")=='0':
        order_by='popularity.desc'
    elif Addon.getSetting("order_networks")=='2':
        order_by='vote_average.desc'
    elif Addon.getSetting("order_networks")=='1':
        order_by='first_air_date.desc'
    addDir3('[COLOR lightblue]Disney+[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=2739&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),3,'https://lumiere-a.akamaihd.net/v1/images/image_308e48ed.png','https://allears.net/wp-content/uploads/2018/11/wonderful-world-of-animation-disneys-hollywood-studios.jpg','Disney'.decode('utf8'))
    
    addDir3('[COLOR blue]Apple TV+[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=2552&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),3,'https://ksassets.timeincuk.net/wp/uploads/sites/55/2019/03/Apple-TV-screengrab-920x584.png','https://www.apple.com/newsroom/videos/apple-tv-plus-/posters/Apple-TV-app_571x321.jpg.large.jpg','Apple'.decode('utf8'))
    
    addDir3('[COLOR red]NetFlix[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=213&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),3,'https://art.pixilart.com/705ba833f935409.png','https://i.ytimg.com/vi/fJ8WffxB2Pg/maxresdefault.jpg','NetFlix'.decode('utf8'))
    addDir3('[COLOR gray]HBO[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=49&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),3,'https://filmschoolrejects.com/wp-content/uploads/2018/01/hbo-logo.jpg','https://www.hbo.com/content/dam/hbodata/brand/hbo-static-1920.jpg','HBO'.decode('utf8'))
    addDir3('[COLOR lightblue]CBS[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=16&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),3,'https://cdn.freebiesupply.com/logos/large/2x/cbs-logo-png-transparent.png','https://tvseriesfinale.com/wp-content/uploads/2014/10/cbs40-590x221.jpg','HBO'.decode('utf8'))
    addDir3('[COLOR purple]SyFy[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=77&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),3,'http://cdn.collider.com/wp-content/uploads/syfy-logo1.jpg','https://imagesvc.timeincapp.com/v3/mm/image?url=https%3A%2F%2Fewedit.files.wordpress.com%2F2017%2F05%2Fdefault.jpg&w=1100&c=sc&poi=face&q=85','SyFy'.decode('utf8'))
    addDir3('[COLOR lightgreen]The CW[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=71&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),3,'https://www.broadcastingcable.com/.image/t_share/MTU0Njg3Mjc5MDY1OTk5MzQy/tv-network-logo-cw-resized-bc.jpg','https://i2.wp.com/nerdbastards.com/wp-content/uploads/2016/02/The-CW-Banner.jpg','The CW'.decode('utf8'))
    addDir3('[COLOR silver]ABC[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=2&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),3,'http://logok.org/wp-content/uploads/2014/03/abc-gold-logo-880x660.png','https://i.ytimg.com/vi/xSOp4HJTxH4/maxresdefault.jpg','ABC'.decode('utf8'))
    addDir3('[COLOR yellow]NBC[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=6&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),3,'https://designobserver.com/media/images/mondrian/39684-NBC_logo_m.jpg','https://www.nbcstore.com/media/catalog/product/cache/1/image/1000x/040ec09b1e35df139433887a97daa66f/n/b/nbc_logo_black_totebagrollover.jpg','NBC'.decode('utf8'))
    addDir3('[COLOR gold]AMAZON[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=1024&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),3,'http://g-ec2.images-amazon.com/images/G/01/social/api-share/amazon_logo_500500._V323939215_.png','https://cdn.images.express.co.uk/img/dynamic/59/590x/Amazon-Fire-TV-Amazon-Fire-TV-users-Amazon-Fire-TV-stream-Amazon-Fire-TV-Free-Dive-TV-channel-Amazon-Fire-TV-news-Amazon-1010042.jpg?r=1535541629130','AMAZON'.decode('utf8'))
    addDir3('[COLOR green]hulu[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=453&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),3,'https://i1.wp.com/thetalkinggeek.com/wp-content/uploads/2012/03/hulu_logo_spiced-up.png?resize=300%2C225&ssl=1','https://www.google.com/url?sa=i&rct=j&q=&esrc=s&source=images&cd=&cad=rja&uact=8&ved=2ahUKEwi677r77IbeAhURNhoKHeXyB-AQjRx6BAgBEAU&url=https%3A%2F%2Fwww.hulu.com%2F&psig=AOvVaw0xW2rhsh4UPsbe8wPjrul1&ust=1539638077261645','hulu'.decode('utf8'))
def movie_prodiction():
    if Addon.getSetting("order_networks")=='0':
        order_by='popularity.desc'
    elif Addon.getSetting("order_networks")=='2':
        order_by='vote_average.desc'
    elif Addon.getSetting("order_networks")=='1':
        order_by='first_air_date.desc'
   
    
    addDir3('[COLOR red]Marvel[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=7505&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),3,'https://yt3.ggpht.com/a-/AN66SAwQlZAow0EBMi2-tFht-HvmozkqAXlkejVc4A=s900-mo-c-c0xffffffff-rj-k-no','https://images-na.ssl-images-amazon.com/images/I/91YWN2-mI6L._SL1500_.jpg','Marvel'.decode('utf8'))
    addDir3('[COLOR lightblue]DC Studios[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=9993&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),3,'https://pmcvariety.files.wordpress.com/2013/09/dc-comics-logo.jpg?w=1000&h=563&crop=1','http://www.goldenspiralmedia.com/wp-content/uploads/2016/03/DC_Comics.jpg','DC Studios'.decode('utf8'))
    addDir3('[COLOR lightgreen]Lucasfilm[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=1&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),3,'https://fontmeme.com/images/lucasfilm-logo.png','https://i.ytimg.com/vi/wdYaG3o3bgE/maxresdefault.jpg','Lucasfilm'.decode('utf8'))
    addDir3('[COLOR yellow]Warner Bros.[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=174&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),3,'http://looking.la/wp-content/uploads/2017/10/warner-bros.png','https://cdn.arstechnica.net/wp-content/uploads/2016/09/warner.jpg','SyFy'.decode('utf8'))
    addDir3('[COLOR blue]Walt Disney Pictures[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=2&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),3,'https://i.ytimg.com/vi/9wDrIrdMh6o/hqdefault.jpg','https://vignette.wikia.nocookie.net/logopedia/images/7/78/Walt_Disney_Pictures_2008_logo.jpg/revision/latest?cb=20160720144950','Walt Disney Pictures'.decode('utf8'))
    addDir3('[COLOR skyblue]Pixar[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=3&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),3,'https://elestoque.org/wp-content/uploads/2017/12/Pixar-lamp.png','https://wallpapercave.com/wp/GysuwJ2.jpg','Pixar'.decode('utf8'))
    addDir3('[COLOR deepskyblue]Paramount[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=4&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),3,'https://upload.wikimedia.org/wikipedia/en/thumb/4/4d/Paramount_Pictures_2010.svg/1200px-Paramount_Pictures_2010.svg.png','https://vignette.wikia.nocookie.net/logopedia/images/a/a1/Paramount_Pictures_logo_with_new_Viacom_byline.jpg/revision/latest?cb=20120311200405&format=original','Paramount'.decode('utf8'))
    addDir3('[COLOR burlywood]Columbia Pictures[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=5&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),3,'https://static.tvtropes.org/pmwiki/pub/images/lady_columbia.jpg','https://vignette.wikia.nocookie.net/marveldatabase/images/1/1c/Columbia_Pictures_%28logo%29.jpg/revision/latest/scale-to-width-down/1000?cb=20141130063022','Columbia Pictures'.decode('utf8'))
    addDir3('[COLOR powderblue]DreamWorks[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=7&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),3,'https://www.dreamworksanimation.com/share.jpg','https://www.verdict.co.uk/wp-content/uploads/2017/11/DA-hero-final-final.jpg','DreamWorks'.decode('utf8'))
    addDir3('[COLOR lightsaltegray]Miramax[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=14&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),3,'https://vignette.wikia.nocookie.net/disney/images/8/8b/1000px-Miramax_1987_Print_Logo.png/revision/latest?cb=20140902041428','https://i.ytimg.com/vi/4keXxB94PJ0/maxresdefault.jpg','Miramax'.decode('utf8'))
    addDir3('[COLOR gold]20th Century Fox[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=25&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),3,'https://pmcdeadline2.files.wordpress.com/2017/03/20th-century-fox-cinemacon1.jpg?w=446&h=299&crop=1','https://vignette.wikia.nocookie.net/simpsons/images/8/80/TCFTV_logo_%282013-%3F%29.jpg/revision/latest?cb=20140730182820','20th Century Fox'.decode('utf8'))
    addDir3('[COLOR bisque]Sony Pictures[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=34&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),3,'https://upload.wikimedia.org/wikipedia/commons/thumb/6/63/Sony_Pictures_Television_logo.svg/1200px-Sony_Pictures_Television_logo.svg.png','https://vignette.wikia.nocookie.net/logopedia/images/2/20/Sony_Pictures_Digital.png/revision/latest?cb=20140813002921','Sony Pictures'.decode('utf8'))
    addDir3('[COLOR navy]Lions Gate Films[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=35&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),3,'http://image.wikifoundry.com/image/1/QXHyOWmjvPRXhjC98B9Lpw53003/GW217H162','https://vignette.wikia.nocookie.net/fanon/images/f/fe/Lionsgate.jpg/revision/latest?cb=20141102103150','Lions Gate Films'.decode('utf8'))
    addDir3('[COLOR beige]Orion Pictures[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=41&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),3,'https://i.ytimg.com/vi/43OehM_rz8o/hqdefault.jpg','https://i.ytimg.com/vi/g58B0aSIB2Y/maxresdefault.jpg','Lions Gate Films'.decode('utf8'))
    addDir3('[COLOR yellow]MGM[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=21&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),3,'https://pbs.twimg.com/profile_images/958755066789294080/L9BklGz__400x400.jpg','https://assets.entrepreneur.com/content/3x2/2000/20150818171949-metro-goldwun-mayer-trade-mark.jpeg','MGM'.decode('utf8'))
    addDir3('[COLOR gray]New Line Cinema[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=12&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),3,'https://upload.wikimedia.org/wikipedia/en/thumb/0/04/New_Line_Cinema.svg/1200px-New_Line_Cinema.svg.png','https://vignette.wikia.nocookie.net/theideas/images/a/aa/New_Line_Cinema_logo.png/revision/latest?cb=20180210122847','New Line Cinema'.decode('utf8'))
    addDir3('[COLOR darkblue]Gracie Films[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=18&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),3,'https://i.ytimg.com/vi/q_slAJmZBeQ/hqdefault.jpg','https://i.ytimg.com/vi/yGofbuJTb4g/maxresdefault.jpg','Gracie Films'.decode('utf8'))
    addDir3('[COLOR goldenrod]Imagine Entertainment[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=23&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),3,'https://s3.amazonaws.com/fs.goanimate.com/files/thumbnails/movie/2813/1661813/9297975L.jpg','https://www.24spoilers.com/wp-content/uploads/2004/06/Imagine-Entertainment-logo.jpg','Imagine Entertainment'.decode('utf8'))
    
    
def tv_menu():
      import datetime
      now = datetime.datetime.now()
      all_img=cache.get(get_tv_poster,24, table='posters')

      addDir3('[COLOR lightblue]סגנונות[/COLOR]'.decode('utf8'),'http://api.themoviedb.org/3/genre/tv/list?api_key=34142515d9d23817496eeb4ff1d223d0&language=he&page=1',2,'http://img0.liveinternet.ru/images/attach/c/1//49/86/49086845_14270296_1.jpg',all_img[0],'סדרות'.decode('utf8'))
      addDir3('[COLOR lightblue]סדרות פופולריות[/COLOR]'.decode('utf8'),'http://api.themoviedb.org/3/tv/popular?api_key=34142515d9d23817496eeb4ff1d223d0&language=he&page=1',3,'http://culture.bestoneonline.co.il/wp-content/uploads/sites/11/2016/07/%D7%A1%D7%93%D7%A8%D7%95%D7%AA.jpg',all_img[1],'סדרות פופולריות'.decode('utf8'))
      
     
      
      addDir3('[COLOR yellow]משודר כעת[/COLOR]'.decode('utf8'),'https://api.themoviedb.org/3/tv/on_the_air?api_key=34142515d9d23817496eeb4ff1d223d0&language=he&page=1',3,'https://i.pinimg.com/236x/1c/49/8f/1c498f196ef8818d3d01223b72678fc4--divergent-movie-poster-divergent-.jpg',all_img[8],'משודר כעת'.decode('utf8'))
      
      addDir3('פופלרים ב20 שנה האחרונות'.decode('utf8'),'tv',133,'https://d2gg9evh47fn9z.cloudfront.net/800px_COLOURBOX4379826.jpg',all_img[11],'סדרות פופלריות לאורך השנים'.decode('utf8'),data='20',original_title='1')
      
      addDir3('פופולרים ב10 שנים האחרונות'.decode('utf8'),'tv',133,'https://previews.123rf.com/images/fsettler/fsettler1206/fsettler120600010/14239678-favorite-movie-icon.jpg',all_img[12],'סדרות פופלריות לאורך השנים'.decode('utf8'),data='10',original_title='1')
      
      addDir3('[COLOR red]הסדרות החמות[/COLOR]'.decode('utf8'),'http://api.themoviedb.org/3/trending/tv/week?api_key=34142515d9d23817496eeb4ff1d223d0&language=he&page=1',3,'https://boygeniusreport.files.wordpress.com/2015/10/browser-popcorn.png',all_img[13],'הסדרות הלוהטות השבוע'.decode('utf8'))
      
      
      addDir3('[COLOR lightblue]סדרות לפי שנים[/COLOR]'.decode('utf8'),'tv_years&page=1',3,domain_s+'lh5.ggpht.com/cr6L4oleXlecZQBbM1EfxtGggxpRK0Q1cQ8JBtLjJdeUrqDnXAeBHU30trRRnMUFfSo=w300',all_img[2],'סדרות לפי שנים'.decode('utf8'))
      addDir3('[COLOR lightblue]סדרות חדשות[/COLOR]'.decode('utf8'),domain_s+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&language=en-US&sort_by=popularity.desc&first_air_date_year='+str(now.year)+'&timezone=America%2FNew_York&include_null_first_air_ates=false&language=he&page=1',3,domain_s+'lh5.ggpht.com/cr6L4oleXlecZQBbM1EfxtGggxpRK0Q1cQ8JBtLjJdeUrqDnXAeBHU30trRRnMUFfSo=w300',all_img[3],'סדרות חדשות'.decode('utf8'))
      addDir3('[COLOR aqua]ערוצי סדרות[/COLOR]','www',93,'https://ae01.alicdn.com/kf/HTB1WLAYPpXXXXcEXFXXq6xXFXXXB/S0104-Dexter-6-TV-series-Canvas-Fabric-Poster-Art-Home-Decor-Cloth-Print-Home-Decor-poster.jpg_640x640.jpg','https://wallpaper.wiki/wp-content/uploads/2017/05/wallpaper.wiki-The-100-tv-series-wide-pictures-PIC-WPE0014866.jpg','ערוצי סדרות')
      addDir3('[COLOR red]סדרות מרשתות שונות[/COLOR]'.decode('utf8'),'tv',101,'http://www.slate.com/content/dam/slate/articles/arts/tv_club/2015/12/151223_TV_ThinkstockPhotos-466978453.jpg.CROP.promo-xlarge2.jpg','https://images.pond5.com/tv-networks-logos-loop-footage-042898083_prevstill.jpeg','סדרות מרשתות שונות כמו נטפליקס HOB CBS וכו'.decode('utf8'))
      addDir3('[COLOR lightcoral]כתוביות אחרונות[/COLOR]'.decode('utf8'),'https://www.screwzira.com/BrowseSeries.aspx?ResultsPerPage=100&Page=1',113,'https://pbs.twimg.com/profile_images/2736818426/19ad6a4048ab9836abc1c61a29bb2e1e.jpeg','https://cdn-images-1.medium.com/max/2000/1*dBJMknulIZSAC36tTmanVA.jpeg','כתוביות אחרונות'.decode('utf8'))
      addDir3('[COLOR lightblue]סדרות מועדפות[/COLOR]'.decode('utf8'),'tv',18,domain_s+'cdn0.iconfinder.com/data/icons/sharp_folder_icons_by_folksnet/256/favorites.png','http://4.bp.blogspot.com/-8q4ops3bX_0/T0TWUOu5ETI/AAAAAAAAA1A/AQMDv0Sv4Cs/s1600/logo1.gif','מועדפים'.decode('utf8'))
      addDir3('[COLOR lightblue][I]מומלצים עבורך[/I][/COLOR]'.decode('utf8'),'tv',26,domain_s+'www.maxrealestateexposure.com/wp-content/uploads/2011/10/Recommendation.jpg',all_img[5],'סדרות מומלצות עבורך על פי היסטוריית הצפייה שלך'.decode('utf8'),isr=0)
      
      addDir3('[COLOR gold][I]הכי פופולריות של IMDB[/I][/COLOR]'.decode('utf8'),'https://www.imdb.com/search/title?title_type=tv_series',114,'http://www.thisgeeksworld.com/wp-content/uploads/2017/03/must-see-tv-logo.jpg',all_img[8],'סדרות שחייבים לראות'.decode('utf8'),isr=0)
      if Addon.getSetting("unfilter_test")=='998':
        search_entered=''
    

        keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש כאן')
        keyboard.doModal()
        if keyboard.isConfirmed():
                search_entered = keyboard.getText()
                if search_entered=='554':
                    addDir3('[COLOR gold][I]Hidden[/I][/COLOR]'.decode('utf8'),'https://www.imdb.com/list/ls064978696/?sort=list_order,asc&st_dt=&mode=simple&page=1&ref_=ttls_vw_smp',114,'http://www.thisgeeksworld.com/wp-content/uploads/2017/03/must-see-tv-logo.jpg',all_img[8],'סדרות שחייבים לראות'.decode('utf8'),isr=0)
      #dbcur.execute("SELECT * FROM last_viewed_last")
      #match_new = dbcur.fetchone()
      
      if 0:#match_new!=None:
          all_d_new,resu_all_d,empty_free=match_new
          if resu_all_d=='yes':
            mark='☻☺'
            color='yellow'
            added_n='השתנה מפעם אחרונה שנכנסת \n'
            
                
          else:
            mark=''
            color='deeppink'
            added_n=''
      else:
        mark=''
        color='deeppink'
        added_n=''
      addDir3('[COLOR %s][I]%sמעקב סדרות%s[/I][/COLOR]'%(color,mark,mark),'tv',32,domain_s+'pbs.twimg.com/profile_images/873323586622078976/Z0BfwrYm.jpg',all_img[6],added_n+'פרקים אחרונים שנצפו'.decode('utf8'),isr=0)
      addDir3('[COLOR deeppink][I]סדרות אחרונות שנצפו[/I][/COLOR]'.decode('utf8'),'tv',91,domain_s+'pbs.twimg.com/profile_images/873323586622078976/Z0BfwrYm.jpg',all_img[7],'פרקים אחרונים שנצפו'.decode('utf8'),isr=0)
      dbcur.execute("SELECT * FROM lastlinktv WHERE o_name='f_name'")

      match = dbcur.fetchone()
      if match!=None:
       
       f_name,name,url,iconimage,fanart,description,data,season,episode,original_title,saved_name,heb_name,show_original_year,eng_name,isr,prev_name,id=match
       try:
           if url!=' ':
             if 'http' not  in url:
             
               url=url.decode('base64')
  
             addLink('[COLOR yellow][I]הפעל לינק אחרון שהופעל[/I][/COLOR]', 'latest_tv',5,False,iconimage,fanart,description,data=show_original_year,original_title=original_title,season=season,episode=episode,id=id,saved_name=saved_name,prev_name=prev_name,eng_name=eng_name,heb_name=heb_name,show_original_year=show_original_year)
             
       except Exception as e:
         logging.warning(e)
         pass
      addDir3('One Click'.decode('utf8'),'tv',155,'http://fundav.com/wp-content/uploads/2016/07/OneClick.png',all_img[2],'Once click movies'.decode('utf8'),data='1')
      
      addDir3('[COLOR lightblue]חפש סידרה[/COLOR]'.decode('utf8'),'http://api.themoviedb.org/3/search/tv?api_key=34142515d9d23817496eeb4ff1d223d0&query=%s&language=he&page=1',3,domain_s+'img.wcdn.co.il/f_auto,w_700,t_18/1/0/7/2/1072572-46.jpg',domain_s+'f.frogi.co.il/news/640x300/010170efc8f.jpg','חפש סידרה'.decode('utf8'))
      addDir3('[COLOR lightblue]חיפושים קודמים[/COLOR]'.decode('utf8'),'tv',151,domain_s+'img.wcdn.co.il/f_auto,w_700,t_18/1/0/7/2/1072572-46.jpg',domain_s+'f.frogi.co.il/news/640x300/010170efc8f.jpg','חיפושים קודמים'.decode('utf8'))
      addDir3('בחירת תוכן מתקדם'.decode('utf8'),'advance_tv',3,'https://filmgator.com/black/pics/tour_search.png','https://cdn0.tnwcdn.com/wp-content/blogs.dir/1/files/2010/03/movies.jpg','חיפוש מתקדם'.decode('utf8'))
def search_menu():

      addDir3('חפש סרט'.decode('utf8'),'http://api.themoviedb.org/3/search/movie?api_key=34142515d9d23817496eeb4ff1d223d0&query=%s&language=he&append_to_response=origin_country&page=1',3,domain_s+'cellcomtv.cellcom.co.il/globalassets/cellcomtv/content/sratim/pets-secret-life/480x543-template.jpg','http://www.videomotion.co.il/wp-content/uploads/whatwedo-Pic-small.jpg','חפש סרט'.decode('utf8'))
      addDir3('חפש שחקן'.decode('utf8'),'search',74,'https://hdqwalls.com/download/avengers-infinity-war-poster-2018-da-640x960.jpg','https://i.pinimg.com/originals/0d/d3/ec/0dd3ec06d890d7f5e699a010e1500c68.jpg','חפש שחקן'.decode('utf8'))
      
      addDir3('[COLOR lightblue]חפש סידרה[/COLOR]'.decode('utf8'),'http://api.themoviedb.org/3/search/tv?api_key=34142515d9d23817496eeb4ff1d223d0&query=%s&language=he&page=1',3,domain_s+'img.wcdn.co.il/f_auto,w_700,t_18/1/0/7/2/1072572-46.jpg',domain_s+'f.frogi.co.il/news/640x300/010170efc8f.jpg','חפש סידרה'.decode('utf8'))
      addDir3('[COLOR yellow][I]חיפוש סרטים מדובבים[/I][/COLOR]'.decode('utf8'),'search',11,'http://2.bp.blogspot.com/-vDRXO2qGAFc/UyCAFd2LAPI/AAAAAAAAEco/pIfXWlRJG6Q/s1600/images+(9).jpg',domain_s+'i.pinimg.com/originals/c1/cb/ed/c1cbede7238494e7878f7107ed478d79.jpg','חיפוש סרטים מדובבים'.decode('utf8'))
      addDir3('[COLOR yellow][I]חיפוש סדרה מדובבת[/I][/COLOR]'.decode('utf8'),'search',45,'https://image.shutterstock.com/image-vector/modern-children-education-logo-happy-260nw-528357007.jpg','http://www.bhmpics.com/download/storks_4k_kids-2560x1440.jpg','חיפוש סדרה מדובבת'.decode('utf8'))
      addDir3('[COLOR lightblue]חיפוש סדרות קודם[/COLOR]'.decode('utf8'),'tv',151,domain_s+'img.wcdn.co.il/f_auto,w_700,t_18/1/0/7/2/1072572-46.jpg',domain_s+'f.frogi.co.il/news/640x300/010170efc8f.jpg','חיפושים קודמים'.decode('utf8'))
      addDir3('[COLOR lightblue]חיפוש סרטים קודם[/COLOR]'.decode('utf8'),'movie',151,domain_s+'img.wcdn.co.il/f_auto,w_700,t_18/1/0/7/2/1072572-46.jpg',domain_s+'f.frogi.co.il/news/640x300/010170efc8f.jpg','חיפושים קודמים'.decode('utf8'))
      #addDir3('חיפוש תוכן ישראלי וטלנובלות'.decode('utf8'),'search',85,'https://static1.squarespace.com/static/56a13391d8af108f38f826ff/56a2139a1f403921c70b6ec3/5afad0da758d462161632695/1529762605167/JANE_NEWLAND_FRENCHSKYBLUE+web.jpg?format=300w','http://jeff-thomas.net/wp-content/uploads/2016/01/Lookout-1.jpg','חיפוש'.decode('utf8'))
def get_genere(link):
   images={}
   html=requests.get(link).json()
   for data in html['genres']:
     if '/movie' in link:
       new_link='http://api.themoviedb.org/3/genre/%s/movies?api_key=34142515d9d23817496eeb4ff1d223d0&language=he&page=1'%str(data['id'])
     else:
       new_link='http://api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&sort_by=popularity.desc&with_genres=%s&language=he&page=1'%str(data['id'])
     if data['name'] in tv_images:
       image=tv_images[data['name']]
     elif data['name'] in movie_images:
       image=movie_images[data['name']]
     addDir3(data['name'],new_link,3,image,image,data['name'])
def movies_channel():
    addLink('ערוץ התוכן של הנוקם'.decode('utf8'),domain_s+'raw.githubusercontent.com/shimonar/sh/master/%D7%94%D7%A0%D7%95%D7%A7%D7%9D%20%D7%94%D7%A8%D7%90%D7%A9%D7%95%D7%9F%20.txt',36,False,'https://imgcs.artprintimages.com/img/print/print/the-avengers-age-of-ultron-captain-america-black-widow-hulk-hawkeye-vision-iron-man-thor_a-l-14824548-11969363.jpg?w=550&h=550','https://i.kinja-img.com/gawker-media/image/upload/s--fWBQap3Z--/c_scale,f_auto,fl_progressive,q_80,w_800/1234660079547003496.jpg','ערוץ הסרטים של הנוקם')
    addLink('ערוץ התוכן של גוסט'.decode('utf8'),'https://files.fm/pa/moshep1977/upload/1.txt',36,False,'https://i.imgur.com/DEJRw9V.jpg','https://i.imgur.com/DEJRw9V.jpg','ערוץ הסרטים גל גוסט')  
    addLink("ערוץ המדובבים".decode('utf8'),'https://github.com/oren2706/Multimedialist/blob/master/hebdub%20list%20(VER_4).txt?raw=true',36,False,'http://icons.iconarchive.com/icons/3xhumed/mega-games-pack-31/256/Cars-pixar-4-icon.png','https://www.filminquiry.com/wp-content/uploads/2015/10/Pixar.jpg',"ערוץ המדובבים")
    addDir3('[COLOR aqua]ערוצי סדרות[/COLOR]','www',93,'https://ae01.alicdn.com/kf/HTB1WLAYPpXXXXcEXFXXq6xXFXXXB/S0104-Dexter-6-TV-series-Canvas-Fabric-Poster-Art-Home-Decor-Cloth-Print-Home-Decor-poster.jpg_640x640.jpg','https://wallpaper.wiki/wp-content/uploads/2017/05/wallpaper.wiki-The-100-tv-series-wide-pictures-PIC-WPE0014866.jpg','ערוצי סדרות')
    #addLink("ערוץ סרטים ישראלים".decode('utf8'),domain_s+'www',40,False,'https://www.edb.co.il/photos/6012003_edbasonot07.news.jpg','https://img.mako.co.il/2017/06/13/vlcsnap-00223_i.jpg',"סרטים ישראלים")
    #addLink("הערוץ של ONI".decode('utf8'),'www',37,False,'https://upload.wikimedia.org/wikipedia/en/thumb/2/2e/Oni_Coverart.jpg/220px-Oni_Coverart.jpg','http://nerdtrek.com/wp-content/uploads/2011/07/streaming-tv-movies.jpg',"הערוץ של ONI")
    #addLink("הערוץ של 1M".decode('utf8'),'www',39,False,'https://thehaletelescope.com/wp-content/uploads/2017/08/war-movies.jpg','https://lumiere-a.akamaihd.net/v1/images/h_blackpanther_intheaters_61ff73b4.jpeg?region=0,0,2048,832',"הערוץ של 1M")











def merge_two_dicts(x, y):
    z = x.copy()   # start with x's keys and values
    z.update(y)    # modifies z with y's keys and values & returns None
    return z
def start_window2(id,tv_movie,name,selected_option):

      if selected_option=='2':
        send_type='find_similar'
      else:
        send_type=''
      menu = sources_search2('plugin.video.allmoviesin', id,tv_movie,send_type)
      menu.doModal()
     
      del menu
      
def start_window(id,tv_movie,name,selected_option):
   
    menu = sources_search('plugin.video.allmoviesin',id,tv_movie,name)
    menu.doModal()
    
    del menu
def get_magnet_direct(url):
     if  allow_debrid:
        return url
     if 'limetorrents' in url:
                    
     
           
         headers = {
    
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
            }
         x=requests.get(url,headers=headers).content
         regex='"magnet:(.+?)"'
         url='magnet:'+re.compile(regex).findall(x)[0]
         
     if '1337x.to' in url :
        x,cook=cloudflare_request('http://www.1337x.to/',headers=base_header)
        x=requests.get(url,headers=cook[1],cookies=cook[0]).content
        regex='"magnet:(.+?)"'
        url='magnet:'+re.compile(regex).findall(x)[0]
     if 'movcr.' in url :
        x,cook=cloudflare_request('https://movcr.to',headers=base_header)
        x=requests.get(url,headers=cook[1],cookies=cook[0]).content
        regex='"magnet:(.+?)"'
        url='magnet:'+re.compile(regex).findall(x)[0]
     if  'torrentquest.com' in url or 'eztv.io' in url:
        
         headers = {
    
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
            }
         x=requests.get(url,headers=headers).content
         regex='"magnet:(.+?)"'
         url='magnet:'+re.compile(regex).findall(x)[0]
     if 'torrentdownloads.me' in url:
         
        
          
         headers = {
    
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
            }
         x=requests.get(url,headers=headers).content
         regex='"magnet:(.+?)"'
         url='magnet:'+re.compile(regex).findall(x)[0]
     if 'ibit.to' in url:
        
        
         
         headers = {
    
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
            }
         x=requests.get(url,headers=headers).content
         regex="'magnet:(.+?)'"
         url='magnet:'+re.compile(regex).findall(x)[0].decode("string-escape").replace('X-X','')
     return url
     
def get_condition(name1,links,server,res,tv_movie,f_result,data,original_title):
    try:
        check_r_l={}
        condition_sources=False
        str_check=[]
        if Addon.getSetting("super_fast_type")=="1":#type of source
            if Addon.getSetting("super_fast_type_google")=='true' :#Google
                if 'google' in links:
                    check_r_l['server_type_google']=True
                    str_check.append(' V Google ')
                    condition_sources=True
                else:
                    check_r_l['server_type_google']=False

            if Addon.getSetting("super_fast_type_torent")=='true' :#Torrents
                if '{P-' in server:
                    check_r_l['server_type_torrents']=True
                    str_check.append(' V Torrent ')
                    condition_sources=True
                else:
                    check_r_l['server_type_torrents']=False
                    
            if Addon.getSetting("super_fast_type_stream")=='true' :#Streamango
                if 'streamango' in links:
                    check_r_l['server_type_streamango']=True
                    str_check.append(' V Streamango ')
                    condition_sources=True
                else:
                    check_r_l['server_type_streamango']=False
                    
            if Addon.getSetting("super_fast_type_uptobox")=='true' :#Uptobox
                if 'uptobox' in links or 'uptostram' in links:
                    check_r_l['super_fast_type_uptobox']=True
                    str_check.append(' V Uptobox ')
                    condition_sources=True
                else:
                    check_r_l['server_type_uptobox']=False
            fav_ser=Addon.getSetting("super_fast_type_fav")#Fav sources
            if len(fav_ser)>0 :
                if "," in fav_ser:
                    fav_ser_n=fav_ser.split(',')
                else:
                    fav_ser_n=[fav_ser]
                check_r_l['server_type_fav']=False
                for items in fav_ser_n:
                    if items.lower() in links.lower():
                        check_r_l['server_type_fav']=True
                        str_check.append(' V Fav Source:%s '%items)
                        condition_sources=True
                        break
         
            fav_ser=Addon.getSetting("super_fast_type_fav_prov")#Fav Providers
            if len(fav_ser)>0 :
                if "," in fav_ser:
                    fav_ser_n=fav_ser.split(',')
                else:
                    fav_ser_n=[fav_ser]
                check_r_l['server_type_fav_prov']=False
                for items in fav_ser_n:
                    if items.lower() == server.lower():
                        str_check.append(' V Fav Provider:%s '+items)
                        check_r_l['server_type_fav_prov']=True
                        condition_sources=True
        else:
            check_r_l['server_type_sources']=True
            condition_sources=True
            
        try:#Resolution
          a=int(res)
        except:
          res='0'
        if tv_movie=='tv':
            min_super_fast=res_table[int(Addon.getSetting("tv_min_super_fast"))]
            max_super_fast=res_table[int(Addon.getSetting("tv_max_super_fast"))]
        else:
            min_super_fast=res_table[int(Addon.getSetting("movies_min_super_fast"))]
            max_super_fast=res_table[int(Addon.getSetting("movies_max_super_fast"))]
      
        if int(res)>=int(min_super_fast) and int(res)<=int(max_super_fast):
            check_r_l['server_type_res']=True
            str_check.append(' V Res:%s '%res)
            condition_res=True
        else:
            check_r_l['server_type_res']=False
            str_check.append(' X Res:%s '%res)
            condition_res=False
        #subs
        condition_subs=False
        if Addon.getSetting("super_fast_type_subs_en")=='true':
            if 'links' in f_result['subs']:
                if len(f_result['subs']['links'])>0:
                    if f_result[data]['subs']==True:
                       pre='101'
                    else:
                        pre=check_pre(name1,f_result['subs']['links'],original_title)
                    super_pre_table=[0,10,20,30,40,50,60,70,80,90]
                    super_pre=super_pre_table[int(Addon.getSetting("super_fast_type_subs_pre"))]
                    if int(pre)>int(super_pre):
                        check_r_l['server_type_subs']=True
                        str_check.append(' V Subs:'+str(pre))
                        condition_subs=True
                    else:
                        check_r_l['server_type_subs']=False
                        condition_subs=False
        else:
            check_r_l['server_type_subs']=True
            condition_subs=True
        
        if condition_subs and condition_res and condition_sources:
            return True,','.join(str_check).replace(' V ','')
        else:
            return False,','.join(str_check).replace(' V ','')
    except Exception as e:
        import linecache
        exc_type, exc_obj, tb = sys.exc_info()
        f = tb.tb_frame
        lineno = tb.tb_lineno
        filename = f.f_code.co_filename
        linecache.checkcache(filename)
        line = linecache.getline(filename, lineno, f.f_globals)
        xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'Line:'+str(lineno)+' E:'+str(e))).encode('utf-8'))
        logging.warning('ERROR IN super play:'+str(lineno))
        logging.warning('inline:'+line)
        logging.warning(e)
        logging.warning('BAD super play')
def start_all_trd():
    global what_to_start,done_what,whats_done
    all_act=[]
    whats_done=0
    while(1):
        try:
            for items in what_to_start:
                if items not in all_act:
                    all_act.append(items)
                    
                    what_to_start[items].start()
            if done_what>0:
                break
        except Exception as e:
            logging.warning('Error fast:'+str(e))
        xbmc.sleep(100)
    whats_done=1
def c_get_sources(name,year,original_title,season,episode,id,eng_name,show_original_year,heb_name,isr,get_local=False,fav_status='false',only_torrent='no',only_heb_servers='0'):
   global stop_all,once_fast_play,silent_mode,stoped_play_once,done_c_get,string_dp
   global what_to_start,done_what,whats_done
   what_to_start={}
   done_what=0
   done_c_get=1
   if Addon.getSetting("stack_size_change")=='true':
        threading.stack_size(int(Addon.getSetting("stack_size_size")))
   try:
    heb_name=heb_name.strip()
    check_lk=[]
    #once_fast_play=0
    global all_s_in,stop_window,global_result,all_links_sources
    import random
    all_s_in=({},0,'','','')
    da=[]
    stop_window=False
    logging.warning('in c_get search')
    da.append((name,year,original_title,season,episode,id,eng_name,show_original_year,heb_name,isr,get_local,fav_status))
    
    
    logging.warning(da)
    logging.warning('silent_mode:'+str(silent_mode))
    if debug_mode==True:
      logging.warning('Searching sources')
    if season!=None and season!="%20":
          tv_movie='tv'
      
          
    else:
          tv_movie='movie'
    from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,base_header
    import dns,socket
    from urlparse import urljoin
    import resolveurl
    import PTN
    import unjuice

    if Addon.getSetting("new_server_dp")=='true' and silent_mode==False:
            
            
            thread=[]
            selected_option=Addon.getSetting("new_server_dp_option")
            logging.warning('selected_option: '+selected_option)
            if selected_option=='3':
                rand=(random.randint(0,299)/100)
                selected_option=str(int(rand))
                logging.warning('RANDOM CHOISE:'+selected_option)
                logging.warning(rand)
            if selected_option=='0':
                thread.append(Thread(start_window,id,tv_movie,heb_name,selected_option))
                thread[len(thread)-1].setName('sources_s1')
            elif selected_option=='1' or selected_option=='2' or selected_option=='4':
                thread.append(Thread(start_window2,id,tv_movie,heb_name,selected_option))
                thread[len(thread)-1].setName('sources_s2')
            thread[0].start()
    if Addon.getSetting("server_dp")=='true' and silent_mode==False:
        
        dp = xbmcgui . DialogProgress ( )
        dp.create('אנא המתן','מחפש מקורות', '','')
        dp.update(0, 'אנא המתן','מחפש מקורות', '' )
    if Addon.getSetting("trailer_dp")=="true" and Addon.getSetting("new_server_dp")=="false":
      pDialog = xbmcgui.DialogProgressBG()
      pDialog.create('אוסף מקורות')
      #pDialog.update(0, message=' אנא המתן ')

    if len(episode)==1:
      episode_n="0"+episode
    else:
       episode_n=episode
    if len(season)==1:
      season_n="0"+season
    else:
      season_n=season
   
    if Addon.getSetting("lang")=="1":
      lang='en'
    else:
      lang='he'
    url2=None

    zzz=0
    if Addon.getSetting("server_test_one")=='true':
        
        all_r=[]
        onlyfiles = [f for f in listdir(done_dir) if isfile(join(done_dir, f))]
        onlyfiles=onlyfiles+[f for f in listdir(mag_dir) if isfile(join(mag_dir, f))]
        onlyfiles=onlyfiles+[f for f in listdir(rd_dir) if isfile(join(rd_dir, f))]
        c_now=0
        for items in onlyfiles:
          if c_now==1:
            break
          start_time = time.time()
          if items !='general.py' and '.pyc' not in items and '.pyo' not in items and '__init__' not in items and items !='resolveurl_temp.py' and items!='cloudflare.py' and items!='Addon.py' and items!='subs.py' and items!='cache.py':
                
                impmodule = __import__(items.replace('.py',''))
                thread=[]
                impmodule.global_var=[]
                thread.append(Thread(impmodule.get_links,tv_movie,original_title,heb_name,season_n,episode_n,season,episode,show_original_year,id))
                thread[len(thread)-1].setName(items.replace('.py',''))
                thread[len(thread)-1].start()
                
              
                
                while thread[0].is_alive():
                    elapsed_time = time.time() - start_time
                    dp.update(int(((zzz* 100.0)/(len(thread))) ), ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),thread[0].name+'-'+str(len(impmodule.global_var)), 'ממתין')
                    xbmc.sleep(1000)
                    if dp.iscanceled():
                      dp.close()
                      c_now=1
                      break
                elapsed_time = time.time() - start_time
                all_r.append(items.replace('.py','')+'-'+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))+'-'+str(len(impmodule.global_var)))
          zzz+=1
        
        TextBox_help('תוצאות', '\n'.join(all_r))
        
        return '',[]
        
    thread=[]
    tv_mode=tv_movie
  
    original_title=original_title.replace('%3a','')
    logging.warning('fav_status22222')
    logging.warning(fav_status)
    all_sources=[]
    all_names_1=[]
    if tv_movie=='movie':
        fav_server_en=Addon.getSetting("fav_servers_en")
        fav_servers=Addon.getSetting("fav_servers")
        google_server= Addon.getSetting("google_server")
        rapid_server=Addon.getSetting("rapid_server")
        direct_server=Addon.getSetting("direct_server")
        heb_server=Addon.getSetting("heb_server")
        torrent_server=Addon.getSetting("torrent_server")
    else:
        fav_server_en=Addon.getSetting("fav_servers_en_tv")
        fav_servers=Addon.getSetting("fav_servers_tv")
        google_server= Addon.getSetting("google_server_tv")
        rapid_server=Addon.getSetting("rapid_server_tv")
        direct_server=Addon.getSetting("direct_server_tv")
        heb_server=Addon.getSetting("heb_server_tv")
        torrent_server=Addon.getSetting("torrent_server_tv")
        
    onlyfiles=[]
    all_torrents=[]
    if  not ((Addon.getSetting("all_t")=='1' and Addon.getSetting("magnet")=='true') or only_torrent=='yes'):
        onlyfiles = [f for f in listdir(done_dir) if isfile(join(done_dir, f))]
    if Addon.getSetting("magnet")=='true' or only_torrent=='yes':
        for f in listdir(mag_dir):
            if isfile(join(mag_dir, f)):
               if Addon.getSetting(f.replace('.py',''))=="true":
                all_torrents.append(f.replace('.py',''))
        onlyfiles=onlyfiles+[f for f in listdir(mag_dir) if isfile(join(mag_dir, f))]
    all_fv_servers=[]
    if Addon.getSetting("server_dp")=='true' and silent_mode==False:
        dp.update(0, 'אנא המתן','אוסף שרתים', '' )
    logging.warning('fav_status:'+fav_status)
        
    if fav_status=='true' or fav_status=='rest':
      if fav_server_en=='true':
        all_fv_servers=fav_servers.split(',')
        all_direct,all_google,all_rapid,all_heb=cache.get(get_server_types, 9999,tv_movie, table='servers')
        if google_server=='true':
            all_fv_servers=all_fv_servers+all_google
        if rapid_server=='true':
            all_fv_servers=all_fv_servers+all_rapid
        if heb_server=='true':
            logging.warning('In Direct')
            all_fv_servers=all_fv_servers+all_heb
        if direct_server=='true':
            logging.warning('In Direct')
            all_fv_servers=all_fv_servers+all_direct
        if torrent_server=='true':
            all_fv_servers=all_fv_servers+all_torrents
        
        if Addon.getSetting("rdsource")=='true':
            onlyfiles2 = [f for f in listdir(rd_dir) if isfile(join(rd_dir, f))]
            f_result={}
            

            name_check=''
            z=0
            for items in onlyfiles2:
              check=False
              
              if Addon.getSetting("server_dp")=='true' and silent_mode==False:
                 dp.update(int((z*100.0)/(len(onlyfiles))), 'אנא המתן','אוסף קבצים', items )
              all_s_in=({},int((z*100.0)/(len(onlyfiles))),items,1,'')
              if items !='general.py' and '.pyc' not in items and '.pyo' not in items and '__init__' not in items and items !='resolveurl_temp.py' and items!='cloudflare.py' and items!='Addon.py':
               logging.warning('Import')
               
               impmodule = __import__(items.replace('.py',''))
              
               if Addon.getSetting(items.replace('.py',''))=="true":
                   
                   if name_check!='':
                     if items.replace('.py','')==name_check:
                       if tv_movie=='movie' and 'movie' in impmodule.type:
                         check=True
                         all_sources.append((items.replace('.py',''),impmodule))
                       elif tv_movie=='tv' and 'tv' in impmodule.type:
                         check=True
                         all_sources.append((items.replace('.py',''),impmodule))
                   else:
                     if tv_movie=='movie' and 'movie' in impmodule.type:
                       check=True
                       all_sources.append((items.replace('.py',''),impmodule))
                     elif tv_movie=='tv' and 'tv' in impmodule.type:
                       all_sources.append((items.replace('.py',''),impmodule))
                       check=True
              if items.replace('.py','') not in all_names_1 and check:
                all_s_in=({},20,items.replace('.py',''),1,'')
                all_names_1.append(items.replace('.py',''))
                impmodule.global_var=[]
                logging.warning('Start Import:'+items)
                thread.append(Thread(impmodule.get_links,tv_movie,original_title,heb_name,season_n,episode_n,season,episode,show_original_year,id))
                thread[len(thread)-1].setName(items.replace('.py',''))
                #thread[len(thread)-1].start()
                what_to_start[items.replace('.py','')]=thread[len(thread)-1]
                logging.warning('Done Import:'+items)
            z+=1
      else:
        all_fv_servers=[]
    
    if (Addon.getSetting("all_t")=='1' or only_torrent=='yes') and Addon.getSetting("magnet")=='true':
        all_fv_servers=[]
    if Addon.getSetting("server_dp")=='true' and silent_mode==False:
       dp.update(0, 'אנא המתן','אוסף קבצים', '' )
    
    
    f_result={}
 
    regular_s=True
    if Addon.getSetting("rdsource")=='true' and Addon.getSetting("rd_only")=='true':
      regular_s=False
    if (Addon.getSetting("all_t")=='1' or only_torrent=='yes') and Addon.getSetting("magnet")=='true':
        regular_s=False
    try:
        for it in all_fv_servers:
            
            if Addon.getSetting(it)!="true":
                logging.warning('POP:'+it)
                all_fv_servers.pop(all_fv_servers.index(it))
    except Exception as e:
        logging.warning('Bad 1:'+str(e))
    logging.warning(all_fv_servers)
    
    if regular_s:
        

        name_check=''
        z=0
        if fav_status=='true':
            for it in all_fv_servers:
                
                   if it+'.py' in onlyfiles:
                    all_s_in=({},int((z*100.0)/(len(all_fv_servers))),'Import:'+it.replace('.py',''),1,'')
                    
                    impmodule = __import__(it.replace('.py',''))
                    if tv_movie=='movie' and 'movie' not in impmodule.type:
                        continue
                    if tv_movie=='tv' and 'tv' not in impmodule.type:
                        
                        continue
                   
                    all_s_in=({},int((z*100.0)/(len(all_fv_servers))),'DImport:'+it.replace('.py',''),1,'')
                    all_sources.append((it.replace('.py',''),impmodule))
                    if it.replace('.py','') not in all_names_1 :
                        all_names_1.append(it.replace('.py',''))
                        all_s_in=({},int((z*100.0)/(len(all_fv_servers))),'Start:'+it.replace('.py',''),1,'')
                        if Addon.getSetting("server_dp")=='true' and silent_mode==False:
                            dp.update(int((z*100.0)/(len(all_fv_servers))), 'אנא המתן','מפעיל', it.replace('.py','') )
                        impmodule.global_var=[]
                        thread.append(Thread(impmodule.get_links,tv_movie,original_title,heb_name,season_n,episode_n,season,episode,show_original_year,id))
                        logging.warning('Start trd:'+it)
                        thread[len(thread)-1].setName(it.replace('.py',''))
                        #thread[len(thread)-1].start()
                        what_to_start[it.replace('.py','')]=thread[len(thread)-1]
                        logging.warning('End trd:'+it)
                        all_s_in=({},int((z*100.0)/(len(all_fv_servers))),'end:'+it.replace('.py',''),1,'')
                        if Addon.getSetting("server_dp")=='true' and silent_mode==False:
                            dp.update(int((z*100.0)/(len(all_fv_servers))), 'אנא המתן','פועל', it.replace('.py','') )
                   z+=1
            #for td in thread:
                
            #    all_s_in=({},int((z*100.0)/(len(all_fv_servers))),'מפעיל '+td.name,1,'')
            #    td.start()
        done_what=1
        logging.warning('whats_done_pre')
        count=0
        
        #while (whats_done==0):
        #    xbmc.sleep(100)
        #    count+=1
        #    if count>10:
        #        break
        #logging.warning('whats_done:'+str(whats_done)+',count:'+str(count))
        for items in onlyfiles:
          check=False
          if Addon.getSetting("server_dp")=='true' and silent_mode==False:
             dp.update(int((z*100.0)/(len(onlyfiles))), 'אנא המתן','אוסף קבצים', items )
          all_s_in=({},int((z*100.0)/(len(onlyfiles))),items,1,'')
          if items !='general.py' and '.pyc' not in items and '.pyo' not in items and '__init__' not in items and items !='resolveurl_temp.py' and items!='cloudflare.py' and items!='Addon.py':
           
           if fav_status=='true':
                break
                    
                if items.replace('.py','') not in all_fv_servers:
                    continue
           
                    
           elif fav_status=='rest':
                if items.replace('.py','')  in all_fv_servers:
                    continue
           if Addon.getSetting("magnet")=='false' and 'magnet' in items:
                continue
           impmodule = __import__(items.replace('.py',''))
           if items!='cache.py':
               if only_heb_servers=='yes' and 'subs' not in impmodule.type:
                 continue
           if Addon.getSetting(items.replace('.py',''))=="true" or (Addon.getSetting("magnet")=='true' and ('magnet' in items.replace('.py','')) and Addon.getSetting(items.replace('.py',''))=="true"):
               
               
               if name_check!='':
                 if items.replace('.py','')==name_check:
                   if tv_movie=='movie' and 'movie' in impmodule.type:
                     check=True
                     all_sources.append((items.replace('.py',''),impmodule))
                   elif tv_movie=='tv' and 'tv' in impmodule.type:
                     check=True
                     all_sources.append((items.replace('.py',''),impmodule))
               else:
                 if tv_movie=='movie' and 'movie' in impmodule.type:
                   check=True
                   all_sources.append((items.replace('.py',''),impmodule))
                 elif tv_movie=='tv' and 'tv' in impmodule.type:
                   check=True
                   all_sources.append((items.replace('.py',''),impmodule))
           if items.replace('.py','') not in all_names_1 and check:
                impmodule.global_var=[]
                all_s_in=({},60,items.replace('.py',''),1,'')
                all_names_1.append(items.replace('.py',''))
                thread.append(Thread(impmodule.get_links,tv_movie,original_title,heb_name,season_n,episode_n,season,episode,show_original_year,id))
                thread[len(thread)-1].setName(items.replace('.py',''))
                #thread[len(thread)-1].start()
                what_to_start[items.replace('.py','')]=thread[len(thread)-1]
        z+=1
            
    else:
      if Addon.getSetting("rdsource")=='true':
        onlyfiles = [f for f in listdir(rd_dir) if isfile(join(rd_dir, f))]
        f_result={}
        

        name_check=''
        z=0
        for items in onlyfiles:
          check=False
          if Addon.getSetting("server_dp")=='true' and silent_mode==False:
             dp.update(int((z*100.0)/(len(onlyfiles))), 'אנא המתן','אוסף קבצים', items )
          all_s_in=({},int((z*100.0)/(len(onlyfiles))),items,1,'')
          if items !='general.py' and '.pyc' not in items and '.pyo' not in items and '__init__' not in items and items !='resolveurl_temp.py' and items!='cloudflare.py' and items!='Addon.py':
           
           impmodule = __import__(items.replace('.py',''))

           if Addon.getSetting(items.replace('.py',''))=="true":
               
               if name_check!='':
                 if items.replace('.py','')==name_check:
                   if tv_movie=='movie' and 'movie' in impmodule.type:
                     check=True
                     all_sources.append((items.replace('.py',''),impmodule))
                   elif tv_movie=='tv' and 'tv' in impmodule.type:
                     check=True
                     all_sources.append((items.replace('.py',''),impmodule))
               else:
                 if tv_movie=='movie' and 'movie' in impmodule.type:
                   check=True
                   all_sources.append((items.replace('.py',''),impmodule))
                 elif tv_movie=='tv' and 'tv' in impmodule.type:
                   check=True
                   all_sources.append((items.replace('.py',''),impmodule))
          if items.replace('.py','') not in all_names_1 and check:
                all_names_1.append(items.replace('.py',''))
                impmodule.global_var=[]
                thread.append(Thread(impmodule.get_links,tv_movie,original_title,heb_name,season_n,episode_n,season,episode,show_original_year,id))
                thread[len(thread)-1].setName(items.replace('.py',''))
                #thread[len(thread)-1].start()
                what_to_start[items.replace('.py','')]=thread[len(thread)-1]
                all_s_in=({},80,items.replace('.py',''),1,'')
        z+=1
    if (Addon.getSetting("all_t")=='1' and Addon.getSetting("magnet")=='true') or only_torrent=='yes'  or (Addon.getSetting("rd_only_torrent")=='true' and Addon.getSetting("rdsource")=='true' and Addon.getSetting("magnet")=='true'):
            name_check=''
            #onlyfiles = [f for f in listdir(done_dir) if isfile(join(done_dir, f))]
            onlyfiles=[f for f in listdir(mag_dir) if isfile(join(mag_dir, f))]
            z=0
            for items in onlyfiles:
             
                if items !='general.py' and '.pyc' not in items and '.pyo' not in items and '__init__' not in items and items !='resolveurl_temp.py' and items!='cloudflare.py' and items!='Addon.py':
                    if 'magnet' in items:
                        if Addon.getSetting("server_dp")=='true' and silent_mode==False:
                            dp.update(int((z*100.0)/(len(onlyfiles))), 'אנא המתן','אוסף קבצים', items )
                        all_s_in=({},int((z*100.0)/(len(onlyfiles))),items,1,'')
                        impmodule = __import__(items.replace('.py',''))
                        if Addon.getSetting(items.replace('.py',''))=="true":
                            
                            all_sources.append((items,impmodule))
                            
                            
                            if items.replace('.py','') not in all_names_1:
                                impmodule.global_var=[]
                                all_names_1.append(items.replace('.py',''))
                                thread.append(Thread(impmodule.get_links,tv_movie,original_title,heb_name,season_n,episode_n,season,episode,show_original_year,id))
                                thread[len(thread)-1].setName(items.replace('.py',''))
                                #thread[len(thread)-1].start()
                                what_to_start[items.replace('.py','')]=thread[len(thread)-1]
                            all_s_in=({},90,items.replace('.py',''),1,'')
                                
            z+=1
    threadw=[]
    threadw.append(Thread(start_all_trd))
    threadw[0].start()
    impmodule = __import__('subs')
    all_sources.append(('subs',impmodule))
    
    thread.append(Thread(impmodule.get_links,tv_movie,original_title,heb_name,season_n,episode_n,season,episode,show_original_year,id))
    thread[len(thread)-1].setName('subs')
    thread[len(thread)-1].start()
    logging.warning('idddddddddddddddddddddddddd')
    all_s_in=({},100,'',1,'')
    logging.warning('Episode Searching:'+episode)
    z=0
    '''
    for name1,items in all_sources:
       if name1 not in all_names_1:
        all_names_1.append(name1)
        items.global_var=[]
        items.stop_all=0
        if Addon.getSetting("server_dp")=='true' and silent_mode==False:
           dp.update(0, 'אנא המתן','מפעיל חיפושים', name1 )
        all_s_in=({},int((z*100.0)/(len(all_sources))),name1,1,'')
        z+=1
        f_result[name1]= items.global_var
        if name_check!='':
           if name1==name_check:
      
             thread.append(Thread(items.get_links,tv_movie,original_title,heb_name,season_n,episode_n,season,episode,show_original_year,id))
             thread[len(thread)-1].setName(name1)
        else:
          thread.append(Thread(items.get_links,tv_movie,original_title,heb_name,season_n,episode_n,season,episode,show_original_year,id))
          thread[len(thread)-1].setName(name1)
        thread[len(thread)-1].start()
    '''
    if Addon.getSetting("trailer_dp")=="true" and Addon.getSetting("new_server_dp")=="false":
      thread.append(Thread(play_trailer_f(id,tv_mode)))
      thread[len(thread)-1].setName('Trailer')
      thread[len(thread)-1].start()

        
 
    start_time = time.time()
    stop_all=0
    
    count_t=0
    if tv_movie=='movie':
        src_ena=Addon.getSetting("fav_search_time_en")
    else:
        src_ena=Addon.getSetting("fav_search_time_en_tv")
    if fav_status=='true' and src_ena=='true':
       if tv_movie=='movie':
          max_time=int(Addon.getSetting("fav_search_time"))
       else:
         max_time=int(Addon.getSetting("fav_search_time_tv"))
    else:
       max_time=int(Addon.getSetting("time_s"))
  
    num_live=0
    tt={}
    for i in range (0,(len(thread)+50)): 
      tt[i]="red"

    
    string_dp=''
    string_dp2=''
    still_alive=0
    if len(thread)==0:
      xbmcgui.Dialog().ok('Error occurred','[COLOR aqua][I] לא נבחרו שרתים מתאימים לתוכן זה [/I][/COLOR]')
    all_links_togther={}
    l_check_lk=[]
    start_time = time.time()
    
    while 1:
         num_live=0
         
          
         
         elapsed_time = time.time() - start_time
        
            
         if 1:#for threads in thread:
              elapsed_time = time.time() - start_time
              num_live=0
              string_dp=''
              string_dp2=''
              still_alive=0
              count_2160=0
              count_1080=0
              count_720=0
              count_480=0
              count_rest=0
              count_alive=0
              all_alive={}
              for yy in range(0,len(thread)):
                all_alive[thread[yy].name]=thread[yy].is_alive()
                
                #logging.warning(thread[yy].name+' Alive: '+str(thread[yy].is_alive()))
                if not thread[yy].is_alive():
                  num_live=num_live+1
                  tt[yy]="lightgreen"
                  
                  #logging.warning('Dead:'+thread[yy].name)
                  #string_dp2=string_dp2+',[COLOR red]O:'+thread[yy].name+'[/COLOR]'
                else:
                  
                  
                  if string_dp2=='':
                    string_dp2=thread[yy].name
                  else:
                    count_alive+=1
                    string_dp2=string_dp2+','+thread[yy].name
                  still_alive=1
                  tt[yy]="red"
              
              f_result={}
              f_result['subs']=[]
              f_result['magnet']={}
              
              f_result['magnet']['links']=''
              f_result['magnet']['color']=''
              save_name=''
              for name1,items in all_sources:
                   f_result[name1]={}
                   try:
                      f_result[name1]['progress']=items.progress
                   except:
                     f_result[name1]['progress']=''
                   f_result[name1]['links']=items.global_var
                   
                   f_result[name1]['color']=items.color
                   if 'torrent' in items.type:
                      f_result[name1]['torrent']=True
                   else:
                      f_result[name1]['torrent']=False
                   if 'rd' in items.type:
                      f_result[name1]['rd']=True
                   else:
                      f_result[name1]['rd']=False
                   if 'subs' in items.type:
                     f_result[name1]['subs']=True
                   else:
                     f_result[name1]['subs']=False
                   if name1!='subs':
                     all_links_togther=merge_two_dicts(all_links_togther,f_result[name1])
                     #all_links_togther=all_links_togther+f_result[name1]
              
              living=[]
              for items in all_alive:
                 if all_alive[items]:
                   living.append(items)
              if count_alive>10:
                
                string_dp2='מקורות שנותרו: '+str(count_alive)+' - '+random.choice (living)
              count_found=0
              for data in f_result:
                if Addon.getSetting("server_dp")=='true' and silent_mode==False:
                       if dp.iscanceled():
                         dp_c=True
                       else:
                         dp_c=False
                else:
                       dp_c=False
                
                if dp_c or elapsed_time>max_time or stop_window:    
                    
                    
                    logging.warning('Break one')
                    break
                #for data in all_links_togther['links']:
              
                if len (f_result[data]['links'])>0:
                   count_found+=1
                   
                if 'links' in f_result[data] and len (f_result[data]['links'])>0 and data!='subs':
                     
                     for links_in in f_result[data]['links']:
                        
                         if Addon.getSetting("server_dp")=='true' and silent_mode==False:
                               if dp.iscanceled():
                                 dp_c=True
                               else:
                                 dp_c=False
                         else:
                               dp_c=False
                         if dp_c or elapsed_time>max_time or stop_window:
                            logging.warning('Break two')
                            break
                         xbmc.sleep(3)
                         name1,links,server,res=links_in
                         new_res=0
                         if '2160' in res:
                           count_2160+=1
                           new_res=2160
                         if '1080' in res:
                           count_1080+=1
                           new_res=1080
                         elif '720' in res:
                           count_720+=1
                           new_res=720
                         elif '480' in res:
                           count_480+=1
                           new_res=480
                         else:
                           count_rest+=1
                         check_super=False
                         if Addon.getSetting("super_fast_type_subs_en")=='true':
                            
                            if 'links' in f_result['subs']:
                               
                                if len(f_result['subs']['links'])>0:
                                   
                                    check_super=True
                            if f_result[data]['subs']==True:
                                    check_super=True
                         else:
                            check_super=True
                         
                         if Addon.getSetting("super_fast")=="true" and links not in check_lk and check_super and once_fast_play==0 and silent_mode==False:
                            
                            check_lk.append(links)
                            check_r_l,str_check=get_condition(name1,links,server,new_res,tv_movie,f_result,data,original_title)
                           
                            logging.warning(stoped_play_once)
                            f_ur=False
                            
                            
                            if  check_r_l :
                              
                                
                                logging.warning('IN play')
                                if  '{P-' in server and allow_debrid:
                                    try:
                                        ur=get_magnet_direct(links)
                                        
                                        f_ur=check_cached(ur)
                                    except Exception as e:
                                        logging.warning('bad link in super:'+str(e)+' '+ur)
                                        xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'Bad Torrent in super:'+str(e))).encode('utf-8'))
                                        global_result='מקור לא תקין ... סורי תפעיל ידנית'
                                else:
                                    
                                        f_ur=True
                                        ur=links
                                logging.warning('f_ur:'+str(f_ur))
                                
                                if f_ur:
                                    
                                    global_result='[COLOR yellow][I][B] Playing '+data+'-'+str_check+'[/B][/I][/COLOR]'
                                    try:
                                        xbmc.Player().stop()
                                        xbmc.sleep(100)
                                        once_fast_play=1
                                        silent_mode=True
                                        
                                        if stoped_play_once==0:
                                            plot='-'+data+'-'
                                            
                                            if f_result[data]['subs']==True:
                                                      plot='-'+data+'-'+'\n-HebDub-'
                                           
                                            
                                            if Addon.getSetting("new_window_type2")!='3' and Addon.getSetting("new_window_type2")!='4':
                                                play(name,ur,' ',' ',plot,show_original_year,season,episode,original_title,name1,heb_name,show_original_year,eng_name,'0',original_title,id,show_errors=False)
                                            else:
                                                play(name1,ur,' ',' ',plot,show_original_year,season,episode,original_title,name1,heb_name,show_original_year,eng_name,isr,original_title,id,windows_play=False,auto_fast=True,auto_play=True,f_auto_play=True,show_errors=False)
                                        if Addon.getSetting("server_dp")=='true' and silent_mode==False:
                                            dp.close()
                                    except Exception as e:
                                        #once_fast_play=0
                                        
                                        logging.warning('bad link in super:'+str(e)+' '+ur)
                                        xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'bad link in super:'+str(e))).encode('utf-8'))
                                        global_result='מקור לא תקין ... סורי תפעיל ידנית'
                all_s_in=(f_result,int(((num_live* 100.0)/(len(thread))) ),string_dp2.replace('מקורות שנותרו: ',''),2,string_dp)
                xbmc.sleep(10)
              global_result="4K: [COLOR yellow]%s[/COLOR] 1080: [COLOR khaki]%s[/COLOR] 720: [COLOR gold]%s[/COLOR] 480: [COLOR silver]%s[/COLOR] Rest: [COLOR burlywood]%s[/COLOR]"%(count_2160,count_1080,count_720,count_480,count_rest)
              string_dp="4K: [COLOR yellow]%s[/COLOR] 1080: [COLOR khaki]%s[/COLOR] 720: [COLOR gold]%s[/COLOR] 480: [COLOR silver]%s[/COLOR] Rest: [COLOR burlywood]%s[/COLOR]"%(count_2160,count_1080,count_720,count_480,count_rest)
              if Addon.getSetting("trailer_dp")=="true" and Addon.getSetting("new_server_dp")=="false":
                
                pDialog.update(int(((num_live* 100.0)/(len(thread))) ), message=time.strftime("%H:%M:%S", time.gmtime(elapsed_time))+' '+string_dp)
              total=count_1080+count_720+count_480+count_rest
              string_dp="4K: [COLOR yellow]%s[/COLOR] 1080: [COLOR khaki]%s[/COLOR] 720: [COLOR gold]%s[/COLOR] 480: [COLOR silver]%s[/COLOR] Rest: [COLOR burlywood]%s[/COLOR]  T: [COLOR darksalmon]%s[/COLOR] '[COLOR gold]SUB: %s[/COLOR]' '[COLOR yellow]SF: %s[/COLOR]' '[COLOR lightcoral]SN: %s[/COLOR]'"%(count_2160,count_1080,count_720,count_480,count_rest,total,(len( f_result['subs']['links'])),str(count_found),len(f_result)-count_found)
              if Addon.getSetting("server_dp")=='true' and silent_mode==False:
                  
                     
                  

                  
                  if Addon.getSetting("server_dp")=='true' and silent_mode==False:
                      dp.update(int(((num_live* 100.0)/(len(thread))) ), ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),string_dp, string_dp2)
                  
                  xbmc.sleep(100)
              all_s_in=(f_result,int(((num_live* 100.0)/(len(thread))) ),string_dp2.replace('מקורות שנותרו: ',''),2,string_dp)
              if Addon.getSetting("server_dp")=='true' and silent_mode==False:
                   if dp.iscanceled():
                     dp_c=True
                   else:
                     dp_c=False
              else:
                   dp_c=False
              if dp_c or elapsed_time>max_time or stop_window:
                   logging.warning('break Window:'+str(elapsed_time))
                   for name1,items in all_sources:
                       items.stop_all=1
                   num_live2=0
                   for threads in thread:
                     all_s_in=(f_result,int(((num_live2* 100.0)/(len(thread))) ),'סוגר תהליכים',2,threads.name)
                     if Addon.getSetting("server_dp")=='true' and silent_mode==False:
                        elapsed_time = time.time() - start_time
                        dp.update(int(((num_live2* 100.0)/(len(thread))) ), ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'סוגר תהליכים', threads.name)
                     if threads.is_alive():
                         
                         
                         threads._Thread__stop()
                     num_live2+=1
                   break
         
         if still_alive==0 and whats_done==1:
           logging.warning('No one is Alive')
           break
         if Addon.getSetting("server_dp")=='true' and silent_mode==False:
           if dp.iscanceled():
             dp_c=True
           else:
             dp_c=False
         else:
           dp_c=False
         if dp_c or elapsed_time>max_time or stop_window:
           logging.warning('break windows2')
           for name1,items in all_sources:
               items.stop_all=1
           num_live2=0
           for threads in thread:
             if Addon.getSetting("server_dp")=='true' and silent_mode==False:
                elapsed_time = time.time() - start_time
                dp.update(int(((num_live2* 100.0)/(len(thread))) ), ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'סוגר תהליכים', threads.name)
             all_s_in=(f_result,int(((num_live2* 100.0)/(len(thread))) ),'סוגר תהליכים',2,threads.name)
             if threads.is_alive():
                 
                 
                 threads._Thread__stop()
             num_live2+=1
           break
         xbmc.sleep(500)
    counter=0
    
    if 1:#while 1:
        alive=0
        stop_all=1
        num_live2=0
        count_all=len(threading.enumerate())
        
        for threads in thread:
          elapsed_time = time.time() - start_time
          if (threads.isAlive()):
             alive=1
             
             threads._Thread__stop()
             if Addon.getSetting("server_dp")=='true' and silent_mode==False:
                dp.update(int(((num_live2* 100.0)/(count_all)) ), ' Please wait2 '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'Closing', threads.getName()+' - '+str(counter))
             num_live2+=1
             all_s_in=(f_result,int(((num_live2* 100.0)/(count_all)) ),'Closing2',2,threads.getName()+' - '+str(counter))
        #if alive==0 or counter>10:
        #    break
        counter+=1
        xbmc.sleep(200)
    f_result={}
    f_result['subs']=[]
    f_result['magnet']={}

    f_result['magnet']['links']=''
    f_result['magnet']['color']=''
    save_name=''
    for name1,items in all_sources:
       
       f_result[name1]={}
       try:
          f_result[name1]['progress']=items.progress
       except:
         f_result[name1]['progress']=''
       f_result[name1]['links']=items.global_var
      
       f_result[name1]['color']=items.color
       if 'torrent' in items.type:
          f_result[name1]['torrent']=True
       else:
          f_result[name1]['torrent']=False
       if 'rd' in items.type:
          f_result[name1]['rd']=True
       else:
          f_result[name1]['rd']=False
       if 'subs' in items.type:
         f_result[name1]['subs']=True
       else:
         f_result[name1]['subs']=False
       
    if Addon.getSetting("trailer_dp")=="true" and Addon.getSetting("new_server_dp")=="false":
      xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'חיפוש מקורות הסתיים')).encode('utf-8'))
      pDialog.close()
    logging.warning('start new matching')
    all_links_fp=[]
    all_pre=[]
    z=0
    all_lk2=[]
    all_mag={}
    page_index=0
    all_mag[0]=[]
    counter_hash=0
    if Addon.getSetting("check_cached")=='true' and allow_debrid:
        try:
            for name_f in f_result:
              if name_f!='subs' :
                for name,link,server,quality in f_result[name_f]['links']:
                    if Addon.getSetting("dp")=='true' and silent_mode==False:
                       elapsed_time = time.time() - start_time
                       dp.update(0, ' Please wait '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'Updating links , check cached', name)
                    if link not in all_lk2:
                        all_lk2.append(link)
                        if 'magnet' in link:
                            try:
                                #hash = str(re.findall(r'btih:(.*?)&', link)[0].lower())
                                hash=link.split('btih:')[1]
                                if '&' in hash:
                                    hash=hash.split('&')[0]
                            except:
                                hash =link.split('btih:')[1]
                            #logging.warning(link)
                            #logging.warning(hash)
                            
                            all_mag[page_index].append(hash)
                            counter_hash+=1
                            if counter_hash>150:
                                page_index+=1
                                all_mag[page_index]=[]
                                counter_hash=0
            
            all_hased=[]
            
            import real_debrid
            rd = real_debrid.RealDebrid()
            for items in all_mag:
                
               
                if len(all_mag[items])>0 :
                    logging.warning(all_mag[items])
                    hashCheck = rd.checkHash(all_mag[items])
                    
                    for hash in hashCheck:
                        if Addon.getSetting("dp")=='true' and silent_mode==False:
                           elapsed_time = time.time() - start_time
                           dp.update(0, ' Please wait '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'Updating links , check cached', hash)
                      
                        if 'rd' in hashCheck[hash]:
                           if len(hashCheck[hash]['rd'])>0:
                                all_hased.append(hash)
                
            for name_f in f_result:
                    index=0
                    if name_f!='subs' :
                     for name,link,server,quality in f_result[name_f]['links']:
                        
                         
                        if 'magnet' in link:
                            hash = str(re.findall(r'btih:(.*?)&', link)[0].lower())
                            if hash in all_hased:
                                
                                f_result[name_f]['links'][index]=['Cached '+name,link,server,quality]
                        index+=1
        
        
        except Exception as e:
            import linecache
            exc_type, exc_obj, tb = sys.exc_info()
            f = tb.tb_frame
            lineno = tb.tb_lineno
            filename = f.f_code.co_filename
            linecache.checkcache(filename)
            line = linecache.getline(filename, lineno, f.f_globals)
            xbmc.executebuiltin(u'Notification(%s,%s)' % ('Victory', 'ERROR IN Cached test:'+str(lineno)))
            logging.warning('ERROR IN Cached test:'+str(lineno))
            logging.warning('inline:'+line)
            logging.warning(e)
            logging.warning('BAD Cached test')
            
    if Addon.getSetting("check_subs_comp")=='true':
        for name_f in f_result:
           all_s_in=( {},int(((z* 100.0)/(len(f_result)))) ,'בודק תאימות כתוביות',3,'')
           if name_f!='subs' :
                
                for name,link,server,quality in f_result[name_f]['links']:
                    if allow_debrid and Addon.getSetting("show_only_chached")=='true' and Addon.getSetting("check_cached")=='true':
                       if 'Cached ' not in name and 'magnet' in name_f :
                        continue
                    if link not in all_links_fp:
                        if Addon.getSetting("server_dp")=='true' and silent_mode==False:
                          elapsed_time = time.time() - start_time
                          dp.update(0, ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'בודק תאימות כתוביות', name)
                          
                        if f_result[name_f]['subs']==True:
                          pre='101'
                        else:
                          pre=check_pre(name,f_result['subs']['links'],original_title)
                        f_result[name_f]['pre']=pre
                        all_links_fp.append(link)
                        all_pre.append(pre)
                    
           z+=1
       
    #logging.warning('end new matching')
    #logging.warning('len pre')
    #logging.warning(len(all_links_fp))
    
    if Addon.getSetting("server_dp")=='true' and silent_mode==False:
      dp.close()
    f_subs=[]
    if tv_mode=='tv':
        import subs
        episode1=str(int(episode)+1)
        if len(episode1)==1:
              episode_n1="0"+episode1
        else:
               episode_n1=episode1
        f_subs=subs.get_links('tv',original_title,name,season_n,episode_n1,season,episode1,show_original_year,id,check_one=True)
    done_c_get=0
    try:
        current_subs=f_result['subs']['links']
    except:
        current_subs=[]
    return f_result,all_links_fp,all_pre,f_subs,current_subs
   except Exception as e:
        import linecache
        exc_type, exc_obj, tb = sys.exc_info()
        f = tb.tb_frame
        lineno = tb.tb_lineno
        filename = f.f_code.co_filename
        linecache.checkcache(filename)
        line = linecache.getline(filename, lineno, f.f_globals)
        xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'Line:'+str(lineno)+' E:'+str(e))).encode('utf-8'))
        logging.warning('ERROR IN Looking sources:'+str(lineno))
        logging.warning('inline:'+line)
        logging.warning(e)
        logging.warning('BAD Looking sources')
        done_c_get=0
        if Addon.getSetting("server_dp")=='true' and silent_mode==False:
            dp.close()

def check_pre(saved_name,all_subs,original_title):
       if Addon.getSetting("check_subs_comp")=='false':
         return 0
       release_names=['bluray','hdtv','dvdrip','bdrip','web-dl','brrip','hdrip','webrip','web']
       #array_original=list(saved_name)
       fixed_name=saved_name.lower().strip().replace("%20",".").replace("_",".").replace(" ",".").replace("-",".").replace(".avi","").replace(".mp4","").replace(".mkv","")
       original_title=original_title.lower().strip().replace("%20",".").replace("_",".").replace(" ",".").replace("-",".").replace(".avi","").replace(".mp4","").replace(".mkv","")
       

       
       
       fixed_name=fixed_name.decode('utf-8','ignore').encode("utf-8").replace(original_title,'').replace(original_title.replace(' ','.'),'')
       
       if fixed_name=='':
         return 0
       array_original=fixed_name.split(".")
       fixed_name_pre=fixed_name
       array_original=[line.strip().lower() for line in array_original]
       array_original=[(x) for x in array_original if x != '']
       array_original_src=array_original
       highest=0
       all_subs_sv=[]
       
       
       for items in all_subs:
           if items not in all_subs_sv:
               all_subs_sv.append(items)
               #array_subs=list(items)
               fixed_name=items.lower().strip().replace("%20",".").replace("_",".").replace(" ",".").replace("-",".").replace(".avi","").replace(".mp4","").replace(".mkv","")
               fixed_name=fixed_name.replace(original_title,'')
               array_subs=fixed_name.split(".")
               array_subs=[line.strip().lower() for line in array_subs]
               array_subs=[str(x).lower() for x in array_subs if x != '']
               array_original=fixed_name_pre.split(".")

               array_original=[line.strip().lower() for line in array_original]
               array_original=[(x) for x in array_original if x != '']
               
               for item_2 in release_names:
                
                if item_2 in array_original and item_2 in array_subs:
                  array_original.append(item_2)
                  array_original.append(item_2)
                  array_original.append(item_2)
                  array_subs.append(item_2)
                  array_subs.append(item_2)
                  array_subs.append(item_2)
        
               
               precent=similar(array_original,array_subs)
               
               if precent>=highest:
                 highest=precent
      
       return highest


def filter_servers(url):
    url=url.lower()
    skip=[]
    
    if Addon.getSetting("re_rapid")=='true':
        if 'rapidvideo' not in url:
            skip.append(True)
        else:
            skip.append(False)
        
    if Addon.getSetting("re_google")=='true':
        if 'google' not in url and 'gdrive' not in url:
            skip.append(True)
        else:
            skip.append(False)
        
    if Addon.getSetting("re_direct")=='true':
        if 'direct' not in url and 'sratim-il' not in url and 'cdn' not in url:
            skip.append(True)
        else:
            skip.append(False)
        
    if Addon.getSetting("re_open")=='true':
        if 'openload' not in url and 'oload' not in url:
            skip.append(True)
        else:
            skip.append(False)
        
            
    if Addon.getSetting("re_stream")=='true':
        if  'streamango' not in url:
            skip.append(True)
            
    if Addon.getSetting("re_magnet")=='true':
        if  '{p-' not in url:
            skip.append(True)
        else:
            skip.append(False)
        
    if Addon.getSetting("re_vidc")=='true':
        if 'vidcloud' not in url:
            skip.append(True)
        else:
            skip.append(False)
        
    result=True
    for items in skip:
        result=result&items
    return result
def get_rest_s(time_to_save, name,year,original_title,season,episode,id,eng_name,show_original_year,heb_name,isr,get_local):
    global silent_mode
    
    silent_mode=True
    time_to_wait_for_rest=int(Addon.getSetting("time_to_wait_for_rest"))
    logging.warning('Waitign for rest')
    
    time.sleep(time_to_wait_for_rest)
    logging.warning('Done for rest')
    t=[]
    t.append((time_to_save, name,year,original_title,season,episode,id,eng_name,show_original_year,heb_name,isr,get_local))
    logging.warning('this is the search')

    all_f_links,all_links_fp,all_pre,f_subs,current_subs= cache.get(c_get_sources, time_to_save, original_title,year,original_title,season,episode,id,eng_name,show_original_year,heb_name,isr,get_local,'rest','no','0', table='pages')
    #xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'כל המקורות מוכנים'.encode('utf-8'))))
    return 0
def get_torrents(url):
    return url
def resolver_supported():
    resolvable_files_dir=os.path.join(xbmc.translatePath("special://home"),"addons", "script.module.resolveurl","lib","resolveurl","plugins")
   
    onlyfiles = [f for f in listdir(resolvable_files_dir) if isfile(join(resolvable_files_dir, f))]
    supported=[]
    for items in onlyfiles:
        if ".pyo" not in items and ".pyc" not in items and '__' not in items:
            supported.append(items.replace('.py',''))
    return (supported)
def get_rd_servers():
    rd_domains=[]
    if allow_debrid:
        rd_domains=[]
        try:
            import real_debrid
            rd = real_debrid.RealDebrid()
            rd_domains=(rd.getRelevantHosters())
       
            if len(rd_domains)==0:
                    Addon.setSetting('rd.client_id','')
                    rd.auth()
                    rd = real_debrid.RealDebrid()
                    rd_domains=(rd.getRelevantHosters())
        except Exception as e:
            logging.warning(e)
            pass
        if len (rd_domains)==0:
            rd_domains=[u'4shared.com', u'rapidgator.net', u'sky.fm', u'1fichier.com', u'depositfiles.com', u'hitfile.net', u'filerio.com', u'solidfiles.com', u'mega.co.nz', u'scribd.com', u'flashx.tv', u'canalplus.fr', u'dailymotion.com', u'salefiles.com', u'youtube.com', u'faststore.org', u'turbobit.net', u'big4shared.com', u'filefactory.com', u'youporn.com', u'oboom.com', u'vimeo.com', u'redtube.com', u'zippyshare.com', u'file.al', u'clicknupload.me', u'soundcloud.com', u'gigapeta.com', u'datafilehost.com', u'datei.to', u'rutube.ru', u'load.to', u'sendspace.com', u'vidoza.net', u'tusfiles.net', u'unibytes.com', u'ulozto.net', u'hulkshare.com', u'dl.free.fr', u'streamcherry.com', u'mediafire.com', u'vk.com', u'uploaded.net', u'userscloud.com',u'nitroflare.com']
        rd_domains.append('nitroflare.com')
        rd_domains.append('rapidgator.net')
        rd_domains.append('uploadgig.com')
    return rd_domains
def undo_get_rest_data(full_str):
    params=get_custom_params(full_str)
    for items in params:
        params[items]=params[items].replace(" ","%20")

    url=None
    name=None
    mode=None
    iconimage=None
    fanart=None
    description=' '
    original_title=' '
    fast_link=''
    data=0
    id=' '
    saved_name=' '
    prev_name=' '
    isr=0
    season="%20"
    episode="%20"
    show_original_year=0
    heb_name=' '
    tmdbid=' '
    eng_name=' '
    dates=' '
    data1='[]'
    fav_status='false'
    only_torrent='no'
    only_heb_servers='0'
    new_windows_only=False
    try:
            url=urllib.unquote_plus(params["url"])
    except:
            pass
    try:
            name=urllib.unquote_plus(params["name"])
    except:
            pass
    try:
            iconimage=urllib.unquote_plus(params["iconimage"])
    except:
            pass
    try:        
            mode=int(params["mode"])
    except:
            pass
    try:        
            fanart=urllib.unquote_plus(params["fanart"])
    except:
            pass
    try:        
            description=urllib.unquote_plus(params["description"].encode('utf-8'))
    except:
            pass
    try:        
            data=urllib.unquote_plus(params["data"])
    except:
            pass
    try:        
            original_title=(params["original_title"])
    except:
            pass
    try:        
            id=(params["id"])
    except:
            pass
    try:        
            season=(params["season"])
    except:
            pass
    try:        
            episode=(params["episode"])
    except:
            pass
    try:        
            tmdbid=(params["tmdbid"])
    except:
            pass
    try:        
            eng_name=(params["eng_name"])
    except:
            pass
    try:        
            show_original_year=(params["show_original_year"])
    except:
            pass
    try:        
            heb_name=urllib.unquote_plus(params["heb_name"])
    except:
            pass
    try:        
            isr=int(params["isr"])
    except:
            pass
    try:        
            saved_name=clean_name(params["saved_name"],1)
    except:
            pass
    try:        
            prev_name=(params["prev_name"])
    except:
            pass
    try:        
            dates=(params["dates"])
    except:
            pass
    try:        
            data1=(params["data1"])
    except:
            pass
    try:        
        
            fast_link=urllib.unquote_plus(params["fast_link"])
    except:
            pass
    try:        
        
            fav_status=(params["fav_status"])
    except:
            pass
    try:        
        
            only_torrent=(params["only_torrent"])
    except:
            pass
    try:        
        
            only_heb_servers=(params["only_heb_servers"])
    except:
            pass
    try:        
           
            new_windows_only=(params["new_windows_only"])
            new_windows_only = new_windows_only == "true" 
    except:
            pass
    return url,name,iconimage,mode,fanart,description,data,original_title,id,season,episode,tmdbid,eng_name,show_original_year,heb_name,isr,saved_name,prev_name,dates,data1,fast_link,fav_status,only_torrent,only_heb_servers,new_windows_only
def check_cached(magnet):
    import real_debrid
    rd = real_debrid.RealDebrid()
    check=False
    hash = str(re.findall(r'btih:(.*?)&', magnet)[0].lower())
    hashCheck = rd.checkHash(hash)
    if hash in hashCheck:
            if 'rd' in hashCheck[hash]:
                if len(hashCheck[hash]['rd'])>0:
                    check=True
    return check
def get_rest_data(name,url,mode,iconimage,fanart,description,video_info={},data=' ',original_title=' ',id=' ',season=' ',episode=' ',tmdbid=' ',eng_name=' ',show_original_year=' ',rating=0,heb_name=' ',isr=0,generes=' ',trailer=' ',dates=' ',watched='no',fav_status='false'):
        name=name.replace("|",' ')
        description=description.replace("|",' ')
        try:
            te1=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
            
            te2="&name="+(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description.encode('utf8'))+"&heb_name="+(heb_name)+"&dates="+(dates)
            te3="&data="+str(data)+"&original_title="+(original_title)+"&id="+(id)+"&season="+str(season)
            te4="&episode="+str(episode)+"&tmdbid="+str(tmdbid)+"&eng_name="+(eng_name)+"&show_original_year="+(show_original_year)+"&isr="+str(isr)
        
        
        
        
        
            u=te1 + te2 + te3 + te4.decode('utf8')+"&fav_status="+fav_status
        except:
           reload(sys)  
           sys.setdefaultencoding('utf8')
           te1=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
            
           te2="&name="+(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description.encode('utf8'))+"&heb_name="+(heb_name)+"&dates="+(dates)
           te3="&data="+str(data)+"&original_title="+(original_title)+"&id="+(id)+"&season="+str(season)
           te4="&episode="+str(episode)+"&tmdbid="+str(tmdbid)+"&eng_name="+(eng_name)+"&show_original_year="+(show_original_year)+"&isr="+str(isr)
        
           u=te1 + te2 + te3 + te4.decode('utf8')+"&fav_status="+fav_status
        return u
def get_m_sub(name):
    headers = {
        'authority': 'moridimtv.com',
        'pragma': 'no-cache',
        'cache-control': 'no-cache',
        'accept': '*/*',
        'origin': 'https://moridimtv.com',
        'x-requested-with': 'XMLHttpRequest',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36',
        'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-mode': 'cors',
        'referer': 'https://moridimtv.com/search?q=%s&table=movies&type=1'%name,
        'accept-encoding': 'utf-8',
        'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
        
    }

    data = {
      'table': 'movies',
      'q': name,
      'index': '0',
      'limit': '10',
      'type': '1'
    }
    link='https://moridim.me/search/%s/'%name.replace(' ','+')
    response = requests.get(link, headers=headers).content
    regex='<h5><a href=.+?>(.+?)<'
    m=re.compile(regex).findall(response)
    
    q=True
    subs=True
    if len(m)>0:
        if 'cam' in   m[0].lower() or 'ts' in   m[0].lower():
            q=False
        
        if 'ללא תרגום' in m[0]:
            subs=False
    
    return subs,q
def is_hebrew(input_str):    
       try:
        import unicodedata
        input_str=input_str.replace(' ','').replace('\n','').replace('\r','').replace('\t','').replace(' ','')
        nfkd_form = unicodedata.normalize('NFKD', input_str.replace(' ','').replace('\n','').replace('\r','').replace('\t','').replace(' ',''))
        a=False
        for cha in input_str:
            
            a='HEBREW' in unicodedata.name(cha.strip())
            if a:
                break
        return a
       except Exception as e:
            logging.warning('heb err:'+str(e))
            return True
            
def get_sources(name,url,icon,image,plot,year,original_title,season,episode,id,eng_name,show_original_year,heb_name,isr,dates='',data1='[]',get_local=False,fast_link='',fav_status='false',only_torrent='no',only_heb_servers='0',new_windows_only=False,metaliq='false'):
    global imdb_global,all_s_in,once_fast_play,close_sources_now,done_c_get,string_dp
    import urlparse
    #res_same=get_rest_data(name,url,4,icon,image,plot,data=year,original_title=original_title,season=season,episode=episode,id=id,eng_name=eng_name,heb_name=heb_name,show_original_year=year,isr=isr,dates=dates,fav_status=fav_status).replace(' ','%20')
    logging.warning('original_title:'+original_title)
    logging.warning('season:'+season)
    logging.warning('episode:'+episode)
    if season!=None and season!="%20":
       tv_movie='tv'
    
          
    else:
        tv_movie='movie'
    if tv_movie=='movie':
        dbcur.execute("SELECT * FROM q_and_s WHERE id = '%s'"%(id))
        match = dbcur.fetchone()
        if match==None:
            import datetime
            now = datetime.datetime.now()
            selected_year=int(now.year)-1
            
            if int(year)==int(now.year) or int(year)==selected_year:
                
                res1,sb,tet_txt,unkown=check_q(original_title,url,year,id,check_ok=True)
                res=''
                su=''
                subtitle_status=True
                if Addon.getSetting("check_s")=='true' and sb==False:
                    
                    subtitle_status=False
                    
                quality_status=True
                if Addon.getSetting("check_q")=='true' and res1==False:
                    
                    quality_status=False
                logging.warning('quality_status:'+str(quality_status))
                logging.warning(Addon.getSetting("check_q"))
                m_sub=''
                m_q=''
                if subtitle_status==False:
                    m_sub,m_q=get_m_sub(clean_name(original_title,1))
                    if m_sub:
                        su='[COLOR lightgreen]יש כתוביות (M)[/COLOR]'
                        subtitle_status=True
                    else:
                        su='[COLOR red]אין כתוביות[/COLOR]'
                else:
                    su='[COLOR lightblue]יש כתוביות[/COLOR]'
                if quality_status==False or unkown==1:
                    quality_status==False
                    if m_sub=='':
                        m_sub,m_q=get_m_sub(clean_name(original_title,1))
                    if m_q:
                        res='[COLOR lightgreen]יש מקור איכותי (M)[/COLOR]'
                    else:
                        
                        if unkown==1:
                            res='[COLOR pink]לא ידוע[/COLOR]'
                        else:
                            res='[COLOR red]אין מקור איכותי[/COLOR]'
                    if len(tet_txt)>0:
                        tet_txt='אמור לצאת ב: '+tet_txt
                else:
                    if unkown==1:
                        res='[COLOR pink]לא ידוע[/COLOR]'
                        quality_status==False
                    else:
                        res='[COLOR lightblue]יש מקור איכותי[/COLOR]'
                        if len(tet_txt)>0:
                            tet_txt='יצא: '+tet_txt
                if quality_status==False or subtitle_status==False:
                    
                        
                    response=xbmcgui.Dialog().yesno('מה לעשות?', su+' - '+res+'\n'+tet_txt, yeslabel='המשך', nolabel='עצור')
                    if not response:
                        sys.exit()
                        return '0',[] 
                else:
                    dbcur.execute("INSERT INTO q_and_s Values ('%s',' ');" %  (id))
                    dbcon.commit()
    logging.warning('get_sources fav_status:'+fav_status)
    o_fav_status=fav_status
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    once_fast_play=0
    o_plot=plot
    rd_domains=[]
    if id=='moridim':
        x=requests.get(url).content
        regex='www.imdb.com/title/(.+?)/'
        m=re.compile(regex).findall(x)
        if len(m)>0:
            id=m[0]
        else:
            id='0'
    if allow_debrid:
        rd_domains=cache.get(get_rd_servers, 72, table='pages')
        
        #rd_domains=requests.get('https://api.real-debrid.com/rest/1.0/hosts/domains').json()
    
    try:
        if 'tt' in id:
             url3='https://api.themoviedb.org/3/find/%s?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&language=en-US&external_source=imdb_id'%id
             xx=requests.get(url3).json()
             logging.warning('Finding')
             if tv_movie=='tv':
                if len(xx['tv_results'])>0:
                    id=str(xx['tv_results'][0]['id'])
             else:
                if len(xx['movie_results'])>0:
                    id=str(xx['movie_results'][0]['id'])
             logging.warning('Found :'+ str(id))
    except Exception as e:
        logging.warning(e)
        pass

    
    
   
    if '-פרק ' in plot and '-NEXTUP-' not in plot:

        all_d=json.loads(urllib.unquote_plus(dates))
        
        if len(all_d)<2:
            all_d=['','','']
        next_season=0
        next_season_json={}
        if all_d[2]==0:
            ur='http://api.themoviedb.org/3/tv/%s?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&language=he&append_to_response=external_ids'%id
            next_season_json=requests.get(ur).json()
            logging.warning('next_season_json:'+str(next_season_json['number_of_seasons'])+'-'+str(season))
            if int(next_season_json['number_of_seasons'])>int(season):
                next_season=1
        if next_season==1:
            choise=['נגן את הפרק בעונה הבאה  ','נגן פרק קודם - '+all_d[0],'פתח את פרקי העונה','פתח את בחירת העונה']
        elif all_d[0]==0:
          choise=['נגן את הפרק הבא - '+all_d[2],'נגן פרק נוכחי - '+all_d[1],'פתח את פרקי העונה','פתח את בחירת העונה']
        elif all_d[2]==0:
          choise=['נגן פרק נוכחי - '+all_d[1],'נגן פרק קודם - '+all_d[0],'פתח את פרקי העונה','פתח את בחירת העונה']
        else:
          if 'magenta' not in all_d[2]:
             choise=['נגן את הפרק הבא - '+all_d[2],'נגן פרק נוכחי - '+all_d[1],'נגן פרק קודם - '+all_d[0],'פתח את פרקי העונה','פתח את בחירת העונה']
          else:
             choise=['[COLOR magenta]'+'נגן את הפרק הבא - '+'[/COLOR]'+all_d[2],'נגן פרק נוכחי - '+all_d[1],'נגן פרק קודם - '+all_d[0],'פתח את פרקי העונה','פתח את בחירת העונה']
       
        if Addon.getSetting("tv_ep_window")=='true':
            menu=[]

            menu = Chose_ep('plugin.video.allmoviesin', heb_name,name,id,season,episode,dates,original_title,next_season)
            menu.doModal()
            ret = menu.params
            logging.warning('ret:'+str(ret))
            logging.warning(all_d)
            del menu
            
        else:
            ret = xbmcgui.Dialog().select("בחר פרק", choise)
        if ret!=-1:
            
            if all_d[2]==0 or all_d[0]==0:
              prev_index=1
            else:
              prev_index=2
            if ret==0 and next_season==1:
              if next_season==1:
                season=str(int(season)+1)
                episode='1'
              
            elif ret==0 and all_d[2]!=0:
             
              episode=str(int(episode)+1)
              from tmdb import get_episode_data
              name,plot,image,ss,ee=get_episode_data(id,season,episode)
              o_plot='עונה %s פרק %s \n'%(season,episode)+plot
            elif ret==prev_index:
              if int(episode)>1:
                episode=str(int(episode)-1)
                from tmdb import get_episode_data
                name,plot,image,ss,ee=get_episode_data(id,season,episode)
                o_plot='עונה %s פרק %s \n'%(season,episode)+plot
            elif ret==(prev_index+1):
                
                plot=plot.replace('-פרק ','')
                xbmc.executebuiltin(('Container.update("plugin://plugin.video.allmoviesin/?name=%s&url=%s&iconimage=%s&fanart=%s&description=%s&data=%s&original_title=%s&id=%s&season=%s&tmdbid=%s&show_original_year=%s&heb_name=%s&isr=%s&mode=8",return)'%(name,urllib.quote_plus(url),icon,image,urllib.quote_plus(plot),year,original_title,id,season,tmdbid,show_original_year,heb_name,isr)))
                '''
                get_episode(name,url,iconimage,image,plot,data,original_title,id,season,tmdbid,show_original_year,heb_name,isr)
                xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
                xbmcplugin.endOfDirectory(int(sys.argv[1]))
                return 0
                '''
                return '0',[] 
                sys.exit()
            elif ret==(prev_index+2):
                plot=plot.replace('-פרק ','')
                logging.warning('OPEN SEASONS')
                xbmc.executebuiltin(('Container.update("plugin://plugin.video.allmoviesin/?name=%s&url=%s&iconimage=%s&fanart=%s&description=%s&data=%s&original_title=%s&id=%s&season=%s&tmdbid=%s&show_original_year=%s&heb_name=%s&isr=%s&mode=7",return)'%(name,urllib.quote_plus(url),icon,image,urllib.quote_plus(plot),year,original_title,id,season,tmdbid,show_original_year,heb_name,isr)))
                '''
                get_seasons(name,url,iconimage,image,plot,data,original_title,id,heb_name,isr)
                xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
                xbmcplugin.endOfDirectory(int(sys.argv[1]))
                return 0
                '''
                return '0',[]
                sys.exit()
             
        else:
          sys.exit()
          return 'ENDALL',[]
    if len(episode)==1:
      episode_n="0"+episode
    else:
       episode_n=episode
    logging.warning('episode:'+episode)
    if len(season)==1:
      season_n="0"+season
    else:
      season_n=season

    time_to_save=int(Addon.getSetting("save_time"))
    search_done=0
    if Addon.getSetting("server_test_one")=='true':
        
       all_f_links=c_get_sources(name,year,original_title,season,episode,id,eng_name,show_original_year,heb_name,isr,get_local=False,fav_status=fav_status,only_torrent=only_torrent,only_heb_servers=only_heb_servers)
  
       sys.exit()
    #all_f_links=c_get_sources(name,year,original_title,season,episode,id,eng_name,show_original_year,heb_name,isr,get_local=False,fav_status=fav_status,only_torrent=only_torrent,only_heb_servers=only_heb_servers)
  
    #sys.exit()
    
    if 'שרתים שסוננו' in name:
        filter_mode=True
    else:
        filter_mode=False
  
    if 'שאר התוצאות' in name:
        filter_loc='rest'
        rest_test=' שאר התוצאות '
    else:
        filter_loc='rest2'
        rest_test=''
    all_d_new=[]
    all_d_new.append((name,url,icon,image,plot,year,original_title,season,episode,id,eng_name,show_original_year,heb_name,isr,dates,data1))
    if tv_movie=='movie':
        fav_search_f=Addon.getSetting("fav_search_f")
        fav_servers_en=Addon.getSetting("fav_servers_en")
        fav_servers=Addon.getSetting("fav_servers")
       
        google_server= Addon.getSetting("google_server")
        rapid_server=Addon.getSetting("rapid_server")
        direct_server=Addon.getSetting("direct_server")
        heb_server=Addon.getSetting("heb_server")
    else:
        fav_search_f=Addon.getSetting("fav_search_f_tv")
        fav_servers_en=Addon.getSetting("fav_servers_en_tv")
        fav_servers=Addon.getSetting("fav_servers_tv")
        google_server= Addon.getSetting("google_server_tv")
        rapid_server=Addon.getSetting("rapid_server_tv")
        direct_server=Addon.getSetting("direct_server_tv")
        heb_server=Addon.getSetting("heb_server_tv")
        
   
              
        
    if fav_status!='rest':
        if  fav_search_f=='true' and fav_servers_en=='true' and (len(fav_servers)>0 or heb_server=='true' or google_server=='true' or rapid_server=='true' or direct_server=='true'):
            fav_status='true'
        else:
            fav_status='false'
    logging.warning('get_sources')
    logging.warning('Now')
    name=name.replace('[COLOR red]','').replace('[COLOR white]','').replace('[/COLOR]','')
    o_year=year
    if plot==None:
      plot=' '
    if 'NEXTUP' in plot:
      nextup=True
    else:
      nextup=False
    o_name=name
    
    try:
      if season!=None and season!="%20":
        name=original_title
      
      d=[]
      d.append((name,year,original_title,season,episode,id,eng_name,show_original_year,heb_name,isr,get_local,fav_status,only_torrent,only_heb_servers))
      logging.warning('fav_status3333')
      logging.warning(d)
      done_c_get=1
      all_f_links,all_links_fp,all_pre,f_subs,current_subs= cache.get(c_get_sources, time_to_save, original_title,year,original_title,season,episode,id,eng_name,show_original_year,heb_name,isr,get_local,fav_status,only_torrent,only_heb_servers, table='pages')
      done_c_get=0
      if tv_movie=='tv':
        fav_first=Addon.getSetting("fav_search_rest_tv")
      else:
        fav_first=Addon.getSetting("fav_search_rest")
      rest_of_data=[]
      rest_found=0
      logging.warning('Found_links2:')
      logging.warning(fav_status)
      logging.warning(Addon.getSetting("all_t"))
      logging.warning(o_name)
      check=False
      if Addon.getSetting("magnet")=='true':
        if Addon.getSetting("all_t")!='1':
            check=True
      else:
        check=True
      if fav_status=='true' and  check and only_torrent!='yes'  :
          found_links=0
          for name_f in all_f_links:
           
           if found_links==1:
             break
           if name_f!='subs' :
         
            
            for name,link,server,quality in all_f_links[name_f]['links']:
                found_links=1
                break
  
          if found_links==0 and fav_status=='true':
            all_f_links,all_links_fp,all_pre,f_subs,current_subs= cache.get(c_get_sources, time_to_save, original_title,year,original_title,season,episode,id,eng_name,show_original_year,heb_name,isr,get_local,'rest','no','0', table='pages')
            rest_found=1
          elif fav_status=='true' and  fav_first=='true':
            
            rest_of_data.append((time_to_save, original_title,year,original_title,season,episode,id,eng_name,show_original_year,heb_name,isr,get_local))
          
            #thread[0].start()
      a=1
    
    except Exception as e:
      import linecache
      exc_type, exc_obj, tb = sys.exc_info()
      f = tb.tb_frame
      lineno = tb.tb_lineno
      filename = f.f_code.co_filename
      linecache.checkcache(filename)
      line = linecache.getline(filename, lineno, f.f_globals)
      
      logging.warning('ERROR IN Sources Search:'+str(lineno))
      logging.warning('inline:'+line)
      logging.warning(e)
      logging.warning('BAD Sources Search')
      xbmcgui.Dialog().ok('Error occurred',' Sources Search Error '+str(e))
      close_sources_now=1
      return 0
      
    
      
    
    next_ep=[]
    if Addon.getSetting("dp")=='true' and silent_mode==False:
        dp = xbmcgui . DialogProgress ( )
        dp.create('אנא המתן','מסדר מקורות', '','')
        dp.update(0, 'אנא המתן','מסדר מקורות', '' )
    all_s_in=({},0,'מסדר מקורות',2,string_dp)
    start_time=time.time()
    if get_local==False:
     if season!=None and season!="%20":
      episode1=str(int(episode)+1)
      if len(episode1)==1:
          episode_n1="0"+episode1
      else:
           episode_n1=episode1
      from tmdb import get_episode_data
      name1,plot1,image1,ss,ee=get_episode_data(id,season,episode1,yjump=False)
      logging.warning('NAME1:'+name1+' S%sE%s'%(season,episode1))
      
      if name1!=' ':    
        
        
        f_name=''
        if Addon.getSetting("dp")=='true' and silent_mode==False:
            elapsed_time = time.time() - start_time
            dp.update(0, 'אנא המתן',' בודק כתוביות לפרק הבא ', '' )
        all_s_in=({},0,' בודק כתוביות לפרק הבא ',2,string_dp)
        import subs
        f_subs=cache.get(subs.get_links,99999,'tv',original_title,name,season_n,episode_n1,season,episode1,show_original_year,id,True, table='pages')
        #f_subs=subs.get_links('tv',original_title,name,season_n,episode_n1,season,episode1,show_original_year,id,check_one=True)
        if len(f_subs)>0:
            f_name='[COLOR peru] ◄ [/COLOR]'
        logging.warning('Nextep fav_status:'+fav_status)
        
        addDir3( f_name+'[COLOR gold][I]פתח מקורות הפרק הבא - %s[/I][/COLOR]'%episode1, url,4,icon,image1,plot1+'-NEXTUP-',data=year,original_title=original_title,season=season,episode=episode1,id=id,eng_name=eng_name,show_original_year=show_original_year,heb_name=heb_name,isr=isr,dates=dates,fav_status=fav_status)
        next_ep.append(get_rest_data( f_name+'[COLOR gold][I]פתח מקורות הפרק הבא - %s[/I][/COLOR]'%episode1, url,4,icon,image1,plot1+'-NEXTUP-',data=year,original_title=original_title,season=season,episode=episode1,id=id,eng_name=eng_name,show_original_year=show_original_year,heb_name=heb_name,isr=isr,dates=dates,fav_status=fav_status))
      else:
        ur='http://api.themoviedb.org/3/tv/%s?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&language=he&append_to_response=external_ids'%(id)
        x=requests.get(ur).json()
        if int(x['number_of_seasons'])>int(season):
            n_season=str(int(season)+1)
            name1,plot1,image1,ss,ee=get_episode_data(id,n_season,'1')
            
            f_name=''
            if Addon.getSetting("dp")=='true' and silent_mode==False:
                elapsed_time = time.time() - start_time
                dp.update(0, 'אנא המתן',' בודק כתוביות לפרק הבא ', '' )
            all_s_in=({},0,' בודק כתוביות לפרק הבא ',2,string_dp)
            import subs
            
            
            f_subs=cache.get(subs.get_links,99999,'tv',original_title,name,n_season,'1',n_season,'1',show_original_year,id,True, table='pages')
            
            if len(f_subs)>0:
                f_name='[COLOR peru] ◄ [/COLOR]'
            
            
            addDir3( f_name+'[COLOR khaki][I]פתח את הפרק של העונה הבאה - %s[/I][/COLOR]'%n_season, url,4,icon,image1,plot1+'-NEXTUP-',data=year,original_title=original_title,season=n_season,episode='1',id=id,eng_name=eng_name,show_original_year=show_original_year,heb_name=heb_name,isr=isr,dates=dates,fav_status=fav_status)
            next_ep.append(get_rest_data( f_name+'[COLOR khaki][I]פתח את הפרק של העונה הבאה - %s[/I][/COLOR]'%n_season, url,4,icon,image1,plot1+'-NEXTUP-',data=year,original_title=original_title,season=n_season,episode='1',id=id,eng_name=eng_name,show_original_year=show_original_year,heb_name=heb_name,isr=isr,dates=dates,fav_status=fav_status))
        else:
            if x['status']=='Ended' or x['status']=='Canceled':
                added_txt='[I]סדרה נגמרה[/I]'
            else:
                added_txt='[I]המתן לעונה הבאה[/I]'
            if 1:
                addDir3( ' [COLOR khaki][I]המלצה לסדרה חדשה[/I][/COLOR] '+added_txt, 'tv',26,icon,image1,plot1+'-NEXTUP-',data=year,original_title=original_title,season=season,episode='1',id=id,eng_name=eng_name,show_original_year=show_original_year,heb_name=heb_name,isr=isr,dates=dates,fav_status=fav_status)
                next_ep.append(get_rest_data( ' [COLOR khaki][I]המלצה לסדרה חדשה [/I][/COLOR] '+added_txt, 'tv',26,icon,image1,plot1+'-NEXTUP-',data=year,original_title=original_title,season=season,episode='1',id=id,eng_name=eng_name,show_original_year=show_original_year,heb_name=heb_name,isr=isr,dates=dates,fav_status=fav_status))
            
                
    logging.warning('len pre After')

    '''
    all_links_fp=[]
    all_pre=[]
    for name_f in all_f_links:
  
       if name_f!='subs' and name_f!='magnet':
            for name,link,server,quality in all_f_links[name_f]['links']:
                logging.warning(link)
                if link not in all_links_fp:
                    if Addon.getSetting("dp")=='true' and silent_mode==False:
                      elapsed_time = time.time() - start_time
                      dp.update(0, ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'בודק תאימות כתוביות', name)
                    if all_f_links[name_f]['subs']==True:
                      pre='101'
                    else:
                      logging.warning(name)
                      pre=check_pre(name,all_f_links['subs']['links'])
                    all_f_links[name_f]['pre']=pre
                    all_links_fp.append(link)
                    all_pre.append(pre)
                    logging.warning(pre)
                
    logging.warning('end new matching')
    '''
    #xbmc.Player().stop()
  
    all_subs=all_f_links['subs']
    all_magnet=all_f_links['magnet']
    
    all_data=[]
    video_data={}
    video_data['title']=name
    video_data['poster']=image
    video_data['plot']=plot
    video_data['icon']=icon
    video_data['year']=year
    if plot==None:
      plot=' '

   
    if Addon.getSetting("lang")=="1":
      lang='en'
    else:
      lang='he'
    url2=None
   
    
    save_fav(id,tv_movie)
    if Addon.getSetting("dp")=='true' and silent_mode==False:
        elapsed_time = time.time() - start_time
        dp.update(0, ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'מעדכן DB', '')
    all_s_in=({},0,'מעדכן DB',2,string_dp)
    if tv_movie=='tv':
        dbcur.execute("SELECT * FROM AllData WHERE original_title = '%s' and type='%s' and season='%s' and episode='%s'"%(original_title.replace("'","%27"),tv_movie,season,episode))

        match = dbcur.fetchone()
        if match==None:
          
          dbcur.execute("INSERT INTO AllData Values ('%s', '%s', '%s', '%s','%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s','%s','%s','%s');" %  (name.replace("'","%27"),url,icon,image,plot.replace("'","%27"),year,original_title.replace("'","%27"),season,episode,id,eng_name.replace("'","%27"),show_original_year,heb_name.replace("'","%27"),isr,tv_movie))
          dbcon.commit()
          
        dbcur.execute("SELECT * FROM Lastepisode WHERE original_title = '%s' and type='%s'"%(original_title.replace("'","%27"),tv_movie))

        match = dbcur.fetchone()
        if match==None:
          
          dbcur.execute("INSERT INTO Lastepisode Values ('%s', '%s', '%s', '%s','%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s','%s','%s','%s');" %  (name.replace("'","%27"),url,icon,image,plot.replace("'","%27"),year,original_title.replace("'","%27"),season,episode,id,eng_name.replace("'","%27"),show_original_year,heb_name.replace("'","%27"),isr,tv_movie))
          dbcon.commit()
         
        else:
          dbcur.execute("SELECT * FROM Lastepisode WHERE original_title = '%s' and type='%s' and season='%s' and episode='%s'"%(original_title.replace("'","%27"),tv_movie,season,episode))

          match = dbcur.fetchone()
         
          if match==None:
            dbcur.execute("UPDATE Lastepisode SET season='%s',episode='%s',image='%s',heb_name='%s' WHERE original_title = '%s' and type='%s'"%(season,episode,image,heb_name.replace("'","%27"),original_title.replace("'","%27"),tv_movie))
            dbcon.commit()
            
            #if nextup==False:
              
            #  xbmc.executebuiltin('Container.Refresh')

    else:
        dbcur.execute("SELECT * FROM AllData WHERE original_title = '%s' and type='%s'"%(original_title.replace("'","%27"),tv_movie))

        match = dbcur.fetchone()
        if match==None:
          
          dbcur.execute("INSERT INTO AllData Values ('%s', '%s', '%s', '%s','%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s','%s','%s','%s');" %  (name.replace("'","%27"),url,icon,image,plot.replace("'","%27"),year,original_title.replace("'","%27"),season,episode,id,eng_name.replace("'","%27"),show_original_year,heb_name.replace("'","%27"),isr,tv_movie))
          dbcon.commit()
        #else:
          
        #  dbcur.execute("UPDATE AllData SET season='%s',episode='%s' WHERE original_title = '%s' and type='%s'"%(season,episode,original_title,tv_movie))
        #  dbcon.commit()

    plot_o1=plot

    all_only_heb={}
    count_n=0
    count_t=0
    all_rd_s={}
    all_torrent_s={}
    all_rd_servers=[]
    count_r=0
    
    all_hebdub_servers=[]

    all_removed=[]
    all_lk={}
    if filter_mode:
        logging.warning('read from %s'%filter_loc)
        dbcur.execute("SELECT * FROM %s"%filter_loc)
        all_new = dbcur.fetchone()[0].decode('base64')
        all_new=json.loads(all_new)
    all_t_links=[]
    all_heb_links=[]
    duplicated=0
    all_lk2=[]
    all_mag={}
    page_index=0
    all_mag[0]=[]
    counter_hash=0
    r_list=[]
    if 0:#Addon.getSetting("check_cached")=='true' and allow_debrid:
        try:
            for name_f in all_f_links:
              if name_f!='subs' :
                for name,link,server,quality in all_f_links[name_f]['links']:
                    if Addon.getSetting("dp")=='true' and silent_mode==False:
                       elapsed_time = time.time() - start_time
                       dp.update(0, ' Please wait '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'Updating links , check cached', name)
                    if link not in all_lk2:
                        all_lk2.append(link)
                        if 'magnet' in link:
                            try:
                                hash = str(re.findall(r'btih:(.*?)&', link)[0].lower())
                            except:
                                hash =link.split('btih:')[1]
                            
                            all_mag[page_index].append(hash)
                            counter_hash+=1
                            if counter_hash>150:
                                page_index+=1
                                all_mag[page_index]=[]
                                counter_hash=0
            
            all_hased=[]
            
            import real_debrid
            rd = real_debrid.RealDebrid()
            for items in all_mag:
                
               
                if len(all_mag[items])>0 :
                    hashCheck = rd.checkHash(all_mag[items])
                    for hash in hashCheck:
                        if Addon.getSetting("dp")=='true' and silent_mode==False:
                           elapsed_time = time.time() - start_time
                           dp.update(0, ' Please wait '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'Updating links , check cached', hash)
                        if 'rd' in hashCheck[hash]:
                           if len(hashCheck[hash]['rd'])>0:
                                all_hased.append(hash)
            
            for name_f in all_f_links:
                    index=0
                    if name_f!='subs' :
                     for name,link,server,quality in all_f_links[name_f]['links']:
                        
                        if 'magnet' in link:
                            hash = str(re.findall(r'btih:(.*?)&', link)[0].lower())
                            if hash in all_hased:
                                
                                all_f_links[name_f]['links'][index]=['Cached '+name,link,server,quality]
                        index+=1
        
        
        except Exception as e:
            import linecache
            exc_type, exc_obj, tb = sys.exc_info()
            f = tb.tb_frame
            lineno = tb.tb_lineno
            filename = f.f_code.co_filename
            linecache.checkcache(filename)
            line = linecache.getline(filename, lineno, f.f_globals)
            xbmc.executebuiltin(u'Notification(%s,%s)' % ('Destiny', 'ERROR IN Cached test:'+str(lineno)))
            logging.warning('ERROR IN Cached test:'+str(lineno))
            logging.warning('inline:'+line)
            logging.warning(e)
            logging.warning('BAD Cached test')
    all_reject=[]
  

    for name_f in all_f_links:
       
       if name_f!='subs' :
       
        for name,link,server,quality in all_f_links[name_f]['links']:
           logging.warning('links pre:'+link)
           
           if allow_debrid and Addon.getSetting("show_only_chached")=='true' and Addon.getSetting("check_cached")=='true':
               if 'Cached ' not in name and 'magnet' in name_f :
                continue
           
           if Addon.getSetting("shrink")=='true':
                if link in all_lk:
                    all_lk[link].append(name_f)
                    
                    
                    #logging.warning('Removed DUP2:'+link+' Server:'+name_f)
                    duplicated+=1
                    continue
                else:
                 
                 all_lk[link]=[]
                 all_lk[link].append(name_f)
                 
         
           if filter_mode:
             if link not in all_new:
                continue
           else:
               if "," in Addon.getSetting("unfilter"):
                 unfilter=Addon.getSetting("unfilter").split(",")
               else:
                 if len(Addon.getSetting("unfilter"))>0:
                    unfilter=[Addon.getSetting("unfilter")]
                 else:
                   unfilter=[]
           
               if Addon.getSetting("remove_all")=='true' and (name_f not in unfilter):
               
                check=filter_servers(server)
               
                if check:
                    logging.warning('in Filter2')
                    all_removed.append(link)
                    logging.warning('Removed:'+link)
                    continue
           
           fixed_q=fix_q(quality)
           
           if Addon.getSetting("dp")=='true' and silent_mode==False:
               elapsed_time = time.time() - start_time
               dp.update(0, ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'מעדכן קישורים , מקורות כפולים - %s'%str(duplicated), name)
           all_s_in=({},0,' מקורות כפולים - %s'%str(duplicated),2,name)
           se='-%s-'%name_f  
           if 'season' in name:
            name1=name.split('season')[0]
           elif 'Season' in name:
            name1=name.split('Season')[0]
           else:
            name1=name
           clean_name_1=(PTN.parse(name1))
           if 'year' in clean_name_1:
                new_year=' / '+str(clean_name_1['year'])
           else:
               new_year=''
           options=[heb_name+' ע%s פ%s'%(season,episode),heb_name+' עונה %s פרק %s'%(season,episode),original_title.replace('%20','.').replace(' ','.').replace('%27',"'").replace('%3a',":")+'.S%sE%s'%(season_n,episode_n)]
           ok=False
           if tv_movie=='tv':
               ok=False
               for it in options:
                if it in name1:
                    ok=True
                    break
          
           
           if not ok:
             if 'title' in clean_name_1 and Addon.getSetting("Rejected")=='true' and tv_movie=='tv':
               fixed_name=clean_name_1['title'].lower().strip().replace("%20",".").replace("_",".").replace(" ",".").replace("-",".").replace(".avi","").replace(".mp4","").replace(".mkv","").replace('Cached ','').replace('cached.','').replace('תרגום מובנה','').replace('.','%20')
               fixed_name2=name.lower().strip().replace("%20",".").replace("_",".").replace(" ",".").replace("-",".").replace(".avi","").replace(".mp4","").replace(".mkv","").replace('Cached ','').replace('cached.','').replace('תרגום מובנה','').replace('.','%20')
               pre=similar(fixed_name.strip().lower(),original_title.strip().lower().replace(" ",".").replace('.','%20'))
               try:
                pre_heb=similar(fixed_name.strip().lower().decode('utf8'),heb_name.strip().lower().decode('utf8').replace(" ",".").replace('.','%20'))
               except:
                pre_heb=100
               try:
                pre_clean=similar(fixed_name2.strip().lower().decode('utf8'),original_title.strip().lower().decode('utf8').replace(" ",".").replace('.','%20'))
               except:
                pre_clean=100
               
               if int(pre)<70 and int(pre_heb)<70 and int(pre_clean)<70:
                if all_f_links[name_f]['subs']==True:
                     plot=plot_o1+'-HebDub-'
                     pre='101'
                #logging.warning(fixed_name.strip().lower())
                #logging.warning(original_title.strip().lower().replace(" ",".").replace('.','%20'))
                
                all_reject.append(('[COLOR red]Rejected [%s] [/COLOR]'%(name_f+new_year)+name.decode('utf8','ignore')+" - "+server, str(link),icon,image,plot,show_original_year,'[COLOR red]Rejected'+quality+'[/COLOR]',se,fixed_q,name,pre,server))
                continue
           
            
           if all_f_links[name_f]['torrent']==True:
             
             if link in all_t_links:
                
                continue
             
             all_t_links.append(link)
             all_torrent_s[count_t]={}
             all_torrent_s[count_t]['name']=name.decode('utf-8','ignore')
             all_torrent_s[count_t]['link']=link.decode('utf-8','ignore')
             all_torrent_s[count_t]['server']=server.decode('utf-8','ignore')
             all_torrent_s[count_t]['quality']=quality.decode('utf-8','ignore')
             all_torrent_s[count_t]['icon']=icon.decode('utf-8','ignore')
             all_torrent_s[count_t]['image']=image.decode('utf-8','ignore')
             all_torrent_s[count_t]['plot']='[COLOR yellow]'+server.decode('utf-8','ignore')+'[/COLOR]\n'+plot.decode('utf-8','ignore')
             all_torrent_s[count_t]['year']=year.decode('utf-8','ignore')
             all_torrent_s[count_t]['season']=season.decode('utf-8','ignore')
             all_torrent_s[count_t]['episode']=episode.decode('utf-8','ignore')
             all_torrent_s[count_t]['id']=id
             all_torrent_s[count_t]['name_f']=name_f
             all_torrent_s[count_t]['color']=all_f_links[name_f]['color']
             count_t+=1
           elif all_f_links[name_f]['rd']==True:
            
             all_rd_s[count_r]={}
             all_rd_s[count_r]['name']=name
             all_rd_s[count_r]['link']=link
             all_rd_s[count_r]['server']=server
             all_rd_s[count_r]['quality']=quality
             all_rd_s[count_r]['icon']=icon
             all_rd_s[count_r]['image']=image
             all_rd_s[count_r]['plot']=plot
             all_rd_s[count_r]['year']=year
             all_rd_s[count_r]['season']=season
             all_rd_s[count_r]['episode']=episode
             all_rd_s[count_r]['id']=id
             all_rd_s[count_r]['name_f']=name_f
             all_rd_s[count_r]['color']=all_f_links[name_f]['color']
             count_r+=1
            
             #pre=all_pre[all_links_fp.index(link)]
             '''
             if 'pre' in all_f_links[name_f]:
               pre=all_f_links[name_f]['pre']
             else:
               pre=all_pre[all_links_fp.index(link)]
               #pre=check_pre(name,all_f_links['subs']['links'])
             '''
             if name_f not in all_rd_servers:
                all_rd_servers.append(name_f)
           elif all_f_links[name_f]['subs']==True:
            
             plot=plot_o1+'-HebDub-'
             pre='101'
             all_heb_links.append(link)
             all_hebdub_servers.append(name_f)
             all_only_heb[count_n]={}
             all_only_heb[count_n]['name']=name
             all_only_heb[count_n]['link']=link
             all_only_heb[count_n]['server']=server
             all_only_heb[count_n]['quality']=quality
             all_only_heb[count_n]['icon']=icon
             all_only_heb[count_n]['image']=image
             all_only_heb[count_n]['plot']=plot
             all_only_heb[count_n]['year']=year
             all_only_heb[count_n]['season']=season
             all_only_heb[count_n]['episode']=episode
             all_only_heb[count_n]['id']=id
             all_only_heb[count_n]['name_f']=name_f
             all_only_heb[count_n]['color']=all_f_links[name_f]['color']
             count_n+=1
           
           else:
             plot=plot_o1
             
             #pre=all_pre[all_links_fp.index(link)]
             '''
             if 'pre' in all_f_links[name_f]:
               pre=all_f_links[name_f]['pre']
             else:
               pre=all_pre[all_links_fp.index(link)]
               #pre=check_pre(name,all_f_links['subs']['links'])
             '''
           check=False
          
           if isr==1:
             
             if all_f_links[name_f]['subs']==True:
               check=True
           else:
             check=True
         
           if check:
             if link in all_links_fp:
                pre=all_pre[all_links_fp.index(link)]
             else:
                pre=check_pre(name,all_f_links['subs']['links'],original_title)
             check_heb=is_hebrew(unicode(name))
             logging.warning('heb names')
             logging.warning(name)
             logging.warning(check_heb)
             if check_heb:
                plot=plot_o1+'-HebDub-'
                pre='101'
             all_data.append(('[COLOR %s][%s] '%('white',name_f+new_year)+name.decode('utf8','ignore')+new_year+" - "+server+'[/COLOR]', str(link),icon,image,plot,show_original_year,quality,se+new_year,fixed_q,name,pre,server))

    if Addon.getSetting("dp")=='true' and silent_mode==False:
        elapsed_time = time.time() - start_time
        dp.update(0, ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'מסדר קישורים', ' ')
    all_s_in=({},0,'מסדר קישורים',2,string_dp)
    if tv_movie=='movie':
        order_by=Addon.getSetting("order_movie")
    else:
        order_by=Addon.getSetting("order_tv")

    if Addon.getSetting("order_torrents_new")=='true' and (Addon.getSetting("3")=='1' or only_torrent=='yes' or 'קישורי מגנט' in o_name) and (Addon.getSetting("magnet")=='true' or only_torrent=='yes'):
         regex='{P-(.+?)/S-(.+?)}'
         all_data2=[]
         for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_data:
             
             peers=0
             seeds=0
             seeds_pre=re.compile(regex).findall(name)
             if len(seeds_pre)>0:
                 seeds=seeds_pre[0][1].replace(' ','')
                 peers=re.compile(regex).findall(name)[0][0].replace(' ','')
            
                 seeds=seeds.replace(',','')
                 peers=peers.replace(',','')
                 try:
                    a=int(seeds)
                 except:
                   seeds=0
                 all_data2.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,int(seeds),peers,supplier))
         all_data2=sorted(all_data2, key=lambda x: x[11], reverse=True)
         all_data=[]
         for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,seeds,peers,supplier in all_data2:
            
            all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
    elif order_by=='0':
      all_fv=[]
      all_rest=[]
      if Addon.getSetting("full_q")=='true'  and  tv_movie=='movie':
        all_data=sorted(all_data, key=lambda x: x[8], reverse=False)
      elif Addon.getSetting("full_q_tv")=='true'  and  tv_movie=='tv':
        all_data=sorted(all_data, key=lambda x: x[8], reverse=False)
      else:
          if Addon.getSetting("fav_servers_en")=='true'  and  tv_movie=='movie':
            all_fv_servers=Addon.getSetting("fav_servers").split(',')
          elif Addon.getSetting("fav_servers_en_tv")=='true'   and  tv_movie=='tv':
            logging.warning('In fav')
            all_fv_servers=Addon.getSetting("fav_servers_tv").split(',')
          else:
            all_fv_servers=[]
          for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_data:
            if '/' in server:
                s_test=server.split('/')[0].replace('-','').strip()
            else:
                s_test=server.replace('-','').strip()
            if s_test.replace('-','') in all_fv_servers:
                all_fv.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
            else:
                all_rest.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
          all_fv=sorted(all_fv, key=lambda x: x[8], reverse=False)
          
          all_rest=sorted(all_rest, key=lambda x: x[8], reverse=False)
          all_data=[]
          for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_fv:
             all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
          for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_rest:
             all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
         
    elif order_by=='1':
      all_fv=[]
      all_rest=[]
      if Addon.getSetting("fav_servers_en")=='true'  and  tv_movie=='movie':
        all_fv_servers=Addon.getSetting("fav_servers").split(',')
      elif Addon.getSetting("fav_servers_en_tv")=='true' and  tv_movie=='tv':
        logging.warning('In fav')
        all_fv_servers=Addon.getSetting("fav_servers_tv").split(',')
      else:
        all_fv_servers=[]
      
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_data:
        if '/' in server:
            s_test=str(server.split('/')[0].replace('-','').strip())
        else:
            s_test=str(server.replace('-','').strip())
        if s_test in all_fv_servers:
            all_fv.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
        else:
            
            all_rest.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
      all_fv=sorted(all_fv, key=lambda x: x[10], reverse=True)
      
      all_rest=sorted(all_rest, key=lambda x: x[10], reverse=True)
      all_data=[]
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_fv:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_rest:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
    elif order_by=='3':
        dp = xbmcgui . DialogProgress ( )
        dp.create('בודק איכות שרתים','אנא המתן', '','')
        dp.update(0, 'בודק איכות שרתים','אנא המתן', '' )
        z=0
        all_data2=[]
        for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_data:
            laten=0
            
            slow_source=int(Addon.getSetting("slow_source"))
            try:
                            headers_g = {
                                
                                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
                                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                                'Accept-Language': 'en-US,en;q=0.5',
                                'Connection': 'keep-alive',
                                'Upgrade-Insecure-Requests': '1',
                            }
                            
                            start_time_l=time.time()
                            if "|" in link:
                              headers_g2=link.split("|")[1]
                              headers_g2= dict(urlparse.parse_qsl(headers_g2))
                              link2=link.split("|")[0]
                              request = urllib2.Request(link2, headers=headers_g2)
                            else:
                              request = urllib2.Request(link, headers=headers_g)
                            site = urllib2.urlopen(request, timeout = (slow_source+2))
                            meta = site.info()
                            end_time_l=time.time()
                            laten=round(float(end_time_l-start_time_l),2)
            except Exception as e:
               logging.warning(e)
               laten=999
               pass
            all_data2.append((name,link,icon,image,str(laten)+'\n'+plot,year,q,server,laten,saved_name,pre,supplier))
            if dp.iscanceled(): 
                dp.close()
                break
            
            dp.update(int((z*100.0)/(len(all_data))),str(server)+"-"+q,str(z)+'/'+str(len(all_data)),str(int((z*100.0)/(len(all_data))))+'%')
            z=z+1
        all_data2=sorted(all_data2, key=lambda x: x[8], reverse=False)
        all_data=all_data2
        dp.close()
    else:
      all_2160=[]
      all_1080=[]
      all_720=[]
      all_480=[]
      all_else=[]
      all_rd=[]
      all_rd_2160=[]
      all_rd_1080=[]
      all_rd_720=[]
      all_rd_480=[]
      all_rd_else=[]
      
      all_fv_2160=[]
      
      all_fv_1080=[]
      all_fv_720=[]
      all_fv_480=[]
      all_fv_else=[]
      
      all_fvmag_2160=[]
      
      all_fvmag_1080=[]
      all_fvmag_720=[]
      all_fvmag_480=[]
      all_fvmag_else=[]
      
      all_fv_by_order=[]
      all_sp_servers=[]
      all_sp_by_order={}
      
      all_2160_fv=[]
      all_1080_fv=[]
      all_720_fv=[]
      all_480_fv=[]
      all_else_fv=[]
      if Addon.getSetting("fav_servers_en")=='true' and  tv_movie=='movie':
        all_fv_servers=Addon.getSetting("fav_servers").split(',')
        if ',' not in Addon.getSetting("fav_servers") and len(Addon.getSetting("fav_servers"))>0:
            all_fv_servers.append(Addon.getSetting("fav_servers"))
        if len(Addon.getSetting("sup_servers"))>0:
            all_sp_servers=Addon.getSetting("sup_servers").split(',')
            if ',' not in Addon.getSetting("sup_servers") and len(Addon.getSetting("sup_servers"))>0:
                all_sp_servers.append(Addon.getSetting("sup_servers"))
      elif Addon.getSetting("fav_servers_en_tv")=='true' and  tv_movie=='tv':
        logging.warning('In fav')
        all_fv_servers=Addon.getSetting("fav_servers_tv").split(',')
        if ',' not in Addon.getSetting("fav_servers_tv") and len(Addon.getSetting("fav_servers_tv"))>0:
            all_fv_servers.append(Addon.getSetting("fav_servers_tv"))
        if len(Addon.getSetting("sup_servers_tv"))>0:
            all_sp_servers=Addon.getSetting("sup_servers_tv").split(',')
            if ',' not in Addon.getSetting("sup_servers_tv") and len(Addon.getSetting("sup_servers_tv"))>0:
                all_sp_servers.append(Addon.getSetting("sup_servers_tv"))
      else:
        all_fv_servers=[]

  
      max_q='99'
      max_q_t=['2160','1080','720','480','360']
      if Addon.getSetting("auto_q_source")=='true':
        if tv_movie=='tv':
          max_q=Addon.getSetting("max_quality_t")
        else:
          max_q=Addon.getSetting("max_quality_m")
        max_q_v=max_q_t[int(max_q)]
          
      logging.warning(all_fv_servers)
      i=0
      al={}
      
      for items in all_sp_servers:
        if len(items)>0:
            al[items.lower()]=i
            i+=1
      for items in all_fv_servers:
        if len(items)>0:
            al[items.lower()]=i
            i+=1
      logging.warning('al')
      logging.warning(al)

      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_data:
        logging.warning(link)
        s_test=server
        if '/' in s_test:
            s_test=s_test.split('/')[0].replace('-','').strip()
        else:
            s_test=s_test.replace('-','').strip()
        sp_test=supplier.lower()
        if '-' in sp_test:
            sp_test=sp_test.split('-')[0].strip()
        add_to_all=True
        if  sp_test in al:
            
            if sp_test not in all_sp_by_order :
                all_sp_by_order[sp_test]=[]
            all_sp_by_order[sp_test].append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier ))
            add_to_all=False
        logging.warning('s_test:'+s_test)
        if s_test in al  :
            #logging.warning('s_test:'+s_test)
            
            all_fv_by_order.append((name,link,icon,image,plot,year,q,server,int(al[s_test]),saved_name,pre,supplier ))
            add_to_all=False
        #logging.warning('all_sp_by_order:')
        #logging.warning(all_sp_by_order)
        #logging.warning('all_fv_by_order:')
        #logging.warning(all_fv_by_order)
        if Addon.getSetting("dp")=='true' and silent_mode==False:
            elapsed_time = time.time() - start_time
            dp.update(0, ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'מסדר קישורים', name)
        all_s_in=({},0,'מסדר קישורים',2,name)
        q=q.replace('p','').replace('4K','2160').replace('4k','2160')
        try:
         a=int(q)
        except:
          q='0'
        if max_q!='99':
  
           if int(q)>int(max_q_v):
             
             continue
        if q=='0':
          q='UNKN'
        if '/' in server:
            server=server.split('/')[0]
        
        if add_to_all:
            if (server.replace('-','').replace(' ','') in all_fv_servers):# and 'magnet' not in server:
                
                if q=='2160':
                 all_fv_2160.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
                elif q=='1080':
                 all_fv_1080.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
                elif q=='720':
                 all_fv_720.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
                elif q=='480':
                 all_fv_480.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
                else :
                 all_fv_else.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))

            elif server.replace('-','') in all_rd_servers:
                if q=='2160':
                 all_rd_2160.append((name,link,icon,image,plot,year,q,server+' RD SOURCE ',f_q,saved_name,pre,supplier))
                elif q=='1080':
                 all_rd_1080.append((name,link,icon,image,plot,year,q,server+' RD SOURCE ',f_q,saved_name,pre,supplier))
                elif q=='720':
                 all_rd_720.append((name,link,icon,image,plot,year,q,server+' RD SOURCE ',f_q,saved_name,pre,supplier))
                elif q=='480':
                 all_rd_480.append((name,link,icon,image,plot,year,q,server+' RD SOURCE ',f_q,saved_name,pre,supplier))
                else :
                 all_rd_else.append((name,link,icon,image,plot,year,q,server+' RD SOURCE ',f_q,saved_name,pre,supplier))
            else:
                if q=='2160':
                 all_2160.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
                elif q=='1080':
                 all_1080.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
                elif q=='720':
                 all_720.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
                elif q=='480':
                 all_480.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
                else :
                 all_else.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
      all_fv_2160=sorted(all_fv_2160, key=lambda x: x[10], reverse=True)
      all_fv_1080=sorted(all_fv_1080, key=lambda x: x[10], reverse=True)
      all_fv_720=sorted(all_fv_720, key=lambda x: x[10], reverse=True)
      all_fv_480=sorted(all_fv_480, key=lambda x: x[10], reverse=True)
      all_fv_else=sorted(all_fv_else, key=lambda x: x[10], reverse=True)
      
      all_fvmag_2160=sorted(all_fvmag_2160, key=lambda x: x[10], reverse=True)
      all_fvmag_1080=sorted(all_fvmag_1080, key=lambda x: x[10], reverse=True)
      all_fvmag_720=sorted(all_fvmag_720, key=lambda x: x[10], reverse=True)
      all_fvmag_480=sorted(all_fvmag_480, key=lambda x: x[10], reverse=True)
      all_fvmag_else=sorted(all_fvmag_else, key=lambda x: x[10], reverse=True)
     
      all_rd_2160=sorted(all_rd_2160, key=lambda x: x[10], reverse=True)
      all_rd_1080=sorted(all_rd_1080, key=lambda x: x[10], reverse=True)
      all_rd_720=sorted(all_rd_720, key=lambda x: x[10], reverse=True)
      all_rd_480=sorted(all_rd_480, key=lambda x: x[10], reverse=True)
      all_rd_else=sorted(all_rd_else, key=lambda x: x[10], reverse=True)
      
      all_2160=sorted(all_2160, key=lambda x: x[10], reverse=True)
      all_1080=sorted(all_1080, key=lambda x: x[10], reverse=True)
      all_720=sorted(all_720, key=lambda x: x[10], reverse=True)
      all_480=sorted(all_480, key=lambda x: x[10], reverse=True)
      all_else=sorted(all_else, key=lambda x: x[10], reverse=True)
      if Addon.getSetting("order_movie_sup")== '0' and  tv_movie=='movie':
        ord=8
        ord_tr=False
      else:
        ord=10
        ord_tr=True
      if Addon.getSetting("order_movie_sup_tv")== '0' and  tv_movie=='tv':
        ord=8
        ord_tr=False
      else:
        ord=10
        ord_tr=True
      for items in all_sp_by_order:
        
        all_sp_by_order[items]=sorted(all_sp_by_order[items], key=lambda x: x[ord], reverse=ord_tr)
      all_f_sp=[]
      for items in all_sp_servers:
        if items in all_sp_by_order:
            for it in all_sp_by_order[items]:
               
                name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier=it
                all_f_sp.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
      order_q=False
      if tv_movie=='tv':
            if Addon.getSetting("fav_by_q_tv")=='0':
                order_q=True
      else:
            if Addon.getSetting("fav_by_q")=='0':
                order_q=True
      if order_q:
        all_fv_by_order=sorted(all_fv_by_order, key=lambda x: x[6], reverse=False)
      else:
        all_fv_by_order=sorted(all_fv_by_order, key=lambda x: x[8], reverse=False)
      
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_fv_by_order:
        if q=='2160':
         all_2160_fv.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
        elif q=='1080':
         all_1080_fv.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
        elif q=='720':
         all_720_fv.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
        elif q=='480':
         all_480_fv.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
        else :
         all_else_fv.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))

      all_data=[]
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_f_sp:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
         
      #for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_fv_by_order:
      #   all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_2160_fv:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_1080_fv:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_720_fv:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_480_fv:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_else_fv:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
         
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_fv_2160:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
         
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_fv_1080:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_fv_720:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_fv_480:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_fv_else:
        all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
      

        
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_rd_2160:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_rd_1080:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_rd_720:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_rd_480:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_rd_else:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
      
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_2160:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_1080:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_720:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_480:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_else:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
         
         
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_fvmag_2160:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_fvmag_1080:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_fvmag_720:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_fvmag_480:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_fvmag_else:
        all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
    for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_reject:
         all_data.append(('[COLOR red]'+name+'[/COLOR]',link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier))
         
    
    if get_local==True:
     
     return all_data,rest_of_data
    
    all_in=[]
    if imdb_global==None:
      imdb_global=id
    else:
      if 'tt' not in imdb_global:
        imdb_global=id
    if all_subs==None:
      all_subs=[]
   
          
    magnet_ofresult=''
    
    if isr==0 and Addon.getSetting("magnet")=='true' and filter_loc!='rest':
    
      if  (Addon.getSetting("all_t")=='2' and only_torrent!='yes' )and  'קישורי מגנט' not in o_name and 'תרגום מובנה' not in o_name :
       dbcur.execute("DELETE FROM torrents")
       dbcon.commit()

       dbcur.execute("INSERT INTO torrents Values ('%s')"%(json.dumps(all_torrent_s).encode('base64')))
       dbcon.commit()
       magnet_ofresult=get_rest_data( '[COLOR aqua][I]קישורי מגנט -(%s)[/I][/COLOR]'%len(all_t_links), 'torrents',4,icon,image,plot+'-NEXTUP-',data=o_year,original_title=original_title,season=season,episode=episode,id=id,eng_name=eng_name,show_original_year=show_original_year,heb_name=heb_name,isr=isr,dates=dates,fav_status=fav_status)
 
       #addDir3( '[COLOR aqua][I]קישורי מגנט -(%s)[/I][/COLOR]'%len(all_torrent_s), 'torrents',21,icon,image,plot,data=year,original_title=json.dumps(all_subs),season=season,episode=episode,id=imdb_global)
       
       #all_d_new.append((name,url,icon,image,plot,year,original_title,season,episode,id,eng_name,show_original_year,heb_name,isr,dates,data1))
       addDir3( '[COLOR aqua][I]קישורי מגנט -(%s)[/I][/COLOR]'%len(all_t_links), 'torrents',4,icon,image,plot,data=o_year,original_title=original_title,season=season,episode=episode,id=id,eng_name=eng_name,show_original_year=show_original_year,heb_name=heb_name,isr=isr,dates=dates,fav_status=fav_status)
      #elif  (Addon.getSetting("all_t")=='1' or only_torrent=='yes') :
        
      #  play_by_subs('[COLOR aqua][I]קישורי מגנט -(%s)[/I][/COLOR]'%len(all_torrent_s),json.dumps(all_torrent_s),icon,image,name.decode('utf8','ignore')+plot.decode('utf8','ignore'),year,json.dumps(all_subs),season,episode,imdb_global,'','',original_title,one_list=True)
    playingUrlsList = []
    t=0
    '''
    if Addon.getSetting("auto_enable")=='true':
        for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_data:
          t=t+1
          if plot==None:
             plot=' '

          
          playingUrlsList.append(link+'$$$$$$$'+server+'$$$$$$$'+q+'$$$$$$$'+saved_name+'$$$$$$$'+'[COLOR gold]'+q+'[/COLOR]\n[COLOR lightblue]'+server+'[/COLOR]\n'+plot)
    '''
    if Addon.getSetting("chapi_enable")=='true' :
        if season!=None and season!="%20":
           url2='http://api.themoviedb.org/3/tv/%s?api_key=%s&language=he&append_to_response=external_ids'%(id,'653bb8af90162bd98fc7ee32bcbbfb3d')
        else:
         
           url2='http://api.themoviedb.org/3/movie/%s?api_key=%s&language=he&append_to_response=external_ids'%(id,'653bb8af90162bd98fc7ee32bcbbfb3d')
        try:
            imdb_id=requests.get(url2).json()['external_ids']['imdb_id']
        except:
            imdb_id=" "
         
            
        url_ch=''
        if season!=None and season!="%20":
              url_pre='http://thetvdb.com/api/GetSeriesByRemoteID.php?imdbid=%s&language=en'%imdb_id.replace('tt','')
              html2=requests.get(url_pre).content
              pre_tvdb = str(html2).split('<seriesid>')
              if len(pre_tvdb) > 1:
                    tvdb = str(pre_tvdb[1]).split('</seriesid>')
                    url_ch='plugin://plugin.video.chappaai/tv/play/%s/%s/%s/library'%(tvdb[0],season,episode)
                   
        else:
            url_ch=('plugin://plugin.video.%s/movies/play/imdb/%s/library'%(Addon.getSetting("metaliq_version_for_s"),imdb_id))
        if url_ch!='':
           addLink( "[COLOR aqua][I]פתח במטאליק[/I][/COLOR]",url_ch,41,False,' ',' ',"פתח במטאליק")
    if Addon.getSetting("auto_enable")=='true':
      addLink( '[COLOR aqua][I]ניגון אוטומטי[/I][/COLOR]', json.dumps(playingUrlsList),6,False,icon,image,plot,data=year,original_title=original_title.replace("%20"," "),season=season,episode=episode,id=id,saved_name=original_title,prev_name=o_name,eng_name=eng_name,heb_name=heb_name,show_original_year=show_original_year)
    if Addon.getSetting("debugmode")=='true':
      try:
        #addLink( '[COLOR aqua][I]תוצאות שרתים[/I][/COLOR]', json.dumps(all_f_links),54,False,icon,image,plot,data=year,original_title=original_title.replace("%20"," "),season=season,episode=episode,id=id,saved_name=original_title,prev_name=o_name,eng_name=eng_name,heb_name=heb_name,show_original_year=show_original_year)
        #addNolink('[COLOR aqua][I]תוצאות שרתים[/I][/COLOR]',json.dumps(all_f_links),54,False,iconimage=icon,fanart=image)
        a=1
      except:
       pass
    only_heb=[]
    if isr!=1 and Addon.getSetting("tran_enable")=='true' and 'קישורי מגנט' not in o_name and 'תרגום מובנה' not in o_name:
      #only_heb.append(get_rest_data('[COLOR aqua][I]מקורות עם תרגום מובנה בלבד[/I][/COLOR]', json.dumps(all_only_heb),50,icon,image,plot+'-NEXTUP-'))
      only_heb.append(get_rest_data( '[COLOR aqua][I]מקורות עם תרגום מובנה בלבד[/I][/COLOR]'+str(len(all_heb_links)), 'hebdub',4,icon,image,plot+'-NEXTUP-',data=o_year,original_title=original_title,season=season,episode=episode,id=id,eng_name=eng_name,show_original_year=show_original_year,heb_name=heb_name,isr=isr,dates=dates,fav_status=fav_status))
      
      
      addDir3( '[COLOR aqua][I]מקורות עם תרגום מובנה בלבד[/I][/COLOR]', json.dumps(all_only_heb),50,icon,image,plot)
    rest_ofresult=''
    collection_data=''
    if tv_movie=='movie':
        url_col='https://api.themoviedb.org/3/movie/%s?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&language=heb'%id
        x=requests.get(url_col).json()
        if 'belongs_to_collection' in x:
          if x['belongs_to_collection']!=None:
            if x['belongs_to_collection']['poster_path']==None:
                x['belongs_to_collection']['poster_path']=''
            if x['belongs_to_collection']['backdrop_path']==None:
                x['belongs_to_collection']['backdrop_path']=''
            collection_data=get_rest_data('[COLOR yellow][I]'+x['belongs_to_collection']['name']+'[/I][/COLOR]',str(x['belongs_to_collection']['id']),150,domain_s+'image.tmdb.org/t/p/original/'+x['belongs_to_collection']['poster_path'],domain_s+'image.tmdb.org/t/p/original/'+x['belongs_to_collection']['backdrop_path'],'')
            addDir3('[COLOR yellow][I]'+x['belongs_to_collection']['name']+'[/I][/COLOR]',str(x['belongs_to_collection']['id']),150,domain_s+'image.tmdb.org/t/p/original/'+x['belongs_to_collection']['poster_path'],domain_s+'image.tmdb.org/t/p/original/'+x['belongs_to_collection']['backdrop_path'],'')
    
    if fav_status=='true' and rest_found==0 and only_torrent!='yes' and 'קישורי מגנט' not in o_name and 'תרגום מובנה' not in o_name:
     
        rest_ofresult=get_rest_data('[COLOR khaki]שאר התוצאות[/COLOR]',all_d_new[0][1],4,all_d_new[0][2],all_d_new[0][3],all_d_new[0][4]+'-NEXTUP-',data=all_d_new[0][5],original_title=all_d_new[0][6],season=all_d_new[0][7],episode=all_d_new[0][8],id=all_d_new[0][9],heb_name=all_d_new[0][12],eng_name=all_d_new[0][10],show_original_year=all_d_new[0][11],isr=all_d_new[0][13],dates=all_d_new[0][14],fav_status='rest')
        addDir3('[COLOR khaki]שאר התוצאות[/COLOR]',all_d_new[0][1],4,all_d_new[0][2],all_d_new[0][3],all_d_new[0][4]+'-NEXTUP-',data=all_d_new[0][5],original_title=all_d_new[0][6],season=all_d_new[0][7],episode=all_d_new[0][8],id=all_d_new[0][9],heb_name=all_d_new[0][12],eng_name=all_d_new[0][10],show_original_year=all_d_new[0][11],isr=all_d_new[0][13],dates=all_d_new[0][14],fav_status='rest')
    if Addon.getSetting("remove_all")=='true' and len(all_removed)>0 and filter_mode==False:
       dbcur.execute("DELETE FROM %s"%filter_loc)
       dbcon.commit()

       dbcur.execute("INSERT INTO %s Values ('%s')"%(filter_loc,json.dumps(all_removed).encode('base64')))
       dbcon.commit()
       logging.warning('save to: %s'%filter_loc)
       addDir3('[COLOR aqua][I]שרתים שסוננו -(%s)[/I][/COLOR]'%len(all_removed)+rest_test,all_d_new[0][1],4,all_d_new[0][2],all_d_new[0][3],all_d_new[0][4],data=all_d_new[0][5],original_title=all_d_new[0][6],season=all_d_new[0][7],episode=all_d_new[0][8],id=all_d_new[0][9],heb_name=all_d_new[0][12],eng_name=all_d_new[0][10],show_original_year=all_d_new[0][11],isr=all_d_new[0][13],dates=all_d_new[0][14],fav_status=fav_status)
       
     
    result = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Playlist.GetItems", "params": { "properties": [ "showlink", "showtitle", "season", "title", "artist" ], "playlistid": 1}, "id": 1}')

    j_list=json.loads(result)
    
    if isr!=1 and Addon.getSetting("rd_menu_enable")=='true' and  Addon.getSetting("rdsource")=='true':
      addDir3( '[COLOR aqua][I]Rd Sources Only[/I][/COLOR]', json.dumps(all_rd_s),50,icon,image,plot)
    if 1:#Addon.getSetting("new_source_menu")=='false':
        if (Addon.getSetting("fast_play2_tv")=='true' and tv_movie=='tv') or (Addon.getSetting("fast_play2_movie")=='true' and tv_movie=='movie'):
            playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            playlist.clear()
    if (Addon.getSetting("fast_play2_tv")=='true' and tv_movie=='tv') and Addon.getSetting("new_source_menu")=='false' and fast_link!='autoPlay':
        addDir3( '[COLOR lightgreen][I]חזור לפרקי העונה[/I][/COLOR]','www',102,icon,image,plot,data=year,original_title=original_title,id=id,season=season,tmdbid=id,show_original_year=year,heb_name=heb_name,isr=isr)
    once=0
    all_lists=[]
    f_link2=''
    logging.warning('fast_link')
    logging.warning(fast_link)
    m=[]
    n=[]
    collection_arr=[]
    n_magnet=[]
    if len(collection_data)>0:
        collection_arr.append(collection_data)
    if len(rest_ofresult)>0:
        n.append(rest_ofresult)
    if len(magnet_ofresult)>0:
        n_magnet.append(magnet_ofresult)
    count_magnet=0
    all_items=[]
    f_plot=''
    all_mag_links=[]
    logging.warning(rd_domains)
    counter=0
    all_ok_mag={}
    if 0:
        if allow_debrid :
            import real_debrid
        
        for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_data:
            if allow_debrid and 'magnet:' in link:
                hash = str(re.findall(r'btih:(.*?)&', link)[0].lower())
                if counter<50:
                    all_mag_links.append(hash)
                elif len(all_mag_links):
 
                    rd = real_debrid.RealDebrid()
                    hashCheck = rd.checkHash(all_mag_links)
                    logging.warning('len_hashCheck:'+str(len(hashCheck)))
                    for key in hashCheck:
                        if key in hashCheck:
                          
                          if 'rd' in hashCheck[key]:
                            if len(hashCheck[key]['rd'])>0:
                                all_ok_mag[key]=True
                            else:
                                logging.warning(hashCheck[key])
                          else:
                            logging.warning(hashCheck[key])
                        else:
                            logging.warning('NOT:'+key)
                    all_mag_links=[]
                    counter=0
                counter+=1
                #logging.warning(all_ok_mag)
                logging.warning('len_all_ok_mag:'+str(len(all_ok_mag)))
    logging.warning('len Hash:'+str(len(all_data)))
    for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in all_data:
      
      if Addon.getSetting("dp")=='true' and silent_mode==False:
          elapsed_time = time.time() - start_time
          dp.update(0, ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'מעמיס קישורים, סה"כ כפולים - %s'%str(duplicated), name)
      all_s_in=({},0,'מעמיס קישורים, סה"כ כפולים - %s'%str(duplicated),2,name)
      if server==None:
        server=' '
      if q==None:
        q=' '
      if plot==None:
        plot=' '
      name=name.replace("|"," ").replace("  "," ").replace("\n","").replace("\r","").replace("\t","").strip()

      if fast_link!='' and fast_link!='autoPlay':
     
        if link==fast_link:
          all_f_data=((name,fast_link,icon,image,'[COLOR gold]'+q+'[/COLOR]\n[COLOR lightblue]'+server+'[/COLOR]\n'+plot,o_year,season,episode,original_title,heb_name,show_original_year,eng_name,isr,id))
          f_link2=('%s?name=%s&mode=5&url=%s&data=%s&season=%s&episode=%s&original_title=%s&saved_name=%s&heb_name=%s&show_original_year=%s&eng_name=%s&isr=%s&id=%s&description=%s&iconimage=%s&fanart=%s'%(sys.argv[0],name,urllib.quote_plus(fast_link),o_year,season,episode,original_title,name,heb_name,show_original_year,eng_name,isr,id,urllib.quote_plus(('[COLOR gold]'+q+'[/COLOR]\n[COLOR lightblue]'+server+'[/COLOR]\n'+plot).encode('utf8')),icon,image))
          
          
     
      if 1:#(Addon.getSetting("fast_play2_tv")=='true' and tv_movie=='tv') or (Addon.getSetting("fast_play2_movie")=='true' and tv_movie=='movie'):
          #if Addon.getSetting("new_source_menu")=='false':
              link2=('%s?name=%s&mode=5&url=%s&data=%s&season=%s&episode=%s&original_title=%s&saved_name=%s&heb_name=%s&show_original_year=%s&eng_name=%s&isr=%s&id=%s&description=%s'%(sys.argv[0],name,urllib.quote_plus(link),o_year,season,episode,original_title,name,heb_name,show_original_year,eng_name,isr,id,urllib.quote_plus(('[COLOR gold]'+q+'[/COLOR]\n[COLOR lightblue]'+server+'[/COLOR]\n'+plot).encode('utf8'))))
              if str(pre)=='0':
                added=''
              else:
                added='[COLOR blue]'+str(pre)+'%|[/COLOR]'
              listItem=xbmcgui.ListItem(added+'[COLOR yellow]'+str(q)+'[/COLOR]|[COLOR magenta]'+server+'[/COLOR]|[COLOR gold]'+supplier.replace("Openload","vumoo")+'|[/COLOR]'+clean_name(name,1), iconImage=icon, thumbnailImage=image,path=link2)
              listItem.setInfo('video', {'Title': name})
              
              playlist.add(url=link2, listitem=listItem)
              all_lists.append(listItem)
      
           
      
      if 'תרגום מובנה בלבד'  in o_name and link not in all_heb_links:
        continue

      if 'קישורי מגנט' in o_name and 'magnet' not in server:
        
        continue
      
      
      size='0'
      if 'magnet' in server:
         saved_name=name.split('{P')[0]
         regex='- - .+? -(.+?) GB'
         try:
             size=re.compile(regex).findall(name)[0]
             #size=size.split('-')[2]
         except:
           
           size='0'
         
         
         regex='{P-(.+?)/S-(.+?)}'
         try:
             seeds=re.compile(regex).findall(name)[0][1].replace(' ','')
             peers=re.compile(regex).findall(name)[0][0].replace(' ','')
             try:
                s=int(seeds)
             except:
                seeds='0'
             try:
                s=int(peers)
             except:
                peers='0'
             seeds=seeds.replace(',','')
             peers=peers.replace(',','')
         except:
            peers='0'
            seeds='0'
            pass
       
         max_size=int(Addon.getSetting("size_limit"))
         try:
             if float(size)>max_size:
                continue
         except:
            pass
         if int(seeds)>=int(Addon.getSetting("min_seed")) or allow_debrid:
            add=''
            '''
            if 'magnet:' in link:
                hash = str(re.findall(r'btih:(.*?)&', link)[0].lower())
                if hash in all_ok_mag:
                    add='Cached'
                logging.warning(hash)
                logging.warning(add)
            '''
            if allow_debrid:
               
                server='[COLOR yellow] ☻ RD ☻ '+'[/COLOR]- P%s/S%s -  [COLOR lighgreen]%sGB[/COLOR]-'%(peers,seeds,size)
            else:
                server='- P%s/S%s -  [COLOR lighgreen]%sGB[/COLOR]-'%(peers,seeds,size)
            count_magnet+=1
            
         else:
            continue
        
            
            
         
         
         
      tes_mag=re.compile('- P(.+?)/S(.+?) -').findall(server)
      color_q='limegreen'
      
      if ('magnet' in server or len(tes_mag)>0) and (Addon.getSetting("all_t")=='2' ) and Addon.getSetting("magnet")=='true' and 'קישורי מגנט' not in o_name :
          if only_torrent!='yes':
            continue
      
      if len(Addon.getSetting("ignore_ser"))>0:
          ignore_server=Addon.getSetting("ignore_ser").split(",")
          ignore=0

          for items in ignore_server:
            
              if items.lower() in name.lower():
                 ignore=1
                 
                 break
          if ignore==1:
             continue
      
      if  Addon.getSetting("rd_menu_enable")=='true' and  Addon.getSetting("rdsource")=='true' and 'RD SOURCE' in server:
        continue
      if allow_debrid and '//' in link:
        #rd_domains=requests.get('https://api.real-debrid.com/rest/1.0/hosts/domains').json()
        try:
            host = link.split('//')[1].replace('www.','')
            host = host.split('/')[0].lower()
           
            if host in rd_domains:
                logging.warning('ini')
                server='[COLOR yellow] ☻ RD ☻ '+server+'[/COLOR]'
        except:
            pass
      
      if isr==0:
        regex=' - (.+?) GB'
        size_l_p=re.compile(regex).findall(supplier)
        if len(size_l_p)>0:
            size_l=' - '+size_l_p[0]+' GB -'
        else:
            size_l=''
        regex='\] (.+?)-'
        o_name1=re.compile(regex).findall(name)[0].replace('%20','.').replace(' ','.')
   
        if Addon.getSetting("source_sim")=='true':
           if pre==0:
             n1='[COLOR lightblue]'+server+'[/COLOR] ' + size_l+'[COLOR %s]◄'%color_q+q+'►[/COLOR]'
           else:
           
              n1='[COLOR gold][I]'+str(pre)+'%[/I][/COLOR] ' + size_l+'[COLOR lightblue]'+server+'[/COLOR]  '+'[COLOR %s]◄'%color_q+q+'►[/COLOR]'
           p1=name+'\n[COLOR gold]'+q+'[/COLOR]\n[COLOR lightblue]'+server+'[/COLOR]\n'+plot
        else:
           if pre==0:
             n1= name
           else:
              n1='[COLOR gold][I]'+str(pre)+'%[/I][/COLOR]-'+ name
           p1='[COLOR gold]'+q+'[/COLOR]\n[COLOR lightblue]'+server+'[/COLOR]\n'+plot
        
        
        if only_torrent=='yes':
   
            name=remove_color(name)
            name=name.replace('magnet_','').replace('.py','')
            n1=('[COLOR yellow]'+str(pre)+'%[/COLOR] -' + size_l+'-[COLOR gold]◄'+q+'►[/COLOR][COLOR lightblue][/COLOR] '+name)

        if ((Addon.getSetting("new_source_menu")=='true' and only_torrent!='yes') or new_windows_only or fast_link=='autoPlay') and  f_link2=='':
            name=name.replace("openload","vumoo").replace("Openload","vumoo").replace('letsupload','avlts')
          
            p1=p1.replace("openload","vumoo").replace("Openload","vumoo").replace('letsupload','avlts')
            m.append((name,link,icon,image,p1,show_original_year,q,server,q,saved_name,pre,supplier))
            f_plot=p1
            all_items.append(addLink(n1, link,5,False,icon,image,p1,data=o_year,original_title=original_title,season=season,episode=episode,id=id,saved_name=saved_name,prev_name=o_name,eng_name=eng_name,heb_name=heb_name,show_original_year=show_original_year,collect_all=True))
        else:
            
            all_items.append(addLink(n1, link,5,False,icon,image,p1,data=o_year,original_title=original_title,season=season,episode=episode,id=id,saved_name=saved_name,prev_name=o_name,eng_name=eng_name,heb_name=heb_name,show_original_year=show_original_year,collect_all=True))
      else:
         
         if only_torrent=='yes':
            name=remove_color(name)
   
            name=('[COLOR yellow]'+str(pre)+'%[/COLOR] -' + size_l+'-[COLOR gold] ◄'+q+'► [/COLOR][COLOR lightblue] [/COLOR] '+name+'$$$$$$$'+link)
         if ((Addon.getSetting("new_source_menu")=='true' and only_torrent!='yes') or new_windows_only or fast_link=='autoPlay') and  f_link2=='':
            name=name.replace("openload","vumoo").replace("Openload","vumoo").replace('letsupload','avlts')
            f_plot='[COLOR %s]◄'%color_q+q+'►[/COLOR]\n[COLOR lightblue]'+server+'[/COLOR]\n'+plot
            f_plot=f_plot.replace("openload","vumoo").replace("Openload","vumoo").replace('letsupload','avlts')
            
            m.append((name,link,icon,image,f_plot,show_original_year,q,server,q,saved_name,pre,supplier))
            all_items.append(addLink( name, link,5,False,icon,image,'[COLOR %s]◄'%color_q+q+'►[/COLOR]\n[COLOR lightblue]'+server+'[/COLOR]\n'+plot,data=o_year,original_title=original_title,season=season,episode=episode,id=id,saved_name=saved_name,prev_name=o_name,eng_name=eng_name,heb_name=heb_name,show_original_year=show_original_year,collect_all=True))
         else:
             all_items.append(addLink( name, link,5,False,icon,image,'[COLOR %s]◄'%color_q+q+'►[/COLOR]\n[COLOR lightblue]'+server+'[/COLOR]\n'+plot,data=o_year,original_title=original_title,season=season,episode=episode,id=id,saved_name=saved_name,prev_name=o_name,eng_name=eng_name,heb_name=heb_name,show_original_year=show_original_year,collect_all=True))
    
    
                
    if new_windows_only==False  or  f_link2!='' or only_torrent=='yes':
        logging.warning('Enter')
        if Addon.getSetting("show_sources_in_4")=='false':
            sh_sor=True
        else:
            sh_sor=False
        xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_items,len(all_items))
        
        
        
    all_s_in=( {},100 ,'סיימתי',4,string_dp)
    if once_fast_play>0:
        close_sources_now=1
    if Addon.getSetting("dp")=='true' and silent_mode==False:
                dp.close()
    if ((Addon.getSetting("fast_play2_tv")=='true' and tv_movie=='tv') or (Addon.getSetting("fast_play2_movie")=='true' and tv_movie=='movie')) and Addon.getSetting("new_source_menu")=='false' and fast_link!='autoPlay':
       a=1
    elif f_link2!='':
        logging.warning('PLAY MEDIA')
        #xbmc.executebuiltin(('XBMC.PlayMedia("%s")'%f_link2))
 
        name,fast_link,iconimage,image,description,data,season,episode,original_title,heb_name,show_original_year,eng_name,isr,id=all_f_data
        play(name,fast_link,iconimage,image,description,data,season,episode,original_title,name,heb_name,show_original_year,eng_name,isr,original_title,id,windows_play=True,auto_fast=False,nextup=True)
        logging.warning('DONE PLAY MEDIA')
        return 990,rest_of_data
    search_done=1
    if (Addon.getSetting("trailer_wait")=='true' and Addon.getSetting("trailer_dp")=='true') or (Addon.getSetting("video_in_s_wait")=='true' and Addon.getSetting("video_in_sources")=='true' and  Addon.getSetting("new_server_dp")=='true'):
       while xbmc.Player().isPlaying():
         xbmc.sleep(100)
    logging.warning('once_fast_play: '+str(once_fast_play))
    check_show=False
    if not xbmc.Player().isPlaying:
        check_show=True
    elif once_fast_play==0:
        check_show=True
    if metaliq=='false' and  (Addon.getSetting("new_window_type2")=='3' or Addon.getSetting("new_window_type2")=='4') and int(KODI_VERSION)<18 and  Addon.getSetting("show_sources_in_4")=='true':
            
            xbmcplugin.endOfDirectory(int(sys.argv[1]))
    if (Addon.getSetting("new_source_menu")=='true' and only_torrent!='yes' and check_show ) or new_windows_only or fast_link=='autoPlay' :
             if f_link2=='':
                logging.warning('datessssssssssssssssss')
                logging.warning(dates)

                if len(dates)>0 and dates!='%20' and dates!='"%20"' and metaliq=='false':
                    #l=get_rest_data('[COLOR deeppink][I]מעקב סדרות[/I][/COLOR]'.decode('utf8'),'tv',32,domain_s+'pbs.twimg.com/profile_images/873323586622078976/Z0BfwrYm.jpg',' ','פרקים אחרונים שנצפו'.decode('utf8'),isr=5)
                    #xbmc.executebuiltin('Container.Refresh(%s)'%l)#res_same
                    #xbmc.executebuiltin('Container.Refresh()')
                    disabled=1
                logging.warning('e2:'+episode)
                logging.warning('e2:'+o_plot)
                logging.warning('Len m:'+str(len(m)))
                xbmc.executebuiltin('Dialog.Close(okdialog, true)')
                res=new_show_sources(m,o_year,o_plot,eng_name,episode,image,heb_name,icon,id,prev_name,original_title,season,show_original_year,n,rest_of_data,n_magnet,only_heb,str(count_magnet),next_ep,str(len(all_heb_links)),only_torrent,fast_link,collection_arr)
                if res=='END':
                    return 'ENDALL',[]
                
                
                
                
                
                
                
                
                
                
                
                
                
    
    
   

    status_pl='0'                 
    
    #sys.exit()
    
      
    if (Addon.getSetting("fast_play2_tv")=='true' and tv_movie=='tv') or (Addon.getSetting("fast_play2_movie")=='true' and tv_movie=='movie'):
      if Addon.getSetting("new_source_menu")=='false' and check_show==False: 
        if 'items' in (j_list['result']) and once_fast_play==0:
            playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            playlist.clear()
            result = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Playlist.Clear", "params": { "playlistid": 0 }, "id": 1}')
        if Addon.getSetting("new_source_menu")=='false':
           if Addon.getSetting("dp")=='true' and silent_mode==False:
                dp.close()
           xbmc.Player().stop()
           logging.warning('Playing Nextup')
           if not 'items' in (j_list['result']):
              xbmc.Player().play(playlist,windowed=False)
           if Addon.getSetting("src_disp")=='false':
                status_pl='ENDALL'
           
          
           
            
           #ok=xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=all_lists[0])
    if Addon.getSetting("dp")=='true' and silent_mode==False:
        dp.close()
    if Addon.getSetting("dp")=='true' and silent_mode==False:
          elapsed_time = time.time() - start_time
          dp.update(0, ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'תהנה', ' ')

    if Addon.getSetting("dp")=='true' and silent_mode==False:
        dp.close()
    
    return status_pl,rest_of_data
def auto_play(name,urls,iconimage,fanart,description,data,season,episode,original_title,saved_name,heb_name,show_original_year,eng_name,isr,prev_name,id):
   
    year=show_original_year
    image=fanart
    plot=description
    icon=iconimage
    all_data=[]

    z=0

    
    all_links=json.loads(urls)
    is_playing=False
    for link in all_links:#for name2,link,icon,image,plot,year,q,server,f_q in all_data:
       if is_playing:
         break
       server=link.split("$$$$$$$")[1]
       q=link.split("$$$$$$$")[2]
       name=link.split("$$$$$$$")[3]
       plot=urllib.unquote_plus(link.split("$$$$$$$")[4].decode('utf8'))
       link=link.split("$$$$$$$")[0]
       
       
       try:
        if '-Sdarot' not in plot:
         r=play(name,link,iconimage,fanart,plot,data,season,episode,original_title,saved_name,heb_name,show_original_year,eng_name,isr,prev_name,id,auto_play=True)
        
         if r=='ok':
            
            while not xbmc.Player().isPlaying():
                xbmc.sleep(100) #wait until video is being played
            time.sleep(5)
            if xbmc.Player().isPlaying():
             
             mode=1999
             
             xbmc.executebuiltin('Dialog.Close(okdialog, true)')
             is_playing==True
             sys.exit()
                
       except Exception as e:
         logging.warning(e)
         if Addon.getSetting("dp")=='true' and silent_mode==False:
           dp.update(int(z/(len(all_links)*100.0)),str(server)+"-"+q,str(z)+'/'+str(len(all_links)),str(e))
       z=z+1


class HeadRequest(urllib2.Request):
    def get_method(self):
        return "HEAD"
def get_redirect(url):
 try:
     if KODI_VERSION>=17:
         request = HeadRequest(url)
         response = urllib2.urlopen(request)
         
         new_url=response.geturl() 
         return new_url
     else:
       return url
 except:
   return url


   










def get_imdb_data(info,name_o,image,source,type):
         tmdbKey = '653bb8af90162bd98fc7ee32bcbbfb3d'
         name=name_o
         imdb_id=''
         icon=image
         fanart=image
         plot=''
         rating=''
         genere=' '
         check=False
         if source=='4k':
            if  Addon.getSetting("4k_tmdb")=='false':
              check=True
         else:
            if source=='jen2':
                check=True
            elif  Addon.getSetting("jen_tmdb")=='false':
             check=True
         if check:
           return name,imdb_id,icon,fanart,plot,rating,genere
         if 'title' in info:
          a=info['title']
         else:
           info['title']=name_o.replace('.',' ')
         
         if len(info['title'])>0:
          a=a
         else:
           info['title']=name_o.replace('.',' ')
         if 1:
          if 'year' in info:
            tmdb_data="https://api.tmdb.org/3/search/%s?api_key=%s&query=%s&year=%s&language=he&append_to_response=external_ids"%(type,tmdbKey,urllib.quote_plus(info['title']),info['year'])
            year_n=info['year']
          else:
            tmdb_data="https://api.tmdb.org/3/search/%s?api_key=%s&query=%s&language=he&append_to_response=external_ids"%(type,tmdbKey,urllib.quote_plus(info['title']))

          all_data=requests.get(tmdb_data).json()
          if 'results' in all_data:
           if len(all_data['results'])>0:
                if (all_data['results'][0]['id'])!=None:
                    url='https://api.themoviedb.org/3/%s/%s?api_key=%s&language=he&append_to_response=external_ids'%(type,all_data['results'][0]['id'],tmdbKey)
                    try:
                        all_d2=requests.get(url).json()
                        imdb_id=all_d2['external_ids']['imdb_id']
                    except:
                        imdb_id=" "
                    genres_list= []
                    if 'genres' in all_d2:
                        for g in all_d2['genres']:
                          genres_list.append(g['name'])
                    
                    try:genere = u' / '.join(genres_list)
                    except:genere=''
                
                try:
                        if 'title' in all_data['results'][0]:
                          name=all_data['results'][0]['title']
                        else:
                          name=all_data['results'][0]['name']
                        rating=all_data['results'][0]['vote_average']
                        try:
                          icon=domain_s+'image.tmdb.org/t/p/original/'+all_data['results'][0]['poster_path']
                          fanart=domain_s+'image.tmdb.org/t/p/original/'+all_data['results'][0]['backdrop_path']
                        except:
                         pass
                        
                        plot=all_data['results'][0]['overview']
                except Exception as e:
                        logging.warning(e)
                        name=info['title']
                        fanart=' '
                        icon=' '
                        plot=' '
          else:
               name=name_o
               fanart=image
               icon=image
               plot=' '
         else:
               name=name_o
               fanart=image
               icon=image
               plot=' '
       
         return name,imdb_id,icon,fanart,plot,rating,genere
def get_qu(url):
    
    tmdb_cacheFile = os.path.join(tmdb_data_dir, '4k.db')
    dbcon_tmdb = database.connect(tmdb_cacheFile)
    dbcur_tmdb = dbcon_tmdb.cursor()
    
    dbcon_tmdb.commit()
    dbcur_tmdb.execute("SELECT * FROM MyTable")
    
    match = dbcur_tmdb.fetchall()
    for index,name,link,icon,fanart,plot,data,date,year,genre,father,type in match:
        data=data.replace('[',' ').replace(']',' ').replace('	','').replace("\\"," ").replace(': """",',': "" "",').replace(': """"}',': "" ""}').replace(': "",',': " ",').replace(': ""}',': " "}').replace('""','"').replace('\n','').replace('\r','')
       
        
        try:
            data2=json.loads(data)
            
            original_title=data2['originaltitle']
            imdb_id=data2['imdb']
            rating=data2['rating']
            generes=data2['genre']
        except:
            original_title=name
            imdb_id=" "
            rating=" "
            generes=" "
        addLink( name, gdecom(link),5,False,icon,fanart,'[COLOR gold]'+'4K'+'[/COLOR]\n[COLOR lightblue]'+'-NEW K-'+'[/COLOR]\n'+plot,data=year,original_title=original_title,id=imdb_id,rating=rating,generes=generes,show_original_year=year,saved_name=name)
                
    logging.warning('H5')
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_YEAR)

    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_RATING)
def fix_name(name_o):
    
    regex_c='\[COLOR(.+?)\]'
    match_c=re.compile(regex_c).findall(name_o)

    if len(match_c)>0:
          for items in match_c:
            name_o=name_o.replace('[COLOR%s]'%items,'')
    name_o=name_o.replace('=',' ').replace('[B]','').replace('[/B]','').replace('silver','').replace('deepskyblue','').replace('[','').replace(']','').replace('/COLOR','').replace('COLOR','').replace('4k','').replace('4K','').strip().replace('(','.').replace(')','.').replace(' ','.').replace('..','.')
    return name_o
    
def get_data(i,url2,headers):
       global matches
       try:
        
        x=requests.get(url2.strip(),headers=headers,timeout=3).content
        regex_pre='<item>(.+?)</item>'
        match_pre=re.compile(regex_pre,re.DOTALL).findall(x)
        
        match=[]
        for items in match_pre:
            
            regex_link='<link>(.+?)</link'
            match_link=re.compile(regex_link,re.DOTALL).findall(items)
           
            if len(match_link)>0:
                if len (match_link)>1:
                  match_link2=''
             
                  for link_in in match_link:
                     if match_link2=='':
                       match_link2=link_in
                     else:
                       match_link2=match_link2+'$$$'+link_in
                  match_link=match_link2
                else:
                  match_link=match_link[0]
                regex_name='<title>(.+?)</title'
                match_name=re.compile(regex_name,re.DOTALL).findall(items)
                if len(match_name)==0:
                  
                  continue
                else:
                   match_name=match_name[0]
                regex_image='<thumbnail>http(.+?)</'
                match_image=re.compile(regex_image,re.DOTALL).findall(items)
                if len (match_image)>0:
                   match_image=match_image[0]
                else:
                   match_image=' '
                
                
                
                match.append((match_name,match_link,match_image))
            
            #match=match+re.compile(regex,re.DOTALL).findall(items)
        matches[i]=match
        
        return matches[i]
       except Exception as e:
         logging.warning(e)
         logging.warning('Bad Jen')
         logging.warning(url2)
         return []
def get_jen_list(url):
    global matches
    
    
    tmdb_cacheFile = os.path.join(tmdb_data_dir, 'tmdb_data.db')
    dbcon_tmdb = database.connect(tmdb_cacheFile)
    dbcur_tmdb = dbcon_tmdb.cursor()
    dbcur_tmdb.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""imdb_id TEXT,""icon TEXT,""fanart TEXT,""plot TEXT,""rating TEXT,""eng_name TEXT,""genere TEXT);"% 'tmdb_data')

    try:
        dbcur_tmdb.execute("VACUUM 'AllData';")
        dbcur_tmdb.execute("PRAGMA auto_vacuum;")
        dbcur_tmdb.execute("PRAGMA JOURNAL_MODE=MEMORY ;")
        dbcur_tmdb.execute("PRAGMA temp_store=MEMORY ;")
    except:
     pass
    dbcon_tmdb.commit()
    tmdbKey = '653bb8af90162bd98fc7ee32bcbbfb3d'
    if Addon.getSetting("jen_progress")=='true':
        dp = xbmcgui . DialogProgress ( )
        dp.create('אנא המתן','מחפש מקורות', '','')
        dp.update(0, 'אנא המתן','מחפש מקורות', '' )
    z=0
    start_time = time.time()
    all_links_in=[]
    headers = {
                
                'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
                'Accept': '*/*',
                'Accept-Language': 'en-US,en;q=0.5',
                
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'X-Requested-With': 'XMLHttpRequest',
                'Connection': 'keep-alive',
              }
    stop_all=0
    matches={}
    thread=[]
    all_lists=[]
    all_jen_lisy=[]
    for i in range (1,40):
        if stop_all==1:
          break
        url2=Addon.getSetting("Pastebin-%s-"%url+str(i))
 
        if 'http' not in url2:
          continue
        
        all_lists.append(url2)
        matches[str(i)]=''
        thread.append(Thread(get_data,str(i),url2,headers))
        thread[len(thread)-1].setName(str(i))

    for td in thread:
      td.start()
    
    while 1:
      num_live=0
      still_alive=0
      
     
      string_dp2=''
      for threads in thread:
        count=0
        for yy in range(0,len(thread)):
            if not thread[yy].is_alive():
              num_live=num_live+1
             
            else:
              still_alive=1
             
              string_dp2=thread[yy].name
             
              if Addon.getSetting("jen_progress")=='true':
                dp.update(0, 'איטי רק בפעם הראשונה אנא המתן ',string_dp2, string_dp2)
      if still_alive==0:
        break
      
    season=' '
    dbcur_tmdb.execute("SELECT * FROM tmdb_data")

    match4 = dbcur_tmdb.fetchall()
    all_eng_name={}
    for eng_name,imdb_id,icon,fanart,plot,rating,name,generes in match4:
       all_eng_name[name.replace('é','e')]=[]
       all_eng_name[name.replace('é','e')].append((eng_name,imdb_id,icon,fanart,plot,rating,name,generes))
    
    for match in matches:
        
        if stop_all==1:
          break
        
        for name_o,link,image in matches[match]:
         
         image='http'+image.strip().replace('\n','').replace(' ','').replace('\r','').replace('\t','')
         check=False
         if Addon.getSetting("rdsource")=='true':
           check=True
         elif '1fichier.com' not in link and 'glasford.ddns.net' not in link and 'http://dl.my-film.in/' not in link and 'http://dl.my-film.org/' not in link  and 'debrid' not in name_o.lower():
           check=True
         
         
         
         if check:
          name_o=fix_name(name_o).strip()
          name_o=name_o.replace('Real.Debrid.Only','')
          if name_o.endswith('.'):
            name_o=name_o[:-1]
          info=(PTN.parse(name_o))
          info['title']=info['title'].replace('-',' ').replace(' ','.')
          
          if 'year' in info:
              name_o=name_o.replace(str(info['year']),'').strip()
              if name_o.endswith('.'):
                name_o=name_o[:-1]
            
         
          rest=''
          for keys in info:
             if keys!='title':
               rest=rest+' '+str(info[keys])
          count=count+1
          imdb_id=' '
          rating=' '
          year_n='0'
          if 'year' in info:
          
            year_n=info['year']

          
          if 'Season ' in link:
            type='tv'
            
          else:
            type='movie'
          
          if Addon.getSetting("jen_progress")=='true':
              if dp.iscanceled():
                dp.close()
                stop_all=1
                break
  
          try: 
            items=all_eng_name[name_o.replace("'","%27").replace('é','e').replace('’',' ')][0]
          except:
            items=None
          if items==None:
              
              name,imdb_id,icon,fanart,plot,rating,generes=get_imdb_data(info,name_o,image,'jen',type)
              if Addon.getSetting("jen_tmdb")=='true':
                 try:
                  dbcur_tmdb.execute("INSERT INTO tmdb_data Values ('%s', '%s', '%s', '%s', '%s', '%s','%s','%s');" %  (name.replace("'","%27"),imdb_id,icon.replace("'","%27"),fanart.replace("'","%27"),plot.replace("'","%27"),rating,name_o.replace("'","%27"),generes))
                  dbcon_tmdb.commit()
                 except:
                   all_data_inin=[]
                   all_data_inin.append((name.replace("'","%27"),imdb_id,icon,fanart,plot.replace("'","%27"),rating,name_o.replace("'","%27"),generes))
                   
                   sys.exit()
          else:
            eng_name,imdb_id,icon,fanart,plot,rating,name,generes=items
          
          
          if imdb_id==None:
            imdb_id=' '
          o_plot=plot
          if rating==None:
            rating=' '
          if generes==None:
            generes=' '
          elapsed_time = time.time() - start_time
          if Addon.getSetting("jen_progress")=='true':
                dp.update(int(((z* 100.0)/(len(matches))) ), 'איטי רק בפעם הראשונה אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),name, str(len(all_links_in))+' , '+str(match))
          z=z+1
          links2=[]
          if '$$$' in link:
            links2=link.split('$$$')
          
            
          else:
             links2.append(link)
          for link in links2:
              
              if '(' in link:
                  regex='http(.+?)\((.+?)\)'
                  match44=re.compile(regex).findall(link)
                  
             
                  for links,name2 in match44:
                        links='http'+links
                       
                       
                        if links not in all_links_in and 'trailer' not in name2.lower():
                            if 'youtube' in links or '<links>' in links or links=='ignore' or 'ignor.me' in links or links=='https://' or links=='http://' or links==None or 'http' not in links:
                                
                                continue
                            all_links_in.append(links)
                           
                            all_jen_lisy.append(( (rest.replace('=',' ')+'---'+fix_name(name2)).replace('..','.'), links,icon,fanart,plot,year_n,name_o,info['title'],imdb_id,rating,generes,year_n,'%20','%20'))
                                                       
              if 'LISTSOURCE' in link :
                  
                  regex='LISTSOURCE\:(.+?)\:\:LISTNAME\:(.+?)\:'
                  match2=re.compile(regex).findall(link)
                  if len(match2)>0:
                    for links,name2 in match2:
                        if '(' in links:
                          regex='http(.+?)\('
                          links=re.compile(regex).findall(links)[0]
                        if links not in all_links_in and 'trailer' not in name2.lower():
                            if 'youtube' in links or '<links>' in links or links=='ignore' or 'ignor.me' in links or links=='https://' or links=='http://' or links==None or 'http' not in links:
                                
                                continue
                            all_links_in.append(links)
                            
                            all_jen_lisy.append(( (rest.replace('=',' ')+'---'+fix_name(name2)).replace('..','.'), links,icon,fanart,plot,year_n,name_o,info['title'],imdb_id,rating,generes,year_n,'%20','%20'))
                                                    
              elif 'sublink' in link:
                 regex_sub='<sublink(.+?)>(.+?)</sublink>'
                 match_sub=re.compile(regex_sub).findall(link)
           
                 if len(match_sub)>0:
                   for ep,links in match_sub:
                    regex_ep='\]Season (.+?) Episode (.+?)\['
                    match_ep=re.compile(regex_ep,re.IGNORECASE).findall(ep)
                    if len(match_ep)>0:
                       season,episode=match_ep[0]
                       plot='עונה '+season+' פרק '+episode+'\n'+o_plot
                    else:
                       season=' '
                       episode=' '
                    if '(' in links:
                          regex='http(.+?)\('
                          links=re.compile(regex).findall(links)[0]
                    if links not in all_links_in:
                        if 'youtube' in links or '<links>' in links or links=='ignore' or 'ignor.me' in links or links=='https://' or links=='http://' or links==None or 'http' not in links:
                              
                                continue
                        all_links_in.append(links)
                        
                        all_jen_lisy.append((ep.replace('=',' '), links,icon,fanart,plot,year_n,name_o,info['title'],imdb_id,rating,generes,year_n,season,episode))
                                                 
                  
              elif link not in all_links_in:
                    if '(' in link:
                          regex='http(.+?)\('
                          link=re.compile(regex).findall(link)
                          if len(link)>0:
                            link=link[0]
                          else:
                            continue
                    if 'youtube' in link or '<link>' in link or link=='ignore' or 'ignor.me' in link or link=='https://' or link=='http://' or link==None or 'http' not in link:
                               
                                continue
                    all_links_in.append(link)
                    
                    all_jen_lisy.append((rest.replace('=',' '), link,icon,fanart,plot,year_n,info['title'],info['title'],imdb_id,rating,generes,year_n,'%20','%20'))
    all_names=[]
    all_links={}
    for  name, link,icon,fanart,plot,data,saved_name,original_title,id,rating,generes,show_original_year,season,episode in all_jen_lisy:
       
        name1=saved_name.decode('utf8').strip()
        
        if name1 not in all_names:
             
             all_names.append(name1)
             all_links[name1]={}
             all_links[name1]['icon']=icon
             all_links[name1]['image']=fanart
             all_links[name1]['plot']=plot
             all_links[name1]['data']=data
             
             all_links[name1]['saved_name']=saved_name
             all_links[name1]['original_title']=original_title
             all_links[name1]['id']=id
             all_links[name1]['rating']=rating
             all_links[name1]['generes']=generes
             all_links[name1]['show_original_year']=show_original_year
             all_links[name1]['season']=season
             all_links[name1]['episode']=episode
            
             all_links[name1]['link']='[['+name+']]'+link
         
        else:
           if link not in all_links[name1]['link']:
             if '$$$' in link:
                  links=link.split('$$$')
                  for link in links:
                    all_links[name1]['link']=all_links[name1]['link']+'$$$'+'[['+name+']]'+link
             else:
               all_links[name1]['link']=all_links[name1]['link']+'$$$'+'[['+name+']]'+link
                   
        

    for items in all_links:
        
             icon=all_links[items]['icon']
             fanart=all_links[items]['image']
             plot=all_links[items]['plot']
             data=all_links[items]['data']
             
             saved_name=all_links[items]['saved_name']
             original_title=all_links[items]['original_title']
             id=all_links[items]['id']
             rating=all_links[items]['rating']
             generes=all_links[items]['generes']
             show_original_year=all_links[items]['show_original_year']
             season=all_links[items]['season']
             episode=all_links[items]['episode']
             
             link=all_links[items]['link']
             addLink( items.replace('.',' '), link,5,False,icon,fanart,plot,data=data,saved_name=saved_name,original_title=original_title,id=id,rating=rating,generes=generes,show_original_year=show_original_year,season=season,episode=episode)
             
    if Addon.getSetting("jen_progress")=='true':
      dp.close()
    logging.warning('H6')
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_YEAR)

    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_RATING)

def build_jen_db():
    global matches
    import urlparse
    rd_domains=['magnet:',u'real-debrid.com',u'4shared.com', u'rapidgator.net', u'sky.fm', u'1fichier.com', u'depositfiles.com', u'hitfile.net', u'filerio.com', u'solidfiles.com', u'mega.co.nz', u'scribd.com', u'flashx.tv', u'canalplus.fr', u'dailymotion.com', u'salefiles.com', u'youtube.com', u'faststore.org', u'turbobit.net', u'big4shared.com', u'filefactory.com', u'youporn.com', u'oboom.com', u'vimeo.com', u'redtube.com', u'zippyshare.com', u'file.al', u'clicknupload.me', u'soundcloud.com', u'gigapeta.com', u'datafilehost.com', u'datei.to', u'rutube.ru', u'load.to', u'sendspace.com', u'vidoza.net', u'tusfiles.net', u'unibytes.com', u'ulozto.net', u'hulkshare.com', u'dl.free.fr', u'streamcherry.com', u'mediafire.com', u'vk.com', u'uploaded.net', u'userscloud.com',u'nitroflare.com']
    
    tmdb_cacheFile = os.path.join(done_dir,'cache_f', 'jen_db.db')
    dbcon_tmdb = database.connect(tmdb_cacheFile)
    dbcur_tmdb = dbcon_tmdb.cursor()
    dbcur_tmdb.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""year TEXT,""type TEXT);"% 'tmdb_data')

    try:
        dbcur_tmdb.execute("VACUUM 'tmdb_data';")
        dbcur_tmdb.execute("PRAGMA auto_vacuum;")
        dbcur_tmdb.execute("PRAGMA JOURNAL_MODE=MEMORY ;")
        dbcur_tmdb.execute("PRAGMA temp_store=MEMORY ;")
    except:
     pass
    dbcon_tmdb.commit()
   
    
    dp = xbmcgui . DialogProgress ( )
    dp.create('אנא המתן','מחפש מקורות', '','')
    dp.update(0, 'אנא המתן','מחפש מקורות', '' )
    z=0
    start_time = time.time()
    all_links_in=[]
    headers = {
                
                'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
                'Accept': '*/*',
                'Accept-Language': 'en-US,en;q=0.5',
                
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'X-Requested-With': 'XMLHttpRequest',
                'Connection': 'keep-alive',
              }
    stop_all=0
    matches={}
    thread=[]
    all_lists=[]
    all_jen_lisy=[]
    m=0
    
    for j in range(1,6):
      for i in range (1,40):
        if stop_all==1:
          break
        url2=Addon.getSetting(("Pastebin-%s-"%str(j))+str(i))
 
        if 'http' not in url2:
          continue
        
        all_lists.append(url2)
        matches[str(m)]=''
        m+=1
        thread.append(Thread(get_data,str(m),url2,headers))
        thread[len(thread)-1].setName(str(m))
    f = open(os.path.join(tmdb_data_dir, 'jen_lists.txt'), 'r')
    file_data = f.readlines()
    f.close()
    for url2 in file_data:
        if 'http' not in url2:
          continue
        
        all_lists.append(url2)
        matches[str(m)]=''
        m+=1
        
        thread.append(Thread(get_data,str(m),url2,headers))
        thread[len(thread)-1].setName(str(m))
    for td in thread:
      td.start()
    
    while 1:
      num_live=0
      still_alive=0
      
     
      string_dp2=''
      for threads in thread:
        count=0
        for yy in range(0,len(thread)):
            if not thread[yy].is_alive():
              num_live=num_live+1
             
            else:
              still_alive=1
             
              string_dp2=thread[yy].name
             
              
              dp.update(0, 'איטי רק בפעם הראשונה אנא המתן ',string_dp2, string_dp2)
      if still_alive==0:
        break
      
    season=' '
    dbcur_tmdb.execute("SELECT * FROM tmdb_data")

    match4 = dbcur_tmdb.fetchall()
    
    all_eng_name=[]
    all_eng_name={link:link for eng_name,link,year,type,index_d in (match4)}
     
    #for eng_name,link,year,type,index_d in match4:

    #   all_eng_name.append(link)
    index=len(match4)
    logging.warning('Index:'+str(index))
    for match in matches:
        
        if stop_all==1:
          break
        
        for name_o,link,image in matches[match]:
         icon=image
         fanart=image
         plot=''
         generes=''
         image='http'+image.strip().replace('\n','').replace(' ','').replace('\r','').replace('\t','')
         
         
         
         
         if 1:
          name_o=fix_name(name_o).strip()
          name_o=name_o.replace('Real.Debrid.Only','')
          if name_o.endswith('.'):
            name_o=name_o[:-1]
          info=(PTN.parse(name_o))
          info['title']=info['title'].replace('-',' ').replace(' ','.')
          name=info['title']
          if 'year' in info:
              name_o=name_o.replace(str(info['year']),'').strip()
              if name_o.endswith('.'):
                name_o=name_o[:-1]
            
         
          rest=''
          for keys in info:
             if keys!='title':
               rest=rest+' '+str(info[keys])
          count=count+1
          imdb_id=' '
          rating=' '
          year_n='0'
          if 'year' in info:
          
            year_n=info['year']

          
          if 'Season ' in link:
            type='tv'
            
          else:
            type='movie'
          
          
          if dp.iscanceled():
            dp.close()
            stop_all=1
            break
  
        
          
          
          if imdb_id==None:
            imdb_id=' '
       
          if rating==None:
            rating=' '
        
          elapsed_time = time.time() - start_time
         
          dp.update(int(((z* 100.0)/(len(matches))) ), 'איטי רק בפעם הראשונה אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),name, str(len(all_links_in))+' , '+str(match))
          z=z+1
          links2=[]
          if '$$$' in link:
            links2=link.split('$$$')
          
            
          else:
             links2.append(link)
          for link in links2:
              
              if '(' in link:
                  regex='http(.+?)\((.+?)\)'
                  match44=re.compile(regex).findall(link)
                  
             
                  for links,name2 in match44:
                        links='http'+links
                       
                       
                        if links not in all_links_in and 'trailer' not in name2.lower():
                            if 'youtube' in links or '<links>' in links or links=='ignore' or 'ignor.me' in links or links=='https://' or links=='http://' or links==None or 'http' not in links:
                                
                                continue
                            all_links_in.append(links)
                           
                            all_jen_lisy.append(( (rest.replace('=',' ')+'---'+fix_name(name2)).replace('..','.'), links,icon,fanart,plot,year_n,name_o,info['title'],imdb_id,rating,generes,year_n,'%20','%20'))
                                                       
              if 'LISTSOURCE' in link :
                  
                  regex='LISTSOURCE\:(.+?)\:\:LISTNAME\:(.+?)\:'
                  match2=re.compile(regex).findall(link)
                  if len(match2)>0:
                    for links,name2 in match2:
                        if '(' in links:
                          regex='http(.+?)\('
                          links=re.compile(regex).findall(links)[0]
                        if links not in all_links_in and 'trailer' not in name2.lower():
                            if 'youtube' in links or '<links>' in links or links=='ignore' or 'ignor.me' in links or links=='https://' or links=='http://' or links==None or 'http' not in links:
                                
                                continue
                            all_links_in.append(links)
                            
                            all_jen_lisy.append(( (rest.replace('=',' ')+'---'+fix_name(name2)).replace('..','.'), links,icon,fanart,plot,year_n,name_o,info['title'],imdb_id,rating,generes,year_n,'%20','%20'))
                                                    
              elif 'sublink' in link:
                 regex_sub='<sublink(.+?)>(.+?)</sublink>'
                 match_sub=re.compile(regex_sub).findall(link)
           
                 if len(match_sub)>0:
                   for ep,links in match_sub:
                    regex_ep='\]Season (.+?) Episode (.+?)\['
                    match_ep=re.compile(regex_ep,re.IGNORECASE).findall(ep)
                    if len(match_ep)>0:
                       season,episode=match_ep[0]
                       plot='עונה '+season+' פרק '+episode+'\n'+o_plot
                    else:
                       season=' '
                       episode=' '
                    if '(' in links:
                          regex='http(.+?)\('
                          links=re.compile(regex).findall(links)[0]
                    if links not in all_links_in:
                        if 'youtube' in links or '<links>' in links or links=='ignore' or 'ignor.me' in links or links=='https://' or links=='http://' or links==None or 'http' not in links:
                              
                                continue
                        all_links_in.append(links)
                        
                        all_jen_lisy.append((ep.replace('=',' '), links,icon,fanart,plot,year_n,name_o,info['title'],imdb_id,rating,generes,year_n,season,episode))
                                                 
                  
              elif link not in all_links_in:
                    if '(' in link:
                          regex='http(.+?)\('
                          link=re.compile(regex).findall(link)
                          if len(link)>0:
                            link=link[0]
                          else:
                            continue
                    if 'youtube' in link or '<link>' in link or link=='ignore' or 'ignor.me' in link or link=='https://' or link=='http://' or link==None or 'http' not in link:
                               
                                continue
                    all_links_in.append(link)
                    
                    all_jen_lisy.append((rest.replace('=',' '), link,icon,fanart,plot,year_n,info['title'],info['title'],imdb_id,rating,generes,year_n,'%20','%20'))
    
    all_names=[]
    all_links={}
    z=0
    n=0
    all_new=[]
    for  name, link,icon,fanart,plot,data,saved_name,original_title,id,rating,generes,show_original_year,season,episode in all_jen_lisy:
       try:
        name1=saved_name.decode('utf8').strip()
        dp.update(int(((z* 100.0)/(len(all_jen_lisy))) ), 'מעדכן DB',name1.replace('.',' ').replace("'","%27"),str( z)+','+'New:'+str(n))
        if dp.iscanceled():
                dp.close()
              
                break
        res=all_eng_name.get(link, -1)
       
        if res==-1:
                if 'magnet:' in link:
                    host='magnet:'
                else:
                    host = link.replace("\\", "")
                    host2 = host.strip('"')
                    host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(host2.strip().lower()).netloc)
                    if len(host)==0:
                        continue
                    host=host[0]
              
                if host not in rd_domains:
                    type='free'
                else:
                    type='RD'
                if 'real-debrid' in link:
                    type='RD'
                n+=1
                all_new.append(name1)
                
                dbcur_tmdb.execute("INSERT INTO tmdb_data Values ('%s', '%s', '%s', '%s', '%s');" %  (name1.replace('.',' ').replace("'","%27").lower(),link.replace("'","27"),str(show_original_year).replace("'","%27"),type,str(index)))
                index+=1
        z+=1
       except:
        pass
        
    showText('חדש', '\n'.join(all_new))
    dbcon_tmdb.commit()
    dp.close()
    clean_data()
def save_fav(id,tv_movie):
   cache.clear(['save_file'])
   if tv_movie=='tv':
     save_file=os.path.join(user_dataDir,"fav_tv.txt")
   else:
     save_file=os.path.join(user_dataDir,"fav_movie.txt")
   file_data=[]
   change=0

   
   if os.path.exists(save_file):
        f = open(save_file, 'r')
        file_data = f.readlines()
        f.close()
   if len(file_data)>150:
       for i in range (len(file_data)-1,0,-1):
         if (i<(len(file_data)-100)) and len(file_data[i])>0:
          file_data.pop(i)
          change=1
       for i in range (len(file_data)-1,0,-1):
         
         if len(file_data[i])<3:
          
          file_data.pop(i)
          change=1

   if id not in file_data or change==1:
      for i in range (len(file_data)-1,0,-1):
         file_data[i]=file_data[i].replace('\n','')
         if len(file_data[i])<3:
          
          file_data.pop(i)
       
      if id not in file_data:
        file_data.append(id)
      file = open(save_file, 'w')
      file.write('\n'.join(file_data))
      file.close()
def open_fav(url):
    save_file=os.path.join(user_dataDir,"fav.txt")
    if url=='movies':
      type='movies'
    elif url=='tv':
      type='tv'
    else:
      type='all'
    url=None
    name=None
    mode=None
    iconimage=None
    fanart=None
    description=None
    original_title=None
    file_data=[]
    change=0

    if os.path.exists(save_file):
        f = open(save_file, 'r')
        file_data = f.readlines()
        f.close()
    num=0
    for items in file_data:
       if len(items)>1:
            list1=items.split("$$")
            full_str=''
            for item_as in list1:
              full_str=full_str+chr(int(item_as))
            
            params=get_custom_params(full_str)
           
            url=None
            name=None
            mode=None
            iconimage=None
            fanart=None
            description=None
            original_title=None
            data=0
            id=' '
            season=0
            episode=0
            show_original_year=0
            heb_name=' '
            tmdbid=' '
            eng_name=' '
            try:
                    url=urllib.unquote_plus(params["url"])
            except:
                    pass
            try:
                    name=urllib.unquote_plus(params["name"])
            except:
                    pass
            try:
                    iconimage=urllib.unquote_plus(params["iconimage"])
            except:
                    pass
            try:        
                    mode=int(params["mode"])
            except:
                    pass
            try:        
                    fanart=urllib.unquote_plus(params["fanart"])
            except:
                    pass
            try:        
                    description=urllib.unquote_plus(params["description"])
            except:
                    pass
            try:        
                    data=urllib.unquote_plus(params["data"])
            except:
                    pass
            try:        
                    original_title=(params["original_title"])
            except:
                    pass
            try:        
                    id=(params["id"])
            except:
                    pass
            try:        
                    season=(params["season"])
            except:
                    pass
            try:        
                    episode=(params["episode"])
            except:
                    pass
            try:        
                    tmdbid=(params["tmdbid"])
            except:
                    pass
            try:        
                    eng_name=(params["eng_name"])
            except:
                    pass
            try:        
                    show_original_year=(params["show_original_year"])
            except:
                    pass
            try:        
                    heb_name=(params["heb_name"])
            except:
                    pass
            
            te1=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
            
            te2="&name="+(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)+"&heb_name="+urllib.quote_plus(heb_name)
    
            te3="&data="+str(data)+"&original_title="+urllib.quote_plus(original_title)+"&id="+(id)+"&season="+str(season)
            te4="&episode="+str(episode)+"&tmdbid="+str(tmdbid)+"&eng_name="+(eng_name)+"&show_original_year="+(show_original_year)
     
           
            
            
            u=te1 + te2 + te3 + te4.decode('utf8')
            link="ActivateWindow(10025,%s,return)" % (u)
            if (type=='movies' and mode==4) or type=='all' or (type=='tv' and mode==7):
             addLink( name, link,99,True, iconimage,fanart,description,data=data,original_title=original_title,id=id,season=season,episode=episode,num_in_list=num)
       num=num+1

def remove_to_fav(plot):
    file_data=[]
    change=0
    cache.clear(['save_file'])
    if os.path.exists(save_file):
        f = open(save_file, 'r')
        file_data = f.readlines()
        f.close()
    
    if plot+'\n' in file_data:
      file_data.pop(file_data.index(plot+'\n'))
      change=1
    if change>0:
       
          file = open(save_file, 'w')
          file.write('\n'.join(file_data))
          file.close()
          xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'נמחק')).encode('utf-8'))
def remove_fav_num(plot):
    file_data=[]
    change=0
    cache.clear(['save_file'])
    if os.path.exists(save_file):
        f = open(save_file, 'r')
        file_data = f.readlines()
        f.close()

    if len(file_data)>=int(plot):
      file_data.pop(int(plot))
      change=1
    if change>0:
       
          file = open(save_file, 'w')
          file.write('\n'.join(file_data))
          file.close()
          xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'נמחק')).encode('utf-8'))
          xbmc.executebuiltin('Container.Refresh')
def play_by_subs(name,urls,iconimage,fanart,description_o,data,original_title,season,episode,id,eng_name,saved_name,original_title1,one_list=False):
   from urllib import quote_plus

   if urls=='torrents':
        dbcur.execute("SELECT * FROM torrents")
        urls = dbcur.fetchone()[0].decode('base64')
 
   dp = xbmcgui.DialogProgress()
   dp.create("מעדכן", "אנא המתן", '')
   dp.update(0)
   all_magents=json.loads(urls)

   plot=description_o
   tmdbKey = '653bb8af90162bd98fc7ee32bcbbfb3d'
   
   if season!=None and season!="%20":
       tv_movie='tv'
       url2='http://api.themoviedb.org/3/tv/%s?api_key=%s&language=he&append_to_response=external_ids'%(id,tmdbKey)
   else:
       tv_movie='movie'
       
       url2='http://api.themoviedb.org/3/movie/%s?api_key=%s&language=he&append_to_response=external_ids'%(id,tmdbKey)
   if 'tt' not in id:
         try:
            imdb_id=requests.get(url2).json()['external_ids']['imdb_id']
         except:
            imdb_id=" "
   else:
         imdb_id=id

   all_subs_in=json.loads(urllib.unquote_plus(original_title))
  
   all_data=[]
   xxx=0
   for mag in all_magents:
     
     regex='- (.+?) -'
     server_p=re.compile(regex).findall(all_magents[mag]['server'])
     if len(server_p)>0:
        server=server_p[0]
     else:
        server=''
     
     dp.update(int(((xxx* 100.0)/(len(all_magents))) ), all_magents[mag]['name'],'')
     xxx+=1
     title=all_magents[mag]['name']
     
     pre=check_pre(title.replace(' ','.').replace('(','').replace(')',''),all_subs_in['links'],original_title)
     
     description=plot
     if 1:#try:
          info=(PTN.parse(title))
          
          if 'resolution' in info:
             res=info['resolution']
          else:
             if "HD" in title:
              res="HD"
             elif "720" in title:
              res="720"
             elif "1080" in title:
               res="1080"
             else:
               res=' '
     #except:
     #   res=' '
     #   pass
     fixed_q=fix_q(res)

    
     try:
         regex=' - (.+?) GB'
         
         size=re.compile(regex).findall(all_magents[mag]['server'])[0]
   
         if 'MB' in size:
           size=size/1000
     except:
        size=0
     max_size=int(Addon.getSetting("size_limit"))
     
     if float(size)<max_size:
       
       regex='{P-(.+?)/S-(.+?)}'
     
       seeds=re.compile(regex).findall(all_magents[mag]['server'])[0][1].replace(' ','')
       peers=re.compile(regex).findall(all_magents[mag]['server'])[0][0].replace(' ','')
       seeds=seeds.replace(',','')
       peers=peers.replace(',','')
       regex='-(.+?)GB'
      
       if int(seeds)>=int(Addon.getSetting("min_seed")):
          if 'hebits' in all_magents[mag]['link']:
                pre='101'
          all_data.append(('[COLOR yellow]'+str(pre)+'%'+ '[/COLOR]- P%s/S%s- [COLOR lightgreen]%sGB[/COLOR]-[COLOR khaki]'%(peers,seeds,size)+res+ '[/COLOR]',all_magents[mag]['link'],urllib.quote_plus(str(all_magents[mag]['name'])),pre,res,fixed_q,all_magents[mag]['plot'],title,int(seeds),size,server))

   if Addon.getSetting("order_torrents_new")=='0':
      all_data=sorted(all_data, key=lambda x: x[5], reverse=False)
   elif Addon.getSetting("order_torrents_new")=='1':
       all_data=sorted(all_data, key=lambda x: x[3], reverse=True)
   elif Addon.getSetting("order_torrents_new")=='2':
       all_2160=[]
       all_1080=[]
       all_720=[]
       all_480=[]
       all_else=[]
       for name,link,origi,pre,res,fixed_q,description,title,seed,size,server in all_data:
        if fixed_q==1:
         all_2160.append((name,link,origi,pre,res,fixed_q,description,title,seed,size,server))
        elif fixed_q==2:
         all_1080.append((name,link,origi,pre,res,fixed_q,description,title,seed,size,server))
        elif fixed_q==3:
         all_720.append((name,link,origi,pre,res,fixed_q,description,title,seed,size,server))
        elif fixed_q==4:
         all_480.append((name,link,origi,pre,res,fixed_q,description,title,seed,size,server))
        else :
         all_else.append((name,link,origi,pre,res,fixed_q,description,title,seed,size,server))
       all_2160=sorted(all_2160, key=lambda x: x[3], reverse=True)
       all_1080=sorted(all_1080, key=lambda x: x[3], reverse=True)
       all_720=sorted(all_720, key=lambda x: x[3], reverse=True)
       all_480=sorted(all_480, key=lambda x: x[3], reverse=True)
       all_else=sorted(all_else, key=lambda x: x[3], reverse=True)
       all_data=all_2160+all_1080+all_720+all_480+all_else
   elif Addon.getSetting("order_torrents_new")=='3':
      logging.warning('ORDER #3')
      all_data=sorted(all_data, key=lambda x: x[8], reverse=True)
   else:
      all_data=sorted(all_data, key=lambda x: x[9], reverse=True)
   m=[]
   for name,link,origi,pre,res,fixed_q,description,title,seed,size,server in all_data:
     dp.update(int(((xxx* 100.0)/(len(all_magents))) ),name,'מסדר')
     video_data={}
     fixed_name=title

     if season!=None and season!="%20":
       video_data['TVshowtitle']=fixed_name.replace('%20',' ').replace('%3a',':').replace('%27',"'").replace('_',".")
       video_data['mediatype']='tvshow'
       
     else:
       video_data['mediatype']='movies'
     video_data['OriginalTitle']=fixed_name.replace('%20',' ').replace('%3a',':').replace('%27',"'").replace('_',".")
     video_data['title']=fixed_name.replace('%20',' ').replace('%3a',':').replace('%27',"'").replace('_',".")
     video_data['poster']=fanart
     video_data['fanart']=fanart
     
     video_data['plot']=description+'\n_from_victory_'
     video_data['icon']=iconimage
     video_data['year']=data
   
     
     video_data['season']=season
     video_data['episode']=episode
     video_data['imdb']=imdb_id
     video_data['code']=imdb_id

     video_data['imdbnumber']=imdb_id
     
     video_data['imdb_id']=imdb_id
     video_data['IMDBNumber']=imdb_id
     video_data['genre']=imdb_id
     if ((Addon.getSetting("new_source_menu")=='true')  or new_windows_only) :
        regex='- P(.+?)/S(.+?)'
        m1=re.compile(regex).findall(name)
        if len(m1)>0:
            added='{P'+m1[0][0]+'/S'+m1[0][1]
        else:
            added=''
        
        m.append((title.replace('[','.').replace(']','.')+'['+server+']'+'-'+size+('GB -{%s}'%added),link,iconimage,fanart,description+'\n_from_victory_','',res,'',res,title,pre))
     else:
        addLink(name, link,5,False, iconimage,fanart,'[COLOR aqua]'+res+'[/COLOR]\n'+description,original_title=original_title,id=id,data=data,saved_name=title,video_info=json.dumps(video_data))
   if Addon.getSetting("new_source_menu")=='true':
        new_show_sources(m,data,description+'\n_from_victory_',fixed_name,episode,fanart,fixed_name,iconimage,id,fixed_name,original_title1,season,data,[],[],[],[],[])
   logging.warning('Done Torrent')
   dp.close()
def activate_torrent(sub,urls,iconimage,fanart,description,data,original_title,season,episode,id,eng_name,saved_name):

    from play import play
    items=eval(urllib.unquote_plus(original_title))

    title=sub.split("% ")[1]
    try:
      s=int (season)
      tv_mode='tv'
    except:
      tv_mode='movie'
      pass
    if tv_mode=='movie':
      payload = '?search=movie&imdb_id=%s&title=%s&year=%s' % (id, title, data)
      play(urls, payload, items)
def server_test():
    addDir3('סריקת שרתים ישירים', 'www',33, ' ',' ',' ')
    onlyfiles = [f for f in listdir(done_dir) if isfile(join(done_dir, f))]
    onlyfiles=onlyfiles+[f for f in listdir(mag_dir) if isfile(join(mag_dir, f))]
    onlyfiles=onlyfiles+[f for f in listdir(rd_dir) if isfile(join(rd_dir, f))]
    onlyfiles=sorted(onlyfiles, key=lambda x: x[0], reverse=False)
    for items in onlyfiles:
      if items !='general.py' and '.pyc' not in items and '.pyo' not in items and '__init__' not in items and items !='resolveurl.py' and items !='cache.py'  and items!='cloudflare.py' and items!='Addon.py':
        addDir3(items.replace('.py',''), items,23, ' ',' ',' ')
def showText(heading, text):
    id = 10147
    xbmc.executebuiltin('ActivateWindow(%d)' % id)
    xbmc.sleep(100)
    win = xbmcgui.Window(id)
    retry = 50
    while (retry > 0):
        try:
            xbmc.sleep(10)
            retry -= 1
            win.getControl(1).setLabel(heading)
            win.getControl(5).setText(text)
            return
        except:
            pass


def run_test(name_o):

    
    dp = xbmcgui.DialogProgress()
    dp.create("בודק", "אנא המתן", '')
    dp.update(0)



    dir_path = os.path.dirname(os.path.realpath(__file__))
    mypath=done_dir

    onlyfiles = [f for f in listdir(mypath) if isfile(join(mypath, f))]
    onlyfiles =onlyfiles+ [f for f in listdir(mag_dir) if isfile(join(mag_dir, f))]
    onlyfiles =onlyfiles+ [f for f in listdir(rd_dir) if isfile(join(rd_dir, f))]


    f_result={}
    all_sources=[]

    name_check=name_o
  
    for items in onlyfiles:
       if items !='general.py' and '.pyc' not in items and '.pyo' not in items and '__init__' not in items and items !='resolveurl.py' and items !='Addon.py' and items !='cache.py' and items!='cloudflare.py':
         
           impmodule = __import__(items.replace('.py',''))
          
           if name_check!='' :
             if items.replace('.py','')==name_check:
               
                 all_sources.append((items.replace('.py',''),impmodule))
          
    thread=[]
    
    string_dp=''
    for name1,items in all_sources:
     f_result[name1]= items.global_var
 
     if name1==name_check:
 
         if 'tv' in items.type and 'movie' in items.type:
           choise=['TV','MOVIE']
           ret = xbmcgui.Dialog().select("בחר", choise)
           if ret!=-1:
             if ret==0:
               tv_movie='tv'
             else:
               tv_movie='movie'
           else:
             sys.exit()
         elif 'tv' in items.type:
           tv_movie='tv'
         else:
           tv_movie='movie'
         if tv_movie=='tv':
            original_title='the flash'
            show_original_year='2014'
            season='6'
            episode='5'
            season_n='06'
            episode_n='05'
            id='60735'
            name='פלאש'
            
         else:
            original_title='anastasia'
            show_original_year='2019'
            season='%20'
            episode='00'
            season_n='00'
            episode_n='00'
            id='427641'
            name='פרא'
         if name1=='sol':
            original_title='Moonlight'
         if name1=='mds':
            original_title='joker'
            show_original_year='2019'
         thread.append(Thread(items.get_links,tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id))
         thread[len(thread)-1].setName(name1)
    

    for td in thread:
          td.start()

    str1=''
    str2=''


    still_alive=0
    xxx=0
    all_links_togther=[]
    start_time=time.time()
    while 1:

        ir={}
        for threads in thread:
           
                still_alive=0
                for yy in range(0,len(thread)):
                        if thread[yy].is_alive():
                          ir[thread[yy].getName()]='[COLOR aqua]'+(thread[yy].getName())+'[/COLOR]'
                          still_alive=1
                        else:
                          ir[thread[yy].getName()]='[COLOR yellow]'+(thread[yy].getName())+'[/COLOR]'
                all_links_togther=[]
                count_rest=0
                count_1080=0
                count_720=0
                count_480=0
                f_result={}
                for name1,items in all_sources:
                   
                   f_result[name1]= items.global_var
                   if name1!='subs':
                     
                     all_links_togther=all_links_togther+f_result[name1]
                links_in=''
               
                
                for data in all_links_togther:
                        
                         name1,links,server,res=data
                         
                         if '1080' in res:
                           count_1080+=1
                         elif '720' in res:
                           count_720+=1
                         elif '480' in res:
                           count_480+=1
                         else:
                           count_rest+=1
                         links_in=links+','+links_in
                all_names=[]
                str1=' '
                
                for items in f_result:
                    all_names.append((items,len(f_result[items])))
                    
                    if threads.is_alive() and items==threads.getName():
                      str1=str1+ir[items]+' : '+str(len(f_result[items]))
                    else:
                    
                      str1=str1+ir[items]+' : '+str(len(f_result[items]))
                
                     
                string_dp="1080: %s 720: %s 480: %s Rest: %s"%(count_1080,count_720,count_480,count_rest)
                elapsed_time = time.time() - start_time
                dp.update(int(((xxx* 100.0)/(100)) ), ' אנא המתן '+' - [COLOR aqua]'+tv_movie+' - [/COLOR]'+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),string_dp)
                
        if dp.iscanceled():
        
          for name1,items in all_sources:
                 for threads in thread:
                   if threads.is_alive():
                     
                     threads._Thread__stop()
                   items.stop_all=1
          dp.close()
            
                        
        if still_alive==0:
               break
       
               
        
    for name,link,server,res in all_links_togther:
      
      addLink(name,link,5,False,' ',' ','-'+server+'- \n'+res)
      
def open_settings():
    Addon.openSettings()
def play_trailer_f(id,tv_movie):
    import random
    global search_done
    if tv_movie=='movie':
      url_t='http://api.themoviedb.org/3/movie/%s/videos?api_key=34142515d9d23817496eeb4ff1d223d0'%id
    else:
      url_t='http://api.themoviedb.org/3/tv/%s/videos?api_key=34142515d9d23817496eeb4ff1d223d0'%id
    html_t=requests.get(url_t).json()

    if len(html_t['results'])>0:
        vid_num=random.randint(0,len(html_t['results'])-1)
    else:
      return 0
    video_id=(html_t['results'][vid_num]['key'])
    playback_url=''
    if video_id!=None:
      try:
        playback_url= get_youtube_link2('https://www.youtube.com/watch?v='+video_id).replace(' ','%20')
        
    
      except Exception as e:
            pass
            
      #from pytube import YouTube
      #playback_url = YouTube(domain_s+'www.youtube.com/watch?v='+video_id).streams.first().download()

      if search_done==0:
          
          xbmc.Player().play(playback_url)
def play_trailer(id,tv_movie):

    if tv_movie=='movie':
        url_t='http://api.themoviedb.org/3/movie/%s/videos?api_key=1248868d7003f60f2386595db98455ef'%id
        html_t=requests.get(url_t).json()
        if 'results' in html_t:
            video_id=(html_t['results'][0]['key'])
        else:
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'אין טריילר')))
            sys.exit()
    else:
        url_t='http://api.themoviedb.org/3/tv/%s/videos?api_key=1248868d7003f60f2386595db98455ef'%id
        html_t=requests.get(url_t).json()
        video_id=(html_t['results'][0]['key'])
    from youtube_ext import get_youtube_link2
    playback_url=''
    if video_id!=None:
      try:
       
        playback_url= get_youtube_link2('https://www.youtube.com/watch?v='+video_id).replace(' ','%20')
        
    
      except Exception as e:
            logging.warning('Error playing youtube:'+str(e))
            pass
      #from pytube import YouTube
      #playback_url = YouTube(domain_s+'www.youtube.com/watch?v='+video_id).streams.first().download()
         
       
        
      #playback_url = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % video_id
      item = xbmcgui.ListItem(path=playback_url)
      xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
def get_array(url,oid):
   from random import randint
   save_file=os.path.join(user_dataDir,"fav_movie.txt")
   file_data=[]
   change=0
   if url=='tv':
        dbcur.execute("SELECT  * FROM Lastepisode WHERE  type='tv' ")
        type='tv'
   else:
       dbcur.execute("SELECT * FROM AllData WHERE  type='movie'")
       type='movie'
   match = dbcur.fetchall()
   all_o_data=[]
   level=0
   for item in match:
      name,url,icon,image,plot,year,original_title,season,episode,id,eng_name,show_original_year,heb_name,isr,tv_movie=item
      file_data.append(id)
   count=0
   x=0
   url_array=[]
   if oid=='':
       while count<20:
        try:
            id=file_data[randint(0, len(file_data)-1)]
        except:
            break
        x=x+1
        if x==len(file_data):
          break
        
        if len(id)>1 and '%' not in id:
         url=domain_s+'api.themoviedb.org/3/%s/%s/recommendations?api_key=34142515d9d23817496eeb4ff1d223d0&language=heb&page=1'%(type,id.replace('\n',''))
         count=count+1
         
         if url not in url_array:
           url_array.append(url)
   else:
    url_array.append(domain_s+'api.themoviedb.org/3/%s/%s/recommendations?api_key=34142515d9d23817496eeb4ff1d223d0&language=heb&page=1'%(type,oid.replace('\n','')))
   return url_array
def movie_recomended(url,id=''):
       new_name_array=[]
       id=id.replace('%20','')
       logging.warning('id:'+id)
       #get_array(url,id)
       url_array=cache.get(get_array,24,url,id, table='posters')
       all_n=[]
       for url in url_array:
        new_name_array,all_n=get_movies(url,0,reco=1,all_n=all_n)
        if len(all_n)>100:
            break
       xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_RATING)
       xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_YEAR)
       xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
       

       
def get_array_tv():
   from random import randint
   save_file=os.path.join(user_dataDir,"fav_tv.txt")
   file_data=[]
   change=0
   
   
   if os.path.exists(save_file):
        f = open(save_file, 'r')
        file_data = f.readlines()
        f.close()
   else:
     xbmcgui.Dialog().ok('שגיאה', ':-) לא קיימת היסטוריית צפייה , תתחיל לראות משהו למי אתה מחכה??')
     return 0
   count=0
   x=0
   url_array=[]
   while count<4:
    id=file_data[randint(0, len(file_data)-1)]
    x=x+1
    if x==len(file_data):
      break
    
    if len(id)>1 and '%' not in id:
          
     url=domain_s+'api.themoviedb.org/3/tv/%s/recommendations?api_key=34142515d9d23817496eeb4ff1d223d0&language=heb&page=1'%id.replace('\n','')
     
     count=count+1
     if url not in url_array:
       url_array.append(url)
   return url_array
def tv_recomended():
    new_name_array=[]
    url_array=cache.get(get_array_tv,24, table='recomended')
    for url in url_array:
    
       get_movies(url,0,reco=1)
 
def get_tmdb_from_imdb(imdb,html_g,xxx):
    global all_new_data
    url=domain_s+'api.themoviedb.org/3/find/%s?api_key=34142515d9d23817496eeb4ff1d223d0&external_source=imdb_id&language=heb'%imdb
    html=requests.get(url).json()
 
    for data in html['movie_results']:
     if 'vote_average' in data:
       rating=data['vote_average']
     else:
      rating=0
     if 'first_air_date' in data:
       year=str(data['first_air_date'].split("-")[0])
     else:
       if 'release_date' in data:
        year=str(data['release_date'].split("-")[0])
       else:
        year=' '
     if data['overview']==None:
       plot=' '
     else:
       plot=data['overview']
     if 'title' not in data:
       new_name=data['name']
     else:
       new_name=data['title']
     if 'original_title' in data:
       original_name=data['original_title']
       mode=4
       
       id=str(data['id'])
      
     else:
       original_name=data['original_name']
       id=str(data['id'])
       mode=7
     if data['poster_path']==None:
      icon=' '
     else:
       icon=data['poster_path']
     if 'backdrop_path' in data:
         if data['backdrop_path']==None:
          fan=' '
         else:
          fan=data['backdrop_path']
     else:
        fan=html['backdrop_path']
     if plot==None:
       plot=' '
     if 'http' not in fan:
       fan=domain_s+'image.tmdb.org/t/p/original/'+fan
     if 'http' not in icon:
       icon=domain_s+'image.tmdb.org/t/p/original/'+icon
     genres_list= dict([(i['id'], i['name']) for i in html_g['genres'] \
            if i['name'] is not None])
     try:genere = u' / '.join([genres_list[x] for x in data['genre_ids']])
     except:genere=''

     trailer = "plugin://plugin.video.allmoviesin?mode=25&url=www&id=%s" % id

     all_new_data.append((new_name,icon,fan,plot,year,original_name,id,rating,genere,trailer,xxx))
     return new_name,icon,fan,plot,year,original_name,id,rating,genere,trailer,xxx
def latest_dvd(url):
    global all_new_data
    start_time=time.time()
    if Addon.getSetting("dp")=='true':
                dp = xbmcgui.DialogProgress()
                dp.create("טוען סרטים", "אנא המתן", '')
                dp.update(0)
    headers = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
        'Host': 'www.dvdsreleasedates.com',
        'Pragma': 'no-cache',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
    }
    url_g=domain_s+'api.themoviedb.org/3/genre/movie/list?api_key=34142515d9d23817496eeb4ff1d223d0&language=he'
    #html_g=requests.get(url_g).json()
    html_g=html_g_movie
    html_o=requests.get(url,headers=headers).content
    regex="'fieldtable-inner'.+?<a id='.+?'></a>(.+?)<(.+?)</table></td></tr>"
    match=re.compile(regex,re.DOTALL).findall(html_o)
    name_array=[]
    all_new_data=[]
    xxx=0
    thread=[]
    for dat,rest in match:
      all_new_data.append(('[COLOR aqua][I]'+dat+'[/I][/COLOR]','','','','','','','','','',xxx))
      
      regex="'http://www.imdb.com/title/(.+?)/'"
      match_in=re.compile(regex,re.DOTALL).findall(rest)
      

      for imdb in match_in:
        if Addon.getSetting("dp")=='true':
                elapsed_time = time.time() - start_time
                dp.update(int(((xxx* 100.0)/(len(match_in)*len(match))) ), ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),imdb)
        xxx=xxx+1
        if imdb not in name_array:
        
            
            thread.append(Thread(get_tmdb_from_imdb,imdb,html_g,xxx))
            thread[len(thread)-1].setName(imdb)
                    
    logging.warning('len(thread)')
    logging.warning(len(thread))
    for td in thread:
        td.start()

        if Addon.getSetting("dp")=='true':
                elapsed_time = time.time() - start_time
                dp.update(0, ' מפעיל '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),td.name)
        #if len(thread)>38:
        xbmc.sleep(255)
    while 1:
          
          still_alive=0
          all_alive=[]
          for yy in range(0,len(thread)):
            
            if  thread[yy].is_alive():
              all_alive.append(thread[yy].name)
              still_alive=1
          if Addon.getSetting("dp")=='true':
                elapsed_time = time.time() - start_time
                dp.update(0, ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),','.join(all_alive))
          if still_alive==0:
            break
          xbmc.sleep(100)

    all_new_data=sorted(all_new_data, key=lambda x: x[10], reverse=False)
    for new_name,icon,fan,plot,year,original_name,id,rating,genere,trailer,xxx in all_new_data:
        if icon=='' and fan=='':
            addNolink(new_name,'www',199,False,iconimage=domain_s+'pbs.twimg.com/profile_images/421736697647218688/epigBm2J.jpeg',fanart='http://www.dream-wallpaper.com/free-wallpaper/cartoon-wallpaper/spawn-wallpaper/1280x1024/free-wallpaper-24.jpg')
        else:
            addDir3(new_name,url,4,icon,fan,plot,data=year,original_title=original_name,id=id,rating=rating,heb_name=new_name,show_original_year=year,isr=isr,generes=genere,trailer=trailer)
    if "a class='monthlink' href='" in html_o:
     regex="<a class='monthlink' href='(.+?)' >(.+?)<"
     match=re.compile(regex).findall(html_o)
     for link,name in match:
       addDir3('[COLOR aqua][I]'+name+'[/I][/COLOR]'.decode('utf8'),domain_s+'www.dvdsreleasedates.com'+link,28,' ',' ','תוצאות ישנות יותר'.decode('utf8'))
       break
    if Addon.getSetting("dp")=='true':
        dp.close()
def get_movie_data(url):
    html=requests.get(url).json()
    return html
def main_trakt():
   addDir3('רשימות','www',64,'https://kodi.expert/wp-content/uploads/2018/05/trakt-logo.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','רשימות')
   addDir3('התקדמות','users/me/watched/shows?extended=full',63,'https://kodi.expert/wp-content/uploads/2018/05/trakt-logo.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','התקדמות')
   addDir3('פרקים בצפייה','sync/watchlist/episodes?extended=full',63,'https://kodi.expert/wp-content/uploads/2018/05/trakt-logo.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','התקדמות')
   addDir3('סדרות בצפייה','users/me/watchlist/episodes?extended=full',31,'https://kodi.expert/wp-content/uploads/2018/05/trakt-logo.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','אוסף')
   
   addDir3('אוסף','users/me/collection/shows',31,'https://kodi.expert/wp-content/uploads/2018/05/trakt-logo.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','אוסף')
   addDir3('רשימות צפייה סדרות','users/me/watchlist/shows',31,'https://kodi.expert/wp-content/uploads/2018/05/trakt-logo.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','אוסף')
   addDir3('רשימות צפייה סרטים','users/me/watchlist/movies',31,'https://kodi.expert/wp-content/uploads/2018/05/trakt-logo.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','אוסף')
   
   addDir3('סרטים שנצפו','users/me/watched/movies',31,'https://kodi.expert/wp-content/uploads/2018/05/trakt-logo.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','אוסף')
   addDir3('סדרות שנצפו','users/me/watched/shows',31,'https://kodi.expert/wp-content/uploads/2018/05/trakt-logo.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','אוסף')
   
   addDir3('Movies Collection','users/me/collection/movies',31,'https://kodi.expert/wp-content/uploads/2018/05/trakt-logo.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','collection')
   addDir3('Liked lists','users/likes/lists',142,'https://kodi.expert/wp-content/uploads/2018/05/trakt-logo.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','Watched shows')
   
   
   
   
def get_trakt():
    
    trakt_lists=call_trakt("users/me/lists")
    #trakt_lists=call_trakt('users/me/collection/shows')
  
    my_lists = []
    
    for list in trakt_lists:
        my_lists.append({
            'name': list["name"],
            'user': list["user"]["username"],
            'slug': list["ids"]["slug"]
        })

    for item in my_lists:
        user = item['user']
        slug = item['slug']
        url=user+'$$$$$$$$$$$'+slug
        addDir3(item['name'],url,31,' ',' ',item['name'])
def progress_trakt(url):
        all_trk_data={}
        if  Addon.getSetting("fav_search_f_tv")=='true' and Addon.getSetting("fav_servers_en_tv")=='true' and len(Addon.getSetting("fav_servers_tv"))>0:
           fav_status='true'
        else:
            fav_status='false'
        if Addon.getSetting("dp")=='true':
                dp = xbmcgui.DialogProgress()
                dp.create("טוען פרקים", "אנא המתן", '')
                dp.update(0)
        import datetime
        start_time = time.time()
        xxx=0
        ddatetime = (datetime.datetime.utcnow() - datetime.timedelta(hours = 5))
        url_g=domain_s+'api.themoviedb.org/3/genre/tv/list?api_key=34142515d9d23817496eeb4ff1d223d0&language=he'
     
  
        #html_g=requests.get(url_g).json()
        html_g=html_g_tv
        result = call_trakt(url)
     
        items = []
        

        new_name_array=[]
        
        for item in result:
            
            try:
                num_1 = 0
                if 'seasons' in item:
                    for i in range(0, len(item['seasons'])):
                        if item['seasons'][i]['number'] > 0: num_1 += len(item['seasons'][i]['episodes'])
                    num_2 = int(item['show']['aired_episodes'])
                    if num_1 >= num_2: raise Exception()

                    season = str(item['seasons'][-1]['number'])

                    episode = [x for x in item['seasons'][-1]['episodes'] if 'number' in x]
                    episode = sorted(episode, key=lambda x: x['number'])
                    episode = str(episode[-1]['number'])
                else:
                    season = str(item['episode']['season'])
                    episode=str(item['episode']['number'])
                

                tvshowtitle = item['show']['title']
                if tvshowtitle == None or tvshowtitle == '': raise Exception()
                tvshowtitle = replaceHTMLCodes(tvshowtitle)

                year = item['show']['year']
                year = re.sub('[^0-9]', '', str(year))
                if int(year) > int(ddatetime.strftime('%Y')): raise Exception()

                imdb = item['show']['ids']['imdb']
                if imdb == None or imdb == '': imdb = '0'

                tmdb = item['show']['ids']['tmdb']
                if tmdb == None or tmdb == '': raise Exception()
                tmdb = re.sub('[^0-9]', '', str(tmdb))
                
               
                trakt = item['show']['ids']['trakt']
                if trakt == None or trakt == '': raise Exception()
                trakt = re.sub('[^0-9]', '', str(trakt))
                if 'last_watched_at' in item:
                    last_watched = item['last_watched_at']
                else:
                    last_watched = item['listed_at']
                if last_watched == None or last_watched == '': last_watched = '0'
                items.append({'imdb': imdb, 'tmdb': tmdb, 'tvshowtitle': tvshowtitle, 'year': year, 'snum': season, 'enum': episode, '_last_watched': last_watched})
            
            except Exception as e:
               logging.warning(e)
            
            
        result = call_trakt('/users/hidden/progress_watched?limit=1000&type=show')
        result = [str(i['show']['ids']['tmdb']) for i in result]

        items_pre = [i for i in items if not i['tmdb'] in result]

      
        for items in items_pre:
          watched='no'
          not_yet=0
          gone=0
          season=items['snum']
          episode=items['enum']
    
          url='http://api.themoviedb.org/3/tv/%s?api_key=%s&language=he&append_to_response=external_ids'%(items['tmdb'],'653bb8af90162bd98fc7ee32bcbbfb3d')
          #url='http://api.themoviedb.org/3/tv/%s/season/%s?api_key=34142515d9d23817496eeb4ff1d223d0&language=he'%(items['tmdb'],season)
          html=cache.get(get_movie_data,time_to_save,url, table='pages')
          plot=' '
          if 'The resource you requested could not be found' not in str(html):
             data=html
            
             if 'vote_average' in data:
               rating=data['vote_average']
             else:
              rating=0
             if 'first_air_date' in data:
               year=str(data['first_air_date'].split("-")[0])
             else:
                if 'release_date' in data:
                  year=str(data['release_date'].split("-")[0])
                else:
                    year=' '
             if data['overview']==None:
               plot=' '
             else:
               plot=data['overview']
             if 'title' not in data:
               new_name=data['name']
             else:
               new_name=data['title']
             f_subs=[]
             
             original_name=data['original_name']
             id=str(data['id'])
             mode=4
             if data['poster_path']==None:
              icon=' '
             else:
               icon=data['poster_path']
             if 'backdrop_path' in data:
                 if data['backdrop_path']==None:
                  fan=' '
                 else:
                  fan=data['backdrop_path']
             else:
                fan=html['backdrop_path']
             if plot==None:
               plot=' '
             if 'http' not in fan:
               fan=domain_s+'image.tmdb.org/t/p/original/'+fan
             if 'http' not in icon:
               icon=domain_s+'image.tmdb.org/t/p/original/'+icon
             genres_list= dict([(i['id'], i['name']) for i in html_g['genres'] \
                    if i['name'] is not None])
             try:genere = u' / '.join([genres_list[x['id']] for x in data['genres']])
             except:genere=''

   
            
             trailer = "plugin://plugin.video.allmoviesin?mode=25&url=www&id=%s" % id
             if new_name not in new_name_array:
              new_name_array.append(new_name)
              if Addon.getSetting("check_subs")=='true' or Addon.getSetting("disapear")=='true':
                  if len(f_subs)>0:
                    color='white'
                  else:
                    color='red'
                    
              else:
                 color='white'
              elapsed_time = time.time() - start_time
              if Addon.getSetting("dp")=='true':
                dp.update(int(((xxx* 100.0)/(len(html))) ), ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'[COLOR'+color+']'+new_name+'[/COLOR]')
              xxx=xxx+1
              if int(data['last_episode_to_air']['season_number'])>=int(season):
                if int(data['last_episode_to_air']['episode_number'])>int(episode):
                
                  episode=str(int(episode)+1)
                else:
                 if int(data['last_episode_to_air']['season_number'])>int(season):
                   season=str(int(season)+1)
                   episode='1'
                 else:
                  if (data['next_episode_to_air'])!=None:
                    episode=str(int(episode)+1)
                   
                    not_yet='1'
                  else:
                    gone=1
              else:
                    if (data['next_episode_to_air'])!=None:
                        season=str(int(season)+1)
                        episode='1'
                        not_yet='1'
                    else:
                        gone=1
              video_data={}

              

              video_data['mediatype']='tvshow'
              video_data['OriginalTitle']=new_name
              video_data['title']=new_name



              video_data['year']=year
              video_data['season']=season
              video_data['episode']=episode
              video_data['genre']=genere
              
              if len(episode)==1:
                  episode_n="0"+episode
              else:
                   episode_n=episode
              if len(season)==1:
                  season_n="0"+season
              else:
                  season_n=season
              if Addon.getSetting("trac_trk")=='true':
                addon='\n'+' עונה'+season_n+'-פרק '+episode_n
              else:
                addon=''
              video_data['plot']=plot+addon
              try:
                max_ep=data['seasons'][int(season)-1]['episode_count']
              except Exception as e:
                max_ep=100
            
              if gone==0:
                  if not_yet==0:
                  
                    if episode_n=='01':
                      dates=json.dumps((0,'' ,''))
                    elif max_ep<=int(episode):
                        dates=json.dumps(('','' ,0))
                    else:
                      dates=json.dumps(('','' ,''))
                    all_trk_data[id]={}
                    all_trk_data[id]['icon']=icon
                    all_trk_data[id]['fan']=fan
                    all_trk_data[id]['plot']=plot+addon
                    all_trk_data[id]['year']=year
                    all_trk_data[id]['original_title']=original_name
                    all_trk_data[id]['title']=new_name
                    all_trk_data[id]['season']=season
                    all_trk_data[id]['episode']=episode
                    all_trk_data[id]['eng_name']=original_title
                    all_trk_data[id]['heb_name']=new_name
                    all_trk_data[id]['type']='tv'
                    
                    
                    logging.warning('121')
                    addDir3('[COLOR '+color+']'+new_name+'[/COLOR]'+' S'+season_n+'E'+episode_n,url,mode,icon,fan,plot+addon,data=year,original_title=original_name,id=id,rating=rating,heb_name=new_name,show_original_year=year,isr=isr,generes=genere,trailer=trailer,watched=watched,season=season,episode=episode,eng_name=original_title,tmdbid=id,video_info=video_data,dates=dates,fav_status=fav_status)
                  else:
                   addNolink('[COLOR red][I]'+ new_name.encode('utf8')+'[/I][/COLOR]'+' S'+season_n+'E'+episode_n, 'www',999,False,iconimage=icon,fanart=fan)
          else:
            
            logging.warning('323')
            responce=call_trakt("shows/{0}".format(items['trakt']), params={'extended': 'full'})
          
           
            addNolink('[COLOR red][I]'+ responce['title']+'[/I][/COLOR]', 'www',999,False)
        logging.warning('424')
        if Addon.getSetting("dp")=='true':
          dp.close()
        logging.warning('H7')
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_YEAR)

        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_RATING)
        return all_trk_data
def get_trk_data(url):
        all_trk_data={}
        time_to_save=int(Addon.getSetting("save_time"))
        xxx=0
        if Addon.getSetting("dp")=='true':
                    dp = xbmcgui.DialogProgress()
                    dp.create("טוען סרטים", "אנא המתן", '')
                    dp.update(0)
        url_g_m=domain_s+'api.themoviedb.org/3/genre/movie/list?api_key=34142515d9d23817496eeb4ff1d223d0&language=he'
                     
        
        url_g_tv=domain_s+'api.themoviedb.org/3/genre/tv/list?api_key=34142515d9d23817496eeb4ff1d223d0&language=he'
        #html_g_tv=requests.get(url_g_tv).json()
        #html_g_m=requests.get(url_g_m).json()
        #html_g_tv=html_g_tv
        html_g_m=html_g_movie
        start_time = time.time()
        src="tmdb" 
            
        i = (call_trakt('/users/me/watched/movies'))
        
        all_movie_w=[]
        for ids in i:
          all_movie_w.append(str(ids['movie']['ids']['tmdb']))
        '''
        i = (call_trakt('/users/me/watched/shows?extended=full'))
        all_tv_w={}
        for ids in i:
         all_tv_w[str(ids['show']['ids']['tmdb'])]=[]
         for seasons in ids['seasons']:
          for ep in seasons['episodes']:
            all_tv_w[str(ids['show']['ids']['tmdb'])].append(str(seasons['number'])+'x'+str(ep['number']))
        '''
         
        if '$$$$$$$$$$$' in url:
            data_in=url.split('$$$$$$$$$$$')
            user = data_in[0]
            slug = data_in[1]
            selected={'slug':data_in[1],'user':data_in[0]}

            responce=call_trakt("/users/{0}/lists/{1}/items".format(user, slug))
        else:
           responce=call_trakt(url)
        new_name_array=[]

        for items in responce:
          
          if 'show' in items:
             slug = 'tv'
             html_g=html_g_tv
          else:
            slug = 'movies'
            html_g=html_g_m
          if slug=='movies':
            url='http://api.themoviedb.org/3/movie/%s?api_key=%s&language=he&append_to_response=external_ids'%(items['movie']['ids']['tmdb'],'653bb8af90162bd98fc7ee32bcbbfb3d')
          else:
            url='http://api.themoviedb.org/3/tv/%s?api_key=%s&language=he&append_to_response=external_ids'%(items['show']['ids']['tmdb'],'653bb8af90162bd98fc7ee32bcbbfb3d')
          
          html=cache.get(get_movie_data,72,url, table='pages')
          if 'The resource you requested could not be found' not in str(html):
             data=html
             if 'overview' not in data:
                continue
             if 'vote_average' in data:
               rating=data['vote_average']
             else:
              rating=0
             if 'first_air_date' in data :
               if data['first_air_date']==None:
                    year=' '
               else:
                   year=str(data['first_air_date'].split("-")[0])
             else:
                 if 'release_date' in data:
                    if data['release_date']==None:
                        year=' '
                    else:
                        year=str(data['release_date'].split("-")[0])
                 else:
                    year=' '
        
             if data['overview']==None:
               plot=' '
             else:
               plot=data['overview']
             if 'title' not in data:
               new_name=data['name']
             else:
               new_name=data['title']
             f_subs=[]
             if slug=='movies':
               original_name=data['original_title']
               mode=4
               
               id=str(data['id'])
               if Addon.getSetting("check_subs")=='true' or Addon.getSetting("disapear")=='true':
                 f_subs=cache.get(get_subs,9999,'movie',original_name,'0','0',id,year,True, table='pages')
               
               
             else:
               original_name=data['original_name']
               id=str(data['id'])
               mode=7
             if data['poster_path']==None:
              icon=' '
             else:
               icon=data['poster_path']
             if 'backdrop_path' in data:
                 if data['backdrop_path']==None:
                  fan=' '
                 else:
                  fan=data['backdrop_path']
             else:
                fan=html['backdrop_path']
             if plot==None:
               plot=' '
             if 'http' not in fan:
               fan=domain_s+'image.tmdb.org/t/p/original/'+fan
             if 'http' not in icon:
               icon=domain_s+'image.tmdb.org/t/p/original/'+icon
             genres_list= dict([(i['id'], i['name']) for i in html_g['genres'] \
                    if i['name'] is not None])
             try:genere = u' / '.join([genres_list[x['id']] for x in data['genres']])
             except:genere=''

   
            
             trailer = "plugin://plugin.video.allmoviesin?mode=25&url=www&id=%s" % id
             if new_name not in new_name_array:
              new_name_array.append(new_name)
              if Addon.getSetting("check_subs")=='true' or Addon.getSetting("disapear")=='true':
                  if len(f_subs)>0:
                    color='white'
                  else:
                    color='red'
                    
              else:
                 color='white'
              elapsed_time = time.time() - start_time
              if Addon.getSetting("dp")=='true':
                dp.update(int(((xxx* 100.0)/(len(html))) ), ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'[COLOR'+color+']'+new_name+'[/COLOR]')
              xxx=xxx+1
              watched='no'
              if id in all_movie_w:
                watched='yes'
              '''
              if id in all_tv_w:
                 if season+'x'+episode in all_tv_w[id]:
                  watched='yes'
              '''
              if slug=='movies':
                    fav_search_f=Addon.getSetting("fav_search_f")
                    fav_servers_en=Addon.getSetting("fav_servers_en")
                    fav_servers=Addon.getSetting("fav_servers")
                   
                    google_server= Addon.getSetting("google_server")
                    rapid_server=Addon.getSetting("rapid_server")
                    direct_server=Addon.getSetting("direct_server")
                    heb_server=Addon.getSetting("heb_server")
              else:
                    fav_search_f=Addon.getSetting("fav_search_f_tv")
                    fav_servers_en=Addon.getSetting("fav_servers_en_tv")
                    fav_servers=Addon.getSetting("fav_servers_tv")
                    google_server= Addon.getSetting("google_server_tv")
                    rapid_server=Addon.getSetting("rapid_server_tv")
                    direct_server=Addon.getSetting("direct_server_tv")
                    heb_server=Addon.getSetting("heb_server_tv")
        
   
              if  fav_search_f=='true' and fav_servers_en=='true' and (len(fav_servers)>0 or heb_server=='true' or google_server=='true' or rapid_server=='true' or direct_server=='true'):
                    fav_status='true'
              else:
                    fav_status='false'
             
              all_trk_data[id]={}
              all_trk_data[id]['icon']=icon
              all_trk_data[id]['fan']=fan
              all_trk_data[id]['plot']=plot
              all_trk_data[id]['year']=year
              all_trk_data[id]['original_title']=original_name
              all_trk_data[id]['title']=new_name
              all_trk_data[id]['season']='%20'
              all_trk_data[id]['episode']='%20'
              all_trk_data[id]['eng_name']=original_name
              all_trk_data[id]['heb_name']=new_name
              all_trk_data[id]['type']='movie'
              addDir3('[COLOR '+color+']'+new_name+'[/COLOR]',url,mode,icon,fan,plot,data=year,original_title=original_name,id=id,rating=rating,heb_name=new_name,show_original_year=year,isr=isr,generes=genere,trailer=trailer,watched=watched,fav_status=fav_status)
          else:
            
            if slug=='movies':
                responce=call_trakt("movies/{0}".format(items['movie']['ids']['trakt']), params={'extended': 'full'})
            else:
                responce=call_trakt("shows/{0}".format(items['show']['ids']['trakt']), params={'extended': 'full'})
           
           
            addNolink('[COLOR red][I]'+ responce['title']+'[/I][/COLOR]', 'www',999,False)
            
        if Addon.getSetting("dp")=='true':
          dp.close()
        logging.warning('H8')
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_YEAR)

        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_RATING)
        return all_trk_data
def get_one_trk(color,name,url_o,url,icon,fanart,data_ep,plot,year,original_title,id,season,episode,eng_name,show_original_year,heb_name,isr,dates,xxx,image):
          global all_data_imdb
          import _strptime
          data_ep=''
          dates=' '
          fanart=image
          url=domain_s+'api.themoviedb.org/3/tv/%s/season/%s?api_key=34142515d9d23817496eeb4ff1d223d0&language=he'%(id,season)
         
          html=requests.get(url).json()
          next=''
          ep=0
          f_episode=0
          catch=0
          counter=0
          if 'episodes' in html:
              for items in html['episodes']:
                if 'air_date' in items:
                   try:
                       datea=items['air_date']+'\n'
                       
                       a=(time.strptime(items['air_date'], '%Y-%m-%d'))
                       b=time.strptime(str(time.strftime('%Y-%m-%d')), '%Y-%m-%d')
                      
                   
                       if a>b:
                         if catch==0:
                           f_episode=counter
                           
                           catch=1
                       counter=counter+1
                       
                   except:
                         ep=0
          else:
             ep=0
          episode_fixed=int(episode)-1
          try:
              plot=html['episodes'][int(episode_fixed)]['overview']
          
              ep=len(html['episodes'])
              if (html['episodes'][int(episode_fixed)]['still_path'])==None:
                fanart=image
              else:
                fanart=domain_s+'image.tmdb.org/t/p/original/'+html['episodes'][int(episode_fixed)]['still_path']
              if f_episode==0:
                f_episode=ep
              data_ep='[COLOR aqua]'+'עונה '+season+'-פרק '+episode+ '[/COLOR]\n[COLOR yellow] מתוך ' +str(f_episode)  +' פרקים לעונה זו [/COLOR]\n' 
              if int(episode)>1:
                
                prev_ep=time.strftime( "%d-%m-%Y",(time.strptime(html['episodes'][int(episode_fixed)-1]['air_date'], '%Y-%m-%d'))) 
              else:
                prev_ep=0

          

                      
              if int(episode)<ep:

                if (int(episode)+1)>=f_episode:
                  color_ep='magenta'
                  next_ep='[COLOR %s]'%color_ep+time.strftime( "%d-%m-%Y",(time.strptime(html['episodes'][int(episode_fixed)+1]['air_date'], '%Y-%m-%d'))) +'[/COLOR]'
                else:
                  
                  next_ep=time.strftime( "%d-%m-%Y",(time.strptime(html['episodes'][int(episode_fixed)+1]['air_date'], '%Y-%m-%d'))) 
              else:
                next_ep=0
              dates=((prev_ep,time.strftime( "%d-%m-%Y",(time.strptime(html['episodes'][int(episode_fixed)]['air_date'], '%Y-%m-%d'))) ,next_ep))
              if int(episode)<int(f_episode):
               color='yellow'
              else:
               color='white'
               h2=requests.get('https://api.themoviedb.org/3/tv/%s?api_key=34142515d9d23817496eeb4ff1d223d0&language=en-US'%id).json()
               last_s_to_air=int(h2['last_episode_to_air']['season_number'])
               last_e_to_air=int(h2['last_episode_to_air']['episode_number'])
              
               if int(season)<last_s_to_air:
                 logging.warning('bigger One')
                 color='lightblue'
            
               if h2['status']=='Ended' or h2['status']=='Canceled':
                color='peru'
               
               
               if h2['next_episode_to_air']!=None:
                 
                 if 'air_date' in h2['next_episode_to_air']:
                  
                  a=(time.strptime(h2['next_episode_to_air']['air_date'], '%Y-%m-%d'))
                  next=time.strftime( "%d-%m-%Y",a)
                  
               else:
                  next=''
                 
          except Exception as e:
              logging.warning('Error :'+ heb_name)
              logging.warning('Error :'+ str(e))
              plot=' '
              color='green'
              if f_episode==0:
                f_episode=ep
              data_ep='[COLOR aqua]'+'עונה '+season+'-פרק '+episode+ '[/COLOR]\n[COLOR yellow] מתוך ' +str(f_episode)  +' פרקים לעונה זו [/COLOR]\n' 
              dates=' '
              fanart=image
          try:
            f_name=urllib.unquote_plus(heb_name.encode('utf8'))
     
          except:
            f_name=name
          if (heb_name)=='':
            f_name=name
          if color=='peru':
            add_p='[COLOR peru][B]סדרה זו הסתיימה או בוטלה[/B][/COLOR]'+'\n'
          else:
            add_p=''
          add_n=''
          if color=='white' and url_o=='tv' :
              if next !='':
                add_n='[COLOR tomato][I]פרק הבא ישודר ב ' +next+'[/I][/COLOR]\n'
              else:
                add_n='[COLOR tomato][I]פרק הבא ישודר ב ' +' לא ידוע עדיין '+'[/I][/COLOR]\n'
                next='???'
          
          added_txt=' [COLOR khaki][I]%sx%s[/I][/COLOR] '%(season,episode)
          all_data_imdb.append((color,f_name+' '+added_txt+' '+next,url,icon,fanart,add_p,data_ep,add_n,plot,year,original_title,id,season,episode,eng_name,show_original_year,heb_name,isr,dates,xxx))
          return data_ep,dates,fanart,color,next
def get_Series_trk_data(url_o,match):
        import _strptime
        cacheFile_trk = os.path.join(user_dataDir, 'cache_play_trk.db')
        dbcon_trk2 = database.connect(cacheFile_trk)
        dbcur_trk2  = dbcon_trk2.cursor()
        dbcur_trk2.execute("CREATE TABLE IF NOT EXISTS %s ( ""data_ep TEXT, ""dates TEXT, ""fanart TEXT,""color TEXT,""id TEXT,""season TEXT,""episode TEXT, ""next TEXT,""plot TEXT);" % 'AllData4')
        dbcon_trk2.commit()
        dbcur_trk2.execute("DELETE FROM AllData4")
        logging.warning('Updating sh')
        image=' '
        for item in match:
          next=''
          name,url,icon,image,plot,year,original_title,season,episode,id,eng_name,show_original_year,heb_name,isr,tv_movie=item
          #name,id,season,episode=item
          data_ep=''
          dates=' '
          fanart=image
          url=domain_s+'api.themoviedb.org/3/tv/%s/season/%s?api_key=34142515d9d23817496eeb4ff1d223d0&language=he'%(id,season)
         
          html=requests.get(url).json()
          if 'status_message' in html:
            if html['status_message']!='The resource you requested could not be found.':
                xbmc.sleep(10000)
                html=requests.get(url).json()
            
          ep=0
          f_episode=0
          catch=0
          counter=0
          if 'episodes' in html:
              for items in html['episodes']:
                if 'air_date' in items:
                   try:
                       datea=items['air_date']+'\n'
                       
                       a=(time.strptime(items['air_date'], '%Y-%m-%d'))
                       b=time.strptime(str(time.strftime('%Y-%m-%d')), '%Y-%m-%d')
                      
                   
                       if a>b:
                         if catch==0:
                           f_episode=counter
                           
                           catch=1
                       counter=counter+1
                       
                   except:
                         ep=0
          else:
             ep=0
          episode_fixed=int(episode)-1
          try:
              try:
                plot=html['episodes'][int(episode_fixed)]['overview']
              except:
                logging.warning(name.decode('utf-8'))
                if 'episodes' not in html:
                    logging.warning(html)
                    
                
                logging.warning(episode_fixed)
                
                plot=''
                pass
              
          
              ep=len(html['episodes'])
              if (html['episodes'][int(episode_fixed)]['still_path'])==None:
                fanart=image
              else:
                fanart=domain_s+'image.tmdb.org/t/p/original/'+html['episodes'][int(episode_fixed)]['still_path']
              if f_episode==0:
                f_episode=ep
              data_ep='[COLOR aqua]'+'עונה '+season+'-פרק '+episode+ '[/COLOR]\n[COLOR yellow] מתוך ' +str(f_episode)  +' פרקים לעונה זו [/COLOR]\n' 
              if int(episode)>1:
                
                prev_ep=time.strftime( "%d-%m-%Y",(time.strptime(html['episodes'][int(episode_fixed)-1]['air_date'], '%Y-%m-%d'))) 
              else:
                prev_ep=0

          

              try:
                  if int(episode)<ep:
                    
                    if (int(episode)+1)>=f_episode:
                      color_ep='magenta'
                      next_ep='[COLOR %s]'%color_ep+time.strftime( "%d-%m-%Y",(time.strptime(html['episodes'][int(episode_fixed)+1]['air_date'], '%Y-%m-%d'))) +'[/COLOR]'
                    else:
                      
                      next_ep=time.strftime( "%d-%m-%Y",(time.strptime(html['episodes'][int(episode_fixed)+1]['air_date'], '%Y-%m-%d'))) 
                  else:
                    next_ep=0
              except:
                next_ep=0
              dates=((prev_ep,time.strftime( "%d-%m-%Y",(time.strptime(html['episodes'][int(episode_fixed)]['air_date'], '%Y-%m-%d'))) ,next_ep))
              if int(episode)<int(f_episode):
               color='yellow'
              else:
               color='white'
               h2=requests.get('https://api.themoviedb.org/3/tv/%s?api_key=34142515d9d23817496eeb4ff1d223d0&language=en-US'%id).json()
               last_s_to_air=int(h2['last_episode_to_air']['season_number'])
               last_e_to_air=int(h2['last_episode_to_air']['episode_number'])
              
               if int(season)<last_s_to_air:
                 logging.warning('bigger')
                 color='lightblue'
               if h2['status']=='Ended' or h2['status']=='Canceled':
                color='peru'
                
               if h2['next_episode_to_air']!=None:
                 if 'air_date' in h2['next_episode_to_air']:
                    a=(time.strptime(h2['next_episode_to_air']['air_date'], '%Y-%m-%d'))
                    next=time.strftime( "%d-%m-%Y",a)
               else:
                  next=''
          
          except Exception as e:
              import linecache
              exc_type, exc_obj, tb = sys.exc_info()
              f = tb.tb_frame
              lineno = tb.tb_lineno
              filename = f.f_code.co_filename
              linecache.checkcache(filename)
              line = linecache.getline(filename, lineno, f.f_globals)
              error='''\
              line no:%s,
              line:%s,
              error:%s,
              url:%s,
              ep_no:%s,
              '''%(str(lineno),line,str(e),url,episode_fixed)
              
              
              
              
              logging.warning(error)
              logging.warning('BAD Series Tracker')
              plot=' '
              color='green'
              if f_episode==0:
                f_episode=ep
              data_ep='[COLOR aqua]'+'עונה '+season+'-פרק '+episode+ '[/COLOR]\n[COLOR yellow] מתוך ' +str(f_episode)  +' פרקים לעונה זו [/COLOR]\n' 
              dates=' '
              fanart=image
          
          dbcon_trk2.execute("INSERT INTO AllData4 Values ('%s', '%s', '%s', '%s','%s', '%s', '%s','%s','%s');" % (data_ep.replace("'","%27"),json.dumps(dates),fanart.replace("'","%27"),color,id,season,episode,next,plot.replace("'","%27")))
        dbcon_trk2.commit()
        dbcon_trk2.close()
        logging.warning('TRD SUCE')
        return 0
def check_next_last_tv_subs(color,original_title,name,season,episode,show_original_year,id):
   try:
  
    global susb_data_next
    import subs
    
    
    if color=='lightblue':
        season=str(int(season)+1)
        episode='1'
    if len(episode)==1:
          episode_n="0"+episode
    else:
           episode_n=episode
    if len(season)==1:
          season_n="0"+season
    else:
          season_n=season
    
    f_subs=subs.get_links('tv',original_title,name,season_n,episode_n,season,episode,show_original_year,id,check_one=True)
   
    if len(f_subs)>0:
        susb_data_next[original_title]=True
    else:
        susb_data_next[original_title]=False
        #f_name='√√ '+f_name
    return susb_data_next
   except Exception as e:
     logging.warning('Error in Subs:'+str(e))
def check_movie_subs(original_title,name,season,episode,show_original_year,id):
    global susb_data
    import subs
    
    logging.warning('In MOVIE SUBS')
    
    if len(episode)==1:
          episode_n="0"+episode
    else:
           episode_n=episode
    if len(season)==1:
          season_n="0"+season
    else:
          season_n=season
      
    f_subs=subs.get_links('movie',original_title,name,season_n,episode_n,season,episode,show_original_year,id,check_one=True)
    logging.warning('ckm:'+original_title)
    
    if len(f_subs)>0:
        susb_data[original_title]=True
    else:
        susb_data[original_title]=False
        #f_name='√√ '+f_name
    return susb_data
def check_last_tv_subs(original_title,name,season,episode,show_original_year,id):
    global susb_data
    import subs
    
    
    
    if len(episode)==1:
          episode_n="0"+episode
    else:
           episode_n=episode
    if len(season)==1:
          season_n="0"+season
    else:
          season_n=season
      
    f_subs=subs.get_links('tv',original_title,name,season_n,episode_n,season,episode,show_original_year,id,check_one=True)
    if len(f_subs)>0:
        susb_data[original_title]=True
    else:
        susb_data[original_title]=False
        #f_name='√√ '+f_name
    return susb_data
def last_viewed(url_o,isr=0,silent=False,dbcur='',dbcon=''):
    global all_data_imdb
    dbcon_trk2 = database.connect(cacheFile_trk)
    dbcur_trk2  = dbcon_trk2.cursor()
    #dbcur.execute("UPDATE last_viewed_last SET new='no' ")
    #dbcon.commit()
        
    all_f_data=[]
    isr_o=int(isr)
    logging.warning('isr:'+str(isr))
    global susb_data,susb_data_next
    import datetime
    strptime = datetime.datetime.strptime
    start_time=time.time()
    if Addon.getSetting("dp")=='true' and isr_o==0 and silent==False:
     
         dp = xbmcgui.DialogProgress()
         dp.create("אוסף", "אנא המתן", '')
         
         elapsed_time = time.time() - start_time
         dp.update(0, ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'אוסף', '')
         
    color='white'
    
    if url_o=='tv':
        dbcur.execute("SELECT  * FROM Lastepisode WHERE  type='tv' and season!='0' ")
    else:
       dbcur.execute("SELECT * FROM AllData WHERE  type='movie'")
    match_tv = dbcur.fetchall()
    xxx=0
    all_data_imdb=[]
    thread=[]
    
    for item in match_tv:
      name,url,icon,image,plot,year,original_title,season,episode,id,eng_name,show_original_year,heb_name,isr,tv_movie=item
      
      dates=' '
      next=''
      data_ep=''
      fanart=image
      if Addon.getSetting("dp")=='true'  and isr_o==0 and silent==False:
        dp.update(int(((xxx* 100.0)/(len(match_tv))) ), ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'אוסף', clean_name(original_title,1))
      xxx+=1
      done_data=0
      if url_o=='tv' :
          try:
              dbcur_trk2.execute("SELECT  * FROM AllData4 WHERE  id='%s' AND season='%s' AND episode='%s'"%(id,season,episode))
               
                  
              match2 = dbcur_trk2.fetchone()

            
              if match2!=None:
                data_ep,dates,fanart,color,i,j,k,next,plot=match2
                dates=json.loads(dates)

                if color=='white' :
                    
                    thread.append(Thread(get_one_trk,color,name,url_o,url,icon,fanart,data_ep,plot,year,original_title,id,season,episode,eng_name,show_original_year,heb_name,isr,dates,xxx,image))
                    thread[len(thread)-1].setName(clean_name(original_title,1))
                    done_data=1
                    #data_ep,dates,fanart,color,next=get_one_trk(color,f_name,url,icon,fanart,add_p,data_ep,add_n,plot,year,original_title,id,season,episode,eng_name,show_original_year,heb_name,isr,dates,xxx,image)
              else:

                thread.append(Thread(get_one_trk,color,name,url_o,url,icon,fanart,data_ep,plot,year,original_title,id,season,episode,eng_name,show_original_year,heb_name,isr,dates,xxx,image))
                thread[len(thread)-1].setName(clean_name(original_title,1))
                done_data=1
                #data_ep,dates,fanart,color,next=get_one_trk(color,f_name,url,icon,fanart,add_p,data_ep,add_n,plot,year,original_title,id,season,episode,eng_name,show_original_year,heb_name,isr,dates,xxx,image)
          except:
            thread.append(Thread(get_one_trk,color,name,url_o,url,icon,fanart,data_ep,plot,year,original_title,id,season,episode,eng_name,show_original_year,heb_name,isr,dates,xxx,image))
            thread[len(thread)-1].setName(clean_name(original_title,1))
            done_data=1
            #data_ep,dates,fanart,color,next=get_one_trk(color,f_name,url,icon,fanart,add_p,data_ep,add_n,plot,year,original_title,id,season,episode,eng_name,show_original_year,heb_name,isr,dates,xxx,image)
     
      if done_data==0:
          try:
            f_name=urllib.unquote_plus(heb_name.encode('utf8'))
     
          except:
            f_name=name
          if (heb_name)=='':
            f_name=name
          if color=='peru':
            add_p='[COLOR peru][B]סדרה זו הסתיימה או בוטלה[/B][/COLOR]'+'\n'
          else:
            add_p=''
          add_n=''
          if color=='white' and url_o=='tv' :
              if next !='':
                add_n='[COLOR tomato][I]פרק הבא ישודר ב ' +next+'[/I][/COLOR]\n'
              else:
                add_n='[COLOR tomato][I]פרק הבא ישודר ב ' +' לא ידוע עדיין '+'[/I][/COLOR]\n'
                next='???'
          
          added_txt=' [COLOR khaki][I]%sx%s[/I][/COLOR] '%(season,episode)
          all_data_imdb.append((color,f_name+' '+added_txt+' '+next,url,icon,fanart,add_p,data_ep,add_n,plot,year,original_title,id,season,episode,eng_name,show_original_year,heb_name,isr,dates,xxx))
      
    
    for td in thread:
        td.start()

        if Addon.getSetting("dp")=='true' and isr_o==0 and silent==False:
                elapsed_time = time.time() - start_time
                dp.update(0, ' מפעיל '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),td.name," ")
        if len(thread)>38:
            xbmc.sleep(255)
        else:
            xbmc.sleep(10)
    while 1:

          still_alive=0
          all_alive=[]
          for yy in range(0,len(thread)):
            
            if  thread[yy].is_alive():
              
              still_alive=1
              all_alive.append(thread[yy].name)
          if still_alive==0:
            break
          if Addon.getSetting("dp")=='true' and isr_o==0 and silent==False:
                elapsed_time = time.time() - start_time
                dp.update(0, ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),','.join(all_alive)," ")
          xbmc.sleep(100)
          if Addon.getSetting("dp")=='true' and isr_o==0 and silent==False:
              if dp.iscanceled():
                dp.close()
              
                break
    
    thread=[]
    if url_o=='tv':
        dbcur.execute("SELECT * FROM subs")
        match = dbcur.fetchall()
        all_subs_db=[]
        for title,id,season,episode in match:
            if len(episode)==1:
              episode_n="0"+episode
            else:
               episode_n=episode
            if len(season)==1:
              season_n="0"+season
            else:
              season_n=season
            next_ep=str(int(episode_n)+1)
            if len(next_ep)==1:
              next_ep_n="0"+next_ep
            else:
              next_ep_n=next_ep
            sub_title=title.replace("%27","'")+'-'+id+'-'+season_n+'-'+episode_n
            all_subs_db.append(sub_title)
        
        for color,f_name,url,icon,fanart,add_p,data_ep,add_n,plot,year,original_title,id,season,episode,eng_name,show_original_year,heb_name,isr,dates,xxx in all_data_imdb:
            if len(episode)==1:
              episode_n="0"+episode
            else:
               episode_n=episode
            if len(season)==1:
              season_n="0"+season
            else:
              season_n=season
            next_ep=str(int(episode_n)+1)
            if len(next_ep)==1:
              next_ep_n="0"+next_ep
            else:
              next_ep_n=next_ep
            season_c=season
            episode_c=episode

            if color=='lightblue':
                season_c=str(int(season)+1)
                
            if len(season_c)==1:
              season_c_n="0"+season_c
            else:
              season_c_n=season_c
            
            sub_title=original_title.replace("%27","'")+'-'+id+'-'+season_n+'-'+episode_n
            sub_title_next=original_title.replace("%27","'")+'-'+id+'-'+season_n+'-'+next_ep_n
            if color=='lightblue':
                        sub_title_next=original_title.replace("%27","'")+'-'+id+'-'+season_c_n+'-'+'01'

            if (color=='yellow' or color=='white' or color=='lightblue')  :
                
                
                if sub_title not in all_subs_db:
                    thread.append(Thread(check_last_tv_subs,original_title,heb_name,season,episode,show_original_year,id))
                    thread[len(thread)-1].setName(eng_name+' S%sE%s'%(season,episode))
                if (color=='yellow' or color=='lightblue') and sub_title_next not in all_subs_db:
                    
                    thread.append(Thread(check_next_last_tv_subs,color,original_title,heb_name,season,str(int(episode)+1),show_original_year,id))
                    season_c=season
                    episode_c=episode
                    if color=='lightblue':
                        season_c=str(int(season)+1)
                        episode_c='1'
                    else:
                        episode_c=str(int(episode_c)+1)
                    thread[len(thread)-1].setName(eng_name+' S%sE%s'%(season_c,episode_c))
                
            
    susb_data={}
    susb_data_next={}

    if url_o=='tv' and Addon.getSetting("tv_ep_subs")=='true':
  
        for td in thread:
            td.start()
        
            if Addon.getSetting("dp")=='true' and isr_o==0 and silent==False:
                    elapsed_time = time.time() - start_time
                    dp.update(0, ' מפעיל '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),td.name," ")
        while 1:

              still_alive=0
              all_alive=[]
              for yy in range(0,len(thread)):
                
                if  thread[yy].is_alive():
                  
                  still_alive=1
                  all_alive.append(thread[yy].name)
              if still_alive==0:
                break
              if Addon.getSetting("dp")=='true' and isr_o==0 and silent==False:
                    elapsed_time = time.time() - start_time
                    dp.update(0, ' מחפש כתוביות '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),','.join(all_alive)," ")
              xbmc.sleep(100)
              if Addon.getSetting("dp")=='true' and isr_o==0 and silent==False:
                  if dp.iscanceled():
                    dp.close()
                  
                    break
    all_data_imdb=sorted(all_data_imdb, key=lambda x: x[19], reverse=False)
    all_o_data=[]
    level=0
    for color,f_name,url,icon,fanart,add_p,data_ep,add_n,plot,year,original_title,id,season,episode,eng_name,show_original_year,heb_name,isr,dates,xxx in all_data_imdb:
        if url_o=='tv':
            if color=='yellow':
                level=1
            elif color=='lightblue':
                level=2
            elif color=='green':
                level=3
            elif color=='white':
                level=4
            elif color=='peru':
                level=5
        else:
            level+=1
        all_o_data.append((color,f_name,url,icon,fanart,add_p,data_ep,add_n,plot,year,original_title,id,season,episode,eng_name,show_original_year,heb_name,isr,dates,xxx,level))
    if url_o=='tv':
        order=False
    else:
        order=True
    if Addon.getSetting("order_latest")=='true':
        all_o_data=sorted(all_o_data, key=lambda x: x[20], reverse=order)
    for color,f_name,url,icon,fanart,add_p,data_ep,add_n,plot,year,original_title,id,season,episode,eng_name,show_original_year,heb_name,isr,dates,xxx,pos in all_o_data:
       
        if len(episode)==1:
          episode_n="0"+episode
        else:
           episode_n=episode
        if len(season)==1:
          season_n="0"+season
        else:
          season_n=season
        season_next=str(int(season)+1)
        if len(season_next)==1:
          season_next_n="0"+season_next
        else:
          season_next_n=season_next
        next_ep=str(int(episode_n)+1)
        if len(next_ep)==1:
          next_ep_n="0"+next_ep
        else:
          next_ep_n=next_ep
          
        sub_title=original_title.replace("%27","'")+'-'+id+'-'+season_n+'-'+episode_n
        if color=='lightblue':
            sub_title_next=original_title.replace("%27","'")+'-'+id+'-'+season_next_n+'-'+'01'
            
        else:
            sub_title_next=original_title.replace("%27","'")+'-'+id+'-'+season_n+'-'+next_ep_n
        
        if original_title in susb_data_next:
            
            if original_title in susb_data:
                if susb_data[original_title]==True:
                    
                    dbcur.execute("DELETE  FROM subs WHERE name = '%s' and id= '%s' and season <> '%s' "%(original_title.replace("'","%27"),id,season_n))
                    dbcur.execute("INSERT INTO subs Values ('%s', '%s','%s','%s');" %  (original_title.replace("'","%27"),id,season_n,episode_n))
                    dbcon.commit()
                    f_name='[COLOR lightblue] ▲ [/COLOR]'+f_name
            if susb_data_next[original_title]==True:
                if color=='lightblue':
                    episode_n='01'
                    next_ep_n='01'
                    
                    season_n=season_next_n
                    
                else:
                    dbcur.execute("DELETE  FROM subs WHERE name = '%s' and id= '%s' and season <> '%s' "%(original_title.replace("'","%27"),id,season_n))
                dbcur.execute("INSERT INTO subs Values ('%s', '%s','%s','%s');" %  (original_title.replace("'","%27"),id,season_n,next_ep_n))
                dbcon.commit()
                f_name='[COLOR peru] ◄ [/COLOR]'+f_name
            
        elif original_title in susb_data:
                
                if susb_data[original_title]==True:
                    dbcur.execute("DELETE  FROM subs WHERE name = '%s' and id= '%s' and season <> '%s'"%(original_title.replace("'","%27"),id,season_n))
                    dbcur.execute("INSERT INTO subs Values ('%s', '%s','%s','%s');" %  (original_title.replace("'","%27"),id,season_n,episode_n))
                    dbcon.commit()
                    f_name='[COLOR lightblue] ▲ [/COLOR]'+f_name
        if sub_title in all_subs_db:
            f_name='[COLOR lightblue] ▲ [/COLOR]'+f_name
        if sub_title_next in all_subs_db:
            f_name=f_name='[COLOR peru] ◄ [/COLOR]'+f_name
        all_d=((dates))
        if color!='white' and len(all_d)>1:
          
            
            
            
            add_n='[COLOR aqua]'+' שודר בתאריך '+all_d[1] + '[/COLOR]\n'
        all_f_data.append(('[COLOR %s]'%color+ f_name+'[/COLOR]', url,4, icon,fanart,add_p+data_ep+add_n+plot,year,original_title,id,season,episode,eng_name,show_original_year,heb_name,isr,json.dumps(dates)))
        
        plot=plot.replace('%27',"'")
        if silent==False:
            addDir3('[COLOR %s]'%color+ f_name+'[/COLOR]', url,4, icon,fanart,add_p+data_ep+add_n+plot,data=year,original_title=original_title,id=id,season=season,episode=episode,eng_name=eng_name,show_original_year=show_original_year,heb_name=heb_name,isr=isr,dates=json.dumps(dates))
    dbcur_trk2.close()
    dbcon_trk2.close()
    
    read_data2=[]
    if url_o=='tv' :
        read_data2.append((url_o,match_tv))
    
    logging.warning('ALLDONE TRK')
    if Addon.getSetting("dp")=='true' and isr_o==0 and silent==False:
        dp.close()
    enc_data=json.dumps(all_f_data).encode('base64')
    return read_data2,enc_data
def last_viewed_tvshows(url_o):
    color='white'
    
    if url_o=='tv':
        dbcur.execute("SELECT  * FROM Lastepisode WHERE  type='tv' ")
    else:
       dbcur.execute("SELECT * FROM AllData WHERE  type='movie'")
    match = dbcur.fetchall()
    all_o_data=[]
    level=0
    for item in match:
      name,url,icon,image,plot,year,original_title,season,episode,id,eng_name,show_original_year,heb_name,isr,tv_movie=item
      dates=' '
      

      
      try:
        f_name=urllib.unquote_plus(heb_name.encode('utf8'))
 
      except:
        f_name=name
      if (heb_name)=='':
        f_name=name
      level+=1
      all_o_data.append((color,f_name,url,icon,image,plot,year,original_title,id,season,episode,eng_name,show_original_year,heb_name,isr,dates,level))
    all_o_data=sorted(all_o_data, key=lambda x: x[16], reverse=True)
    if url_o=='tv':
        n_mode=7
    else:
        n_mode=4
    for color,f_name,url,icon,fanart,plot,year,original_title,id,season,episode,eng_name,show_original_year,heb_name,isr,dates,pos in all_o_data:
        addDir3('[COLOR %s]'%color+ f_name.encode('utf8')+'[/COLOR]', url,n_mode, icon,fanart,plot,data=year,original_title=original_title,id=id,season=season,episode=episode,eng_name=eng_name,show_original_year=show_original_year,heb_name=heb_name,isr=isr,dates=json.dumps(dates))

def scan_direct_links(next):
    from timeit import default_timer as timer
    servers_db=os.path.join(__PLUGIN_PATH__, "resources","servers.db")
    dp = xbmcgui.DialogProgress()
    dp.create("סורק שרתים", "אנא המתן", '','')
    dp.update(0)
    dbconserver = database.connect(servers_db)
    dbcurserver = dbconserver.cursor()


    dbcurserver.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT, ""speed TEXT);" % 'servers')
    dbcurserver.execute("VACUUM 'servers';")
    dbcurserver.execute("PRAGMA auto_vacuum;")
    dbcurserver.execute("PRAGMA JOURNAL_MODE=MEMORY ;")
    dbcurserver.execute("PRAGMA temp_store=MEMORY ;")
    dbconserver.commit()
    
    dbconserver.execute("DELETE FROM servers")
    dbconserver.commit()
    headers = {
        'User-Agent': 'Mozilla/5.0 (Linux; U; Android 4.4.2; zh-CN; HUAWEI MT7-TL00 Build/HuaweiMT7-TL00) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/40.0.2214.89 UCBrowser/11.3.8.909 Mobile Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'TE': 'Trailers',
    }
    headers2 = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0'}
    if next=='www':
     html=requests.get(domain_s+'filepursuit.com/discover.php',headers=headers).content
    else:
      html=requests.get(domain_s+'filepursuit.com/discover.php?startrow='+next,headers=headers).content

    
    regex="discover.php\?link=(.+?)'>(.+?)<"
    match_all=re.compile(regex).findall(html)
    f_time_avg=0
    xxx=0

    for links,name in match_all:
      f_time_avg=0

      for i in range(0,5):
          try:
            start = timer()
            html2=requests.get(links,headers=headers2,timeout=1).content
            if  'provider nor the domain owner maintain any relationship with the advertisers.' in html2 or 'tehmovies.org has expired' in html2 or domain_s+'www.google.com/recaptcha/api/fallback?k=' in html2 or 'Access Denied' in html2 or 'not found' in html2.lower() or 'Unauthorized' in html2 or 'Forbidden' in html2 or 'Service Unavailable' in html2:
              f_time='TIMEOUT'
              f_time_avg='TIMEOUT'
            else:
                end = timer()
                f_time=float(end-start)
                f_time_avg=f_time_avg+f_time
          except Exception as e:
            logging.warning(e)
            f_time='TIMEOUT'
            f_time_avg='TIMEOUT'
            break
      if dp.iscanceled():
          dp.close()
          return 0
          break
      if f_time_avg!='TIMEOUT':
        final_time=str(f_time_avg/6)
      else:
        final_time='TIMEOUT'
      if next=='www':
        next=0
      dp.update(int(((xxx* 100.0)/(len(match_all))) ), name,final_time,'Page '+str(int(next)/50))
      xxx=xxx+1
      dbcurserver.execute("SELECT * FROM servers WHERE name = '%s'"%(name))

      match = dbcur.fetchone()
      if match==None:
          dbcurserver.execute("INSERT INTO servers Values ('%s', '%s');" %  (name.replace("'","%27"),final_time))
          dbconserver.commit()
      else:
          
          dbcurserver.execute("UPDATE servers SET speed='%s' WHERE name = '%s'"%(final_time,name.replace("'","%27")))
          dbconserver.commit()
    dp.close()
    regex='"discover.php\?startrow=(.+?)">Next</'
    match_next=re.compile(regex).findall(html)
    if len(match_next)>0:
      scan_direct_links(match_next[0])
def remove_from_trace(name,original_title,id,season,episode):
   
    #dbcur.execute("select id from Lastepisode WHERE original_title = '%s'"%(original_title))

    #dbcon.commit()
    #id_new = dbcur.fetchone()[0]
    
    if id=='0':
      ok=xbmcgui.Dialog().yesno(("הסרה ממעקב סדרות"),(' ממעקב סדרות?'+name+"אתה בטוח שאתה רוצה להסיר את "))
    else:
      ok=xbmcgui.Dialog().yesno(("הסרת סימון נצפה"),(' ממצב נצפה?'+name+"אתה בטוח שאתה רוצה להסיר את "))
    if ok:
      if id=='0':
        dbcur.execute("DELETE  FROM Lastepisode WHERE original_title = '%s'"%(original_title))
      
        dbcon.commit()
      else:
      
        if len(episode)==0:
          episode='%20'
        if len(season)==0:
          season='%20'
        episode=episode.replace(" ","%20")
        season=season.replace(" ","%20")
        dbcur.execute("DELETE  FROM  AllData WHERE original_title = '%s'  AND season='%s' AND episode = '%s'"%(original_title,season.replace(" ","%20"),episode.replace(" ","%20")))
       
        
        dbcon.commit()
      
      #season_t, episode_t = int('%01d' % int(season)), int('%01d' % int(episode))
      #i = (post_trakt('/users/hidden/progress_watched', data={"shows": [{"seasons": [{"episodes": [{"number": episode_t}], "number": season_t}], "ids": {"tmdb": id_new}}]}))
      #logging.warning('Removed:')
      #logging.warning(i)
      xbmc.executebuiltin('Container.Refresh')
def play_level_movies(url):
    from youtube_ext import get_youtube_link2
            
    playback_url= get_youtube_link2(url).replace(' ','%20')
    #from pytube import YouTube
    #playback_url = YouTube(url).streams.first().download()
     
   
    
    
    item = xbmcgui.ListItem(path=playback_url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

def tv_mode_avg(name,url):


    import random
    from run import get_links
    if 'גוסט' in name:
        user_dataDir=os.path.join(done_dir,'cache_f','ghost')
    elif 'הנוקם' in name:
        user_dataDir=os.path.join(done_dir,'cache_f','avegner')
    else:
        user_dataDir=os.path.join(done_dir,'cache_f','orn')
    if not os.path.exists(user_dataDir):
        os.makedirs(user_dataDir)
                
    def download_file(url,path):
        local_filename =os.path.join(path, "fixed_list.txt")
        # NOTE the stream=True parameter
        r = requests.get(url, stream=True)
        with open(local_filename, 'wb') as f:
            for chunk in r.iter_content(chunk_size=1024): 
                if chunk: # filter out keep-alive new chunks
                    f.write(chunk)
                    #f.flush() commented by recommendation from J.F.Sebastian
        return local_filename

    def unzip(file):
        
        from zfile import ZipFile
        
        
        zip_file = file
        ptp = 'Masterpenpass'
        zf=ZipFile(zip_file)
        #zf.setpassword(bytes(ptp))
        #with ZipFile(zip_file) as zf:
        zf.extractall(user_dataDir)
    def renew_data(path):

        
        download_file(l_list,path)
        

        unzip(os.path.join(path, "fixed_list.txt"))


        
        
        return 'ok'
    
        
    import cache
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    
    
    l_list=url
    
    cacheFile=os.path.join(user_dataDir,'localfile.txt')
    if not os.path.exists(cacheFile):
       
        download_file(l_list,user_dataDir)

        unzip(os.path.join(user_dataDir, "fixed_list.txt"))

    else:

        all_img=cache.get(renew_data,1,arg=(user_dataDir,), table='posters')
    
    


    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("SELECT * FROM MyTable where  type='item'")
    match = dbcur.fetchall()


    
  
   
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    video_data={}
    
    video_data[u'mpaa']=unicode('heb')
    all_name_links=[]
    all_lins_in=[]
    for index,name,link,icon,fanart,plot,data,date,year,genre,father,type in match:
     if link not in all_lins_in:
      all_lins_in.append(gdecom(link))
      all_name_links.append((name,gdecom(link)))
    random.shuffle(all_name_links)
    once=0

    xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'בונה רשימת צפייה מ '.decode('utf8')+str(len(all_lins_in))+' סרטים וסדרות')).encode('utf-8'))
    for name,link in all_name_links:
     try:
      link2=get_links(link,tv_m=True)
      #link2=my_resolver(link)

      video_data['title']=name
      video_data['plot']='ערוץ'
      listItem=xbmcgui.ListItem(name)
      listItem.setInfo('video', video_data)
      if once==1 and not xbmc.Player().isPlaying():
        break
      playlist.add(url=link2, listitem=listItem)
      if once==0:
        once=1
        ok=xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
 
        xbmc.sleep(10000)
     except Exception as e:
       logging.warning(e)
       pass
def tv_mode_oni():
    import random
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    for c in range (0,3):
        page=random.randint(1,400)
        url=domain_s+'www.onitube.com/videos?o=mv&page='+str(page)
        headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive',
            'Host': 'www.onitube.com',
            'Pragma': 'no-cache',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
        }
        html=requests.get(url,headers=headers).content
        regex='<a href="%swww.onitube.com/video/(.+?)/.+?title="(.+?)".+?"hd-text-icon">(.+?)<'%domain_s
        match=re.compile(regex,re.DOTALL).findall(html)
        once=0
        for link,name,quality in match:
           info=(PTN.parse(name.replace(" ",".")))
          
           ok=1
           if ok==1:
           
                if "1080" in quality:
                  res="1080"
                elif "720" in quality:
                  res="720"
                elif "480" in quality:
                  res="480"
                elif "hd" in quality.lower():
                  res="HD"
                else:
                 res=' '
                 
                
                match_s='Direct'
                name1=clean_name(original_title,1)
                
                f_link=domain_s+'ont-assets-1.finalservers.net/mp4sd.php?id='+link
      
                if 'season' in info:
                  
                  season=info['season']
                else:
                  season='0'
                if 'episode' in info:
                  episode=info['episode']
                else:
                  episode='0'
                if 'year' in info:
                  year=info['year']
                
                  url2='http://www.omdbapi.com/?apikey=8e4dcdac&t=%s&year=%s'%(original_title,year)
                else:
                  year=''
                  url2='http://www.omdbapi.com/?apikey=8e4dcdac&t=%s'%(original_title)
                imdb_id="0"
                try:
                   imdb_id=requests.get(url2).json()['imdbID']
                except:
                  pass
                if once==1 and not xbmc.Player().isPlaying():
                    break
                video_data={}
           
                fixed_name=info['title']
              
                video_data['mediatype']='movies'
                video_data['OriginalTitle']=fixed_name.replace('%20',' ').replace('%3a',':').replace('%27',"'")
                video_data['title']=fixed_name
 
     
         
                video_data['year']=data
                video_data['season']=season
                video_data['episode']=episode
                video_data['imdb']=imdb_id
                video_data['code']=imdb_id
              

                video_data['imdbnumber']=imdb_id
                
                listItem=xbmcgui.ListItem(name)
                listItem.setInfo('video', infoLabels=video_data)
                playlist.add(url=f_link, listitem=listItem)
                if once==0:
                    once=1
                    ok=xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
             
                    xbmc.sleep(10000)
    playlist.shuffle()

def m1_channel():
    import random
    headers = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
        'Host': '1movies.biz',
        'Pragma': 'no-cache',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
    }
    url='http://1movies.biz/movies/mostviewed/?page='+str(random.randint(1,10))
    html=requests.get(url,headers=headers).content
    regex='<a class="thumb" href="(.+?)" title="(.+?)"'
    match=re.compile(regex).findall(html)
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    once=0
    for link,title in match:
      try:
         info=(PTN.parse(title.replace(" ",".").replace("(",".").replace(")",".").replace("_",".")))
         video_data={}
         fixed_name=info['title']
         original_title=info['title']
         if season!=None and season!="%20":
           video_data['TVshowtitle']=fixed_name.replace('%20',' ').replace('%3a',':').replace('%27',"'")
           video_data['mediatype']='tvshow'
           if 'season' in info:
             video_data['season']=info['season']
           if 'episode' in info:
             video_data['episode']=info['episode']
         else:
           video_data['mediatype']='movies'
         video_data['OriginalTitle']=original_title.replace('%20',' ').replace('%3a',':').replace('%27',"'")
         video_data['title']=fixed_name
         
         if 'year' in info:
           video_data['year']=info['year']
        
   
         new_url=get_1m_link(title,link)

         listItem=xbmcgui.ListItem(new_url[0][0])
         listItem.setInfo('video', video_data)
          
         playlist.add(url=new_url[0][1], listitem=listItem)
         if once==1 and not xbmc.Player().isPlaying():
            break

         if once==0:
            once=1
            ok=xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
     
            xbmc.sleep(10000)
      except Exception as e:
       logging.warning(e)
       pass
def israel_tv():
    import random
    html=requests.get('https://files.fm/u/c3m3xd3b#/list/').content
    regex='arrDisplayNames = \[(.+?)\]'
    names=re.compile(regex).findall(html)[0].split(",")
    regex='var arrHashes = \[(.+?)\]'
    links=re.compile(regex).findall(html)[0].split(",")
    regex='var arrThumbnails = \[(.+?)\]'
    images=re.compile(regex).findall(html)[0].split(",")
    html_g=cache.get(get_genere,72, table='pages')
    regex='var arrSizes = \[(.+?)\]'
    sizes=re.compile(regex).findall(html)[0].split(",")
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    all_one=[]
    for i in range (0,len(names)-1):
      all_one.append((names[i].replace('"','').replace('\\',''),links[i].replace('"',''),images[i].replace('"',''),sizes[i].replace('"','')))
    xxx=0
    start_time=time.time()
    all_name_links=[]
    for name,link,image,size in all_one:
      elapsed_time = time.time() - start_time

      info=(PTN.parse(name))

      f_link='https://fv5.failiem.lv/down.php?i=%s&n=%s'%(link,name)
      all_name_links.append((info['title'],f_link))
    random.shuffle(all_name_links)
    once=0

    xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'בונה רשימת צפייה מ '.decode('utf8')+str(len(all_name_links))+' סרטים')).encode('utf-8'))
    for name,link in all_name_links:
     try:
      link2=(link)
      video_data={}
      video_data['title']=name
             
      listItem=xbmcgui.ListItem(name)
      listItem.setInfo('video', video_data)
      if once==1 and not xbmc.Player().isPlaying():
        break
      playlist.add(url=link2, listitem=listItem)
      if once==0:
        once=1
        ok=xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
 
        xbmc.sleep(10000)
     except Exception as e:
       logging.warning(e)
       pass
def fast_play(final_link):
    listItem = xbmcgui.ListItem('FP', path=final_link) 
    listItem.setInfo(type='Video', infoLabels={'title':'FP'})


    listItem.setProperty('IsPlayable', 'true')

        
    ok=xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
def get_jen_cat():
    addNolink( '[COLOR blue][B][I]Update Jen DB[/I][/B][/COLOR]', 'www',131,False, iconimage="DefaultFolder.png",fanart="DefaultFolder.png",description=' ')
    tmdb_cacheFile = os.path.join(done_dir,'cache_f', 'clean_jen_db.db')
    dbcon_tmdb = database.connect(tmdb_cacheFile)
    dbcur_tmdb = dbcon_tmdb.cursor()
    
    dbcur_tmdb.execute("SELECT DISTINCT name FROM tmdb_data where (link not like '%http://dl8.f2m.io/%' or link like '%$$$%')")
    all_res_total=dbcur_tmdb.fetchall()
    
    addDir3('חפש ברשימות JEN (באנגלית)','search',154,'https://i.pinimg.com/736x/f2/4a/95/f24a95322599dd911e293779cd34a00a--purple-wallpaper-wallpaper-space.jpg','https://koditips.com/wp-content/uploads/jen-kodi.jpg','חפש ברשימות JEN',data='0')
    
    addDir3(' (%s סרטים) כל קישורי JEN'%str(len(all_res_total)),'0',154,'https://i.pinimg.com/736x/f2/4a/95/f24a95322599dd911e293779cd34a00a--purple-wallpaper-wallpaper-space.jpg','https://koditips.com/wp-content/uploads/jen-kodi.jpg','כל קישורי JEN',data='0')
    dbcur_tmdb.execute("SELECT DISTINCT name FROM tmdb_data where (res='2160')")
    all_res_total=dbcur_tmdb.fetchall()
    addDir3('JEN 4K(%s - סרטים)'%str(len(all_res_total)),'4K-0',154,'http://wwwbest-kodi-guideseu-9ueui6uviy.stackpathdns.com/wp-content/uploads/2017/10/4k-logo-jpg.jpg','https://i.imgur.com/tsmJz07.jpg','כל קישורי JEN',data='0')
    addDir3('קישורי JEN לפי שנים','years-0-0',154,'http://wwwbest-kodi-guideseu-9ueui6uviy.stackpathdns.com/wp-content/uploads/2017/10/4k-logo-jpg.jpg','https://i.imgur.com/tsmJz07.jpg','כל קישורי JEN',data='0')
    dbcur_tmdb.close()
    dbcon_tmdb.close()
    '''
    for i in range (1,7):

        cat_ena=Addon.getSetting("jen_cat-"+str(i))
        if cat_ena=='true':
          addDir3(Addon.getSetting("jen_name_cat-"+str(i)),str(i),43,'https://i.pinimg.com/736x/f2/4a/95/f24a95322599dd911e293779cd34a00a--purple-wallpaper-wallpaper-space.jpg','https://koditips.com/wp-content/uploads/jen-kodi.jpg',Addon.getSetting("jen_name_cat-"+str(i)))
    '''
def fix_name_origin(saved_name,original_title):
         regex_name='] (.+?) -'

         if saved_name==None:
            saved_name=''
         match_name=re.compile(regex_name).findall(saved_name)
         if len(match_name)>0:
           fixed_name=match_name[0]
          
           if clean_name(original_title,1).replace(' ','').replace(':','').replace("'",'').lower() not in fixed_name.replace("'",'').replace('.',' ').replace('_',' ').replace('-',' ').replace(':','').replace(' ','').lower():
            
             fixed_name=original_title
         else:
           
           fixed_name=saved_name
           
           if clean_name(original_title,1).replace(' ','').replace(':','').replace("'",'').lower() not in fixed_name.replace("'",'').replace('.',' ').replace('_',' ').replace('-',' ').replace(':','').replace(' ','').lower():
             
             fixed_name=original_title
         return fixed_name
def get_isrlink(name):

    headers = {
        'Host': 'www.favez0ne.net',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'utf-8',
        'Referer': 'https://www.favez0ne.net/search.php',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'TE': 'Trailers',
        'Content-Length': '72'
    }
    org=name.decode('utf-8')
    f_t=''
    for ch in org:
        
        if not ch.isdigit():
            
            new=ord(ch)-1264
            try:
                f_t=f_t+urllib.quote_plus(chr(new))
            except:
                f_t=f_t+urllib.quote_plus(ch)
        else:
            new=ch
            f_t=f_t+new
        
    f_t=f_t.replace(' ','+')
   


    response = requests.post('https://www.favez0ne.net/search.php', headers=headers,data='srch=%s&submit.x=0&submit.y=0'%f_t).content

    regex="OnClick=.+?>.+?<.+?>(.+?)<|http://adf.ly/.+?/(.+?)'"
    match=re.compile(regex,re.DOTALL).findall(response)
    
    all_l=[]
    all_n=[]
    f_q=''
    for q,link in match:
        if q!='':
          f_q=q
        
        if 'openload' in link or 'upto' in link or 'upfile' in link:
            name1,match_s,res,check=server_data(link,org)
      
            if check:
                regex='//(.+?)/'
                s_n=re.compile(regex).findall(link)[0]
                
                all_l.append(link)
                all_n.append(s_n.replace('openload','vummo').replace('letsupload','avlts')+' - '+f_q)
            
            
    ret = xbmcgui.Dialog().select("בחר", all_n)
    if ret!=-1:
        return all_l[ret]
    else:
      sys.exit()
def get_fame(url):
    headers = {
                
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
                }
    x=requests.get(url,headers=headers).content
    all_l=[]
    all_n=[]

    regex='iframe.+?src="(.+?)"'
    link=re.compile(regex,re.IGNORECASE).findall(x)
    if len(link)>0:
        link=link[0]
        regex='//(.+?)/'
        host=re.compile(regex).findall(link)[0]
        all_l.append(link)
        all_n.append(host)
        regex='class="play_next btn" data-meta-key="(.+?)" data-post-id="(.+?)">(.+?)<'
        match=re.compile(regex).findall(x)
        if len(match)==0:
      
            xbmcgui.Dialog().ok('שגיאה','אין לינק לפרק זה סורי')
            return 'NOT OK'
    else:
        xbmcgui.Dialog().ok('שגיאה','אין לינק לפרק זה סורי')
        return 'NOT OK'
  
    for key,id,host in match:
        data = {
          'action': 'wpse_296903_call_meta',
          'post_id': id,
          'meta_key': key
        }

        response = requests.post('https://www.moviesfame.com/wp-admin/admin-ajax.php', headers=headers, data=data).content
 
        regex='src="(.+?)"'
        match2=re.compile(regex,re.IGNORECASE).findall(response)
        if len(match2)>0:
            if 'http' not in match2[0]:
              link='http:'+match2[0]
            else:
              link=match2[0]
            all_l.append(link)
            all_n.append(host)
    if len(all_l)>1:
        
            ret = xbmcgui.Dialog().select("בחר", all_n)
            if ret!=-1:
                return all_l[ret]
            else:
              sys.exit()
    else:
            return all_l[0]
    '''
    regex='Watch Online.+?iframe.+?src="(.+?)"'
    match=re.compile(regex,re.DOTALL).findall(x)
    regex='<p>Direct Download Links</p>(.+?)</ul>'
    match_pre=re.compile(regex,re.DOTALL).findall(x)
    if len (match_pre)>0:
        regex='<li><a href=(.+?) target="_blank">'
        match2=re.compile(regex,re.DOTALL).findall(match_pre[0])
        logging.warning(match2)
        all_l=[]
        all_n=[]
        for link in (match+match2):
            if 'http' in link and '1fichier.com' not in link and 'www.moviesfame.com' not in link:
                regex='//(.+?)/'
                s_n=re.compile(regex).findall(link)[0]
                
                all_l.append(link.replace('"','').strip())
                all_n.append(s_n.replace('openload','vummo'))
        if len(all_l)>1:
        
            ret = xbmcgui.Dialog().select("בחר", all_n)
            if ret!=-1:
                return all_l[ret]
            else:
              sys.exit()
        else:
            return all_l[0]
    else:
       return match[0]
    '''
def get_eli_link(url):
    headers = {
                
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
                }
    x=requests.get(url,headers=headers).content
    regex='iframe src="(.+?)"'
    match=re.compile(regex,re.IGNORECASE).findall(x)
    all_l=[]
    all_n=[]
    for link in match:
        y=requests.get(link,headers=headers).url
        all_l.append(y)
        regex='//(.+?)/'
        s_n=re.compile(regex).findall(y)[0]
        all_n.append(s_n.replace('openload','vummo').replace('letsupload','avlts'))
    regex='iframe width=".+?" height=".+?" src="(.+?)"'
    match=re.compile(regex,re.IGNORECASE).findall(x)
    for link in match:
        y=requests.get(link,headers=headers).url
        all_l.append(y)
        regex='//(.+?)/'
        s_n=re.compile(regex).findall(y)[0]
        all_n.append(s_n.replace('openload','vummo').replace('letsupload','avlts'))
    if len(all_l)>1:
        
            ret = xbmcgui.Dialog().select("בחר", all_n)
            if ret!=-1:
                return all_l[ret]
            else:
              sys.exit()
    else:
        return all_l[0]
def resolve_magnet(url,listitem,match_playtime,info,mag_start_time):
    from kodipopcorntime.torrent import TorrentPlayer
    from kodipopcorntime import settings
    mediaSettings = getattr(settings, 'movies')
    item={'info': {'rating': 0.0, 'plotoutline': 'Elastigirl springs into action to save the day, while Mr. Incredible faces his greatest challenge yet \xe2\x80\x93 taking care of the problems of his three children.', 'code': 'tt3606756', 'director': '', 'studio': '', 'year': 2018, 'genre': 'animation / family / action / adventure / superhero', 'plot': 'Elastigirl springs into action to save the day, while Mr. Incredible faces his greatest challenge yet \xe2\x80\x93 taking care of the problems of his three children.', 'votes': 0.0, 'castandrole': [], 'title': 'Playing', 'tagline': '1080p: 18930 seeds; 720p: 14301 seeds; ', 'writer': '', 'originaltitle': 'Incredibles 2'}, 'thumbnail': 'http://image.tmdb.org/t/p/w500/x1txcDXkcM65gl7w20PwYSxAYah.jpg', 'stream_info': {'subtitle': {'language': ''}, 'audio': {'channels': 2, 'codec': 'aac', 'language': 'en'}, 'video': {'width': 1920, 'codec': 'h264', 'height': 720}}, 'label': 'Incredibles 2', 'properties': {'fanart_image': 'http://image.tmdb.org/t/p/w500/mabuNsGJgRuCTuGqjFkWe1xdu19.jpg'}, 'icon': 'http://image.tmdb.org/t/p/w500/x1txcDXkcM65gl7w20PwYSxAYah.jpg'}
    return TorrentPlayer().playTorrentFile(mediaSettings, url, item,match_playtime,info,mag_start_time, None,listitem)

def get_torrent_link(url):
    from urllib import quote_plus
    plugin_p = Addon.getSetting('players_new')
    infohash=re.compile('btih:(.+?)&').findall(url)
    if plugin_p=='0':
      plugin = 'Quasar'
    elif plugin_p=='1':
      plugin = 'Pulsar'
    elif plugin_p=='2':
      plugin = 'KmediaTorrent'
    elif plugin_p=='3':
      plugin = 'Torrenter'
    elif plugin_p=='4':
      plugin = 'YATP'
    elif plugin_p=='5':
      plugin = 'XBMCtorrent'
    elif plugin_p=='6':
      plugin = 'KODIPOPCORN'
    elif plugin_p=='7':
      plugin = 'Victory'
    elif plugin_p=='8':
      plugin = 'Acestream'
    elif plugin_p=='9':
            list_players = ['Quasar', 'Pulsar', 'KmediaTorrent', 'Torrenter', 'YATP', 'XBMCtorrent','KODIPOPCORN','Victory','Acestream']
        
            selection = xbmcgui.Dialog().select("Torrent Player", list_players)
            if selection == -1:
                return

            plugin = list_players[selection]
  

    filename = (url)
   
    uri_string = quote_plus(filename)
   
    if plugin == "Acestream":
        link = 'http://127.0.0.1:6878/ace/getstream?infohash=%s&hlc=1&transcode=0&transcode_mp3=0&transcode_ac3=0&preferred_audio_language=eng'%infohash[0]

        link='http://127.0.0.1:6878/ace/manifest.m3u8?infohash=%s&format=json&use_api_events=1&use_stop_notifications=1'%infohash[0]
        try:
        
            req_pre=requests.get(link).json()
        except:
            xbmcgui.Dialog().ok('Acestream Error','אופסס שכחת להפעיל ACESTREAM , תפעיל אני מחכה פה...')
            return ''
        size=0
        f_size=0
        speed=0
        peers=0
        unit='b'
        status=''
        start_time=time.time()
   
     
        dp = xbmcgui.DialogProgress()
        dp.create("מתחיל ניגון", "אנא המתן", '')
        xbmc.sleep(100)
        check=True
        if req_pre['response']==None:
            
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('Acestream Error', 'Acestream נכשל בחר נגן אחר'.encode('utf-8'))))
            list_players = ['Quasar', 'Pulsar', 'KmediaTorrent', 'Torrenter', 'YATP', 'XBMCtorrent','KODIPOPCORN','Victory']
        
            selection = xbmcgui.Dialog().select("Torrent Player", list_players)
            if selection == -1:
                return

            plugin = list_players[selection]
            check=False
        if check:
            if 'stat_url' in req_pre['response']:
                stat_link=req_pre['response']['stat_url']
            else:
                xbmc.sleep(300)
                stat_link=req_pre['response']['stat_url']
            req=requests.get(stat_link).json()
            
            while size<(1*1024*1024) or status!='dl':
                if len(req)>0:
                    
                    if 'downloaded' in req['response']:
                        size=req['response']['downloaded']
                        if size>1024:
                            f_size=size/1024
                            unit='Kb'
                        if size>(1024*1024):
                            f_size=size/(1024*1024)
                            unit='Mb'
                        if size>(1024*1024*1024):
                            f_size=size/(1024*1024*1024)
                            unit='Gb'
                    if 'peers' in req['response']:
                        peers=req['response']['peers']
                    if 'speed_down' in req['response']:
                        speed=req['response']['speed_down']
                    if 'status' in req['response']:
                        status=req['response']['status']
                    elapsed_time = time.time() - start_time
                    dp.update(0, ' אנא המתן '+status+' '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'P-%s %sKb/s'%(str(peers),str(speed)), 'Size '+str(f_size)+unit)
                    
                    xbmc.sleep(1000)
                    req=requests.get(stat_link).json()
                if dp.iscanceled(): 
                    dp.close()
                    break
                
            dp.close()
            link=req_pre['response']['playback_url']
        #link = 'http://127.0.0.1:6878/ace/getstream?infohash=%s&hlc=1&transcode=0&transcode_mp3=0&transcode_ac3=0&preferred_audio_language=eng'%infohash[0]
    if plugin == 'Quasar':
        link = 'plugin://plugin.video.quasar/play?uri=%s' % uri_string

    elif plugin == 'Pulsar':
        link = 'plugin://plugin.video.pulsar/play?uri=%s' % uri_string

    elif plugin == 'KmediaTorrent':
        link = 'plugin://plugin.video.kmediatorrent/play/%s' % uri_string

    elif plugin == "Torrenter":
        link = 'plugin://plugin.video.torrenter/?action=playSTRM&url=' + uri_string

    elif plugin == "YATP":
        link = 'plugin://plugin.video.yatp/?action=play&torrent=' + uri_string
    elif plugin == "KODIPOPCORN":
        link='plugin://plugin.video.kodipopcorntime/?endpoint=player&amp;720psize=1331439862&amp;1080psize=2566242959&amp;720p='+uri_string+'&amp;mediaType=movies'
    elif plugin == "XBMCtorrent":
        link = 'plugin://plugin.video.xbmctorrent/play/%s' % uri_string
    
    else:
        link=url
    return link
def get_hebits(url):
    import shutil
    username = Addon.getSetting('username_hebits')
    password = Addon.getSetting('Password_sdr_hebits')
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
        'Accept': '*/*',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'Content-Type': 'application/x-www-form-urlencoded',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        
        'Cache-Control': 'no-cache',
    }

    data = {
      'username': username,
      'password': password
    }

    tk_cook = requests.post('https://hebits.net/takeloginAjax.php', headers=headers, data=data).cookies
    x=requests.get(url,headers=headers,cookies=tk_cook).content
    regex="title='title'><a href='(.+?)'"
    match=re.compile(regex).findall(x)

    new_url='https://hebits.net/'+match[0]
    tor_dataDir = os.path.join(xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8"),'torrent_temp')
    
    if not os.path.exists(tor_dataDir):
         os.makedirs(tor_dataDir)
    else:
        shutil.rmtree(tor_dataDir)
        os.makedirs(tor_dataDir)
    local_filename=os.path.join(tor_dataDir,'temp_tor.torrent')

    r = requests.get(new_url,headers=headers,cookies=tk_cook, stream=True)
    with open(local_filename, 'wb') as f:
        for chunk in r.iter_content(chunk_size=1024): 
            if chunk: # filter out keep-alive new chunks
                f.write(chunk)
    from torrentool.api import Torrent
    my_torrent = Torrent.from_file(local_filename)

    final_link=my_torrent.magnet_link
    for items in my_torrent.announce_urls[0]:
        final_link=final_link+'&tr='+urllib.quote_plus(items)
    final_link=final_link+'&private=1'

    return final_link
def get_hsi(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
        'Accept': '*/*',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'Content-Type': 'application/x-www-form-urlencoded',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        
        'Cache-Control': 'no-cache',
    }
    x=requests.get(url,headers=headers).content
    regex='IFRAME SRC="(.+?)"'
    m=re.compile(regex,re.IGNORECASE).findall(x)
    if len(m)>0:
        return m[0]
    else:
        xbmcgui.Dialog().ok('שגיאה','אין לינק לפרק זה סורי')
        return 'NOT OK'
def get_walla_link(url):
    itemId=url.split('=')[1]
    url="http://ws.walla.co.il/flvpl/?id=" + itemId +"&type=json&device=android"
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
        'Accept': '*/*',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'Content-Type': 'application/x-www-form-urlencoded',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        
        'Cache-Control': 'no-cache',
    }
    resultJSON=requests.get(url,headers=headers).json()
    item = resultJSON["items"]["item"]
    subtitlesUrl = None
    if resultJSON.has_key("subtitles") :
        
        subtitles = resultJSON["subtitles"]["subtitle"]
        firstitem = subtitles[0]
        print firstitem
        subtitlesUrl = firstitem["src"]
        
        print "subtitleUrl=" + subtitlesUrl
        
    videoUrl = resultJSON.get("video_src_tv", "")
    if videoUrl == "":
        videoUrl = resultJSON["video_src_ipad"]
    return subtitlesUrl,videoUrl
def get_nan(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
        'Accept': '*/*',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'Content-Type': 'application/x-www-form-urlencoded',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        
        'Cache-Control': 'no-cache',
    }
    
    result=requests.get(url,headers=headers).content
    regex='"VideoIframe".+?src="(.+?)"'
    m=re.compile(regex).findall(result)[0]
    x=requests.get('http://docu.nana10.co.il/'+m,headers=headers).content
    
    regex='UserID=(.+?);'
    userid=re.compile(regex).findall(x)[0]
    regex='"MediaStockVideoItemGroupID","(.+?)"'
    VideoID=re.compile(regex).findall(x)[0]
    url='http://vod.ch10.cloudvideoplatform.com/api/getlink/getflash?userid=%s&showid=%s'%(userid,VideoID)
    y=requests.get(url,headers=headers).json()
    m_lk=y[0]['MediaFile'].split('.')[0]+y[0]['Bitrates']+'.'+y[0]['MediaFile'].split('.')[1]
    f_url=y[0]['ProtocolType']+y[0]['ServerAddress']+y[0]['MediaRoot']+m_lk+y[0]['StreamingType']+y[0]['Params']

    return f_url

def get_kan(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }
    text = requests.get(url,headers=headers).content
    if 'ByPlayer' in url:
        match = re.compile('bynetURL:\s*"(.*?)"').findall(text)
        link = match[0].replace('https', 'http').replace('\u0026', '&')
    elif len(re.compile('media\.(ma)?kan\.org\.il').findall(url)) > 0:
        match = re.compile('hls:\s*?"(.*?)"').findall(text)
        link = match[0]
    else:
        match = re.compile("var\s*metadataURL\s*?=\s*?'(.+?)'").findall(text)
        text = common.OpenURL(match[0].replace('https_streaming=true', 'https_streaming=false'), headers=headers)
        match = re.compile("<SmilURL.*>(.+)</SmilURL>").findall(text)
        smil = match[0].replace('amp;', '')
        match = re.compile("<Server priority=['\"]1['\"]>(.+)</Server>").findall(text)
        server = match[0]
        link = urlparse.urlunparse(urlparse.urlparse(smil)._replace(netloc=server))
    
    return '{0}|User-Agent={1}'.format(link, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36')

def Check_Playback(ignore_dp=False,timeout=10):
    """
This function will return true or false based on video playback. Simply start a stream
(whether via an add-on, direct link to URL or local storage doesn't matter), the code will
then work out if playback is successful. This uses a number of checks and should take into
account all potential glitches which can occur during playback. The return should happen
within a second or two of playback being successful (or not).

CODE: Check_Playback()

AVAILABLE PARAMS:

    ignore_dp  -  By default this is set to True but if set to False
    this will ignore the DialogProgress window. If you use a DP while
    waiting for the stream to start then you'll want to set this True.
    Please bare in mind the reason this check is in place and enabled
    by default is because some streams do bring up a DialogProgress
    when initiated (such as f4m proxy links) and disabling this check
    in those circumstances can cause false positives.

    timeout  -  This is the amount of time you want to allow for playback
    to start before sending back a response of False. Please note if
    ignore_dp is set to True then it will also add a potential 10s extra
    to this amount if a DialogProgress window is open. The default setting
    for this is 10s.

EXAMPLE CODE:
xbmc.Player().play('http://totalrevolution.tv/videos/python_koding/Browse_To_Folder.mov')
isplaying = koding.Check_Playback()
if isplaying:
    dialog.ok('PLAYBACK SUCCESSFUL','Congratulations, playback was successful')
    xbmc.Player().stop()
else:
    dialog.ok('PLAYBACK FAILED','Sorry, playback failed :(')
~"""
    if not ignore_dp:
        isdialog = True
        counter = 1

# Check if the progress window is active and wait for playback
        while isdialog and counter < 60:
            if xbmc.getCondVisibility('Window.IsActive(progressdialog)'):
                try:
                    if dp.iscanceled():
                        dp.close()
                        break
                except:
                    pass
            xbmc.log('### Current Window: %s' % xbmc.getInfoLabel('System.CurrentWindow'))
            xbmc.log('### Current XML: %s' % xbmc.getInfoLabel('Window.Property(xmlfile)'))
            xbmc.log('### Progress Dialog active, sleeping for %s seconds' % counter)
            xbmc.sleep(1000)
            if xbmc.getCondVisibility('Window.IsActive(progressdialog)') or (xbmc.getInfoLabel('Window.Property(xmlfile)') == 'DialogProgress.xml'):
                isdialog = True
            else:
                isdialog = False
            counter += 1
            xbmc.log('counter: %s' % counter)

# Given the DialogProgress 10 seconds to finish and it's still up - time to close it
            if counter >= 10:
                try:
                    xbmc.log('attempting to send click to close dp')
                    xbmc.executebuiltin('SendClick()')
                    if dp.iscanceled():
                        dp.close()
                    try:
                        dp.close()
                    except:
                        pass
                except:
                    xbmc.log('### FAILED TO CLOSE DP')
    try:
        dp.close()
    except:
        pass

    isplaying = xbmc.Player().isPlaying()
    counter   = 1
    if xbmc.Player().isPlayingAudio():
        return True
# If xbmc player is not yet active give it some time to initialise
    while not isplaying and counter < timeout:
        xbmc.sleep(1000)
        isplaying = xbmc.Player().isPlaying()
        xbmc.log('### XBMC Player not yet active, sleeping for %s seconds' % counter)
        counter += 1

    success = 0
    counter = 0

# If it's playing give it time to physically start streaming then attempt to pull some info
    if isplaying:
        xbmc.sleep(1000)
        while not success and counter < 5:
            try:
                if xbmc.Player().isPlayingVideo():
                    infotag = xbmc.Player().getVideoInfoTag()
                vidtime = xbmc.Player().getTime()
                if vidtime > 0:
                    success = 1

# If playback doesn't start automatically (buffering) we force it to play
                else:
                    xbmc.log('### Playback active but time at zero, trying to unpause')
                    xbmc.executebuiltin('PlayerControl(Play)')
                    xbmc.sleep(2000)
                    vidtime = xbmc.Player().getTime()
                    if vidtime > 0:
                        success = 1

# If no infotag or time could be pulled then we assume playback failed, try and stop the xbmc.player
            except:
                counter += 1
                xbmc.sleep(1000)

# Check if the busy dialog is still active from previous locked up playback attempt
    isbusy  = xbmc.getCondVisibility('Window.IsActive(busydialog)')
    counter   = 1
    while isbusy:
        xbmc.log('### Busy dialog active, sleeping for %ss' % counter)
        xbmc.sleep(1000)
        isbusy  = xbmc.getCondVisibility('Window.IsActive(busydialog)')
        counter += 1
        if counter >= 5:
            xbmc.executebuiltin('Dialog.Close(busydialog)')

    if not success:
        xbmc.executebuiltin('PlayerControl(Stop)')
        xbmc.log('### Failed playback, stopped stream')
        return False
    else:
        return True
def get_nex_ep( time_to_save, original_title,year,season,episode,id,eng_name,show_original_year,heb_name,isr,st,fav,prev_name,url,iconimage,fanart,o_plot):
    
    global done1,done_c_get
    count=0
    while done1!=1 and done_c_get==1:
        count+=1
        xbmc.sleep(600)
        if count>100:
            break
    
    try:
        logging.warning('NEXT EP SOURCES:'+episode+'-'+str(done1)+'-'+str(done_c_get))


     
             
       
         
      
        da=[]
        stop_window=False
        da.append((original_title,year,original_title,season,episode,id,eng_name,show_original_year,heb_name,isr,st,fav))
        
        logging.warning('in play search')
        logging.warning(da)
    
        match_a,a,b,f_subs,current_subs= cache.get(c_get_sources, time_to_save, original_title,year,original_title,season,episode,id,eng_name,show_original_year,heb_name,isr,st,fav,'no','0',table='pages')
        #if fav_status=='true':
        #    match_a,a,b,f_subs= cache.get(c_get_sources, time_to_save, original_title,year,original_title,season,episode,id,eng_name,show_original_year,heb_name,isr,st,'rest','no','0',table='pages')
        #logging.warning(match_a)
        
        logging.warning('DONE NEXT EP SEARCHING:'+fav)
    
    except Exception as e:
        import linecache
        exc_type, exc_obj, tb = sys.exc_info()
        f = tb.tb_frame
        lineno = tb.tb_lineno
        filename = f.f_code.co_filename
        linecache.checkcache(filename)
        line = linecache.getline(filename, lineno, f.f_globals)
        xbmc.executebuiltin((u'Notification(%s,%s)' % ('מקור', str(e))).encode('utf-8'))
        logging.warning('ERROR IN NEXTUP:'+str(lineno))
        logging.warning('inline:'+line)
        logging.warning(e)
        logging.warning('BAD NEXT EP SEARCHING')
        
        #match_a,a,b,f_subs= cache.get(c_get_sources, time_to_save, original_title,year,original_title,season,episode,id,eng_name,show_original_year,heb_name,isr,st,fav,'no','0',table='pages')
  
       

def decode_watch(x):
    regex='<script>var.+?\[(.+?)</script'
    m1=re.compile(regex,re.DOTALL).findall(x.content)[0]
    
    regex='"(.+?)"'
    m2=re.compile(regex,re.DOTALL).findall(m1)
    f_str=''
    reg='atob.+? - (.+?)\)'
    ma=re.compile(reg).findall(m1)[0]
   
    for items in m2:
       
        a=items.decode('base64')
        b=re.sub("\D", "", a)
        
        f_str=f_str+chr(int(b)-int(ma))
    regex='src="(.+?)"'
    m3=re.compile(regex).findall(f_str)[0]
    return m3
def reolve_watchcartoononline(url):
    
    
    
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:66.0) Gecko/20100101 Firefox/66.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
    #'Referer': 'https://www.watchcartoononline.io/101-dalmatians-ii-patchs-london-adventure',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    'TE': 'Trailers',
    }

    x = requests.get(url,headers=headers)
    code=decode_watch(x)
    logging.warning('code:'+code)
    cookies={}
    for key, morsel in x.cookies.items():
            cookies[key] = morsel
   
    headers['Referer']=url
    cookies[ 'bbl']= '2'
    cookies[ 'BB_plg']= 'pm'

    response = requests.get('https://www.watchcartoononline.io'+code, headers=headers,cookies=cookies)
    logging.warning(response.cookies)
    regex='get\("(.+?)"'
    m=re.compile(regex).findall(response.content)[0]
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:67.0) Gecko/20100101 Firefox/67.0',
        'Accept': '*/*',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'Referer': 'https://www.watchcartoononline.io'+code,
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'TE': 'Trailers',
    }
    response = requests.get('https://www.watchcartoononline.io'+m, headers=headers,cookies=cookies).json()
    
    f_link=response['cdn']+'/getvid?evid='+response['enc']

    

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:67.0) Gecko/20100101 Firefox/67.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }
    

    
    ff_link_head=requests.head(f_link,stream=True).headers
    if 'Location' in ff_link_head:
        ff_link=ff_link_head['Location']
    else:
        ff_link=f_link
    #ff_link=f_link#requests.get(f_link,headers=headers,stream=True).url
    logging.warning(ff_link)
    
    head=urllib.urlencode(headers)
    ff_link=ff_link+"|"+head


    #ok=xbmc.Player().play(ff_link)
    
    return ff_link
def unpad(padded_data, block_size, style='pkcs7'):
    pdata_len = len(padded_data)
    if style in ('pkcs7', 'x923'):
        padding_len = ord(padded_data[-1])
        if padding_len < 1 or padding_len > min(block_size, pdata_len):
            #raise ValueError("Padding is incorrect.")
            return "Padding is incorrect."
        if style == 'pkcs7':
            if padded_data[-padding_len:] != chr(padding_len)*padding_len:
                #raise ValueError("PKCS#7 padding is incorrect.")
                return "PKCS#7 padding is incorrect."
        else:
            if padded_data[-padding_len:-1] != chr(0)*(padding_len-1):
                #raise ValueError("ANSI X.923 padding is incorrect.")
                return "ANSI X.923 padding is incorrect."
    elif style == 'iso7816':
        padding_len = pdata_len - padded_data.rfind(chr(128))
        if padding_len < 1 or padding_len > min(block_size, pdata_len):
            #raise ValueError("Padding is incorrect.")
            return "Padding is incorrect."
        if padding_len > 1 and padded_data[1-padding_len:] != chr(0)*(padding_len-1):
            #raise ValueError("ISO 7816-4 padding is incorrect.")
            return "ISO 7816-4 padding is incorrect."
    else:
        #raise ValueError("Unknown padding style")
        return "Unknown padding style"
    return padded_data[:-padding_len]
def decode_tvtap(url):
    player_user_agent = "mediaPlayerhttp/2.1 (Linux;Android 5.1) ExoPlayerLib/2.6.1"
    ch_id=url.split('$$$$')[1]
    key = b"19087321"
    from pyDes import des, PAD_PKCS5
    from base64 import b64decode, urlsafe_b64encode
    user_agent = "Dalvik/2.1.0 (Linux; U; Android 5.1.1; AFTS Build/LVY48F)"
    token_url = "http://tvtap.net/tvtap1/index_tvtappro.php?case=get_channel_link_with_token_tvtap_updated"
    list_url = "http://tvtap.net/tvtap1/index_new.php?case=get_all_channels"
    r = requests.post(list_url, headers={"app-token": "9120163167c05aed85f30bf88495bd89"}, data={"username": "603803577"}, timeout=15)
    ch = r.json()
    for c in ch["msg"]["channels"]:
        if c["pk_id"] == ch_id:
            selected_channel = c
            break

    title = selected_channel.get("channel_name")
    image = "http://tvtap.net/tvtap1/{0}|User-Agent={1}".format(quote(c.get("img"), "/"), quote(user_agent))

    logging.warning(selected_channel)
    r = requests.post(token_url, headers={"app-token": "9120163167c05aed85f30bf88495bd89"}, data={"channel_id": ch_id, "username": "603803577"}, timeout=15)
    
    links = []
    for stream in r.json()["msg"]["channel"][0].keys():
        if "stream" in stream or "chrome_cast" in stream:
            d = des(b"98221122")
            link = d.decrypt(b64decode(r.json()["msg"]["channel"][0][stream]))
            if "dummytext" not in  link and len(link)>0:
                logging.warning(link)
                link = unpad(link, 8).decode("utf-8")
                
                if link:
                    
                    
                    if not link == "dummytext" and link not in links:
                        if link.startswith("http"):
                            links.append(link)

    
    
    link = links[0]

    if link.startswith("http"):
        media_url = "{0}|User-Agent={1}".format(link, urllib.quote('mediaPlayerhttp/1.9 (Linux;Android 5.1) ExoPlayerLib/2.6.1'))
    else:
        media_url = link
    return media_url
def resolve_zoogle(url,name,data,imge,description):
    global list_index
    if data!='0':
        year=data
        url2='http://api.themoviedb.org/3/search/movie?api_key=34142515d9d23817496eeb4ff1d223d0&query=%s&year=%s&language=he&append_to_response=origin_country&page=1'%(eng_name,year)
    else:
        url2='http://api.themoviedb.org/3/search/movie?api_key=34142515d9d23817496eeb4ff1d223d0&query=%s&language=he&append_to_response=origin_country&page=1'%(eng_name)
    logging.warning(url2)
    y=requests.get(url2).json()
    try:
        id=y['results'][0]['id']
    except:
        id=''
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:67.0) Gecko/20100101 Firefox/67.0',
        'Accept': '*/*',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
       
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'TE': 'Trailers',
    }
    
    x=requests.get(url+'?s=ns&v=t&sd=d',headers=headers).content
    regex='Quality:(.+?)</a></li></ul>'
    m=re.compile(regex,re.DOTALL).findall(x)
    all_nam=[]
    all_u=[]
    all_num_t=[]
    for items in m:
        regex='<a href="(.+?)">(.+?)\&nbsp;<span class="smaller text-muted3">(.+?)<'
        m2=re.compile(regex).findall(items)
        for ur,nam,num in m2:
            all_nam.append(nam)
            all_u.append(ur)
            all_num_t.append(nam+'('+num+')')
    all_nam=list(reversed(all_nam))
    all_u=list(reversed(all_u))
    all_num_t=list(reversed(all_num_t))
    list2=[]
    all_links=[]
    ret = xbmcgui.Dialog().select("בחר איכות", all_num_t)
    if ret!=-1:
        url2=all_u[ret]
        
        logging.warning(url+url2)
        y=requests.get(url+url2,headers=headers).content
        regex_p='<tr>(.+?)</tr>'
        m3=re.compile(regex_p,re.DOTALL).findall(y)
        for items2 in m3:
            
            regex_p='href="(.+?)">(.+?)<.+?div class="progress-bar prog-blue prog-l" style=".+?">(.+?)<.+?"progress-bar smaller prog-green prog-l"style=".+?">(.+?)<.+?progress-bar smaller prog-yellow prog-r"style=".+?">(.+?)<'
            m4=re.compile(regex_p,re.DOTALL).findall(items2)
            logging.warning('m4:'+str(len(m4)))
            for ur2,name2,size,seed,peers in m4:
                txt='[COLOR deepskyblue]'+name2.replace('-',' ').replace('%20',' ').strip().decode('utf-8','ignore')+'[/COLOR]\nServer: Magnet'+' Subs: '+'  Quality:[COLOR gold] ◄'+all_nam[ret]+'► [/COLOR]Provider: [COLOR lightblue]'+'S %s,P %s'%(seed,peers)+'[/COLOR] Size:[COLOR coral]'+size+'[/COLOR]$$$$$$$'+ur2.decode('utf-8','ignore')
               
                
                list2.append(txt)
                all_links.append(ur2)
        window = sources_window(name ,list2,'0',imge,description)
        window.doModal()

        del window
        logging.warning('https://zooqle.com'+all_links[list_index])
        z=requests.get('https://zooqle.com'+all_links[list_index],headers=headers).content
        regex='href="magnet(.+?)"'
        f_link='magnet'+re.compile(regex).findall(z)[0]
        return f_link,str(id)
    else:
        sys.exit()
def resolve_sratim(url,eng_name,name):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:67.0) Gecko/20100101 Firefox/67.0',
        'Accept': '*/*',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
       
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'TE': 'Trailers',
    }
    logging.warning(url)
    x=requests.get(url,headers=headers).content
    eng_name=eng_name.replace('\n','')
    if eng_name==' ' or eng_name=='%20':
        eng_name=name.replace('\n','')
    regex='<li><span title=".+?">(.+?)<'
    y=re.compile(regex).findall(x)
    if len(y)>0:
        year=y[0]
        url2='http://api.themoviedb.org/3/search/movie?api_key=34142515d9d23817496eeb4ff1d223d0&query=%s&year=%s&language=he&append_to_response=origin_country&page=1'%(eng_name,year)
    else:
        url2='http://api.themoviedb.org/3/search/movie?api_key=34142515d9d23817496eeb4ff1d223d0&query=%s&language=he&append_to_response=origin_country&page=1'%(eng_name)
    logging.warning(url2)
    y=requests.get(url2).json()
    try:
        id=y['results'][0]['id']
    except:
        id=''
    link=re.compile('<video id="wp_mep_.+? src="(.+?)"').findall(x)[0]
    return link,str(id)
def googledrive_download(id):
    #download('http://mirrors.kodi.tv/addons/jarvis/script.module.requests/script.module.requests-2.9.1.zip','script.module.requests')
    #dis_or_enable_addon('script.module.requests','auto')
    #import requests,time
    keys=[]
    #id_pre=id.split('=')
    #id=id_pre[len(id_pre)-1]
    
    def get_confirm_token(response):
        
        for cookie in response:
            logging.warning('cookie.name')
            logging.warning(cookie.name)
            backup_cookie= cookie.value
            if 'download_warning' in cookie.name:
                logging.warning(cookie.value)
                logging.warning('cookie.value')
                return cookie.value
            return backup_cookie

        return None

    
    URL = "https://docs.google.com/uc?export=download"

    #session = requests.Session()

    #response = session.get(URL, params = { 'id' : id }, stream = True)
    import urllib2
    import cookielib

    from cookielib import CookieJar

    cj = CookieJar()
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
    # input-type values from the html form
    formdata =  { 'id' : id }
    data_encoded = urllib.urlencode(formdata)
    logging.warning(URL+'&'+ data_encoded)
    response = opener.open(URL+'&'+ data_encoded)
    content = response.read()
    cookies={}
    cook=[]
    
    for cookie in cj:
         cook.append(cookie.name+'='+cookie.value)
         cookies[cookie.name]=cookie.value
         logging.warning( cookie)
    token = get_confirm_token(cj)
    logging.warning(token)
    if token:
        params = { 'id' : id, 'confirm' : token }
        headers = {'Access-Control-Allow-Headers': 'Content-Length','Cookie':';'.join(cook)}
        
        data_encoded = urllib.urlencode(params)
        return (URL+'&'+ data_encoded+"|"+ urllib.urlencode(headers))
        #response = opener.open(URL+'&'+ data_encoded)
        #chunk_read(response, report_hook=chunk_report,dp=dp,destination=destination,filesize=filesize)
        

    #save_response_content(response, destination)
    return(keys)
def get_refl(eng_name,url,year):
    nm=eng_name
    if 'movie' in url:
        url2='http://api.themoviedb.org/3/search/movie?api_key=34142515d9d23817496eeb4ff1d223d0&query=%s&year=%s&language=he&page=1'%(eng_name,year)
        x=requests.get(url2).json()
        
        id=''
        try:
            id=x['results'][0]['id']
            nm=x['results'][0]['title']
            logging.warning('id:'+str(id))
        except:
           pass
        url2='http://redflixtv.me/api/get_single_details?api_secret_key=ssgx54x49bkv2xk7mkghksfz&&type=movie&id='+url.replace('redflixtv.me/movie/','')
        headers={
            'Connection': 'Keep-Alive',

            'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 6.0.1; LS)'}
        html=requests.get(url2,headers=headers).json()
        all_n=[]
        all_l=[]
        for items in html['videos']:
            all_n.append(items['label'])
            all_l.append(items['file_url'])
        if len(all_l)==1:
            return all_l[0],str(id),nm
        ret = xbmcgui.Dialog().select("בחר", all_n)
        if ret!=-1:
        
        
            return all_l[ret],str(id),nm
    else:
        url2='http://api.themoviedb.org/3/search/tv?api_key=34142515d9d23817496eeb4ff1d223d0&query=%s&year=%s&language=he&page=1'%(eng_name,year)
        
        x=requests.get(url2).json()
        logging.warning(x)
        
        id=''
        try:
            id=x['results'][0]['id']
            nm=x['results'][0]['name']
            logging.warning('id:'+str(id))
        except:
           pass
        return url.replace('redflixtv.me/tv/',''),str(id),nm
def check_last_ep(season,episode,name,url,icon,image,plot,original_title,id,eng_name,show_original_year,heb_name,isr):
        year=show_original_year
        if season!=None and season!="%20":
            tv_movie='tv'
        else:
            tv_movie='movie'
        dbcur.execute("SELECT * FROM AllData WHERE original_title = '%s' and type='%s' and season='%s' and episode='%s'"%(original_title.replace("'","%27"),tv_movie,season,episode))

        match = dbcur.fetchone()
        if match==None:
          
          dbcur.execute("INSERT INTO AllData Values ('%s', '%s', '%s', '%s','%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s','%s','%s','%s');" %  (name.replace("'","%27"),url,icon,image,plot.replace("'","%27"),year,original_title.replace("'","%27"),season,episode,id,eng_name.replace("'","%27"),show_original_year,heb_name.replace("'","%27"),isr,tv_movie))
          dbcon.commit()
          
        dbcur.execute("SELECT * FROM Lastepisode WHERE original_title = '%s' and type='%s'"%(original_title.replace("'","%27"),tv_movie))

        match = dbcur.fetchone()
        if match==None:
          
          dbcur.execute("INSERT INTO Lastepisode Values ('%s', '%s', '%s', '%s','%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s','%s','%s','%s');" %  (name.replace("'","%27"),url,icon,image,plot.replace("'","%27"),year,original_title.replace("'","%27"),season,episode,id,eng_name.replace("'","%27"),show_original_year,heb_name.replace("'","%27"),isr,tv_movie))
          dbcon.commit()
         
        else:
          dbcur.execute("SELECT * FROM Lastepisode WHERE original_title = '%s' and type='%s' and season='%s' and episode='%s'"%(original_title.replace("'","%27"),tv_movie,season,episode))

          match = dbcur.fetchone()
         
          if match==None:
            dbcur.execute("UPDATE Lastepisode SET season='%s',episode='%s',image='%s',heb_name='%s' WHERE original_title = '%s' and type='%s'"%(season,episode,image,heb_name.replace("'","%27"),original_title.replace("'","%27"),tv_movie))
            dbcon.commit()
        return 'Done'
def get_wow(url):
    
    cook=json.loads(url.split('$$$$')[1].decode('base64'))
    url=url.split('$$$$')[0]
    headers={
            'Connection': 'keep-alive',

            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Origin': 'null',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'crow/2.3',
            'content-type': 'application/x-www-form-urlencoded',
            'Accept-Encoding': 'utf-8',
            'Accept-Language': 'en-US',
            'X-Requested-With': 'com.wowsports3'}
    url='https://flysohigh.xyz/data_4w/data_3w/'+url.split('%%%')[1]
    data={'token':'dbca79a3fda0b34f6a97898456c1cd10'}
    tk=get_token()
    
    x=requests.get(url+'&token='+tk,headers=cook[1],cookies=cook[0])
    #logging.warning(x)
    if '#EXTM3U' in x.content:
        logging.warning(x.url)
    
        new_ur=x.url
        return new_ur
    x=x.content
    if "new Date('" in x:
        regex=re.compile("new Date\('(.+?)'")
        nn=re.compile(regex).findall(x)
        xbmcgui.Dialog().ok('Not Yet',"Starts at:"+nn[0])
        sys.exit()
    regex="<a class='btn btn-success btn-block justify-content-center align-items-center align-content-center visible' role='button'.+?href=(.+?)>(.+?)</a>"
    mm=re.compile(regex,re.DOTALL).findall(x)
    all_lk=[]
    all_nm=[]
    for lk,nm in mm:
        all_lk.append(lk)
        all_nm.append(nm)
    ret = xbmcgui.Dialog().select("Choose", all_nm)
    if ret!=-1:
     
        ff_link=all_lk[ret]
        url='https://flysohigh.xyz/data_4w/data_3w/'+ff_link
        x=requests.get(url,headers=cook[1],data=urllib.urlencode(data),cookies=cook[0]).url
       
        headers={'User-Agent': '/5.3 (Linux;Android 6.0.1) ExoPlayerLib/2.9.5',
                #'Accept-Encoding': 'identity',

                'Connection': 'Keep-Alive'}
        head=urllib.urlencode(headers)
        
        x=x+"|"+head
        return x
    else:
        sys.exit()
def get_google_subs(url):
    from xmlsub import xml2srt
    headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
            'Accept': 'video/webm,video/ogg,video/*;q=0.9,application/ogg;q=0.7,audio/*;q=0.6,*/*;q=0.5',
            'Accept-Language': 'en-US,en;q=0.5',
           
            'Connection': 'keep-alive',
            
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
        }
    
    x=requests.get(url.strip(),headers=headers).content
    
    regex='"ttsurl","(.+?)"'
    m=re.compile(regex).findall(x)
    if len(m)==0:
        return False
        
    url=m[0].decode('unicode_escape')+'&ts=%s&type=track&lang=iw&format=1&kind='%(str(time.time()*100))
    
    x=requests.get(url,headers=headers).content
    if len(x)<10:
        url=m[0].decode('unicode_escape')+'&ts=%s&type=track&lang=en&format=1&kind='%(str(time.time()*100))
    
        x=requests.get(url,headers=headers).content
    xml2srt(x,os.path.join(user_dataDir, 'sub.srt'))

    return os.path.join(user_dataDir, 'sub.srt')
def jump_seek(set_runtime):
    global break_jump
    logging.warning('Waiting for jump')
    logging.warning(xbmc.Player().isPlaying())
    timeout=0
    break_jump=1
    
    
    while timeout<600:
        timeout+=1
        if break_jump==0:
            break
        try:
        
            vidtime = xbmc.Player().getTime()
        except:
            vidtime=0
            pass
        logging.warning('Waiting for Vid2:'+str(vidtime))
        if vidtime>0:
            logging.warning('set_runtime for Vid')
            logging.warning(set_runtime)
            if int(float(set_runtime))>0:
                logging.warning('Jump Now')
                xbmc.Player().seekTime(int(float(set_runtime)))
            break
        xbmc.sleep(100)
    logging.warning('Waiting for Vid3:'+str(xbmc.Player().isPlaying()))
def get_4kfox(url):
    x=requests.get(url,headers=base_header).content
    regex='id="download_video" url="(.+?)"'
    m=re.compile(regex,re.DOTALL).findall(x)
    return m[0].replace('&amp;','&')
def play(name,url,iconimage,fanart,description,data,season,episode,original_title,saved_name,heb_name,show_original_year,eng_name,isr,prev_name,id,auto_play=False,windows_play=False,auto_fast=False,nextup=False,f_auto_play=False,show_errors=True):
     global stop_auto_play,break_jump
     break_jump=0
     
     if 'www.youtube.com' in url and '$$$' not in url:
        from youtube_ext import get_youtube_link2
        url= get_youtube_link2(url)
        
     logging.warning('URL:'+url)
     if '[mosh]' in description or '[orn]' in description:
        oo_name=name+'101%'
     else:
        oo_name=name
     
    
     if 'TE' in url and '$$$' not in url and 'google' not in url:
     
            description=description+'TEME'+'\n_from_victory_'
            url=url.split('%%%')[0]
            
            regex='\[\[(.+?)\]\]'
            match2=re.compile(regex).findall(url)
            url=url.replace(match2[0],'').replace('[','').replace(']','')
            saved_name=name
            original_title=url[:len(url)/2] 
            season='%20'
     all_d=[]
     all_d.append((name,url,iconimage,fanart,description,data,season,episode,original_title,saved_name,heb_name,show_original_year,eng_name,isr,prev_name,id))
     logging.warning('all_d::')
     logging.warning(json.dumps(all_d))
     name=name.replace('Cached ','')                                
     nm=original_title
     logging.warning('name::'+name)
     logging.warning('url::'+url)
     sub=None
     if 'https://www.4kfox.com' in url:
        url=get_4kfox(url)
     if  'google' in url and '101%' in oo_name:
        logging.warning('Get Subs')
        sub=get_google_subs(url)
        logging.warning(sub)
   
      
    
     if 'wow_sport' in url:
        url=get_wow(url)
     if '-sdarot--KIDSSECTION-' in description:
        logging.warning('-sdarot--KIDSSECTION-')
        if len(episode)==1:
          episode_n="0"+episode
        else:
           episode_n=episode
        if len(season)==1:
          season_n="0"+season
        else:
          season_n=season
        impmodule = __import__('sdarot')
        thread=[]
        thread.append(Thread(impmodule.get_links,'tv',original_title,original_title,season_n,episode_n,season,str(int(episode)+1),show_original_year,id))
        thread[0].start()
     if 'redflixtv.me' in url:
        url,id,nm=get_refl(original_title,url,data)
        check_last_ep(season,episode,name,url,iconimage,fanart,description,original_title,id,eng_name,show_original_year,nm,isr)
     if not os.path.exists(os.path.join(user_dataDir, '4.1.0')):
        #check_updated()
        file = open(os.path.join(user_dataDir, '4.1.0'), 'w') 
         
        file.write(str('Done'))
        file.close()
     #logging.warning('Play url:'+url)
     
     skip_404=False
     heb_dub_ok=False

     if 'zooqle.com' in url and 'magnet:' not in url:
        url,id=resolve_zoogle(url,name,data,fanart,description)
     if 'itsmine.space' in url:
        heb_dub_ok=True
        url,id=resolve_sratim(url,eng_name,name)
     if 'watchcartoononline' in url or 'www.wcostream.com' in url:
        url=reolve_watchcartoononline(url)
        skip_404=True
     global silent_mode,list_index,playing_text,mag_start_time_new
     if 'tvtap' in url:
        url=decode_tvtap(url)
     if 'nbareplayhd.com' in url or 'nflhdreplay' in url:
        url=nba_solve(url)
     url=url.replace('https://www.rapidvideo.com/e/','https://www.rapidvideo.com/v/')
     url=url.replace('oload.download','openload.co')
     start_time=time.time()
     if Addon.getSetting("dp_play")=='true'  and windows_play==False:
     
         dp = xbmcgui.DialogProgress()
         dp.create("מתחיל ניגון", "אנא המתן", '')
         
         elapsed_time = time.time() - start_time
         dp.update(0, ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'מתחיל ניגון', '')
     elapsed_time = time.time() - start_time
     playing_text='מתחיל ניגון$$$$'+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
     o_name=name
     #logging.warning(url)
     try:
                        
            dbcur.execute("INSERT INTO historylinks Values ('%s','GOOD','')"%url.encode('base64'))
            dbcon.commit()
     except Exception as e:
        
        pass
     url=url.replace("'",'%27')
     if 'youtube' in url and 'embed/' in url:
        url=url.replace('embed/','watch?v=')
     subtitlesUrl = None
     wall_link=False
     if 'kanapi.' in url:
        url=get_kan(url)
     if "walla_item_id=" in url:
        subtitlesUrl,url=get_walla_link(url)
        wall_link=True
     if 'mako.co.il' in url:
        import mako
        url=mako.get_mako(url)
        wall_link=True
     if 'nana10.co.il' in url and 'f2h' not in url:
        url=get_nan(url)
        wall_link=True
     if 'hitarganti.' in url:
        url=get_hsi(url)
        if url=='NOT OK':
            return 0

     if 'hebits' in url and allow_debrid==False:
        url=get_hebits(url)
     #logging.warning(url)

     if 'Redirector' in url:
        url=requests.get(url,stream=True).url
     o_plot=description
     
     add_ace=''

     if url=='aceplay' or '/ace/getstream' in url:
        url=cache.get(refresh_ace,24,name, table='cookies')
        add_ace='__aceplay__'
        
     if 'play_fame' in description:
        url=get_fame(url)
        if url=='NOT OK':
            return 0
     if 'play_israli' in description:
        url=get_isrlink(name)
     if 'play_eli_s' in description:
        url=get_eli_link(url)

     if Addon.getSetting("dp_play")=='true'  and windows_play==False:
         elapsed_time = time.time() - start_time
         dp.update(0, ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'שומר לDB', '')
     elapsed_time = time.time() - start_time
     playing_text='שומר לDB$$$$'+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
     url=url.replace('vidcloud.co','vcstream.to')
     if url=='latest_movie':
        dbcur.execute("SELECT * FROM lastlinkmovie WHERE o_name='f_name'")

        match = dbcur.fetchone()
        if match!=None:
            f_name,name,url,iconimage,fanart,description,data,season,episode,original_title,saved_name,heb_name,show_original_year,eng_name,isr,prev_name,id=match
            
         
            if 'http' not  in url and 'plugin' not in url and 'magnet:' not in url:

                url=url.decode('base64')
     elif  url=='latest_tv':
        dbcur.execute("SELECT * FROM lastlinktv WHERE o_name='f_name'")

        match = dbcur.fetchone()
        if match!=None:
           
            f_name,name,url,iconimage,fanart,description,data,season,episode,original_title,saved_name,heb_name,show_original_year,eng_name,isr,prev_name,id=match
               
                  
            if 'http' not  in url and 'plugin' not in url and 'magnet:' not in url:
             
                url=url.decode('base64')
  
     if 'http' not in url   and 'TEME' not in description and 'TEME' not in url and 'magnet:' not in url and not os.path.exists(url) and 'ftp:' not in url and  '-sdarot-' not in o_plot and  '-Sdarot-' not in o_plot and 'plugin' not in url:
        
          url='http'+url
     url=url.strip().replace('\n','').replace('\t','').replace('\r','')
     all_f_name=[]
     if '$$$' in url:
       links=url.split('$$$')
       sour_pre=''
       sour=''
       all_s=[]
       for lk in links:
           f_name=''
           regex='\[\[(.+?)\]\]'
           match=re.compile(regex).findall(str(lk))
           if len(match)==0:
               if 'TEME' in lk:
                 fn=lk.split('%%%')[0]
                 f_name=lk.split('%%%')[1].split('_')[1]
                 regex='\[\[(.+?)\]\]'
                 match2=re.compile(regex).findall(fn)
                 ff_link=fn.replace(match2[0],'').replace('[','').replace(']','')
                 match=[('TE',f_name)]
               else:
                    regex='//(.+?)/'
                     
                    match_ser=re.compile(regex).findall(str(lk))
            
                    if len(match_ser)>0:
                         match=[]
                         match.append((sour,match_ser[0]))
                    else:
                        match=[]
                        match.append((sour,'Direct'))
           else:
                if 'TEME' in lk:
                 logging.warning(lk)
                 fn=lk.split('%%%')[0]
                 f_name=lk.split('%%%')[1].split('_')[1]
                 regex='\[\[(.+?)\]\]'
                 match2=re.compile(regex).findall(fn)
                 ff_link=fn.replace(match2[0],'').replace('[','').replace(']','')
                 match=[('TE',f_name)]
                 
                else:
                    regex='\[\[(.+?)\]\].+?//(.+?)/'
                    match=re.compile(regex).findall(str(lk))
                if len(match)==0:
                    if 'TEME' in lk:
                     fn=lk.split('%%%')[0]
                     f_name=lk.split('%%%')[1].split('_')[1]
                     regex='\[\[(.+?)\]\]'
                     match2=re.compile(regex).findall(fn)
                     ff_link=fn.replace(match2[0],'').replace('[','').replace(']','')
                     match=[('TE',f_name)]
                     
                    else:
                        regex='\[\[(.+?)\]\]'
                        sour=re.compile(regex).findall(str(lk))[0]
                        match=[]
                        match.append((sour,'Direct'))
           logging.warning(match)
           for sour,ty in match:
                all_f_name.append(f_name)
                sour=sour.replace('openload','vummo')
                ty=ty.replace('tv4kids','streamango').replace('.tk','.com')
                if 'sratim' in ty:
                    ty='str'
                all_s.append('[COLOR lightblue][B]'+sour+'[/B][/COLOR] - [COLOR yellow][I]'+ty.replace('letsupload','avlts')+'[/I][/COLOR]')
                
       #logging.warning(all_s)
       
       ret = xbmcgui.Dialog().select("בחר", all_s)
       if ret!=-1:
         #logging.warning(links)
         #logging.warning(ret)
         ff_link=links[ret]
         
         regex='\[\[(.+?)\]\]'
         match2=re.compile(regex).findall(links[ret])
         if len(match2)>0:
           if 'TE' in all_s[ret]:
            description=description+'TEME'
            
            ff_link=ff_link.split('%%%')[0]
            logging.warning('ff_link2:'+ff_link)
           if 'http' in ff_link or 'TE' in all_s[ret]:
            ff_link=ff_link.replace(match2[0],'').replace('[','').replace(']','')
           else:
            ff_link=ff_link.replace(match2[0],'')
         else:
            try:
                if 'http' in ff_link:
                    ff_link=ff_link.replace(match2[0],'').replace('[','').replace(']','')
                else:
                    ff_link=ff_link.replace(match2[0],'')
            except:
                pass
         logging.warning('ff_link:'+ff_link)
        
         if 'TE' in all_s[ret]:
            description=description+'TEME'+'\n_from_victory_'
            
            heb_name=all_f_name[ret]
            saved_name=all_f_name[ret]
            original_title=all_f_name[ret]
            season='%20'
            
         url=ff_link.strip()
       else:
         sys.exit()
     if 'tv4kids' in url:
        url=urllib.unquote_plus(url).replace('[[OS]]','')
        logging.warning('f_url:'+url.replace('[[OS]]','').decode('utf8'))
        headers = {
            'authority': 'tv4kids.tk',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'sec-fetch-site': 'none',
            'sec-fetch-mode': 'navigate',
            'accept-encoding': 'gzip, deflate, br',
            'accept-language': 'en-US,en;q=0.9',
            
        }

        response = requests.get(url, headers=headers,stream=True).url
        logging.warning(response)


        headers = {
            'authority': 'tv4kids.tk',
            'accept-encoding': 'identity;q=1, *;q=0',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36',
            'accept': '*/*',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-mode': 'no-cors',
            'referer':url.replace('[[OS]]',''),
            'accept-language': 'en-US,en;q=0.9',
           
        }
        
        head=urllib.urlencode(headers)
        url=url+"|"+head
        url=response
     regex='\[\[(.+?)\]\]'
     match=re.compile(regex).findall(str(url))
     ff_link=url
     
     #logging.warning(ff_link)
     if len(match)>0:
        for items in match:
           ff_link=ff_link.replace(items,'').replace('[','').replace(']','')
        url=ff_link.strip()
     url=url.replace('[[]]','')
     if '-KIDSSECTION-' not in o_plot :
             if season!=None and season!="%20":
               table_name='lastlinktv'
             else:
               table_name='lastlinkmovie'
             dbcur.execute("SELECT * FROM %s WHERE url='%s'"%(table_name,url))
             
             match = dbcur.fetchone()
             
             if match==None:
                test1=[]
                test1.append((table_name,name,url.encode('base64'),iconimage,fanart,description,data,season,episode,original_title,saved_name,heb_name,show_original_year,eng_name,isr,prev_name,id))
                
                try:
                    dbcur.execute("UPDATE %s SET name='%s',url='%s',iconimage='%s',fanart='%s',description='%s',data='%s',season='%s',episode='%s',original_title='%s',saved_name='%s',heb_name='%s',show_original_year='%s',eng_name='%s',isr='%s',prev_name='%s',id='%s' WHERE o_name = 'f_name'"%(table_name,name.replace("'","%27"),url.encode('base64'),iconimage,fanart,description.replace("'","%27"),str(data).replace("'","%27"),season,episode,original_title.replace("'","%27"),saved_name.replace("'","%27"),heb_name.replace("'","%27"),show_original_year,eng_name.replace("'","%27").replace("'","%27"),isr,prev_name.replace("'","%27"),id))
                    dbcon.commit()
                except:
                    pass
     tmdbKey = '653bb8af90162bd98fc7ee32bcbbfb3d'
     silent_mode=True

     year=data
     if len (saved_name)<3:
       saved_name=name
     if Addon.getSetting("dp_play")=='true'  and windows_play==False:
                    if dp.iscanceled(): 
                        
                        stop_auto_play=1
                        return 0
     if Addon.getSetting("dp_play")=='true'  and windows_play==False:
         elapsed_time = time.time() - start_time
         dp.update(0, ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'משיג מספר IMDB', '')
     elapsed_time = time.time() - start_time
     playing_text='משיג מספר IMDB$$$$'+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
     if season!=None and season!="%20":
       tv_movie='tv'
       url2='http://api.themoviedb.org/3/tv/%s?api_key=%s&language=he&append_to_response=external_ids'%(id,tmdbKey)
     else:
       tv_movie='movie'
       
       url2='http://api.themoviedb.org/3/movie/%s?api_key=%s&language=he&append_to_response=external_ids'%(id,tmdbKey)
     if 'tt' not in id:
         try:
            imdb_id=requests.get(url2,timeout=10).json()['external_ids']['imdb_id']
         except:
            imdb_id=" "
     else:
         imdb_id=id
         url3='https://api.themoviedb.org/3/find/%s?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&language=en-US&external_source=imdb_id'%imdb_id
         xx=requests.get(url3).json()

         if tv_movie=='tv':
            if len(xx['tv_results'])>0:
                id=str(xx['tv_results'][0]['id'])
         else:
            if len(xx['movie_results'])>0:
                id=str(xx['movie_results'][0]['id'])

         
     
     if 1:#try:
         
         

     
         
         video_data={}

         fixed_name=fix_name_origin(saved_name,original_title)
  
         if season!=None and season!="%20":
           video_data['TVshowtitle']=fixed_name.replace('%20',' ').replace('%3a',':').replace('%27',"'").replace('_',".")
           video_data['mediatype']='tvshow'
           
         else:
           video_data['mediatype']='movies'
         video_data['OriginalTitle']=original_title.replace('%20',' ').replace('%3a',':').replace('%27',"'").replace('_',".")
         if Addon.getSetting("check_subs_comp")=='true':
            video_data['title']=fixed_name.replace('%20',' ').replace('%3a',':').replace('%27',"'").replace('_',".")
         else:
            video_data['title']=heb_name
         video_data['poster']=fanart
         video_data['fanart']=fanart
         if add_ace!='':
           o_plot=o_plot+add_ace
         video_data['plot']=o_plot+'\n_from_victory_'
         video_data['icon']=iconimage
         video_data['year']=data
       
         
         video_data['season']=season
         video_data['episode']=episode
         video_data['imdb']=imdb_id
         video_data['code']=imdb_id
         no_subs='0'
         logging.warning('Oplot:'+o_plot)
         if '-HebDub-' in o_plot or '-KIDSSECTION-' in o_plot or wall_link or 'besttv1.cdn' in url or heb_dub_ok or sub:
             video_data[u'mpaa']=unicode('heb')
             no_subs='1'
             logging.warning('Oplot:No subs')
         
         video_data['imdbnumber']=imdb_id
         video_data['Writer']=id
         video_data['imdb_id']=imdb_id
         video_data['IMDBNumber']=imdb_id
         video_data['genre']=imdb_id
         #logging.warning(video_data)
         #sys.exit()
       
 

         
        
         
         
         from run import get_links
         c_head={'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0'}
         
         if "|" in url and 'willtv' not in url:
              import urlparse
              import mimetools
              from StringIO import StringIO
              headers_g2=url.split("|")[1]
              c_head = dict(x.split('=') for x in headers_g2.split('&'))
              
              link2=url.split("|")[0]

         else:
           link2=url
         if Addon.getSetting("dp_play")=='true'  and windows_play==False:
                    if dp.iscanceled(): 
                        
                        stop_auto_play=1
                        return 0
         if Addon.getSetting("dp_play")=='true'  and windows_play==False:
             elapsed_time = time.time() - start_time
             dp.update(0, ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'בודק קישורים', '')
         elapsed_time = time.time() - start_time
         playing_text='בודק קישורים$$$$'+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
         from run import isValid
         resolver_supporteds=cache.get(resolver_supported, 72, table='pages')
         url_host_pre=re.compile('//(.+?)/').findall(url)
         url_host='No'
         if len(url_host_pre)>0:
            url_host=url_host_pre[0]
            if '.' in url_host:
              
                url_host=url_host.split('.')[0]
         #logging.warning('url_host')
         #logging.warning(url_host)
         try:
             host = link.split('//')[1].replace('www.','')
             host = host.split('/')[0].lower()
         except:
                host='no'
         rd_domains=cache.get(get_rd_servers, 72, table='pages')
         if rd_domains==None:
            rd_domains=[]
         regex='-(.+?)-'
         dont_check=False
         try:
            mm=re.compile(regex).findall(o_plot)[0]
         except:
            dont_check=True
         if 'TEME' not in description and skip_404==False and not os.path.exists(link2) and not isValid(url) and host not in rd_domains and url_host not in resolver_supporteds and 'plugin' not in url and 'streamvid.co' not in url and 'failiem' not in url and 'omwplayer' not in url and 'magnet:' not in url and '__music__' not in o_plot and '__NBA__' not in o_plot and 'sratim-il.com' not in link2 and 'ftp://' not in link2 and '-rts-' not in o_plot and '-fp-' not in o_plot and '-sdarot-' not in o_plot and '-iwi-' not in o_plot and  '-Sdarot-' not in o_plot and '-KIDSSECTION-' not in o_plot and dont_check==False:
             logging.warning('Checking Links Now')
             try:
                 try_head = requests.head(link2,headers=c_head,timeout=15)
                 
                 check=(try_head.status_code)
               
             except Exception as e:
               try:
                     try_head = requests.head(link2.replace('https','http'),headers=c_head,timeout=15)
                    
                     check=(try_head.status_code)
                     
               except Exception as e:
                    check='403'
                    logging.warning(e)
               
          
             if 'solaris' in o_plot and '- Direct' in o_name:
              check='403'
             
             
             if str(check) =='400' or str(check) =='404' or str(check) =='401' or str(check) =='403':
                if 'http://127.0.0.1:6878/ace/getstream' in link2:
                    xbmcgui.Dialog().ok('Acestream Error','אופסס שכחת להפעיל ACESTREAM , תפעיל אני מחכה פה...')
                    return 0
  
                xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'מחדש לינק זמני'.encode('utf-8'))))
                
                regex='-(.+?)-'
                try:
                    match=re.compile(regex).findall(o_plot)[0]
                except:
                    return 'ok'
                    
                check=True
                try:
                    impmodule = __import__(match.replace('.py',''))
                except:
                    check=False
                if check:
                    if len(episode)==1:
                      episode_n="0"+episode
                    else:
                       episode_n=episode
                    if len(season)==1:
                      season_n="0"+season
                    else:
                      season_n=season
                    thread=[]
                    thread.append(Thread(impmodule.get_links,tv_movie,original_title,heb_name,season_n,episode_n,season,episode,show_original_year,id))
                  
                    thread[0].start()
                    start_time=time.time()
                    

                    if Addon.getSetting("dp_play")=='false'  and windows_play==False:
                        dp = xbmcgui.DialogProgress()
                        dp.create("מחדש קישורים", "אנא המתן", '')
                    elapsed_time = time.time() - start_time
                    playing_text='מחדש קישורים$$$$'+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
                    while thread[0].is_alive():
                        count_1080=0
                        count_720=0
                        count_480=0
                        count_rest=0
                        all_results=impmodule.global_var
                        for links_in in impmodule.global_var:
                             name1,links,server,res=links_in
                 
                             if '1080' in res:
                               count_1080+=1
                             elif '720' in res:
                               count_720+=1
                             elif '480' in res:
                               count_480+=1
                             else:
                               count_rest+=1
                        string_dp="1080: [COLOR khaki]%s[/COLOR] 720: [COLOR gold]%s[/COLOR] 480: [COLOR silver]%s[/COLOR] Rest: [COLOR burlywood]%s[/COLOR]"%(count_1080,count_720,count_480,count_rest)
                        elapsed_time = time.time() - start_time
                        if Addon.getSetting("dp_play")=='true'  and windows_play==False:
                            dp.update(0, ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'מחדש קישורים', string_dp)
                   
                
                        playing_text='מחדש קישורים$$$$'+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))+'\n'+string_dp
                        all_results=impmodule.global_var
                        if Addon.getSetting("dp_play")=='true'  and windows_play==False:
                          if  dp.iscanceled() or elapsed_time>30:
                       
                          
                            impmodule.stop_all=1
                            all_results=impmodule.global_var
                            if thread[0].is_alive():
                                 
                                 
                                 thread[0]._Thread__stop()
              
                            break
                    
                    if Addon.getSetting("dp_play")=='false' and windows_play==False:
                        dp.close()
                    all_names=[]
                    all_links=[]
                    all_q=[]
                    all_s=[]
                    all_c=[]
                    logging.warning('Checking done')
                    
                    
                    for name,link,server,quality in all_results:
                        all_names.append(name)
                        all_links.append(link)
                        all_q.append(quality)
                        all_s.append(server)
                        all_c.append(name+' - [COLOR yellow]' +quality+'[/COLOR] - '+server.replace('openload','vummo').replace('letsupload','avlts'))
                    if len(all_links)>0:
                        if Addon.getSetting("new_source_menu")=='true':
                            ret=0
                        else:
                            ret = xbmcgui.Dialog().select("בחר קישור משרת "+server, all_c)
                        if ret!=-1:
                            url=all_links[ret]
                            
                            fixed_name=fix_name_origin(all_names[ret],original_title)
                            if Addon.getSetting("check_subs_comp")=='true':
                                video_data['title']=fixed_name.replace('%20',' ').replace('%3a',':').replace('%27',"'").replace('_',".")
                            else:
                                video_data['title']=heb_name
                            
                            
                        else:
                          
                            return 0
                    else:
                       url=all_links[0]
                       
                       fixed_name=fix_name_origin(all_names[0],original_title)
                       if Addon.getSetting("check_subs_comp")=='true':
                            video_data['title']=fixed_name.replace('%20',' ').replace('%3a',':').replace('%27',"'").replace('_',".")
                       else:
                            video_data['title']=heb_name
                       
         
         link='error'
         was_error=0
         elapsed_time = time.time() - start_time
         if Addon.getSetting("dp_play")=='true'  and windows_play==False:
                    if dp.iscanceled(): 
                        
                        stop_auto_play=1
                        return 0
         if Addon.getSetting("dp_play")=='true'  and windows_play==False:
            
            dp.update(0, ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'משיג לינק ניגון', '')
         playing_text='משיג לינק ניגון$$$$'+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
         if ('magnet' in url or 'limetorrents' in url or '1337x.to' in url or 'ibit.to' in url or 'torrentdownloads.me' in url or 'torrentquest.com' in url or 'eztv.io' in url or 'movcr.to' in url) and not allow_debrid:
            link='OK'
            get_torrent_file(silent_mode=True)
            
         else :
               #link=get_links(url)
               if windows_play and auto_fast:
                  link=get_links(url)
               else:
                   try:
                     
                     if 'TEME' in description:
                        link=url
                     else:
                        link=get_links(url)
                     
                   except Exception as e:
                        import linecache
                        exc_type, exc_obj, tb = sys.exc_info()
                        f = tb.tb_frame
                        lineno = tb.tb_lineno
                        filename = f.f_code.co_filename
                        linecache.checkcache(filename)
                        line = linecache.getline(filename, lineno, f.f_globals)
                        
                        pass
           
         if 1:
             
           
             
             if link=='error' and was_error==0 :
                news='''\
                שגיאה בניגון
                לא תקין.
                מקור : %s,
                שם:%s
                פרק:%s
                עונה:%s
                קישור:%s
                שגיאה:%s
                מיקום:%s
                שרת:%s
                '''
                sendy(news%(o_name,original_title,season,episode,url.replace('openload','vummo').replace('letsupload','avlts'),e,str(lineno),o_plot),'error Vik','vikerror')
                playing_text='Error:'+str(e)+'$$$$'+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
                if Addon.getSetting("dp_play")=='true'  and windows_play==False:
                        dp.close()
                if windows_play==False and nextup==False and show_errors==True:
                    window = whats_new('אופססס','https://i.gifer.com/ItfD.gif',news%(o_name,original_title,season,episode,url.replace('openload','vummo').replace('letsupload','avlts'),e,str(lineno),o_plot))
                    window.doModal()
                    del window
                    
                return 0
    
             

             set_runtime=''
             set_total=''
             info = {'title': id, 'season': season, 'episode': episode}
             mag_start_time='0'
             elapsed_time = time.time() - start_time
             if Addon.getSetting("dp_play")=='true'  and windows_play==False:
                
                dp.update(0, ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'בודק נקודת ניגון אחרונה', '')
             playing_text='בודק נקודת ניגון אחרונה$$$$'+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
             logging.warning('in last play2')
             if Addon.getSetting("dp_play")=='true'  and windows_play==False:
                    if dp.iscanceled(): 
                        
                        stop_auto_play=1
                        return 0
             if  Addon.getSetting("adv_watched")=='true' and id!='%20':
                 #AWSHandler.UpdateDB()
                 logging.warning('in last play')
                 #res = AWSHandler.CheckWS(info)
                 dbcur.execute("SELECT * FROM playback where tmdb='%s' and season='%s' and episode='%s'"%(id,str(season).replace('%20','0').replace(' ','0'),str(episode).replace('%20','0').replace(' ','0')))
                 logging.warning("SELECT * FROM playback where tmdb='%s' and season='%s' and episode='%s'"%(id,str(season).replace('%20','0').replace(' ','0'),str(episode).replace('%20','0').replace(' ','0')))
                 match_playtime = dbcur.fetchone()
                 if match_playtime!=None:
           
                    name_r,timdb_r,season_r,episode_r,playtime,totaltime,free=match_playtime
                    res={}
                    res['wflag']=False
                    res['resumetime']=playtime
                    res['totaltime']=totaltime
                 else:
                    res=False
                 logging.warning('res:')
                 logging.warning(res)
                 logging.warning("Check Advance")
                 
                    
                   
                 if res:
                    logging.warning('In res')
                    if not res['wflag']:
                        logging.warning('In res1')
                        if res['resumetime']!=None:
                            logging.warning('In res2')
                            
                            choose_time='המשך מ '+time.strftime("%H:%M:%S", time.gmtime(float(res['resumetime'])))
                            #ret = xbmcgui.Dialog().select("בחר", choose_time)
                            '''
                            addonPath = xbmcaddon.Addon().getAddonInfo('path').decode('utf-8')
                            dlg = SelectorDialog("DialogFavourites.xml", addonPath,  title='מועדפים',
                                                         steps=len(choose_time),list=choose_time)
                            dlg.doModal()
                            selection = dlg.get_selection()
                            items = dlg.items
                            del dlg
                            '''
                            if float(res['resumetime'])>=(0.98*(float(res['totaltime']))):
                                selection=1
                            else:
                              if Addon.getSetting("play_first")=='true':
                                selection=0
                              else:
                                window = selection_time('תפריט',choose_time)
                                window.doModal()
                                selection = window.get_selection()
                                del window
                           
                            if selection==-1:
                               stop_auto_play=1
                               if "103.107.134.100" in link:
                                mag_start_time='5'
                                set_runtime='5'
                                set_total=res['totaltime']
                               return 0
                            if selection==0:
                                mag_start_time=res['resumetime']
                                set_runtime=res['resumetime']
                                set_total=res['totaltime']
                                #listItem.setProperty('resumetime', res['resumetime'])
                                #listItem.setProperty('totaltime', res['totaltime'])
                                
                            elif selection==1:
                                
                                mag_start_time='0'
                                set_runtime='0'
                                set_total=res['totaltime']
                                if "103.107.134.100" in link:
                                    mag_start_time='5'
                                    set_runtime='5'
                                    set_total=res['totaltime']
                                #listItem.setProperty('resumetime', '0')
                                #listItem.setProperty('totaltime', res['totaltime'])
      
             
             
             logging.warning(link)
             
             listItem = xbmcgui.ListItem(video_data['title'], path=link) 
             listItem.setInfo(type='Video', infoLabels=video_data)
             
             
             listItem.setProperty('IsPlayable', 'true')
             listItem.setProperty('resumetime', set_runtime)
             listItem.setProperty('totaltime', set_total)
             
             if 'magnet' in url or 'limetorrents' in url or '1337x.to' in url  or 'ibit.to' in url or 'torrentdownloads.me' in url or 'torrentquest.com' in url or 'eztv.io' in url or 'movcr.to' in url:
                 if not allow_debrid:
                     if 'limetorrents' in url:
                         elapsed_time = time.time() - start_time
                         if Addon.getSetting("dp_play")=='true'  and windows_play==False:
                            dp.update(0, ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'משיג לינק מגנט ישיר', '')
                         playing_text='משיג לינק מגנט ישיר$$$$'+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
                         headers = {
                    
                                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
                                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                                'Accept-Language': 'en-US,en;q=0.5',
                                'Connection': 'keep-alive',
                                'Upgrade-Insecure-Requests': '1',
                            }
                         x=requests.get(url,headers=headers).content
                         regex='"magnet:(.+?)"'
                         url='magnet:'+re.compile(regex).findall(x)[0]
                         
                     if '1337x.to' in url :
                        x,cook=cloudflare_request('http://www.1337x.to/',headers=base_header)
                        x=requests.get(url,headers=cook[1],cookies=cook[0]).content
                        regex='"magnet:(.+?)"'
                        url='magnet:'+re.compile(regex).findall(x)[0]
                        logging.warning(url)
                     if 'movcr.' in url :
                            x,cook=cloudflare_request('https://movcr.to',headers=base_header)
                            x=requests.get(url,headers=cook[1],cookies=cook[0]).content
                            regex='"magnet:(.+?)"'
                            url='magnet:'+re.compile(regex).findall(x)[0]
                            logging.warning(url)
                     if  'torrentquest.com' in url or 'eztv.io' in url:
                         elapsed_time = time.time() - start_time
                         if Addon.getSetting("dp_play")=='true'  and windows_play==False:
                            dp.update(0, ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'משיג לינק מגנט ישיר', '')
                         playing_text='משיג לינק מגנט ישיר$$$$'+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
                         headers = {
                    
                                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
                                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                                'Accept-Language': 'en-US,en;q=0.5',
                                'Connection': 'keep-alive',
                                'Upgrade-Insecure-Requests': '1',
                            }
                         x=requests.get(url,headers=headers).content
                         regex='"magnet:(.+?)"'
                         url='magnet:'+re.compile(regex).findall(x)[0]
                     if 'torrentdownloads.me' in url:
                         elapsed_time = time.time() - start_time
                         if Addon.getSetting("dp_play")=='true'  and windows_play==False:
                            dp.update(0, ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'משיג לינק מגנט ישיר', '')
                         playing_text='משיג לינק מגנט ישיר$$$$'+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
                         headers = {
                    
                                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
                                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                                'Accept-Language': 'en-US,en;q=0.5',
                                'Connection': 'keep-alive',
                                'Upgrade-Insecure-Requests': '1',
                            }
                         x=requests.get(url,headers=headers).content
                         regex='"magnet:(.+?)"'
                         url='magnet:'+re.compile(regex).findall(x)[0]
                     if 'ibit.to' in url:
                         elapsed_time = time.time() - start_time
                         if Addon.getSetting("dp_play")=='true'   and windows_play==False:
                            dp.update(0, ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'משיג לינק מגנט ישיר', '')
                         playing_text='משיג לינק מגנט ישיר$$$$'+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
                         headers = {
                    
                                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
                                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                                'Accept-Language': 'en-US,en;q=0.5',
                                'Connection': 'keep-alive',
                                'Upgrade-Insecure-Requests': '1',
                            }
                         x=requests.get(url,headers=headers).content
                         regex="'magnet:(.+?)'"
                         url='magnet:'+re.compile(regex).findall(x)[0].decode("string-escape").replace('X-X','')
                     '''
                     if season!=None and season!="%20" and '-KIDSSECTION-' not in o_plot:
                        elapsed_time = time.time() - start_time
                        if Addon.getSetting("dp_play")=='true'  and windows_play==False:
                            
                            dp.update(0, ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'מפעיל חיפוש לפרק הבא', '')
                        playing_text='מפעיל חיפוש לפרק הבא$$$$'+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
                        time_to_save=int(Addon.getSetting("save_time"))

                    
                        fav_status='false'
                        thread=[]
                        thread.append(Thread(get_next_ep_links,original_title,year,season,str(int(episode)+1),id,eng_name,show_original_year,heb_name,isr,fav_status))
                        thread[0].start()
                     '''
                 if season!=None and season!="%20":
                    prev_name=original_title
                 elapsed_time = time.time() - start_time
                 if Addon.getSetting("dp_play")=='true'  and windows_play==False:
                     
                     dp.update(0, ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'שומר לDB מגנט', '')
                 playing_text='שומר לDB מגנט$$$$'+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
                 dbcur.execute("DELETE FROM sources")
                 dbcur.execute("INSERT INTO sources Values ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s','%s','%s','%s');" %  (prev_name.replace("'","%27"),url,iconimage,fanart,o_plot.replace("'","%27"),year,season,episode,original_title.replace("'","%27"),heb_name.replace("'","%27"),show_original_year,eng_name.replace("'","%27"),isr,id))
                 
                 elapsed_time = time.time() - start_time
                 if Addon.getSetting("dp_play")=='true'  and windows_play==False:
                     
                     dp.update(100, ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'מסרתי לקודי עכשיו זה בידיים שלו', '')
                 playing_text='מסרתי לקודי עכשיו זה בידיים שלו$$$$'+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
                 if allow_debrid:
                    import real_debrid
                    #real_debrid.RealDebrid().auth()
                    rd = real_debrid.RealDebrid()
                    if 1:#try:
                        if  url.endswith('.torrent') and 'magnet:' not in url:
                            link=rd.addtorrent(url)
                        else:
                            link=rd.singleMagnetToLink(url)
                        listItem = xbmcgui.ListItem(video_data['title'], path=link) 
                        listItem.setInfo(type='Video', infoLabels=video_data)


                        listItem.setProperty('IsPlayable', 'true')
                        listItem.setProperty('resumetime', set_runtime)
                        listItem.setProperty('totaltime', set_total)
                    '''
                    except Exception as e:
                        get_torrent_file(silent_mode=True)
                        xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'RD כשל מנגן רגיל'.encode('utf-8')+str(e))))
                        if Addon.getSetting("players_new")!='7':
                            link=get_torrent_link(url)
                            
                            listItem = xbmcgui.ListItem(video_data['title'], path=link) 
                            listItem.setInfo(type='Video', infoLabels=video_data)


                            listItem.setProperty('IsPlayable', 'true')
                            listItem.setProperty('resumetime', set_runtime)
                            listItem.setProperty('totaltime', set_total)
                            if link==url:
                            
                                resolve_magnet(url,listItem,AWSHandler,info,mag_start_time)
                                xbmc.sleep(500)
                                xbmc.executebuiltin('Dialog.Close(okdialog, true)')
                                return 0
                        else:
                            listItem = xbmcgui.ListItem(video_data['title'], path=link) 
                            listItem.setInfo(type='Video', infoLabels=video_data)


                            listItem.setProperty('IsPlayable', 'true')
                            listItem.setProperty('resumetime', set_runtime)
                            listItem.setProperty('totaltime', set_total)
                            if Addon.getSetting("dp_play")=='true':
                                dp.close()
                            resolve_magnet(url,listItem,AWSHandler,info,mag_start_time)
                            xbmc.sleep(500)
                            xbmc.executebuiltin('Dialog.Close(okdialog, true)')
                            return 0
                    '''
                 else:
                    if Addon.getSetting("players_new")!='7':
                        link=get_torrent_link(url)
                        
                        listItem = xbmcgui.ListItem(video_data['title'], path=link) 
                        listItem.setInfo(type='Video', infoLabels=video_data)


                        listItem.setProperty('IsPlayable', 'true')
                        listItem.setProperty('resumetime', set_runtime)
                        listItem.setProperty('totaltime', set_total)
                        if link==url:
                        
                            resolve_magnet(url,listItem,match_playtime,info,mag_start_time)
                            xbmc.sleep(500)
                            xbmc.executebuiltin('Dialog.Close(okdialog, true)')
                            return 0
                    else:
                        listItem = xbmcgui.ListItem(video_data['title'], path=link) 
                        listItem.setInfo(type='Video', infoLabels=video_data)


                        listItem.setProperty('IsPlayable', 'true')
                        listItem.setProperty('resumetime', set_runtime)
                        listItem.setProperty('totaltime', set_total)
                        if Addon.getSetting("dp_play")=='true'  and windows_play==False:
                            dp.close()
                        resolve_magnet(url,listItem,match_playtime,info,mag_start_time)
                        xbmc.sleep(500)
                        xbmc.executebuiltin('Dialog.Close(okdialog, true)')
                        return 0
             elapsed_time = time.time() - start_time
             if Addon.getSetting("dp_play")=='true'  and windows_play==False:
                 
                 dp.update(100, ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'מסרתי לקודי עכשיו זה בידיים שלו', '')
             playing_text='מסרתי לקודי עכשיו זה בידיים שלו$$$$'+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
             #logging.warning(video_data)
             mag_start_time_new=set_runtime
             logging.warning('mag_start_time_new:'+mag_start_time_new)
             #listItem.setProperty('inputstreamaddon', 'inputstream.adaptive')
             #listItem.setProperty('inputstream.adaptive.manifest_type', 'mpd')
             #listItem.setProperty('inputstream.adaptive.stream_headers', link.split('|')[1])
             
             if 'TEME' in description:
                logging.warning('pre_saved_name:')
                logging.warning(saved_name)
                logging.warning(id)
                if 'https://t.me' in url:
                    url_id=url
                    
                    link='plugin://plugin.video.telemedia/?url=%s&no_subs=%s&season=%s&episode=%s&mode=40&original_title=%s&id=%s&data=&fanart=&url=%s&iconimage=&file_name=%s&description=%s&resume=%s&name=%s&heb_name=%s'%(url_id,no_subs,season,episode,original_title.decode('utf-8','ignore').encode("utf-8"),id,url_id,saved_name.decode('utf-8','ignore').encode("utf-8"),'_from_victory_',set_runtime,saved_name,heb_name)
                else:
                    l_link=json.loads(url)
                    c_id=l_link['c_id']
                    m_id=l_link['m_id']
                    url_id=l_link['id']
                
                    link='plugin://plugin.video.telemedia/?url=%s&no_subs=%s&season=%s&episode=%s&mode=40&original_title=%s&id=%s&data=&fanart=&url=%s&iconimage=&file_name=%s&description=%s&resume=%s&name=%s&heb_name=%s&c_id=%s&m_id=%s'%(url_id,no_subs,season,episode,original_title.decode('utf-8','ignore').encode("utf-8"),id,url_id,saved_name.decode('utf-8','ignore').encode("utf-8"),'_from_victory_',set_runtime,saved_name,heb_name,c_id,m_id)
                #xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'המתן לניגון... לא לגעת :-)')))
                if Addon.getSetting("dp_play")=='true'  and windows_play==False:
                    dp.update(100, ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'ממתין לטלמדיה :-)', '')
                xbmc.executebuiltin('XBMC.RunPlugin(%s)'%link)
             
             logging.warning('Statign Play')
             seek_now=False
             if 'TEME' not in description:
                 logging.warning('TemeStatign Play')
                 
                 if windows_play or 'shortshortcut' in description:
                    logging.warning('11')
                    if nextup or 'shortshortcut'  in description:
                        logging.warning('1')
                        ok=xbmc.Player().play(link,listitem=listItem,windowed=False)
                        seek_now=True
                        
                    else:
                        logging.warning('2')
                        ok=xbmc.Player().play(link,listitem=listItem,windowed=True)
                        seek_now=True
                 else:
                     logging.warning('12')
                     if auto_play==True:
                       if Addon.getSetting("show_sources_in_4")=='true':
                            logging.warning('3')
                            ok=xbmc.Player().play(link,listitem=listItem)
                            seek_now=True
                       else:
                            logging.warning('4')
                            ok=xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
                       if f_auto_play==False:
                        ok=xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
                    
                     else:
                       
                        logging.warning('13')
                        
                        ok=xbmc.Player().play(link,listitem=listItem)
                        ok=xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
                        seek_now=True
             if seek_now:
                
                thread=[]
        
                thread.append(Thread(jump_seek,  set_runtime))
                    
                
                thread[0].start()
             if 'TEME' not in description:
                 if (wall_link and subtitlesUrl) or sub:
                    x=0
                    while not xbmc.Player().isPlaying() and x<1000:
                            xbmc.sleep(10) #wait until video is being played
                            x+=1
                    xbmc.sleep(500)
                    
                    if sub:
                        subtitlesUrl=sub
                    logging.warning('Place subtitle:'+subtitlesUrl)
                    xbmc.Player().setSubtitles(subtitlesUrl)
                
                    
                 if Addon.getSetting("dp_play")=='true'  and windows_play==False:
                    if dp.iscanceled(): 
                        
                        stop_auto_play=1
                    dp.close()
                 if Addon.getSetting("play_first")!='true':
                    playing_text=''
                 xbmc.executebuiltin('Dialog.Close(okdialog, true)')
                 logging.warning('Check Play')
                 logging.warning(Check_Playback(ignore_dp=True))
                 xbmc.sleep(1000)
             logging.warning(' Done Playing')
             
             #AWSHandler.QueueWS(info)
             #f_names=link.split('/')
             #f_name=f_names[len(f_names)-1]
             #AWSHandler.QueueWS(info,f_tit=f_name)
             
             if 1:#xbmc.Player().isPlaying():
                 logging.warning('season:'+season)
                 
                 if Addon.getSetting("use_trak")=='true' and len(id)>1 and id!='%20':
                    
                     if season!=None and season!="%20":
                       '''
                       logging.warning('tv')
                       logging.warning(imdb_id)
                       url_pre='http://thetvdb.com/api/GetSeriesByRemoteID.php?imdbid=%s&language=en'%imdb_id.replace('tt','')
                       html2=requests.get(url_pre).content
                       pre_tvdb = str(html2).split('<seriesid>')
                       if len(pre_tvdb) > 1:
                            tvdb = str(pre_tvdb[1]).split('</seriesid>')
                       logging.warning(tvdb)
                       '''
                       season_t, episode_t = int('%01d' % int(season)), int('%01d' % int(episode))
                       
                       i = (post_trakt('/sync/watchlist', data={"shows": [{"seasons": [{"episodes": [{"number": episode_t}], "number": season_t}], "ids": {"tmdb": id}}]}))
                     else:
                       
                       i = (post_trakt('/sync/watchlist',data= {"movies": [{"ids": {"tmdb": id}}]}))
                     logging.warning(i)
             try:
            
              if season!=None and season!="%20" and '-KIDSSECTION-' not in o_plot:
                time_to_save=int(Addon.getSetting("save_time"))
                fav_search_f=Addon.getSetting("fav_search_f_tv")
                fav_servers_en=Addon.getSetting("fav_servers_en_tv")
                fav_servers=Addon.getSetting("fav_servers_tv")
                google_server= Addon.getSetting("google_server_tv")
                rapid_server=Addon.getSetting("rapid_server_tv")
                direct_server=Addon.getSetting("direct_server_tv")
                heb_server=Addon.getSetting("heb_server_tv")
        
   
                if  fav_search_f=='true' and fav_servers_en=='true' and (len(fav_servers)>0 or heb_server=='true' or google_server=='true' or rapid_server=='true' or direct_server=='true'):
                
                    fav_status='true'
                else:
                    fav_status='false'
                logging.warning('searching next_ep fav')
                thread=[]
        
                thread.append(Thread(get_nex_ep,  time_to_save, original_title,year,season,str(int(episode)+1),id,eng_name,show_original_year,heb_name,isr,False,fav_status,prev_name,url,iconimage,fanart,o_plot))
                    
                
                thread[0].start()
                
                #match_a,a,b,f_subs= cache.get(c_get_sources, time_to_save, original_title,year,original_title,season,str(int(episode)+1),id,eng_name,show_original_year,heb_name,isr,False,fav_status,'no','0',table='pages')

                if 0:#fav_status=='true':
                    logging.warning('searching next_ep rest')
                    #match_a= cache.get(c_get_sources, time_to_save, original_title,year,original_title,season,str(int(episode)+1),id,eng_name,show_original_year,heb_name,isr,False,'rest','no','0', table='pages')
                    thread.append(Thread(get_nex_ep,  time_to_save, original_title,year,season,str(int(episode)+1),id,eng_name,show_original_year,heb_name,isr,False,'rest',prev_name,url,iconimage,fanart,o_plot))
                    thread[1].start()
                logging.warning('Done Prep')
                
                    
             except Exception as e:
               logging.warning('ERRORRRRRRRRRRRRRRR: '+str(e))
               pass
             if season!=None and season!="%20":
                prev_name=original_title

             dbcur.execute("DELETE FROM sources")
             dbcur.execute("INSERT INTO sources Values ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s','%s','%s','%s');" %  (prev_name.replace("'","%27"),url,iconimage,fanart,o_plot.replace("'","%27"),year,season,episode,original_title.replace("'","%27"),heb_name.replace("'","%27"),show_original_year,eng_name.replace("'","%27"),isr,id))
             dbcur.execute("DELETE FROM nextup")
  
             if season!=None and season!="%20" and Addon.getSetting('nextup')=='true':

                 dbcur.execute("INSERT INTO nextup Values ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s','%s','%s','%s');" %  (prev_name.replace("'","%27"),url,iconimage,fanart,o_plot.replace("'","%27"),year,season,str(int(episode)+1),original_title.replace("'","%27"),heb_name.replace("'","%27"),show_original_year,eng_name.replace("'","%27"),isr,id))
                 
     
                 
              
                   
                   
             dbcon.commit()
             
             if 'TEME' not in description:
                 logging.warning('DONE ALL')
                 xbmc.sleep(1000)
                 if 'plugin.video.f4mTester' in url:
                    xbmc.executebuiltin('Dialog.Close(all, true)') 
                 logging.warning('OK')
                 xbmc.executebuiltin('Dialog.Close(okdialog, true)')
             #xbmc.executebuiltin('ReloadSkin()')
             
             return 'ok'
def last_played_c():
      dbcur.execute("SELECT * FROM lastlinkmovie WHERE o_name='f_name'")

      match = dbcur.fetchone()
      if match!=None:
       f_name,name,url,iconimage,fanart,description,data,season,episode,original_title,saved_name,heb_name,show_original_year,eng_name,isr,prev_name,id=match
       try:
           if url!=' ':
             if 'http' not  in url:
           
               url=url.decode('base64')
              
             addLink('[COLOR yellow][I]לינק סרט אחרון[/I][/COLOR]','latest_movie',5,False,iconimage,fanart,description,data=show_original_year,original_title=original_title,season=season,episode=episode,id=id,saved_name=saved_name,prev_name=prev_name,eng_name=eng_name,heb_name=heb_name,show_original_year=show_original_year)
       except  Exception as e:
         logging.warning(e)
         pass

      dbcur.execute("SELECT * FROM lastlinktv WHERE o_name='f_name'")

      match = dbcur.fetchone()
      if match!=None:
       
       f_name,name,url,iconimage,fanart,description,data,season,episode,original_title,saved_name,heb_name,show_original_year,eng_name,isr,prev_name,id=match
       try:
           if url!=' ':
             if 'http' not  in url:
             
               url=url.decode('base64')

             addLink('[COLOR yellow][I]לינק סדרה אחרון[/I][/COLOR]'.decode('utf8'), 'latest_tv',5,False,iconimage,fanart,description,data=show_original_year,original_title=original_title,season=season,episode=episode,id=id,saved_name=saved_name,prev_name=prev_name,eng_name=eng_name,heb_name=heb_name,show_original_year=show_original_year)
       except Exception as e:
         logging.warning(e)
         pass
       addNolink('[COLOR yellow][I]מקורות אחרונים[/I][/COLOR]'.encode('utf8'), url,75,False,iconimage='https://ak6.picdn.net/shutterstock/videos/13058996/thumb/1.jpg',fanart='https://pixelz.cc/wp-content/uploads/2018/06/the-last-of-us-ellie-and-joel-uhd-4k-wallpaper.jpg')
       
def only_heb_links(url):
    all_only_heb=json.loads(url)
   
    for item in all_only_heb:
         name=all_only_heb[item]['name']
         url=all_only_heb[item]['link']
         server=all_only_heb[item]['server']
         quality=all_only_heb[item]['quality']
         icon=all_only_heb[item]['icon']
         image=all_only_heb[item]['image']
         plot=all_only_heb[item]['plot']
         year=all_only_heb[item]['year']
         season=all_only_heb[item]['season'].replace(' ','%20')
         episode=all_only_heb[item]['episode'].replace(' ','%20')
         id=all_only_heb[item]['id'].replace(' ','%20')
         name_f=all_only_heb[item]['name_f']
         color=all_only_heb[item]['color']
             
         addLink('[COLOR %s][%s] '%(color,name_f)+name+" - "+server+'[/COLOR]', url,5,False,icon,image,'[COLOR gold]'+quality+'[/COLOR]\n[COLOR lightblue]'+server+'[/COLOR]\n'+plot,data=year,original_title=name,season=season,episode=episode,id=id,saved_name=name,prev_name=name,eng_name=name,heb_name=name,show_original_year=year)
def display_results(url):
    all_f_links=json.loads(url)
    text_f=''
    text_nf=''
    for name_f in all_f_links:
       if name_f!='subs' and Addon.getSetting(name_f)=='true':
        count_1080=0
        count_720=0
        count_480=0
        count_rest=0
        
        for name,link,server,quality in all_f_links[name_f]['links']:
           
                
     
                 if '1080' in quality:
                   count_1080+=1
                 elif '720' in quality:
                   count_720+=1
                 elif '480' in quality:
                   count_480+=1
                 else:
                   count_rest+=1
        if len(all_f_links[name_f]['links'])>0:
          string_dp="1080: [COLOR khaki]%s[/COLOR] 720: [COLOR gold]%s[/COLOR] 480: [COLOR silver]%s[/COLOR] Rest: [COLOR burlywood]%s[/COLOR]"%(count_1080,count_720,count_480,count_rest)
          text_f=text_f+name_f+' : '+string_dp+'\n'
        else:
          text_nf=text_nf+name_f+' : [COLOR red]NOT FOUND[/COLOR]'+'\n'
          
    showText('Results', text_f+text_nf)
def get_m3u8():
    addNolink('[COLOR khaki][I]כדי להפעיל עם פרוקסי יש לרשום proxy בשם הקובץ[/I][/COLOR]','www',999,False,iconimage='http://cdn.marketplaceimages.windowsphone.com/v8/images/31edc250-11db-47c3-ad08-712fb1082435?imageType=ws_icon_large',fanart='https://blog.keycdn.com/blog/wp-content/uploads/2014/11/live-streaming-1-768x384.png')
    for i in range(0,5):
      
        nam=Addon.getSetting("M3u8_name-"+str(i))
        list=Addon.getSetting("M3u8_addr-"+str(i))
        if len(nam)>0 and 'http' in list:
          addDir3(nam.decode('utf8').replace('.m3u',''),list,56,'http://cdn.marketplaceimages.windowsphone.com/v8/images/31edc250-11db-47c3-ad08-712fb1082435?imageType=ws_icon_large','https://blog.keycdn.com/blog/wp-content/uploads/2014/11/live-streaming-1-768x384.png',nam.decode('utf8').replace('.m3u8',''))
    onlyfiles = [f for f in listdir(m3_path) if isfile(join(m3_path, f))]
    for file in onlyfiles:
      addDir3(file.decode('utf8').replace('.m3u',''),os.path.join(m3_path, file).encode('utf8'),56,'http://cdn.marketplaceimages.windowsphone.com/v8/images/31edc250-11db-47c3-ad08-712fb1082435?imageType=ws_icon_large','https://blog.keycdn.com/blog/wp-content/uploads/2014/11/live-streaming-1-768x384.png',file.decode('utf8').replace('.m3u8',''))
      
    onlyfiles = [f for f in listdir(m3_dir) if isfile(join(m3_dir, f))]
    for file in onlyfiles:
      addDir3(file.decode('utf8').replace('.m3u',''),os.path.join(m3_dir, file).encode('utf8'),56,'http://cdn.marketplaceimages.windowsphone.com/v8/images/31edc250-11db-47c3-ad08-712fb1082435?imageType=ws_icon_large','https://blog.keycdn.com/blog/wp-content/uploads/2014/11/live-streaming-1-768x384.png',file.decode('utf8').replace('.m3u8',''))
def m3u8_cont(name,url):
    if 'http' in url:
      logging.warning('m3u8')
      
      headers = {
        
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding':'UTF-8',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        }
      file_data=requests.get(url,headers=headers).content.replace('\n\n','\n').replace('\r','').replace('\t','').split('\n')
    
    else:
        s_file=url.decode('utf8')

        file = open(s_file, 'r') 
        file_data= file.readlines()
        file.close()
    if len(file_data)>200 and Addon.getSetting("group_m3u")=='true':
        all_letters=[]
     
        for r in range(0, len(file_data)/200):
          
              addDir3('Group - '+str(r),url,66,iconimage='http://cdn.marketplaceimages.windowsphone.com/v8/images/31edc250-11db-47c3-ad08-712fb1082435?imageType=ws_icon_large',fanart='https://blog.keycdn.com/blog/wp-content/uploads/2014/11/live-streaming-1-768x384.png',description=str(r))
    else:
   
        for data in file_data:
          
           if '#EXTINF' in data:
               line_d=data.split(",")

               display_name=line_d[1]
               icon=' '
               if len(line_d)>1:
                if 'tvg-logo' in line_d[0]:
                     regex=' tvg-logo=(.+?)"'
                     match=re.compile(regex).findall(line_d[0])
                     if len(match)>0:
                        icon=match[0].replace('"','')
                     else:
                        icon=' '
               
                  
               
           elif 'http' in data:
             url=data
             if 'proxy' in name:
                url='plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url='+url
             addLink(display_name,url,5,False,iconimage=icon,fanart=icon,description=display_name+'__music__')
    '''
    matches=re.compile('^#EXTINF:(.*?),(.*?)$\n^(.*?)$',re.I+re.M+re.U+re.S).findall(file_data)
    logging.warning('2')
    for params, display_name, url in matches:
        if 'tvg-logo' in params:
         regex=' tvg-logo=(.+?)"'
         match=re.compile(regex).findall(params)
     
         icon=match[0].replace('"','')
        else:
          icon=' '
        if len(icon)==0:
          icon=' ' 
        addLink(display_name,url,5,False,iconimage=icon,fanart=icon,description=display_name)
    '''
def get_group_m3u8(url,plot):
    if 'http' in url:
      headers = {
        
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        }
      file_data=requests.get(url,headers=headers).content.replace('\n\n','\n').replace('\r','').replace('\t','').split('\n')
    else:
        s_file=url.decode('utf8')
       
        file = open(s_file, 'r') 
        file_data= file.readlines()
        file.close()
    start=int(plot)*100
    end=int(plot)*100+100
    counter=0
    for data in file_data:
      
       if '#EXTINF' in data:
           line_d=data.split(",")

           display_name=line_d[1]
           icon=' '
           if len(line_d)>1:
            if 'tvg-logo' in line_d[0]:
                 regex=' tvg-logo=(.+?)"'
                 match=re.compile(regex).findall(line_d[0])
                 if len (match)>0:
                    icon=match[0].replace('"','')
                 else:
                    icon=' '
           
              
           
       elif 'http' in data:
         url=data
         if counter>=start and counter<=end:
           addLink(display_name,url,5,False,iconimage=icon,fanart=icon,description=display_name+'__music__')
         counter+=1
def fix_data(data):
    return data.replace('[',' ').replace(']',' ').replace('	','').replace("\\"," ").replace("\n"," ").replace("\r"," ").replace("\t"," ")
def israeli():
        user_dataDir=os.path.join(done_dir,'cache_f','dragon')
        if not os.path.exists(user_dataDir):
            os.makedirs(user_dataDir)
                
        

       
        def renew_data(path):

            
            download_file(l_list,path)
            

            unzip(os.path.join(path, "fixed_list.txt"))


            
            
            return 'ok'
        
            
            
        import cache
        try:
            from sqlite3 import dbapi2 as database
        except:
            from pysqlite2 import dbapi2 as database
        
        
        l_list='https://raw.githubusercontent.com/yonni55555/---rotary-phone/master/53.txt'
       
        cacheFile=os.path.join(user_dataDir,'localfile.txt')
        if not os.path.exists(cacheFile):
           
            download_file(l_list,user_dataDir)

            unzip(os.path.join(user_dataDir, "fixed_list.txt"))

        else:

            all_img=cache.get(renew_data,1,arg=(user_dataDir,), table='posters')
        
        


        dbcon = database.connect(cacheFile)
        dbcur = dbcon.cursor()
        dbcur.execute("SELECT * FROM MyTable where father like '%ישראלים%' and father like '%סרטים%' and type='item'")
        match = dbcur.fetchall()
        for index,name,f_link,icon,fanart,plot,data,date,year,genre,father,type in match:
            name=name.replace('%27',"'")
            plot=plot.replace('%27',"'")
            data=data.replace('%27',"'").replace('[',' ').replace(']',' ').replace('	','').replace("\\"," ").replace(': """",',': "" "",').replace(': """"}',': "" ""}').replace(': "",',': " ",').replace(': ""}',': " "}').replace('""','"').replace('\n','').replace('\r','')
            try:
                f_link=gdecom(f_link)
            except:
               pass
         
            addLink(name,f_link,5,False,icon,fanart,plot,video_info=data)
        logging.warning('H1')
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
def eng_anim2():
    headers = {
        
        'user-agent': 'Dart/2.2(dart:io)',

    }
    
    
    x=requests.post('http://json.mangapanda.com/home',headers=headers).json()
    for items in x:
        addDir3(items['manganame'],items['link'],62,items['coverimg'],items['coverimg'],items['manganame'])
    
def eng_anim():
    addDir3('Cartoon'.decode('utf8'),'http://api.animetoon.tv/GetAllCartoon',59,'https://png.pngtree.com/element_pic/00/16/12/07584794601cb2b.jpg','https://wallpapersite.com/images/pages/pic_w/2604.jpg','מומלצים'.decode('utf8'))
    addDir3('אנימה'.decode('utf8'),'http://api.animetoon.tv/GetAllDubbed',59,'https://i.imgur.com/e4Crf1p.jpg','http://www.tokkoro.com/picsup/2618741-anime-4k-full-desktop-wallpaper.jpg','חדשים'.decode('utf8'))
    
    addDir3('[COLOR aqua][I]חיפוש[/I][/COLOR]'.decode('utf8'),'search',62,'https://upload.wikimedia.org/wikipedia/commons/0/0e/Wikipe-tan_sailor_fuku.png','https://worldwithouthorizons.com/wp-content/uploads/Artsy-2016-4K-Anime-Wallpaper-1280x720.jpg','חיפוש'.decode('utf8'))
def download_img(local_filename,cook,url):
    
    if os.path.exists(local_filename):
   
      return 0
    r = requests.get(url,headers=cook[1],cookies=cook[0], stream=True)
    with open(local_filename, 'wb') as f:
        for chunk in r.iter_content(chunk_size=1024): 
            if chunk: # filter out keep-alive new chunks
                f.write(chunk)
                #f.flush() commented by recommendation from J.F.Sebastian
    return local_filename
def next_anime(url):
    headers = {
        
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
    }

    x=requests.get(url,headers).json()
    for items in x:
        if items['description']!=None:
          plot=items['description']
        else:
           plot=' '
        video_data={}
        video_data['title']=items['name']
        video_data['poster']='http://www.animetoon.tv/images/series/big/'+items['id']+'.jpg'
        video_data['plot']=plot
        video_data['icon']='http://www.animetoon.tv/images/series/big/'+items['id']+'.jpg'
        if items['released']!=None:
          video_data['year']=items['released'].split('-')[0]
        video_data['rating']=str(int(items['rating']))
        
        addDir3(items['name'],items['id'],60,'http://www.animetoon.tv/images/series/big/'+items['id']+'.jpg','http://www.animetoon.tv/images/series/big/'+items['id']+'.jpg',plot,video_info=video_data)
def anime_ep(url,image):
    headers = {
        'App-Version': '8.0',
        'App-Name': '#Toonmania',
        'App-LandingPage': 'http://www.mobi24.net/toon.html',
        'Host': 'api.animetoon.tv',
        'Connection': 'Keep-Alive',
        'Accept-Encoding': 'utf-8',
        'User-Agent': 'okhttp/2.3.0'
      
    }
  
    x=requests.get('http://api.animetoon.tv/GetDetails/'+url,headers=headers).json()
    for items in x['episode']:
        video_data={}
        video_data['title']=items['name']
        video_data['poster']=image
        video_data['plot']=items['name']
        video_data['icon']=image
        if items['date']!=None:
          video_data['year']=items['date'].split('-')[0]
        
        addLink(items['name'],items['id'],61,False,image,image,items['name'],video_info=json.dumps(video_data))
def play_anime(name,url,iconimage):

    headers = {
        'App-Version': '8.0',
        'App-Name': '#Toonmania',
        'App-LandingPage': 'http://www.mobi24.net/toon.html',
        'Host': 'api.animetoon.tv',
        'Connection': 'Keep-Alive',
        'Accept-Encoding': 'utf-8',
        'User-Agent': 'okhttp/2.3.0'
      
    }
  
    x=requests.get('http://api.animetoon.tv/GetVideos/'+url,headers=headers).json()

    all_hosts=[]
    all_links=[]
    for items in x:
      regex='//(.+?)/'
      host=re.compile(regex).findall(items[0])[0]
      all_hosts.append(host)
      all_links.append(items[0])
    headers = {
        
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
    }
    ret = xbmcgui.Dialog().select("בחר", all_hosts)
    
    if ret!=-1:
        temp = None
        r = requests.get(all_links[ret],headers=headers)
        
        html = r.text
        if 'var video_links' in html:
            # Try the generic videozoo \ play44 solve first:
            temp = re.findall(r'''var video_links.*?['"]link['"]\s*?:\s*?['"](.*?)['"]''', html, re.DOTALL)
        else:
            # Try variants:
            temp = re.findall(r'''{\s*?url\s*?:\s*?['"](.*?)['"]''', html, re.DOTALL)
            if not temp:
                temp = re.findall(r'''file\s*?:\s*?['"](.*?)['"]''', html, re.DOTALL)
        
        f_link=(temp[0].replace(r'\/', r'/')) # In case there's escaped JS slashes.
        video_data={}
        video_data['title']=name
        video_data['poster']=iconimage
  
        video_data['icon']=iconimage
        
        listItem = xbmcgui.ListItem(video_data['title'], path=f_link) 
        listItem.setInfo(type='Video', infoLabels=video_data)


        listItem.setProperty('IsPlayable', 'true')
 
       
           
        ok=xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
def search_anime():
    search_entered=''
    

    keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש כאן')
    keyboard.doModal()
    if keyboard.isConfirmed():
            search_entered = keyboard.getText()
            headers = {
        
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
            }

            x=requests.get('http://api.animetoon.tv/GetAllCartoon',headers).json()
            all_r=[]
            for items in x:
                if search_entered.lower() in items['name'].lower():
                    if items['description']!=None:
                      plot=items['description']
                    else:
                       plot=' '
                    all_r.append((items['name'],'http://www.animetoon.tv/images/series/big/'+items['id']+'.jpg',items['id'],plot))
            x=requests.get('http://api.animetoon.tv/GetAllDubbed',headers).json()
            for items in x:
                
                if search_entered.lower() in items['name'].lower():
                    if items['description']!=None:
                      plot=items['description']
                    else:
                       plot=' '
                    all_r.append((items['name'],'http://www.animetoon.tv/images/series/big/'+items['id']+'.jpg',items['id'],plot))
                   
        
            for items in all_r:
                video_data={}
                video_data['title']=items[0]
                video_data['poster']=items[1]
                video_data['plot']=items[3]
                video_data['icon']=items[1]
             
                
                
                addDir3(items[0],items[2],60,items[1],items[1],items[3],video_info=video_data)
def add_remove_trakt(name,original_title,id,season,episode):

    if original_title=='add':
        if name=='tv':
         
           season_t, episode_t = int('%01d' % int(season)), int('%01d' % int(episode))
           
           i = (post_trakt('/sync/history', data={"shows": [{"seasons": [{"episodes": [{"number": episode_t}], "number": season_t}], "ids": {"tmdb": id}}]}))
        else:
          
           i = (post_trakt('/sync/history',data= {"movies": [{"ids": {"tmdb": id}}]}))
    elif original_title=='remove':
        if name=='tv':
         
           season_t, episode_t = int('%01d' % int(season)), int('%01d' % int(episode))
           
           i = (post_trakt('/sync/history/remove', data={"shows": [{"seasons": [{"episodes": [{"number": episode_t}], "number": season_t}], "ids": {"tmdb": id}}]}))
        else:
         
           i = (post_trakt('/sync/history/remove',data= {"movies": [{"ids": {"tmdb": id}}]}))
    if 'added' in i:
       xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'סומן כנצפה'.encode('utf-8'))))
    elif 'deleted' in i:
       xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'הוסר סימון נצפה'.encode('utf-8'))))
    else:
      xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'שגיאה פעולה לא הצליחה'.encode('utf-8'))))
    xbmc.executebuiltin('Container.Refresh')
def download_file(url):

    from run import get_links
    

    idm_folder=Addon.getSetting("idm_folder")
    if idm_folder.endswith('\\'):
        idm_folder=idm_folder[:-1]
    o_folder=os.path.join(idm_folder,'idman.exe')
    split_folder=idm_folder.split('\\')
    f_folder=''
    c=0
    for item in split_folder:
        if c==0:
          c=1
          f_folder=f_folder+item+'\\'
        else:
          f_folder=f_folder+'"'+item+'"'+'\\'
    
    idm_path=os.path.join(f_folder,'idman.exe')
   
    if not os.path.exists(o_folder):
        xbmcgui.Dialog().ok('Error occurred','IDM לא מותקן או תקייה לא תקינה בהגדרות')
        sys.exit()
    f_link=get_links(url)
    if Addon.getSetting("dialog_idm")=='true':
      os.system(idm_path+' /d "%s" /n'%f_link)
    else:
      os.system(idm_path+' /d "%s"'%f_link)
    logging.warning(idm_path+' /d "%s" /n'%f_link)
def cartoon():
    url='https://www.watchcartoononline.io/'
    headers = {
        
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
    }
    x=requests.get(url,headers=headers).content
    regex='<ul id="nav">(.+?)</ul>'
    match_pre=re.compile(regex,re.DOTALL).findall(x)

    regex='<li><a href="(.+?)">(.+?)</a></li>'
    match=re.compile(regex).findall(match_pre[0])

    for link,name in match:
       if name!='Home' and name!='Contact':
        addDir3(name.decode('utf8'),link,69,'http://www.cartoon-media.eu/files/library/Cartoon-Movie/2018/JungleBunch_square.jpg?thumb=media-pt','http://digitalspyuk.cdnds.net/16/31/980x490/landscape-1470221630-cartoon-heroes.jpg',name.decode('utf8'))
def cartoon_list(url):
    url='https://www.watchcartoononline.io'+url
    headers = {
        
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
    }
    x=requests.get(url,headers=headers).content
    regex='<a name="#"></a><p class="sep">#</p><ul>(.+?)</div>'
    match_pre=re.compile(regex,re.DOTALL).findall(x)
    regex='<li><a href="(.+?)" title="(.+?)"'
    match=re.compile(regex).findall(match_pre[0])

    if len(match)==0:
       regex='<li><a href="(.+?)">(.+?)</a></li>'
       match=re.compile(regex).findall(match_pre[0])
       for link,title in match:
         addLink(title,link,5,False,iconimage='http://www.cartoon-media.eu/files/library/Cartoon-Movie/2018/JungleBunch_square.jpg?thumb=media-pt',fanart='http://digitalspyuk.cdnds.net/16/31/980x490/landscape-1470221630-cartoon-heroes.jpg',description=title)
    else:
     for link,name in match:
       if name!='Home' and name!='Contact':
        addDir3(name.decode('utf8'),link,70,'http://www.cartoon-media.eu/files/library/Cartoon-Movie/2018/JungleBunch_square.jpg?thumb=media-pt','http://digitalspyuk.cdnds.net/16/31/980x490/landscape-1470221630-cartoon-heroes.jpg',name.decode('utf8'))
def cartoon_episodes(url):
    url='https://www.watchcartoononline.io'+url
    headers = {
        
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
    }
    x=requests.get(url,headers=headers).content
    regex='<meta property="og:image" content="(.+?)"'
    image_p=re.compile(regex).findall(x)
    if len(image_p)>0:
       image=image_p[0]
    else:
       image=' '
    regex_pre='<div id="catlist-listview"(.+?)</ul>'
    m_p=re.compile(regex,re.DOTALL).findall(x)[0]
    regex='li><a href="(.+?)" rel="bookmark" title=".+?" class="sonra">(.+?)<'
    m_p=re.compile(regex).findall(x)
    for link,title in m_p:
  
        addLink(title,link,5,False,iconimage=image,fanart=image,description=title)
def by_actor(url):
    if url=='www':
        url='1'
    if url=='1':
        addDir3('[COLOR lightblue][I]חפש (באנגלית)[/I][/COLOR]','http://api.themoviedb.org/',72,domain_s+'cellcomtv.cellcom.co.il/globalassets/cellcomtv/content/sratim/pets-secret-life/480x543-template.jpg','http://www.videomotion.co.il/wp-content/uploads/whatwedo-Pic-small.jpg','חפש שחקן'.decode('utf8'))
    if 'themovie' in url:
    
        search_entered=''
        keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש כאן')
        keyboard.doModal()
        if keyboard.isConfirmed():
               search_entered = keyboard.getText()
               link='https://api.themoviedb.org/3/search/person?api_key=34142515d9d23817496eeb4ff1d223d0&query=%s&language=he&page=1&include_adult=false'%search_entered
               url='1'
    else:
        link='https://api.themoviedb.org/3/person/popular?api_key=34142515d9d23817496eeb4ff1d223d0&language=en-US&page=%s&language=he&sort_by=popularity.desc'%url
    headers = {
                                
                                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
                                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                                'Accept-Language': 'en-US,en;q=0.5',
                                'Connection': 'keep-alive',
                                'Upgrade-Insecure-Requests': '1',
                            }
    html=requests.get(link,headers=headers).json()
    for items in html['results']:
        icon=items['profile_path']
        if len (items['known_for'])==0:
            
            continue
        if 'backdrop_path' in items['known_for'][0]:
            fanart=items['known_for'][0]['backdrop_path']
        else:
            fanart=' '
        if icon==None:
          icon=' '
        else:
          icon=domain_s+'image.tmdb.org/t/p/original/'+icon
        if fanart==None:
          fanart=' '
        else:
          fanart=domain_s+'image.tmdb.org/t/p/original/'+fanart
        addDir3(items['name'],str(items['id']),73,icon,fanart,items['name'])
    addDir3('[COLOR aqua][I]עמוד הבא[/COLOR][/I]',str(int(url)+1),72,' ',' ','[COLOR aqua][I]עמוד הבא[/COLOR][/I]')
    
def actor_m(url):
    choise=['סדרות','סרטים']
    ret = xbmcgui.Dialog().select("בחר", choise)
    if ret!=-1:
        if ret==0:
         tv_mode='tv'
        else:
         tv_mode='movie'
    else:
      sys.exit()

    if tv_mode=='movie':
       link='https://api.themoviedb.org/3/person/%s/movie_credits?api_key=34142515d9d23817496eeb4ff1d223d0&append_to_response=credits&language=he&sort_by=popularity.desc'%url
    else:
       link='https://api.themoviedb.org/3/person/%s/tv_credits?api_key=34142515d9d23817496eeb4ff1d223d0&append_to_response=credits&language=he&sort_by=popularity.desc'%url
   
    headers = {
                                
                                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
                                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                                'Accept-Language': 'en-US,en;q=0.5',
                                'Connection': 'keep-alive',
                                'Upgrade-Insecure-Requests': '1',
                            }
    html=requests.get(link,headers=headers).json()
   
    if tv_mode=='movie':
        url_g=domain_s+'api.themoviedb.org/3/genre/movie/list?api_key=34142515d9d23817496eeb4ff1d223d0&language=he'
        html_g=html_g_movie
    else:
       url_g=domain_s+'api.themoviedb.org/3/genre/tv/list?api_key=34142515d9d23817496eeb4ff1d223d0&language=he'
       html_g=html_g_tv
    #html_g=requests.get(url_g,headers=headers).json()
    
    if tv_mode=='movie':
      test=html['cast']
      mode=4
    else:
      test=html['cast']
      mode=7
    for items in test:
        
        icon=items['poster_path']
        fanart=items['backdrop_path']
        if icon==None:
          icon=' '
        else:
          icon=domain_s+'image.tmdb.org/t/p/original/'+icon
        if fanart==None:
          fanart=' '
        else:
          fanart=domain_s+'image.tmdb.org/t/p/original/'+fanart
        plot=items['overview']
        if tv_mode=='movie':
          original_title=items['original_title']
        else:
          original_title=items['original_name']
        id=items['id']
        rating=items['vote_average']
        if tv_mode=='movie':
          title=items['title']
        else:
          title=items['name']
        if 'first_air_date' in items:
           year=str(items['first_air_date'].split("-")[0])
        else:
            if 'release_date' in items:
              year=str(items['release_date'].split("-")[0])
            else:
              year=' '
        genres_list= dict([(i['id'], i['name']) for i in html_g['genres'] \
                    if i['name'] is not None])
        genere = u' / '.join([genres_list[x] for x in items['genre_ids']])
        #except:genere=''
        
        video_data={}
        video_data['title']=title
        video_data['poster']=fanart
        video_data['plot']=plot
        video_data['icon']=icon
        video_data['genre']=genere
        video_data['rating']=rating
        video_data['year']=year
        addDir3(title,'www',mode,icon,fanart,plot,data=year,original_title=original_title,id=str(id),rating=rating,heb_name=title,show_original_year=year,isr=0,generes=genere,video_info=video_data)
        logging.warning('H2')
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_YEAR)
        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
        

        xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_RATING)
def search_actor():
    search_entered=''
    keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש כאן')
    keyboard.doModal()
    if keyboard.isConfirmed():
           search_entered = keyboard.getText()
           link='https://api.themoviedb.org/3/search/person?api_key=34142515d9d23817496eeb4ff1d223d0&language=he&query=%s&page=1&include_adult=false'%search_entered
           headers = {
                                
                                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
                                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                                'Accept-Language': 'en-US,en;q=0.5',
                                'Connection': 'keep-alive',
                                'Upgrade-Insecure-Requests': '1',
                            }
           html=requests.get(link,headers=headers).json()
           for items in html['results']:
                    icon=items['profile_path']
                    fanart=items['known_for'][0]['backdrop_path']
                    if icon==None:
                      icon=' '
                    else:
                      icon=domain_s+'image.tmdb.org/t/p/original/'+icon
                    if fanart==None:
                      fanart=' '
                    else:
                      fanart=domain_s+'image.tmdb.org/t/p/original/'+fanart
                    addDir3(items['name'],str(items['id']),73,icon,fanart,items['name'])
def fix_links(all_f_links,iconimage,image,plot,show_original_year,season,episode):
    all_data=[]
    all_rd_s={}
    all_rd_servers=[]
    count_r=0
    if season!=None and season!="%20":
          tv_movie='tv'
      
          
    else:
          tv_movie='movie'
   
    for name_f in all_f_links:
       
       if name_f!='subs' :
     
        
        for name,link,server,quality in all_f_links[name_f]['links']:
           name=name.decode('utf-8','ignore').encode("utf-8")
           fixed_q=fix_q(quality)
          
          
           se='-%s-'%name_f   
           if all_f_links[name_f]['rd']==True:
            
            
             
             if name_f not in all_rd_servers:
                all_rd_servers.append(name_f)
                
           if all_f_links[name_f]['subs']==True:
             plot=plot+'-HebDub-'
             pre='101'
          
           else:
             if 'pre' in all_f_links[name_f]:
               pre=all_f_links[name_f]['pre']
             else:
               pre=check_pre(name,all_f_links['subs']['links'],original_title)
            
           check=False
        
           
             
           all_data.append(('[COLOR %s][%s] '%(all_f_links[name_f]['color'],name_f)+name+" - "+server+'[/COLOR]', str(link),iconimage,image,plot,show_original_year,quality,se,fixed_q,name,pre))
    if tv_movie=='movie':
        order_by=Addon.getSetting("order_movie")
    else:
        order_by=Addon.getSetting("order_tv")
 
    logging.warning('order_by:'+order_by)
    if order_by=='0':
      all_fv=[]
      all_rest=[]
      if Addon.getSetting("full_q")=='true'  and  tv_movie=='movie':
        all_data=sorted(all_data, key=lambda x: x[8], reverse=False)
      elif Addon.getSetting("full_q_tv")=='true'  and  tv_movie=='tv':
        all_data=sorted(all_data, key=lambda x: x[8], reverse=False)
      else:
          if Addon.getSetting("fav_servers_en")=='true'  and  tv_movie=='movie':
            all_fv_servers=Addon.getSetting("fav_servers").split(',')
          elif Addon.getSetting("fav_servers_en_tv")=='true'   and  tv_movie=='tv':
            logging.warning('In fav')
            all_fv_servers=Addon.getSetting("fav_servers_tv").split(',')
          else:
            all_fv_servers=[]
          for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre in all_data:
            if server.replace('-','') in all_fv_servers:
                all_fv.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre))
            else:
                all_rest.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre))
          all_fv=sorted(all_fv, key=lambda x: x[8], reverse=False)
          
          all_rest=sorted(all_rest, key=lambda x: x[8], reverse=False)
          all_data=[]
          for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre in all_fv:
             all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre))
          for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre in all_rest:
             all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre))
      
    elif order_by=='1':
      all_fv=[]
      all_rest=[]
      if Addon.getSetting("fav_servers_en")=='true'  and  tv_movie=='movie':
        all_fv_servers=Addon.getSetting("fav_servers").split(',')
      elif Addon.getSetting("fav_servers_en_tv")=='true' and  tv_movie=='tv':
        logging.warning('In fav')
        all_fv_servers=Addon.getSetting("fav_servers_tv").split(',')
      else:
        all_fv_servers=[]
      
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre in all_data:
        if server.replace('-','') in all_fv_servers:
            all_fv.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre))
        else:
            all_rest.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre))
      all_fv=sorted(all_fv, key=lambda x: x[10], reverse=True)
      
      all_rest=sorted(all_rest, key=lambda x: x[10], reverse=True)
      all_data=[]
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre in all_fv:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre))
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre in all_rest:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre))
   
    
    elif order_by=='2':
      all_2160=[]
      all_1080=[]
      all_720=[]
      all_480=[]
      all_else=[]
      all_rd=[]
      all_rd_2160=[]
      all_rd_1080=[]
      all_rd_720=[]
      all_rd_480=[]
      all_rd_else=[]
      
      all_fv_2160=[]
      
      all_fv_1080=[]
      all_fv_720=[]
      all_fv_480=[]
      all_fv_else=[]
      logging.warning('Trying fav')
      if Addon.getSetting("fav_servers_en")=='true' and tv_movie=='movie':
        all_fv_servers=Addon.getSetting("fav_servers").split(',')
      elif Addon.getSetting("fav_servers_en_tv")=='true'  and  tv_movie=='tv':
        logging.warning('In fav')
        all_fv_servers=Addon.getSetting("fav_servers_tv").split(',')
      else:
        all_fv_servers=[]
        
      max_q='99'
      max_q_t=['2160','1080','720','480','360']
      if Addon.getSetting("auto_q_source")=='true':
        if tv_movie=='tv':
          max_q=Addon.getSetting("max_quality_t")
        else:
          max_q=Addon.getSetting("max_quality_m")
        max_q_v=max_q_t[int(max_q)]
      
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre in all_data:
        q=q.replace('p','').replace('4K','2160').replace('4k','2160')
        try:
         a=int(q)
        except:
          q='0'
        if max_q!='99':
           if int(q)>int(max_q_v):
             continue
        if q=='0':
          q='UNKN'
        if server.replace('-','') in all_fv_servers:
            if q=='2160':
             all_fv_2160.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre))
            elif q=='1080':
             all_fv_1080.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre))
            elif q=='720':
             all_fv_720.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre))
            elif q=='480':
             all_fv_480.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre))
            else :
             all_fv_else.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre))
             
        
        elif server.replace('-','') in all_rd_servers:
            if q=='2160':
             all_rd_2160.append((name,link,icon,image,plot,year,q,server+' RD SOURCE ',f_q,saved_name,pre))
            elif q=='1080':
             all_rd_1080.append((name,link,icon,image,plot,year,q,server+' RD SOURCE ',f_q,saved_name,pre))
            elif q=='720':
             all_rd_720.append((name,link,icon,image,plot,year,q,server+' RD SOURCE ',f_q,saved_name,pre))
            elif q=='480':
             all_rd_480.append((name,link,icon,image,plot,year,q,server+' RD SOURCE ',f_q,saved_name,pre))
            else :
             all_rd_else.append((name,link,icon,image,plot,year,q,server+' RD SOURCE ',f_q,saved_name,pre))
        else:
            if q=='2160':
             all_2160.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre))
            elif q=='1080':
             all_1080.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre))
            elif q=='720':
             all_720.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre))
            elif q=='480':
             all_480.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre))
            else :
             all_else.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre))
      all_fv_2160=sorted(all_fv_2160, key=lambda x: x[10], reverse=True)
      all_fv_1080=sorted(all_fv_1080, key=lambda x: x[10], reverse=True)
      all_fv_720=sorted(all_fv_720, key=lambda x: x[10], reverse=True)
      all_fv_480=sorted(all_fv_480, key=lambda x: x[10], reverse=True)
      all_fv_else=sorted(all_fv_else, key=lambda x: x[10], reverse=True)
      
      all_rd_2160=sorted(all_rd_2160, key=lambda x: x[10], reverse=True)
      all_rd_1080=sorted(all_rd_1080, key=lambda x: x[10], reverse=True)
      all_rd_720=sorted(all_rd_720, key=lambda x: x[10], reverse=True)
      all_rd_480=sorted(all_rd_480, key=lambda x: x[10], reverse=True)
      all_rd_else=sorted(all_rd_else, key=lambda x: x[10], reverse=True)
      
      all_2160=sorted(all_2160, key=lambda x: x[10], reverse=True)
      all_1080=sorted(all_1080, key=lambda x: x[10], reverse=True)
      all_720=sorted(all_720, key=lambda x: x[10], reverse=True)
      all_480=sorted(all_480, key=lambda x: x[10], reverse=True)
      all_else=sorted(all_else, key=lambda x: x[10], reverse=True)
      all_data=[]
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre in all_fv_2160:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre))
         
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre in all_fv_1080:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre))
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre in all_fv_720:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre))
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre in all_fv_480:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre))
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre in all_fv_else:
        all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre))
      
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre in all_rd_2160:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre))
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre in all_rd_1080:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre))
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre in all_rd_720:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre))
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre in all_rd_480:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre))
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre in all_rd_else:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre))
      
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre in all_2160:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre))
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre in all_1080:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre))
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre in all_720:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre))
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre in all_480:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre))
      for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre in all_else:
         all_data.append((name,link,icon,image,plot,year,q,server,f_q,saved_name,pre))
 
    return all_data
class selection_time(pyxbmct.AddonDialogWindow):
    
    def __init__(self, title='',item=''):
       
        super(selection_time, self).__init__(title)
        self.item=[item,'נגן מההתחלה']
        self.setGeometry(350, 150,1, 1,pos_x=700, pos_y=200)
        self.list_index=-1

        
        
        self.set_active_controls()
        self.set_navigation()
        # Connect a key action (Backspace) to close the window.
        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)
       

    
    def get_selection(self):
        """ get final selection """
        return self.list_index
    def click_list(self):
       
        self.list_index=self.list.getSelectedPosition()
       
        self.close()
    
    def set_active_controls(self):
     
      
        # List
        self.list = pyxbmct.List()
        self.placeControl(self.list, 0,0,  rowspan=2, columnspan=1)
        # Add items to the list
        
       
        self.list.addItems(self.item)
        
        # Connect the list to a function to display which list item is selected.
        self.connect(self.list, self.click_list)
        
       

    def set_navigation(self):
        
        self.setFocus(self.list)

    

    

    def setAnimation(self, control):
        # Set fade animation for all add-on window controls
        control.setAnimations([('WindowOpen', 'effect=fade start=0 end=100 time=50',),
                                ('WindowClose', 'effect=fade start=100 end=0 time=50',)])
class whats_new(pyxbmct.AddonDialogWindow):
    
    def __init__(self, title='',img=' ',txt=''):
    
        super(whats_new, self).__init__(title)

        self.setGeometry(1000, 600, 4,4)
   
        self.img=img
        self.txt=txt
        self.set_info_controls()
        self.set_active_controls()
        self.set_navigation()
        # Connect a key action (Backspace) to close the window.
        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)

    
    def set_info_controls(self):
      
      
     
        self.image = pyxbmct.Image( self.img)
        self.placeControl(self.image, 0, 0, 3, 2)
        self.textbox = pyxbmct.TextBox(font='Med')
        
        self.placeControl(self.textbox, 0,2, 4, 2)
        self.textbox.setText(self.txt)
        # Set auto-scrolling for long TexBox contents
        self.textbox.autoScroll(3000, 3000, 3000)
       
  
    def click_c(self):
       
        self.close()
    def set_active_controls(self):
     
      
       
        
        # Connect key and mouse events for list navigation feedback.
        
     
        
        self.button = pyxbmct.Button('Close')
        self.placeControl(self.button, 3, 0)
        # Connect control to close the window.
        self.connect(self.button, self.click_c)

    def set_navigation(self):
        # Set navigation between controls
        
        self.button.controlDown(self.button)
        self.button.controlUp(self.button)
        # Set initial focus
        self.setFocus(self.button)
       

   

    def setAnimation(self, control):
        # Set fade animation for all add-on window controls
        control.setAnimations([('WindowOpen', 'effect=fade start=0 end=100 time=500',),
                                ('WindowClose', 'effect=fade start=100 end=0 time=500',)])
                                
                                
class fav_mv(xbmcgui.WindowXMLDialog):
    
    def __new__(cls, addonID,id):
        
        FILENAME='moviefavorite.xml'
        
        return super(fav_mv, cls).__new__(cls, FILENAME,Addon.getAddonInfo('path'), 'DefaultSkin')
        

    def __init__(self, addonID,id):
        super(fav_mv, self).__init__()
        self.id=id
        self.all_d={}
        self.closenow=0
        try:
            self.time_c=xbmc.Player().getTotalTime()-xbmc.Player().getTime()
        except:
            self.time_c=30
        #Thread(target=self.background_task).start()
        
        #Thread(target=self.get_similer).start()
    
    def onInit(self):
        a=1
        x='http://api.themoviedb.org/3/movie/%s/recommendations?api_key=34142515d9d23817496eeb4ff1d223d0&language=heb&page=1'%self.id
        html=requests.get(x).json()
        loc=random.randint(0,len(html['results'])-1)
        self.all_d={}
        self.all_d['title']=html['results'][loc]['title']
        self.all_d['icon']=domain_s+'image.tmdb.org/t/p/original/'+html['results'][loc]['poster_path']
        self.all_d['fan']=domain_s+'image.tmdb.org/t/p/original/'+html['results'][loc]['backdrop_path']
        self.all_d['original_title']=html['results'][loc]['original_title']
        self.all_d['plot']=html['results'][loc]['overview']
        self.all_d['n_id']=html['results'][loc]['id']
        html_g=html_g_movie
        genres_list= dict([(i['id'], i['name']) for i in html_g['genres'] \
                if i['name'] is not None])
        try:self.all_d['genere'] = u' / '.join([genres_list[x] for x in html['results'][loc]['genre_ids']])
        except:self.all_d['genere']=''
        self.all_d['rating']=str(html['results'][loc]['vote_average'])
        if 'release_date' in html['results'][loc]:
            self.all_d['year']=str(html['results'][loc]['release_date'].split("-")[0])
        else:
            self.all_d['year']='0'
        #self.getControl(101).setImage(self.all_d['icon'])
        self.getControl(103).setImage(self.all_d['fan'])
        self.getControl(102).setLabel('[COLOR blue][B]'+self.all_d['title']+' - '+self.all_d['year']+ ' - '+self.all_d['rating']+'[/B][/COLOR]')
        self.getControl(104).setText(self.all_d['plot'])
        self.getControl(105).setLabel(self.all_d['genere'])
        Thread(target=self.background_task).start()
    def onAction(self, action):
        global stop_window,once_fast_play
        
        actionId = action.getId()

        if actionId in [ACTION_CONTEXT_MENU, ACTION_C_KEY]:
            
            stop_window=True
            #self.close_tsk=1
            
            
            return self.close()

        if actionId in [ACTION_PARENT_DIR, ACTION_PREVIOUS_MENU, ACTION_BACK]:
           
            stop_window=True
          
            return self.close()
    def background_task(self):
            global list_index
            t=int(self.time_c)*10
            counter_close=0
            self.progressControl = self.getControl(3014)
            e_close=0
            before_end=int(Addon.getSetting("window_movie"))*10
            counter_close2=before_end
            while(t>30):
                try:
                    t=(xbmc.Player().getTotalTime()-xbmc.Player().getTime())*10
                except:
                    pass
                self.label=self.getControl(3015)
                self.label.setLabel(('%s')%str(int(counter_close2)/10))
                self.label=self.getControl(3016)
                self.label.setLabel(('סוף הסרט בעוד %s')%str(int(t)/10))
                counter_close2-=1
                if counter_close2==0:
                    t=0
                    break
                if t<counter_close2:
                    sh_p=t
                else:
                    sh_p=counter_close2
                self.currentProgressPercent=int((sh_p*100)/before_end)
           
                self.progressControl.setPercent(self.currentProgressPercent)
                xbmc.sleep(100)
                
                if self.closenow==1:
                    break
             
            self.close()

    def onClick(self, controlId):
        
        stop_window=True
        self.closenow=1
        if controlId==201:
            settings=Addon.getSetting
            fav_search_f=settings("fav_search_f_tv")
            fav_servers_en=settings("fav_servers_en_tv")
            fav_servers=settings("fav_servers_tv")
            google_server= settings("google_server_tv")
            rapid_server=settings("rapid_server_tv")
            direct_server=settings("direct_server_tv")
            heb_server=settings("heb_server_tv")
            if  fav_search_f=='true' and fav_servers_en=='true' and (len(fav_servers)>0 or heb_server=='true' or google_server=='true' or rapid_server=='true' or direct_server=='true'):
                
                fav_status='true'
            else:
                fav_status='false'
            xbmc.executebuiltin(('ActivateWindow(10025,"plugin://plugin.video.allmoviesin/?data=%s&dates=EMPTY&description=%s&eng_name=%s&episode=%s&fanart=%s&heb_name=%s&iconimage=%s&id=%s&isr=0&mode=4&name=%s&original_title=%s&season=%s&show_original_year=%s&tmdbid=EMPTY&url=%s&fast_link=%s&fav_status=%s",return)'%(self.all_d['year'],urllib.quote_plus(self.all_d['plot'].encode('utf-8')),self.all_d['original_title'],str(int(0)),urllib.quote_plus(self.all_d['fan']),self.all_d['title'],urllib.quote_plus(self.all_d['icon']),self.all_d['n_id'],self.all_d['title'],self.all_d['original_title'],'0',self.all_d['year'],' ',' ',fav_status)).replace('EMPTY','%20'))
      
        self.close()
        
    
    def onFocus(self, controlId):
        pass 

class MyAddon_clean(pyxbmct.AddonDialogWindow):
    def __init__(self,title='הפרק הבא',txt=''):
        super(MyAddon_clean, self).__init__(title)
        px=int(Addon.getSetting("px"))
        py=int(Addon.getSetting("py"))
        
        self.txt=txt
        self.setGeometry(500, 200, 4, 10,pos_x=px, pos_y=py)
        try:
            self.time_c=xbmc.Player().getTotalTime()-xbmc.Player().getTime()
        except:
            self.time_c=30
        
        self.set_info_controls()
        self.set_navigation()
        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)
        Thread(target=self.background_task).start()
    def background_task(self):
        global list_index
        t=int(self.time_c)*10
        counter_close=0
        
        e_close=0
        before_end=int(Addon.getSetting("before_end2"))*10
        counter_close2=before_end
        while(t>30):
          xbmc.sleep(100)
          self.label.setLabel(('פרק הבא בעוד %s שניות')%str(int(counter_close2)/10))
          #self.button.setLabel(('סגור %s')%str(int(counter_close)/10))
          self.button.setLabel(('סגור %s')%str(int(((int(Addon.getSetting("window"))+1)*10)-counter_close)/10))
          
          counter_close+=1
          counter_close2-=1
          if counter_close2==0:
            t=0
            break
          if counter_close>((int(Addon.getSetting("window"))+1)*10):
            e_close=1
          try:
             t=(xbmc.Player().getTotalTime()-xbmc.Player().getTime())*10
          except:
             t=0
             pass
        if e_close==1:
            list_index=888
            logging.warning('Eclose')
        else:
            list_index=0
        self.close()
    def click_c(self):
        global list_index
        list_index=888
        current_list_item=''
        self.close()
    def click_c2(self):
        global list_index
        list_index=0
        current_list_item=''
        self.close()
    def set_info_controls(self):
        self.label = pyxbmct.Label('פרק הבא בעוד 15 שניות')
        self.placeControl(self.label,  2, 3,7,7)
        
        self.label2 = pyxbmct.Label(self.txt)
        self.placeControl(self.label2,  1, 3,7,7)
        self.button = pyxbmct.Button('סגור')
        self.placeControl(self.button, 3, 5,1,4)
        # Connect control to close the window.
        self.connect(self.button, self.click_c)
        
        self.button2 = pyxbmct.Button('נגן')
        self.placeControl(self.button2, 3, 0,1,4)
        # Connect control to close the window.
        self.connect(self.button2, self.click_c2)
    def set_navigation(self):
        # Set navigation between controls
        
        self.button.controlDown(self.button2)
        self.button.controlUp(self.button2)
        
        self.button.controlLeft(self.button2)
        self.button.controlRight(self.button2)
        
                
        self.button2.controlDown(self.button)
        self.button2.controlUp(self.button)
        
        self.button2.controlLeft(self.button)
        self.button2.controlRight(self.button)
        
        # Set initial focus
        self.setFocus(self.button2)
    def setAnimation(self, control):
        # Set fade animation for all add-on window controls
        control.setAnimations([('WindowOpen', 'effect=fade start=0 end=100 time=500',),
                                ('WindowClose', 'effect=fade start=100 end=0 time=500',)])
class MyAddon(pyxbmct.AddonDialogWindow):
    
    def __init__(self, title='',list=[],time_c=10,img=' ',txt=''):
    
        super(MyAddon, self).__init__(title)
        self.list_o=list
        self.title=title
        wd=int(Addon.getSetting("width"))
        hd=int(Addon.getSetting("hight"))
        px=int(Addon.getSetting("px"))
        py=int(Addon.getSetting("py"))
        
        self.setGeometry(wd, hd, 9, 1,pos_x=px, pos_y=py)
        self.time_c=time_c
        self.img=img
        self.txt=txt
        self.set_info_controls()
        self.set_active_controls()
        self.set_navigation()
        # Connect a key action (Backspace) to close the window.
        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)
        Thread(target=self.background_task).start()
    def background_task(self):
        global list_index
        t=int(self.time_c)*10
        
        while(t>30):
          xbmc.sleep(100)
          self.label.setLabel(str(int(t)/10))
          
          windowsid=xbmcgui.getCurrentWindowDialogId()
        
          if windowsid==10153 or windowsid==10101:
            break
          if 'הפרק הבא' in self.title:
           try:
             t=(xbmc.Player().getTotalTime()-xbmc.Player().getTime())*10
           except:
             t=0
             pass
          else:
            t-=1
        list_index=999
        self.close()
    def set_info_controls(self):
      
      
         # Label
        self.label = pyxbmct.Label(str(int(self.time_c)))
        self.placeControl(self.label,  4, 0, 3, 1)
        self.image = pyxbmct.Image( self.img)
        self.placeControl(self.image, 0, 0, 2, 1)
        self.textbox = pyxbmct.TextBox()
        
        self.placeControl(self.textbox, 2,0, 2, 1)
        self.textbox.setText(self.txt)
        # Set auto-scrolling for long TexBox contents
        self.textbox.autoScroll(1000, 1000, 1000)
       
    def click_list(self):
        global list_index
        list_index=self.list.getSelectedPosition()
        self.close()
    def click_c(self):
        global list_index
        list_index=888
        current_list_item=''
        self.close()
    def set_active_controls(self):
     
      
        # List
        self.list = pyxbmct.List()
        self.placeControl(self.list, 4, 0, 4, 1)
        # Add items to the list
        items = self.list_o
        n_items=[]
        a_links=[]
        for it in items:
         
          n_items.append(it.split('$$$$$$$')[0])
          a_links.append(it.split('$$$$$$$')[1])
        self.list.addItems(n_items)
        # Connect the list to a function to display which list item is selected.
        self.connect(self.list, self.click_list)
        
        # Connect key and mouse events for list navigation feedback.
        
     
        
        self.button = pyxbmct.Button('Close')
        self.placeControl(self.button, 8, 0)
        # Connect control to close the window.
        self.connect(self.button, self.click_c)

    def set_navigation(self):
        # Set navigation between controls
        
        self.list.controlDown(self.button)
        self.button.controlUp(self.list)
        # Set initial focus
        self.setFocus(self.list)

    def slider_update(self):
        # Update slider value label when the slider nib moves
        try:
            if self.getFocus() == self.slider:
                self.slider_value.setLabel('{:.1F}'.format(self.slider.getPercent()))
        except (RuntimeError, SystemError):
            pass

    def radio_update(self):
        # Update radiobutton caption on toggle
        if self.radiobutton.isSelected():
            self.radiobutton.setLabel('On')
        else:
            self.radiobutton.setLabel('Off')

    def list_update(self):
        # Update list_item label when navigating through the list.
        try:
            if self.getFocus() == self.list:
                self.list_item_label.setLabel(self.list.getListItem(self.list.getSelectedPosition()).getLabel())
            else:
                self.list_item_label.setLabel('')
        except (RuntimeError, SystemError):
            pass

    def setAnimation(self, control):
        # Set fade animation for all add-on window controls
        control.setAnimations([('WindowOpen', 'effect=fade start=0 end=100 time=500',),
                                ('WindowClose', 'effect=fade start=100 end=0 time=500',)])
def load_test_data(title,icon,fanart,plot,s_title,season,episode,list):
    test_episode = {"episodeid": 0, "tvshowid": 0, "title": title, "art": {}}
    test_episode["art"]["tvshow.poster"] = icon
    test_episode["art"]["thumb"] = icon
    test_episode["art"]["tvshow.fanart"] = fanart
    test_episode["art"]["tvshow.landscape"] =fanart
    test_episode["art"]["tvshow.clearart"] = fanart
    test_episode["art"]["tvshow.clearlogo"] = icon
    test_episode["plot"] = plot
    test_episode["showtitle"] =s_title
    test_episode["playcount"] = 1
    test_episode["season"] =int( season)
    test_episode["episode"] = int(episode)
    test_episode["seasonepisode"] = "%sx%s"%(season,episode)
    test_episode["rating"] = None
    test_episode["firstaired"] = ""
    test_episode["list"]=list
    return test_episode
def nextup(dbcur,settings):
    

    try:
        global list_index,done_nextup,all_s_in,done1
        list=[]

        time_to_save=int(settings["save_time"])
        
        dbcur.execute("SELECT * FROM nextup")

        match = dbcur.fetchone()
        
        fast_link=' '
        if match!=None:
            name,url,icon,image,plot,year,season,episode,original_title,heb_name,show_original_year,eng_name,isr,id=match
            name=str(name)
          
            url=str(url)
            icon=str(icon)
            image=str(image)
            plot=str(plot).replace('%27',"'")
            year=str(year)
            season=str(season)
            episode=str(episode)
            original_title=str(original_title)

            heb_name=str(heb_name.decode('utf-8')).replace('%27',"'")
            show_original_year=str(show_original_year)
            eng_name=str(eng_name).replace('%27',"'")
            isr=str(isr)
            id=str(id)
            
            
            iconimage=icon
            fanart=image
            data=year
            
            description=plot.replace('-פרק ','').replace('-NEXTUP-','').encode('utf8')
            fav_search_f=settings["fav_search_f_tv"]
            fav_servers_en=settings["fav_servers_en_tv"]
            fav_servers=settings["fav_servers_tv"]
            google_server= settings["google_server_tv"]
            rapid_server=settings["rapid_server_tv"]
            direct_server=settings["direct_server_tv"]
            heb_server=settings["heb_server_tv"]
            
       
            if  fav_search_f=='true' and fav_servers_en=='true' and (len(fav_servers)>0 or heb_server=='true' or google_server=='true' or rapid_server=='true' or direct_server=='true'):
            
                fav_status='true'
            else:
                fav_status='false'
            if debug_mode==True:
                
                logging.warning('nextup sources')
            f_subs=[]
            match_a,all_links_fp,all_pre,f_subs,current_subs= cache.get(c_get_sources, time_to_save, original_title,year,original_title,season,str(int(episode)),id,eng_name,show_original_year,heb_name,isr,False,fav_status,'no','0', table='pages')
            
            all_s_in=( {},100 ,'',4,'')
            all_data=fix_links(match_a,iconimage,fanart,description,show_original_year,season,episode)
            #xbmc.executebuiltin((u'Notification(%s,%s)' % ('Nextup Runing', 'מחכה למידע מTMDB')).encode('utf-8'))
            #logging.warning('Nextup Runing:'+ 'מחכה למידע מTMDB')
            from tmdb import get_episode_data
            name_n,plot_n,image_n,season,episode=get_episode_data(id,season,str(int(episode)))
            if settings["auto_nextup"]=='true':
                list.append('[COLOR yellow]ניגון אוטומטי[/COLOR]'+'$$$$$$$'+'autoPlay')
            
            for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre in all_data:
                tes_mag=re.compile('- P(.+?)/S(.+?) -').findall(server)
                check=False
                if ('magnet' in server or len(tes_mag)>0): 
                   if (settings["all_t"]!='2' ):
                    check=True
                else:
                    check=True
                if check:
                    list.append('[COLOR yellow]'+str(pre)+'%[/COLOR]-[COLOR gold]'+q+'[/COLOR][COLOR lightblue]'+server+'[/COLOR]-'+name.replace('openload','vummo').replace('letsupload','avlts')+'$$$$$$$'+link)
            #logging.warning(list)
            #return list
            fast_link=list[0].split('$$$$$$$')[1]
            try:
                time_left=xbmc.Player().getTotalTime()-xbmc.Player().getTime()
            except:
                time_left=30
                pass
            if len(current_subs)>0:
                f_name='[COLOR peru] ◄ יש כתוביות [/COLOR]\n'
            else:
                f_name='[COLOR red] ֎ אין כתוביות [/COLOR]\n'
            if settings['nextup_style']=='1':
                window = MyAddon_clean('הפרק הבא - '+name_n,f_name)
                window.doModal()
           
                del window
            elif settings['nextup_style']=='2':
                def calculate_progress_steps(period):
                    return (100.0 / int(period)) / 10
                next_up_page = UpNext("script-upnext-upnext.xml",Addon.getAddonInfo('path'), "DefaultSkin", "1080i")
                                          
                ep=load_test_data(name_n,image_n,image_n,plot,heb_name,season,episode,list)
                
                next_up_page.setItem(ep)

                next_up_page.setProgressStepSize(calculate_progress_steps(30))
                next_up_page.doModal()
                del next_up_page
            else:
                window = MyAddon('הפרק הבא - '+name_n ,list,time_left,image_n,f_name+plot_n)
                window.doModal()
           
                del window
            play_now=False
            logging.warning('list_index final:'+str(list_index))
            
            playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            playlist.clear()
            result = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Playlist.Clear", "params": { "playlistid": 0 }, "id": 1}')
            if list_index!=999 and list_index!=888:
                xbmc.Player().stop()
                xbmc.sleep(2)
                logging.warning('Victory Stoped')
                fast_link=list[list_index].split('$$$$$$$')[1]
                #xbmc.executebuiltin(('XBMC.PlayMedia("plugin://plugin.video.allmoviesin/?data=%s&dates=EMPTY&description=%s&eng_name=%s&episode=%s&fanart=%s&heb_name=%s&iconimage=%s&id=%s&isr=0&mode=4&name=%s&original_title=%s&season=%s&show_original_year=%s&tmdbid=EMPTY&url=%s&fast_link=%s",return)'%(data,urllib.quote_plus(description),eng_name,str(int(episode)+1),urllib.quote_plus(fanart),heb_name,urllib.quote_plus(iconimage),id,name,original_title,season,show_original_year,urllib.quote_plus(fast_link),urllib.quote_plus(fast_link))).replace('EMPTY','%20'))

            if settings['play_nextup_wait']=='false' and list_index==999:
                return '0'
            if list_index==888: 
                return '0'
            if fast_link!=' ':
                n_fast_link=fast_link
                if settings["fast_play2_tv"]=='true':
                    
                    if list_index==999:
                        n_fast_link='999'
                    else:
                       n_fast_link=fast_link
                    
                
                logging.warning('Next episode now')
                logging.warning('Next episode again')
                #
                
                logging.warning('fast_link first:'+fast_link)
                #xbmc.executebuiltin(('XBMC.PlayMedia("plugin://plugin.video.allmoviesin/?data=%s&dates=EMPTY&description=%s&eng_name=%s&episode=%s&fanart=%s&heb_name=%s&iconimage=%s&id=%s&isr=0&mode=4&name=%s&original_title=%s&season=%s&show_original_year=%s&tmdbid=EMPTY&url=%s&fast_link=%s",return)'%(data,urllib.quote_plus(description),eng_name,str(int(episode)+1),urllib.quote_plus(fanart),heb_name,urllib.quote_plus(iconimage),id,name,original_title,season,show_original_year,urllib.quote_plus(url),urllib.quote_plus(fast_link))).replace('EMPTY','%20'))
                #if settings("fast_play2_tv")=='true':
                    
                result = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Playlist.Clear", "params": { "playlistid": 0 }, "id": 1}')
                xbmc.Player().stop()
                logging.warning('Victory Stoped2')
                xbmc.sleep(2)
                done_nextup=0
                xbmc.executebuiltin(('ActivateWindow(10025,"plugin://plugin.video.allmoviesin/?data=%s&dates=EMPTY&description=%s&eng_name=%s&episode=%s&fanart=%s&heb_name=%s&iconimage=%s&id=%s&isr=0&mode=4&name=%s&original_title=%s&season=%s&show_original_year=%s&tmdbid=EMPTY&url=%s&fast_link=%s&fav_status=%s",return)'%(data,urllib.quote_plus(description),eng_name,str(int(episode)),urllib.quote_plus(fanart),heb_name,urllib.quote_plus(iconimage),id,name,original_title,season,show_original_year,urllib.quote_plus(n_fast_link),urllib.quote_plus(n_fast_link),fav_status)).replace('EMPTY','%20'))
                    
                xbmc.executebuiltin( "XBMC.Action(Fullscreen)" )
                return '0'
                mode=1999
                    #sys.exit()
                '''
                playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                playlist.clear()
                for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre in all_data:
                    listItem=xbmcgui.ListItem(name, iconImage=icon, thumbnailImage=image)
                    listItem.setInfo('video', {'Title': name, 'Genre': 'Kids'})
                    link2=(('plugin://plugin.video.allmoviesin/?data=%s&dates=EMPTY&description=%s&eng_name=%s&episode=%s&fanart=%s&heb_name=%s&iconimage=%s&id=%s&isr=0&mode=4&name=%s&original_title=%s&season=%s&show_original_year=%s&tmdbid=EMPTY&url=%s&fast_link=%s'%(data,urllib.quote_plus(description),eng_name,str(int(episode)+1),urllib.quote_plus(fanart),heb_name,urllib.quote_plus(iconimage),id,name,original_title,season,show_original_year,urllib.quote_plus(link),urllib.quote_plus(link))).replace('EMPTY','%20'))
                    logging.warning(link2)
                    playlist.add(url=link2, listitem=listItem)
                play_now=True
                '''
    except Exception as e:
            import linecache
            exc_type, exc_obj, tb = sys.exc_info()
            f = tb.tb_frame
            lineno = tb.tb_lineno
            filename = f.f_code.co_filename
            linecache.checkcache(filename)
            line = linecache.getline(filename, lineno, f.f_globals)

            logging.warning('ERROR IN NEXTUP IN:'+str(lineno))
            logging.warning('inline:'+line)
            logging.warning('Error:'+str(e))
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('Error', 'inLine:'+str(lineno))).encode('utf-8'))
            done_nextup=1
            marked_trk=1
            
   
        
    return 0
def prepare_library(dbcon_kodi,dbcur_kodi):
   

    dbcur_kodi.execute("SELECT MAX(idFile) FROM movie")

    match = dbcur_kodi.fetchone()
    try:
        index=match[0]+1
    except:
        index=0
    
    dbcur_kodi.execute("SELECT MAX(idFile) FROM files")

    match = dbcur_kodi.fetchone()
    try:
        file_index=match[0]+1
    except:
        file_index=0

    dbcur_kodi.execute("SELECT MAX(art_id) FROM art")

    match = dbcur_kodi.fetchone()

    try:
        art_index=match[0]+1
    except:
        art_index=0
    dbcur_kodi.execute("SELECT * FROM genre")

    match = dbcur_kodi.fetchall()
    all_gen={}
    for g_id,nm in match:

        all_gen[nm]=g_id
    dbcur_kodi.execute("SELECT * FROM path")
    found=0
    match = dbcur_kodi.fetchall()
    for items in match:
        if items[0]==99879:
            found=1
    if found==0:
        dbcur_kodi.execute("INSERT INTO path Values ('99879', 'plugin://plugin.video.allmoviesin/', '', '', '', '','', '', '', '', '', '');")
        dbcon_kodi.commit()

    return index,file_index,art_index,all_gen
def add_item_to_lib(name,url,mode,icon,fan,plot,year,original_name,id,rating,new_name,isr,genere,trailer,fav_status,index,file_index,art_index,dbcon_kodi,dbcur_kodi,all_gen):

    
    icon_db='<thumb aspect="poster" preview="img_poster">img_poster</thumb><thumb aspect="poster" preview="img_poster">img_poster</thumb><thumb aspect="poster" preview="img_poster">img_poster</thumb><thumb aspect="poster" preview="img_poster">img_poster</thumb><thumb aspect="poster" preview="img_poster">img_poster</thumb><thumb aspect="poster" preview="img_poster">img_poster</thumb><thumb aspect="poster" preview="img_poster">img_poster</thumb><thumb aspect="poster" preview="img_poster">img_poster</thumb><thumb aspect="poster" preview="img_poster">img_poster</thumb><thumb aspect="poster" preview="img_poster">img_poster</thumb><thumb aspect="poster" preview="img_poster">img_poster</thumb><thumb aspect="poster" preview="img_poster">img_poster</thumb><thumb aspect="poster" preview="img_poster">img_poster</thumb><thumb aspect="poster" preview="img_poster">img_poster</thumb><thumb aspect="poster" preview="img_poster">img_poster</thumb><thumb aspect="poster" preview="img_poster">img_poster</thumb><thumb aspect="poster" preview="img_poster">img_poster</thumb><thumb aspect="poster" preview="img_poster">img_poster</thumb><thumb aspect="poster" preview="img_poster">img_poster</thumb><thumb aspect="poster" preview="img_poster">img_poster</thumb><thumb aspect="poster" preview="img_poster">img_poster</thumb><thumb aspect="poster" preview="img_poster">img_poster</thumb><thumb aspect="poster" preview="img_poster">img_poster</thumb><thumb aspect="poster" preview="img_poster">img_poster</thumb>'
    icon_db=icon_db.replace('img_poster',icon)
    fanart_db='<fanart><thumb preview="img_poster">img_poster</thumb><thumb preview="img_poster">img_poster</thumb><thumb preview="img_poster">img_poster</thumb><thumb preview="img_poster">img_poster</thumb><thumb preview="img_poster">img_poster</thumb><thumb preview="img_poster">img_poster</thumb><thumb preview="img_poster">img_poster</thumb><thumb preview="img_poster">img_poster</thumb><thumb preview="img_poster">img_poster</thumb><thumb preview="img_poster">img_poster</thumb><thumb preview="img_poster">img_poster</thumb><thumb preview="img_poster">img_poster</thumb><thumb preview="img_poster">img_poster</thumb></fanart>'
    fanart_db=fanart_db.replace('img_poster',fan)
    link=get_rest_data(name,url,mode,icon,fan,plot,data=year,original_title=original_name,id=id,rating=rating,heb_name=new_name,show_original_year=year,isr=isr,generes=genere,trailer=trailer,fav_status=fav_status).replace(' ','%20')
    dbcur_kodi.execute("INSERT INTO movie Values ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s');" %  (index,file_index,name.replace("'","''"),plot.replace("'","''"),'','',None,'99879','',None,icon_db,'99879','','','','0',genere,'',original_name.replace("'","''"),'','',trailer,fanart_db,'',url,'4',None,None,year))
    dbcur_kodi.execute("INSERT INTO files Values ('%s', '%s', '%s', '%s', '%s', '%s');" %  (file_index,'99879',link.replace("'","''"),'','',''))
    dbcur_kodi.execute("INSERT INTO art Values ('%s', '%s', '%s', '%s', '%s');" %  (art_index,index,'movie','fanart',fan))
    dbcur_kodi.execute("INSERT INTO art Values ('%s', '%s', '%s', '%s', '%s');" %  (art_index+1,index,'movie','poster',icon))
    for items in genere.split('/'):
        if items.strip() in all_gen:
            dbcur_kodi.execute("INSERT INTO genre_link Values ('%s', '%s', '%s');" %  (all_gen[items.strip()],index,'movie'))
    '''
    index+=1
    file_index+=1
    art_index+=2
    '''
def remove_color(name):
  
    regex='COLOR (.+?)\]'
    m=re.compile(regex).findall(name)
    if len(m)>0:
        for items in m:
            name=name.replace('[COLOR %s]'%items,'').replace('[/COLOR]','')
    
    regex='\[(.+?)\]'
    m=re.compile(regex).findall(name)
    if len(m)>0:
    
        name=name.replace(m[0],'[COLOR green]'+m[0]+'[/COLOR]')
        name=name.replace('[[','[').replace(']]',']')
    
    regex='\{(.+?)\}'
    m=re.compile(regex).findall(name)
    if len(m)>0:
        name=name.replace('{'+m[0]+'}','')
        name='{'+m[0]+'}'+name
        name=name.replace(m[0],'[COLOR blue]'+m[0]+'[/COLOR]')
    name_s=name.split('-')
  
    m=[]
    found=0
    sv_items2=''
    for items2 in name_s:
      
        try:
            
            x=float(items2.replace('GB','').split('{')[0])
            m.append(items2.split('{')[0])
            found=1
            
        except:
            pass
        if len(items2)>1:
            sv_items2=items2
    if found==0:
       
        name=name.replace(sv_items2,'[COLOR yellow]'+sv_items2+'[/COLOR]')
  
    if len(m)>0:
        name=name.replace(m[0],'')
        name=m[0]+'-'+name
        name=name.replace(m[0],'[COLOR coral]'+m[0]+'[/COLOR]')
  
    #name=name.replace('GB','[COLOR yellow]GB[/COLOR]')

    return name
def new_show_sources(m,data,description,eng_name,episode,image,heb_name,iconimage,id,prev_name,original_title,season,show_original_year,n,rest_data,n_magnet,only_heb,len_all_torrent_s,next_ep,count_heb,only_torrent,fast_link,collection_arr):
    global stop_try_play,done1,stop_auto_play
    original_data=[]
    original_data.append((m,data,description,eng_name,episode,image,heb_name,iconimage,id,prev_name,original_title,season,show_original_year,n,rest_data,n_magnet,only_heb,len_all_torrent_s,next_ep))
    
    global list_index

    list=[]
    
   
    stop_try_play=False

    menu=[]
    all_links=[]
    all_s_names=[]
    all_plot=[]
    all_server_name=[]
    real_index=0
    if len(only_heb)>0:
        list.append('[COLOR coral][I]►►►(%s) קישורים עם תרגום מובנה בלבד ◄◄◄[/I][/COLOR]'%count_heb+'$$$$$$$'+only_heb[0])
        menu.append(['[COLOR coral][I]►►►(%s) קישורים עם תרגום מובנה בלבד ◄◄◄[/I][/COLOR]'%count_heb, '','','','','',only_heb[0],''])
        all_links.append(only_heb[0])
        all_s_names.append('קישורים עם תרגום מובנה בלבד')
        all_plot.append('קישורים עם תרגום מובנה בלבד')
        all_server_name.append('0')
        real_index+=1
    if len(next_ep)>0:
        if 'העונה הבאה' in next_ep[0]:
            txt_ep_nex='פתח את הפרק של העונה הבאה'
        elif 'סדרה חדשה' in next_ep[0]:
           
           txt_ep_nex='המלצה לסדרה חדשה'
           if 'סדרה נגמרה' in next_ep[0]:
            txt_ep_nex=' הסדרה נגמרה.. ' +txt_ep_nex
           if 'המתן לעונה הבאה' in next_ep[0]:
            txt_ep_nex=' המתן לעונה הבאה.. '+txt_ep_nex
        else:
            txt_ep_nex='פתח את מקורות הפרק הבא'
            
        list.append('[COLOR khaki][I]►►► %s ◄◄◄[/I][/COLOR]'%txt_ep_nex+'$$$$$$$'+next_ep[0])
        menu.append(['[COLOR khaki][I]►►► %s ◄◄◄[/I][/COLOR]'%txt_ep_nex, '','','','','',next_ep[0],''])
        all_links.append(next_ep[0])
        all_s_names.append(txt_ep_nex)
        all_plot.append(txt_ep_nex)
        all_server_name.append('0')
        real_index+=1
    if len(collection_arr)>0:
        list.append('[COLOR khaki][I]►►► פתח אוסף ◄◄◄[/I][/COLOR]'+'$$$$$$$'+collection_arr[0])
        menu.append(['[COLOR khaki][I]►►► פתח אוסף ◄◄◄[/I][/COLOR]', '','','','','',collection_arr[0],''])
        all_links.append(collection_arr[0])
        all_s_names.append('פתח אוסף')
        all_plot.append('פתח אוסף')
        all_server_name.append('0')
        real_index+=1
    if len(n_magnet)>0:
        list.append('[COLOR khaki][I]►►►(%s) קישורי מגנט ◄◄◄[/I][/COLOR]'%len_all_torrent_s+'$$$$$$$'+n_magnet[0])
        menu.append(['[COLOR khaki][I]►►►(%s) קישורי מגנט ◄◄◄[/I][/COLOR]'%len_all_torrent_s, '','','','','',n_magnet[0],''])
        all_links.append(n_magnet[0])
        
        all_s_names.append('קישורי מגנט')
        all_plot.append('קישורי מגנט')
        all_server_name.append('0')
        real_index+=1
    if len(n)>0:
        list.append('[COLOR lightgreen][I]►►► שאר התוצאות ◄◄◄[/I][/COLOR]'+'$$$$$$$'+n[0])
        menu.append(['[COLOR lightgreen][I]►►► שאר התוצאות ◄◄◄[/I][/COLOR]', '','','','','',n[0],''])
        
        all_links.append(n[0])
        all_s_names.append('שאר התוצאות ')
        all_plot.append('שאר התוצאות ')
        all_server_name.append('0')
        real_index+=1
    if  Addon.getSetting("auto_enable_new")== 'true'  and (Addon.getSetting("new_window_type2")=='3' or Addon.getSetting("new_window_type2")=='4'):
        list.append('[COLOR khaki][I]►►►ניגון אוטומטי◄◄◄[/I][/COLOR]')
        menu.append(['[COLOR khaki][I]►►►ניגון אוטומטי ◄◄◄[/I][/COLOR]', '','','','','','',''])
        all_links.append('www')
        all_s_names.append('ניגון אוטומטי')
        all_plot.append('-ניגון אוטומטי-')
        all_server_name.append('0')
        real_index+=1
    if allow_debrid:
        rd_domains=cache.get(get_rd_servers, 72, table='pages')
    else:
        rd_domains=[]
    list_of_play=[]
    for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre,supplier in m:
        
        
        name=remove_color(name)
        all_plot.append(plot)
        all_server_name.append(server)
        pre_n=''
        if pre>0:
            pre_n='[COLOR yellow]'+str(pre)+'%[/COLOR]'
            
        regex='\[COLOR green\](.+?)\[/COLOR\]'
        m=re.compile(regex).findall(name)
        
        server=''
        supplay=supplier
        
        if '-' in supplay:
            supplay=supplay.split('-')[0]
       
        size=''
        if len(m)>0:
           
            server=m[0]
            name=name.replace('[COLOR green]%s[/COLOR]'%m[0],'')
            server='[COLOR plum]'+server+'[/COLOR]'
        regex='\[COLOR yellow\](.+?)\[/COLOR\]'
        m=re.compile(regex).findall(name)
        if len(m)>0:
      
            
            name=name.replace('[COLOR yellow]%s[/COLOR]'%m[0],'')
        regex='\[COLOR coral\](.+?)\[/COLOR\]'
        if '1337' in name:
           
            regex=' - (.+?) GB'
                  
       
            m=re.compile(regex).findall(name)
             
            if len(m)>0:
                size=m[0].replace('--','')+' GB'
                name=name.replace(' - %s GB'%m[0],'')
        else:
            m=re.compile(regex).findall(name)
            if len(m)>0:
                size=m[0]
                name=name.replace('[COLOR coral]%s[/COLOR]'%m[0],'')
        regex='\{(.+?)\}'
        m=re.compile(regex).findall(name)
        if len(m)>0:
            name=name.replace('{%s}'%m[0],'')
           
            supplay=m[0]
        
        if '2160' in q or '4k' in q.lower():
            q='2160'
        elif '1080' in q:
            q='1080'
        elif '720' in q:
            q='720'
        elif '480' in q:
            q='480'
        elif '360' in q:
            q='360'
        else:
            q='unk'
        rd=False
        try:
            host = link.split('//')[1].replace('www.','')
            host = host.split('/')[0].lower()
        except:
            host='no'
        if host in rd_domains:
            rd=True
        
        if allow_debrid and 'magnet' in server:
            rd=True
        add_rd=''
        if rd:
            add_rd='[COLOR gold]RD- [/COLOR]'
        add_c=''
        if 'Cached ' in name:
            add_c='[COLOR gold] Cached [/COLOR]'
        if 'Rejected' in name:
            name='[COLOR red]'+name+'[/COLOR]'
        supplay=supplay.replace('P-0/','')
        txt=add_c+'[COLOR deepskyblue]'+add_rd+name.replace('-',' ').replace('%20',' ').strip().decode('utf-8','ignore')+'[/COLOR]\nServer: '+server.replace('openload','vummo').replace('letsupload','avlts')+' Subs: '+str(pre_n)+'  Quality:[COLOR gold] ◄'+q+'► [/COLOR]Provider: [COLOR lightblue]'+supplay.replace('openload','vummo').replace('letsupload','avlts').decode('utf-8','ignore')+'[/COLOR] Size:[COLOR coral]'+size+'[/COLOR]$$$$$$$'+link.decode('utf-8','ignore')
        menu.append([name.replace('-',' ').replace('%20',' ').strip(), server.replace('openload','vummo').replace('letsupload','avlts'),str(pre_n),q,supplay.replace('openload','vummo').replace('letsupload','avlts'),size,link,rd])
        list_of_play.append((name,link,icon,image,plot,year,season,episode,original_title,saved_name.encode('utf8'),heb_name,show_original_year,eng_name,'0',prev_name,id,supplay))
        list.append(txt)
        all_links.append(link)
        all_s_names.append(saved_name)
    #time_left=xbmc.Player().getTotalTime()-xbmc.Player().getTime()

    
    if len(rest_data)>0:
        thread=[]
        time_to_save, original_title,year,original_title2,season,episode,id,eng_name,show_original_year,heb_name,isr,get_local=rest_data[0]
        thread.append(Thread(get_rest_s, time_to_save,original_title,year,original_title,season,episode,id,eng_name,show_original_year,heb_name,isr,get_local))
            
        
        thread[0].start()
   
    
    if Addon.getSetting("new_window_type2")=='1' and fast_link!='autoPlay':

        menu = ContextMenu('plugin.video.allmoviesin', menu,iconimage,image,description)
        menu.doModal()
        param = menu.params
        del menu
   
        if param==888:
            logging.warning('INININ:')
            playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            playlist.clear()
            xbmc.Player().stop()
            
            logging.warning('END EXITTTTTTTT')
            return 'END'
        list_index=param
    elif Addon.getSetting("new_window_type2")=='2' and fast_link!='autoPlay':

        menu = ContextMenu_new('plugin.video.allmoviesin', menu,iconimage,image,description)
        menu.doModal()
        param = menu.params
        del menu
        
        if param==888:
            logging.warning('END EXIT')
            playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            playlist.clear()
            xbmc.Player().stop()
            return 'END'
        list_index=param
    elif Addon.getSetting("new_window_type2")=='3' or Addon.getSetting("new_window_type2")=='4' or fast_link=='autoPlay':
        param=0
        global now_playing_server,playing_text,mag_start_time_new
        xbmc.executebuiltin("Dialog.Close(busydialog)")

        menu2 = ContextMenu_new2('plugin.video.allmoviesin', menu,iconimage,image,description)
        menu2.show()
        play_now=0
        close_window_now=False
        if Addon.getSetting("play_first")=='true' or fast_link=='autoPlay':
            if not allow_debrid:
                for name, server,pre_n,q,supplay,size,link,rd in menu:
                    
                    if "magnet" in server:
                        real_index+=1
                    elif len(server)>0:
                        break
            
            if (real_index<len(all_s_names)) and only_torrent=='no':
                play_now=1
                xbmc.sleep(100)
                '''
                try:
                    xbmc.sleep(100)
                    play(all_s_names[real_index].encode('utf8'),all_links[real_index],iconimage,image,all_plot[real_index],data,season,episode,original_title,all_s_names[real_index].encode('utf8'),heb_name,show_original_year,eng_name,'0',prev_name,id,windows_play=True)
                except:
                    pass
                '''
        while param!=888:
            try:
                param = menu2.params
            except Exception as e:
                logging.warning('Skin E:'+str(e))
                param=7777
            
            list_index=param
            fast_link=' '
            f_plot=' '
            
            if (param!=7777 and param!=None and param!=666666) or play_now>0:
                if play_now>0:
                    fast_link=all_links[real_index]
                    f_plot=all_plot[real_index]
                    list_index=real_index
                else:
                    if list_index!=999 and list_index!=888:
                        fast_link=all_links[list_index]
                        f_plot=all_plot[list_index]
                    if list_index==888 or list_index==999: 
                        logging.warning('Stop Play')
                        stop_try_play=True
                        if Addon.getSetting("show_sources_in_4")=='false':
                            logging.warning('END NOW')
                            playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                            playlist.clear()
                            
                            return 'ok'
                        else:
                            return 'ok'
                now_playing_server=all_server_name[list_index]+'$$$$'+str(list_index-real_index+1)+'/'+str(len(all_links))
                if fast_link!=' ':
                    xbmc.Player().stop()
                    logging.warning('fast_link:'+fast_link)
           
                    if 'plugin:' in fast_link:
                        if '&mode=150' or 'המלצה לסדרה חדשה' in fast_link:
                            menu2.close_now()
                            xbmc.executebuiltin('Container.update("%s")'%fast_link)
                        else:
                            url,name,iconimage,mode,fanart,description,data,original_title,id,season,episode,tmdbid,eng_name,show_original_year,heb_name,isr,saved_name,prev_name,dates,data1,fast_link,fav_status,only_torrent,only_heb_servers,new_windows_only=undo_get_rest_data(fast_link)
                            menu2.close_now()
                            get_sources(name, url,iconimage,fanart,description+'-NEXTUP-',data,original_title,season,episode,id,eng_name,show_original_year,heb_name,isr,dates=dates,fav_status=fav_status)
                            
                        break
                       
                        
                        
                    else:
      
                            logging.warning('1')
                       
                       
                            
                            if (('אוטומטי' in all_s_names[list_index]) or play_now>0)  :
                                auto_fast=True
                                play_now=0
                                new_index=real_index
                                errors=[]
                                play_ok=0
                                stop_auto_play=0
                                while(1):
                                        menu2.tick=60
                                        menu2.auto_play=1
                                        if stop_auto_play==1:
                                            menu2.close_now()
                                            play_ok=1
                                            break
                                        try:
                                            
                                            menu2.tick=60
                                            if xbmc.Player().isPlaying():
                                                play_time=int(Addon.getSetting("play_full_time"))
                                                count_p=0
                                                
                                                while(1):
                                                    menu2.tick=60
                                                    vidtime = xbmc.Player().getTime()
                                                    
                                                    try:
                                                        value_d=(vidtime-(int(float(mag_start_time_new)))) 
                                                    except:
                                                        value_d=vidtime
                                                    if value_d> (play_time) :
                                                        play_ok=1
                                                        #xbmc.executebuiltin( "XBMC.Action(Fullscreen)" )
                                                        logging.warning('Closing Played')
                                                        break
                                                    count_p+=1
                                                    if count_p>(play_time*2) :
                                                        logging.warning('Closing Not Played')
                                                        break
                                                    try:
                                                        param = menu2.params
                                                    except Exception as e:
                                                        logging.warning('Skin Error2:'+str(e))
                                                    
                                                    if param==888:
                                                        logging.warning('Close:11')
                                                        logging.warning('CACEL PLAY AUTO')
                                                        break
                                                    xbmc.sleep(500)
                                            if play_ok>0:
                                                logging.warning('Close:12')
                                                break
                                            
                                            f_new_link=all_links[new_index]
                                            '''
                                            if new_index<5:
                                                f_new_link='www'
                                            '''
                                            now_playing_server=all_server_name[new_index]+'$$$$'+str(new_index-real_index+1)+'/'+str(len(all_links))
                                            playing_text='מנסה לינק הבא$$$$'+'0'
                                            try:
                                                param = menu2.params
                                            except Exception as e:
                                                logging.warning('Skin Error2:'+str(e))
                                            
                                            if param==888:
                                                logging.warning('Close:9')
                                                logging.warning('CACEL PLAY AUTO')
                                                break
                                            menu2.count_p=0
                                            logging.warning('time')
                                            
                                            if not allow_debrid:
                                              if not "magnet" in all_server_name[new_index]:
                            
                                                play(name,f_new_link,iconimage,image,all_plot[new_index],data,season,episode,original_title,all_s_names[new_index].encode('utf8'),heb_name,show_original_year,eng_name,'0',prev_name,id,windows_play=False,auto_fast=auto_fast,auto_play=True,f_auto_play=False,show_errors=False)
                                            else:
                                                play(name,f_new_link,iconimage,image,all_plot[new_index],data,season,episode,original_title,all_s_names[new_index].encode('utf8'),heb_name,show_original_year,eng_name,'0',prev_name,id,windows_play=False,auto_fast=auto_fast,auto_play=True,f_auto_play=False,show_errors=False)
                                            if (new_index>real_index):
                                                errors.append(f_new_link+'\n'+all_plot[new_index])
                                                
                                                logging.warning('Send Error:'+f_new_link)
                                            if 'Direct TEME' in list[new_index]:
                                                logging.warning('Stop AUTO')
                                                logging.warning(txt)
                                                logging.warning(f_new_link)
                                                param=888
                                                close_window_now=True
                                                break
                                            new_index+=1
                                            logging.warning('time2')
                                            if new_index>=len(all_links):
                                                logging.warning('Close:91')
                                                #menu2.close_now()
                                                if not xbmc.Player().isPlaying():
                                                    xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'לא נמצאו לינקים תקינים...'.decode('utf8'))).encode('utf-8'))
                                                break
                                            playing_text='מנסה לנגן המתן...$$$$'+'0'
                                            xbmc.sleep(500)
                                            
                                            if len(errors)>0:
                                                sendy('\n'.join(errors),'Error Auto Vik','vikauto')
                                        
                                        except Exception as e:
                                            import linecache
                                            new_index+=1
                                            playing_text='שגיאה בקישור עובר לבא...$$$$'+'0'
                                            if new_index>=len(all_links):
                                                logging.warning('Close:92')
                                                menu2.close_now()
                                                xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'לא נמצאו לינקים תקינים...'.decode('utf8'))).encode('utf-8'))
                                                break
                                            exc_type, exc_obj, tb = sys.exc_info()
                                            f = tb.tb_frame
                                            lineno = tb.tb_lineno
                                            filename = f.f_code.co_filename
                                            linecache.checkcache(filename)
                                            line = linecache.getline(filename, lineno, f.f_globals)

                                            logging.warning('ERROR IN SKIN:'+str(e))
                                            logging.warning('inline:'+line)
                                            logging.warning(e)
                                            pass
                                        
                            else:
                                auto_fast=False
                                counter_end=0
                                try:
                                    while(1):
                                        counter_end+=1
                                        if counter_end>500:
                                            menu2.close_now()
                                            xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'התייאשתי תנסה לבד...'.decode('utf8'))).encode('utf-8'))
                                            break
                                        if fast_link!=' ' and (param!=7777 and param!=None and param!=666666):
                                            menu2.params=666666
                                            xbmc.Player().stop()
                                            now_playing_server=all_server_name[param]+'$$$$'+str(param-real_index+1)+'/'+str(len(all_links))
                                            logging.warning('fast_link:'+fast_link)
                                            
                                            if 'plugin:' in fast_link:
                                                #xbmc.executebuiltin('Container.update("%s")'%fast_link)
                                                url,name,iconimage,mode,fanart,description,data,original_title,id,season,episode,tmdbid,eng_name,show_original_year,heb_name,isr,saved_name,prev_name,dates,data1,fast_link,fav_status,only_torrent,only_heb_servers,new_windows_only=undo_get_rest_data(fast_link)
                                                menu2.close_now()
                                                get_sources(name, url,iconimage,fanart,description+'-NEXTUP-',data,original_title,season,episode,id,eng_name,show_original_year,heb_name,isr,dates=dates,fav_status=fav_status)
                                                
                                                break
                                            else:
                                                try:
                                                    play(name,fast_link,iconimage,image,f_plot,data,season,episode,original_title,all_s_names[list_index].encode('utf8'),heb_name,show_original_year,eng_name,'0',prev_name,id,windows_play=False,auto_fast=auto_fast,auto_play=True,f_auto_play=False)
                                                    logging.warning('Play')
                                                except:
                                                    playing_text='שגיאה בקישור...$$$$'+'0'
                                                    pass
                                                if 'Direct TEME' in f_plot:
                                                    param=888
                                                    close_window_now=True
                                                    break
                                            fast_link=''
                                        play_ok=0
                                        if xbmc.Player().isPlaying():
                                                play_time=int(Addon.getSetting("play_full_time"))
                                                count_p=0
                                                
                                                while(1):
                                                    menu2.tick=60
                                                    vidtime = xbmc.Player().getTime()
                                                    
                                                    try:
                                                        value_d=(vidtime-(int(float(mag_start_time_new)))) 
                                                    except:
                                                        value_d=vidtime
                                                    if value_d> (play_time/2) :
                                                        play_ok=1
                                                        #xbmc.executebuiltin( "XBMC.Action(Fullscreen)" )
                                                        logging.warning('Closing Played')
                                                        break
                                                    count_p+=1
                                                    if count_p>(play_time*2) :
                                                        logging.warning('Closing Not Played')
                                                        break
                                                    try:
                                                        param = menu2.params
                                                        logging.warning('New Param:'+str(param))
                                                        if (param!=7777 and param!=None and param!=666666):
                                                            break
                                                    except Exception as e:
                                                        logging.warning('Skin Error2:'+str(e))
                                                    
                                                    if param==888:
                                                        logging.warning('Close:11')
                                                        logging.warning('CACEL PLAY AUTO')
                                                        break
                                                    xbmc.sleep(500)
                                        if play_ok>0:
                                                logging.warning('Close:120')
                                                logging.warning(play_time)
                                                logging.warning(value_d)
                                                break
                                        if (param!=7777 and param!=None and param!=666666):
                                            list_index=param#-real_index
                                            logging.warning('list_index: '+str(list_index))
                                            if list_index!=999 and list_index!=888:
                                                fast_link=all_links[list_index]
                                                f_plot=all_plot[list_index]
                                            if list_index==888 or list_index==999: 
                                                logging.warning('Stop Play')
                                                stop_try_play=True
                                                logging.warning('Break now: '+str(list_index))
                                                break
                                        try:
                                            param = menu2.params
                                        except Exception as e:
                                            logging.warning('Skin E:'+str(e))
                                            param=7777
                                        if param==888 or param==999: 
                                                logging.warning('Stop Play')
                                                stop_try_play=True
                                                logging.warning('Break now2: '+str(list_index))
                                                break
                                        xbmc.sleep(500)
                                        logging.warning('Tick: '+str(param))
                                except Exception as e:
                                    import linecache
                                    exc_type, exc_obj, tb = sys.exc_info()
                                    f = tb.tb_frame
                                    lineno = tb.tb_lineno
                                    logging.warning('SKIN EEEE:'+str(e)+' At:'+str(lineno))
                                    pass
                                    
                    menu2.played()
            
            if close_window_now:
                menu2.close_now()
            if param==888 or param==7777:
                #menu2.close_now()
                #xbmc.executebuiltin( "XBMC.Action(Fullscreen)" )
                
                break
            else:
                xbmc.sleep(100)
        counter=0
        
       
        if 0:#while 1:
            alive=0
           
            for thread in threading.enumerate():
              
              if (thread.isAlive()):
                 alive=1
                 thread._Thread__stop()
                 
            if alive==0 or counter>10:
                break
            counter+=1
            xbmc.sleep(200)
        
        logging.warning('Del window')
        xbmc.executebuiltin( "XBMC.Action(Fullscreen)" )
        done1=2
        del menu2
    else:
        window = sources_window(original_title ,list,'0',image,description)
        window.doModal()
        logging.warning('end window')
        del window
        logging.warning('del window')
    if Addon.getSetting("new_window_type2")!='3' and Addon.getSetting("new_window_type2")!='4':
        fast_link=' '
        f_plot=' '
        logging.warning('list_index')
        logging.warning(list_index)
        if list_index!=7777 and ('אוטומטי' in all_s_names[list_index])  :
            fav_search_f=Addon.getSetting("fav_search_f_tv")
            fav_servers_en=Addon.getSetting("fav_servers_en_tv")
            fav_servers=Addon.getSetting("fav_servers_tv")
            google_server= Addon.getSetting("google_server_tv")
            rapid_server=Addon.getSetting("rapid_server_tv")
            direct_server=Addon.getSetting("direct_server_tv")
            heb_server=Addon.getSetting("heb_server_tv")
            
       
            if  fav_search_f=='true' and fav_servers_en=='true' and (len(fav_servers)>0 or heb_server=='true' or google_server=='true' or rapid_server=='true' or direct_server=='true'):
            
                fav_status='true'
            else:
                fav_status='false'
            #xbmc.executebuiltin(('Container.update("plugin://plugin.video.allmoviesin/?data=%s&dates=EMPTY&description=%s&eng_name=%s&episode=%s&fanart=%s&heb_name=%s&iconimage=%s&id=%s&isr=0&mode=4&name=%s&original_title=%s&season=%s&show_original_year=%s&tmdbid=EMPTY&url=%s&fast_link=%s&fav_status=%s",return)'%(data,urllib.quote_plus(description),eng_name,str((episode)),urllib.quote_plus(image),heb_name,urllib.quote_plus(iconimage),id,name,original_title,season,show_original_year,urllib.quote_plus('autoPlay'),urllib.quote_plus('autoPlay'),fav_status)).replace('EMPTY','%20'))
        else:
            if list_index!=999 and list_index!=888 and list_index!=7777:
                fast_link=all_links[list_index]
                f_plot=all_plot[list_index]
            if list_index==888 or list_index==999: 
                logging.warning('Stop Play')
                stop_try_play=True
                url=''
                logging.warning('INININ:')
                playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                playlist.clear()
                xbmc.Player().stop()
                return 'END'
            logging.warning('list_index:'+str(list_index))
            if fast_link!=' ':
                xbmc.Player().stop()
                logging.warning('Play Links:')
                logging.warning(list_index)
                logging.warning(fast_link)
                
                if 'plugin:' in fast_link:
                    logging.warning(fast_link)
                    
                    #xbmc.executebuiltin('Container.update("%s")'%fast_link)
                    url,name,iconimage,mode,fanart,description,data,original_title,id,season,episode,tmdbid,eng_name,show_original_year,heb_name,isr,saved_name,prev_name,dates,data1,fast_link,fav_status,only_torrent,only_heb_servers,new_windows_only=undo_get_rest_data(fast_link)
                    logging.warning(id)
                   
                    get_sources(name, url,iconimage,fanart,description+'-NEXTUP-',data,original_title,season,episode,id,eng_name,show_original_year,heb_name,isr,dates=dates,fav_status=fav_status)
                    
                   
                    
                    
                else:
                    #xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'מתחיל ניגון המתן קטנה מייד יתחיל'.decode('utf8'))).encode('utf-8'))
                    #xbmc.executebuiltin(('XBMC.PlayMedia("plugin://plugin.video.allmoviesin/?data=%s&dates=EMPTY&description=%s&eng_name=%s&episode=%s&fanart=%s&heb_name=%s&iconimage=%s&id=%s&isr=0&mode=5&name=%s&original_title=%s&season=%s&show_original_year=%s&tmdbid=EMPTY&url=%s&fast_link=%s&prev_name=%s&saved_name=%s",return)'%(data,urllib.quote_plus(f_plot.encode('utf8')),eng_name,episode,urllib.quote_plus(fanart),heb_name,urllib.quote_plus(iconimage),id,prev_name,original_title,season,show_original_year,urllib.quote_plus(fast_link),urllib.quote_plus(fast_link),prev_name,all_s_names[list_index].encode('utf8'))).replace('EMPTY','%20'))
                    logging.warning('1')
                    #if len(list_of_play)>0:
                    #    menu = wizard('plugin.video.allmoviesin', list_of_play,fast_link)
                    #    menu.doModal()

                    #    del menu
                        
                    play(name,fast_link,iconimage,image,f_plot,data,season,episode,original_title,all_s_names[list_index].encode('utf8'),heb_name,show_original_year,eng_name,'0',prev_name,id)
                    '''
                    isbusy  = xbmc.getCondVisibility('Window.IsActive(busydialog)')
                    
                   
                        
                    played=False
                    while isbusy:
                        isbusy  = xbmc.getCondVisibility('Window.IsActive(busydialog)')
                        xbmc.sleep(200)
                    if xbmc.Player().isPlaying():
                        xbmc.sleep(2000)
                        vidtime = xbmc.Player().getTime()
                        if vidtime > 0:
                            played=True
                    logging.warning('played')
                    logging.warning(played)
                    if not played:
                        m,data,description,eng_name,episode,image,heb_name,iconimage,id,prev_name,original_title,season,show_original_year,n,rest_data,n_magnet,only_heb,len_all_torrent_s,next_ep=original_data[0]
                        new_show_sources(m,data,description,eng_name,episode,image,heb_name,iconimage,id,prev_name,original_title,season,show_original_year,n,rest_data,n_magnet,only_heb,len_all_torrent_s,next_ep)
                    xbmc.sleep(200)
                    '''
        return 'END'
    return 'ok'
def show_sources():
    global list_index

    list=[]
    
    time_to_save=int(Addon.getSetting("save_time"))
    
    dbcur.execute("SELECT * FROM sources")

    match = dbcur.fetchone()

    if match!=None:
        name,url,icon,image,plot,year,season,episode,original_title,heb_name,show_original_year,eng_name,isr,id=match
        m=[]
        m.append((name,url,icon,image,plot,year,season,episode,original_title,heb_name,show_original_year,eng_name,isr,id))
  
        prev_name=name
       

        iconimage=icon
        fanart=image
        data=year

        description=plot.replace('-פרק ','').replace('-NEXTUP-','').encode('utf8')
        if season!=None and season!="%20":
           name1=name
        else:
           name1=name.encode('utf8').replace("%27","'").replace("%20"," ")
        
        match_a,all_links_fp,all_pre,f_subs,current_subs= cache.get(c_get_sources, time_to_save,original_title ,year,original_title.replace("%27","'"),season,episode,id,eng_name.replace("%27","'"),show_original_year,heb_name.replace("%27","'"),isr,False,'false','no','0', table='pages')

        all_data=fix_links(match_a,iconimage,fanart,description,show_original_year,season,episode)
        
        all_links=[]
  
        for name,link,icon,image,plot,year,q,server,f_q,saved_name,pre in all_data:
          
            list.append('[COLOR yellow]'+str(pre)+'%[/COLOR]-[COLOR gold]'+q+'[/COLOR][COLOR lightblue]'+server+'[/COLOR]-'+name+'$$$$$$$'+link)
            all_links.append(link)

        #time_left=xbmc.Player().getTotalTime()-xbmc.Player().getTime()
        time_to_wait=int(Addon.getSetting("show_p_time"))

        window = MyAddon(name  ,list,time_to_wait,image,plot)
        window.doModal()

        del window

        fast_link=' '
        if list_index!=999 and list_index!=888:
            fast_link=all_links[list_index]
        if list_index==888: 
            return '0'
        if fast_link!=' ':
            xbmc.Player().stop()
            
            xbmc.executebuiltin(('XBMC.PlayMedia("plugin://plugin.video.allmoviesin/?data=%s&dates=EMPTY&description=%s&eng_name=%s&episode=%s&fanart=%s&heb_name=%s&iconimage=%s&id=%s&isr=0&mode=5&name=%s&original_title=%s&season=%s&show_original_year=%s&tmdbid=EMPTY&url=%s&fast_link=%s&prev_name=%s",return)'%(data,urllib.quote_plus(description),eng_name,episode,urllib.quote_plus(fanart),heb_name,urllib.quote_plus(iconimage),id,prev_name,original_title,season,show_original_year,urllib.quote_plus(fast_link),urllib.quote_plus(fast_link),prev_name)).replace('EMPTY','%20'))
def last_sources():

    show_sources()
def acestream():
    addDir3('[COLOR fuchsia][I]חיפוש[/I][/COLOR]'.decode('utf8'),'www',77,'https://lh3.googleusercontent.com/0m0JeYjdEbLUVYCn_4vQjgaybPzyZB9z1fazy07JFkKyF6dK1gboo7_N9cz0GADxJw4=s180','https://i.pinimg.com/originals/6b/18/31/6b1831503dc0e0470b2bf1e1b5df978f.jpg','Acestream'.decode('utf8'))
    addDir3('[COLOR deepskyblue][I]הערוצים שלי[/I][/COLOR]'.decode('utf8'),'www',79,'https://lh3.googleusercontent.com/0m0JeYjdEbLUVYCn_4vQjgaybPzyZB9z1fazy07JFkKyF6dK1gboo7_N9cz0GADxJw4=s180','https://i.pinimg.com/originals/6b/18/31/6b1831503dc0e0470b2bf1e1b5df978f.jpg','Acestream'.decode('utf8'))
def search_ace():
        search_entered=''
       
        
        keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש כאן')
        keyboard.doModal()
        if keyboard.isConfirmed():
               search_entered = keyboard.getText()
               headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:68.0) Gecko/20100101 Firefox/68.0',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
                    'Connection': 'keep-alive',
                    
                    'Upgrade-Insecure-Requests': '1',
                    'Pragma': 'no-cache',
                    'Cache-Control': 'no-cache',
                }

               params = (
                    ('q', search_entered),
               )

               response = requests.get('https://acestreamsearch.net/en/', headers=headers, params=params).content
               regex_pre='<ul class="list-group">(.+?)</ul>'
               match_pre=re.compile(regex_pre,re.DOTALL).findall(response)
               logging.warning(match_pre)
               for item in match_pre:
                regex='<li class="list-group-item"><a href="(.+?)">(.+?)<'
                match=re.compile(regex).findall(item)
                icon='https://lh3.googleusercontent.com/0m0JeYjdEbLUVYCn_4vQjgaybPzyZB9z1fazy07JFkKyF6dK1gboo7_N9cz0GADxJw4=s180'
                fanart='https://i.pinimg.com/originals/6b/18/31/6b1831503dc0e0470b2bf1e1b5df978f.jpg'
                for link,name in match:
                   
                    regex='acestream://(.+?)(?:/|$)'
                    match=re.compile(regex).findall(link)
                    f_link='http://127.0.0.1:6878/ace/getstream?id='+match[0]
                    addLink(name,f_link,5,False,iconimage=icon,fanart=fanart,description=name)
               headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'en-US,en;q=0.5',
                    'Connection': 'keep-alive',
                    'Upgrade-Insecure-Requests': '1',
                    'Pragma': 'no-cache',
                    'Cache-Control': 'no-cache',
                }

               params = (
                    ('sort', 'fname'),
                )
               logging.warning('Getting')
               response = requests.get('http://91.92.66.82/trash/ttv-list/AceLiveList.php', headers=headers, params=params).content
               regex='type=checkbox /></TD><TD data-v="(.+?)">.+?</TD><TD data-v=".+?">.+?</TD><TD>(.+?)<'
                      
               match=re.compile(regex).findall(response)
       
       
               for name,link in match:
                   if search_entered.lower() in name.lower():
                   
                    f_link='http://127.0.0.1:6878/ace/getstream?id='+link
                    addLink('[S-2] '+name,f_link,5,False,iconimage=icon,fanart=fanart,description=name)
               headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'en-US,en;q=0.5',
                    'Connection': 'keep-alive',
                    'Upgrade-Insecure-Requests': '1',
                    'Pragma': 'no-cache',
                    'Cache-Control': 'no-cache',
                }
               '''
               response = requests.get('https://www.livefootballol.net/acestream-channel-list-2018.html', headers=headers).content
               regex='<tr>(.+?)</tr>'
               match_pre=re.compile(regex,re.DOTALL).findall(response)
               for items in match_pre:
                   regex='a href=".+?>(.+?)<.+?<td>(.+?)<'
                   match=re.compile(regex,re.DOTALL).findall(items)
                   #logging.warning(match
                   for name,link in match:
              
                       if search_entered.lower() in name.lower():
                        regex='acestream://(.+?)(?:/|$)'
                        match=re.compile(regex).findall(link)
                        f_link='http://127.0.0.1:6878/ace/getstream?id='+match[0]
                        addLink('[S-3] '+name,f_link,5,False,iconimage=icon,fanart=fanart,description=name)
               '''
def chan_ace(name,url,description):
    
    if description=='add':
        dbcur.execute("INSERT INTO acestream Values ('%s', '%s', '%s', '%s','%s', '%s', '%s');" %  (name.replace("'","%27"),url,description.replace("'","%27"),'','','',''))
        dbcon.commit()
        xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'הוספתי'.decode('utf8'))).encode('utf-8'))
    elif description=='remove':
        dbcur.execute("DELETE  FROM acestream WHERE url = '%s'"%(url))
        
      
        dbcon.commit()
        xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'הוסר'.decode('utf8'))).encode('utf-8'))
def refresh_ace(search_entered):
    o_name=search_entered

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:68.0) Gecko/20100101 Firefox/68.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'Connection': 'keep-alive',
        
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }

    params = (
        ('q', search_entered),
    )

    response = requests.get('https://acestreamsearch.net/en/', headers=headers, params=params).content
    regex_pre='<ul class="list-group">(.+?)</ul>'
    match_pre=re.compile(regex_pre,re.DOTALL).findall(response)
    for item in match_pre:
        regex='<li class="list-group-item"><a href="(.+?)">(.+?)<'
        match=re.compile(regex).findall(item)
        icon='https://lh3.googleusercontent.com/0m0JeYjdEbLUVYCn_4vQjgaybPzyZB9z1fazy07JFkKyF6dK1gboo7_N9cz0GADxJw4=s180'
        fanart='https://i.pinimg.com/originals/6b/18/31/6b1831503dc0e0470b2bf1e1b5df978f.jpg'
        for link,name in match:
            
            regex='acestream://(.+?)(?:/|$)'
            match=re.compile(regex).findall(link)
            
            if search_entered==name:
                f_link='http://127.0.0.1:6878/ace/getstream?id='+match[0]
                #return f_link
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }

    params = (
        ('sort', 'fname'),
    )
    logging.warning('Getting')
    response = requests.get('http://91.92.66.82/trash/ttv-list/AceLiveList.php', headers=headers, params=params).content
    regex='type=checkbox /></TD><TD data-v="(.+?)">.+?</TD><TD data-v=".+?">.+?</TD><TD>(.+?)<'
           
    match=re.compile(regex).findall(response)


    logging.warning('Renew s2')
    for name,link in match:
       
       
       if search_entered.lower() =='[s-2] '+name.lower():
        logging.warning('Found s2')
        f_link='http://127.0.0.1:6878/ace/getstream?id='+link
    
    headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
        }
    '''
    response = requests.get('https://www.livefootballol.net/acestream-channel-list-2018.html', headers=headers).content
    regex='<tr>(.+?)</tr>'
    match_pre=re.compile(regex,re.DOTALL).findall(response)

    for items in match_pre:
           regex='a href=".+?>(.+?)<.+?<td>(.+?)<'
           match=re.compile(regex,re.DOTALL).findall(items)
           #logging.warning(match
           for name,link in match:
               
               if search_entered.lower() =='[s-3] '+ name.lower():
                regex='acestream://(.+?)(?:/|$)'
                match=re.compile(regex).findall(link)
                f_link='http://127.0.0.1:6878/ace/getstream?id='+match[0]
    ''' 
    if f_link=='':
      xbmcgui.Dialog().ok("תקלה",'ערוץ חסר')
      sys.exit()
    else:
      return f_link
def my_ace():
    dbcur.execute("SELECT * FROM acestream")

    match = dbcur.fetchall()
    
    icon='https://lh3.googleusercontent.com/0m0JeYjdEbLUVYCn_4vQjgaybPzyZB9z1fazy07JFkKyF6dK1gboo7_N9cz0GADxJw4=s180'
    fanart='https://i.pinimg.com/originals/6b/18/31/6b1831503dc0e0470b2bf1e1b5df978f.jpg'
    for name,link,plot,op,op1,op2,op3 in match:
        addLink(name,'aceplay',5,False,iconimage=icon,fanart=fanart,description=name)

def israeli_cont(url):
    headers = {
                                
                                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
                                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                                'Accept-Language': 'en-US,en;q=0.5',
                                'Connection': 'keep-alive',
                                'Upgrade-Insecure-Requests': '1',
                                'Accept-Encoding': 'UTF-8',
                            }
    
    if 'tvnetil' not in url:
        url='https://www.tvnetil.net/reviews/show/y/mPage/0/'
    x=requests.get(url,headers=headers).content.decode('windows-1255').encode('utf8')
    regex='IMGReviewsPage" src="(.+?)".+?href="https://www.TVNetil.net/review/(.+?)/.+?">(.+?)<.+?<p>(.+?)</p>'
    match=re.compile(regex,re.DOTALL).findall(x)


    all_ids=[]
    for image,id,name,plot in match:
        
        if id not in all_ids:
            all_ids.append(id)
            fixed_name=name.split('-')
            if len(fixed_name)>0:
                fixed_name=fixed_name[0]
            
            
            addDir3(fixed_name,'https://www.tvnetil.net/review/'+id,82,image,image,plot)
        
        
    regex='<a href="(.+?)" style="text-decoration:underline;">(.+?)<'
    match=re.compile(regex).findall(x)

    f_link=''
    for link,txt in match:
        if 'הבא' in txt:
            f_link=link

    if f_link!='':
        addDir3('[COLOR aqua][I]עמוד הבא[/I][/COLOR]','https://www.tvnetil.net'+f_link,81,' ',' ','עמוד הבא')
    addDir3('[COLOR khaki][I]חיפוש[/I][/COLOR]','search',83,' ',' ','חיפוש')
def deep_israli(url,image,plot):
    headers = {
                                
                                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
                                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                                'Accept-Language': 'en-US,en;q=0.5',
                                'Connection': 'keep-alive',
                                'Upgrade-Insecure-Requests': '1',
                                'Accept-Encoding': 'UTF-8',
                            }
    
 
    x=requests.get(url,headers=headers).content.decode('windows-1255').encode('utf8')
    regex='align="top">תכנים:</td>(.+?)</td>'
    
    match_pre=re.compile(regex,re.DOTALL).findall(x)[0]

    regex='a href="(.+?)">(.+?)</b>'
    
    match=re.compile(regex,re.DOTALL).findall(match_pre)
    video_info={}
    for link,name in match:
        name=name.replace('\n','').replace('\r','').replace('\t','')
        video_info['title']=name
        video_info['icon']=image
        video_info['plot']=description
        addLink(name,link,5,False,iconimage=image,fanart=image,description=plot+'-HebDub-'+'\nplay_israli',video_info=json.dumps(video_info))
        
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
def search_isr():
    search_entered=''
    headers = {
                
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
                }
        
    keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש כאן')
    keyboard.doModal()
    if keyboard.isConfirmed():
        search_entered = keyboard.getText().decode('utf-8')
        f_t=''
        for ch in search_entered:
            
            if not ch.isdigit():
                
                new=ord(ch)-1264
                try:
                    f_t=f_t+urllib.quote_plus(chr(new))
                except:
                    f_t=f_t+urllib.quote_plus(ch)
            else:
                new=ch
                f_t=f_t+new
            
        f_t=f_t.replace(' ','+')
        url='https://www.tvnetil.net/search/term/?search_term=%s&type=all&go='%f_t
   
        x=requests.get(url,headers=headers).content
        regex='<div class="search-big-box-right-user"><a href="(.+?)">(.+?)<.+?"search-big-box-right-comments">(.+?)<.+?<img src="(.+?)"'
        match=re.compile(regex,re.DOTALL).findall(x)
        for link,name,plot,image in match:
            name=name.replace('\n','').replace('\r','').replace('\t','')
            #import chardet
            #encoding = chardet.detect(name)['encoding']
           
            addDir3(name.decode('windows-1255'),'https://www.tvnetil.net'+link,82,'https://www.tvnetil.net'+image,'https://www.tvnetil.net'+image,plot.decode('windows-1255'))
        
        
        
    
    
    
    
def new_source(iconimage,fanart):
    addDir3('פרקים אחרונים'.decode('utf8'),'https://www.moviesfame.com/category/tv-show/',85,iconimage,fanart,'פרקים אחרונים'.decode('utf8'))
    addDir3('כל הסדרות'.decode('utf8'),'https://www.moviesfame.com/serial/',86,iconimage,fanart,'כל הסדרות'.decode('utf8'))
    addDir3('האבקות'.decode('utf8'),'https://www.moviesfame.com/category/wrestling/',85,iconimage,fanart,'האבקות'.decode('utf8'))
    addDir3('סרטים הודים'.decode('utf8'),'https://www.moviesfame.com/category/bollywood/',85,iconimage,fanart,'האבקות'.decode('utf8'))
    addDir3('חיפוש'.decode('utf8'),'search',85,iconimage,fanart,'חיפוש'.decode('utf8'))
def eli_sratim(url,iconimage,fanart):
    headers = {
                
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
                }
    x=requests.get(url,headers=headers).content
    regex="'post-titl.+?'>.+?a href='(.+?)'>(.+?)<"
    match=re.compile(regex,re.DOTALL).findall(x)
    video_info={}
    for link,name in match:
        name=name.replace('\n','').replace('\r','').replace('\t','')
        video_info['title']=name
        video_info['icon']=iconimage
        video_info['plot']=name
        addLink(name,link,5,False,iconimage=iconimage,fanart=fanart,description=name+'-HebDub-'+'\nplay_eli_s',video_info=json.dumps(video_info))
def in_new_source(url,iconimage,fanart):
    if url=='search':
        search_entered=''
       
        
        keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש כאן')
        keyboard.doModal()
        if keyboard.isConfirmed():
                search_entered = keyboard.getText()
                url='https://www.moviesfame.com/?s=%s&category_name=&genre_name=&language_name='%search_entered
        else:
          sys.exit()
    headers = {
                
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
                }
    x=requests.get(url,headers=headers).content
    regex='<div class="post-title".+?a href="(.+?)"><marquee>(.+?)<.+?<img.+?src="(.+?)"'
    match=re.compile(regex,re.DOTALL).findall(x)
    for link,name,image in match:
        video_info={}
  
        name=name.replace('\n','').replace('\r','').replace('\t','')
        info=(PTN.parse(name.replace(' ','.').replace('(','').replace(')','')))
        video_info['title']=info['title']
        video_info['icon']=image
        video_info['plot']=''
        video_info['original_title']=info['title']
        
        if 'year' in info:
            
            year_n=info['year']
            video_info['year']=year_n
        else:
           year_n='0'
        add_no_subs='-HebDub-'
        if 'bollywood'  in url:
            add_no_subs=''
        addLink(info['title'],link,5,False,iconimage=image,fanart=image,description=name+'-KIDSSECTION-'+add_no_subs+'\nplay_fame',original_title=info['title'],video_info=json.dumps(video_info),data=year_n)
    regex='link rel="next" href="(.+?)"'
    match=re.compile(regex).findall(x)
    if len(match)>0:
        addDir3('[COLOR aqua][I]עמוד הבא[/I][/COLOR]',match[0],85,iconimage,fanart,'עמוד הבא')

def all_new_source(url):
    headers = {
                
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
                }
    x=requests.get(url,headers=headers,verify=False).content

    regex='<div class=".+?-post">.+?a href="(.+?)">(.+?)<.+?<img.+?src="(.+?)"'
    match=re.compile(regex,re.DOTALL).findall(x)
    for link,name,image in match:
        addDir3(name,link,85,image,image,name)
        
    regex='link rel="next" href="(.+?)"'
    match=re.compile(regex).findall(x)
    if len(match)>0:
        addDir3('[COLOR aqua][I]עמוד הבא[/I][/COLOR]',match[0],85,iconimage,fanart,'עמוד הבא')
        
def change_to_simple():
    st_file=os.path.join(addonPath, 'resources', 'settings.xml')
    sm_file=os.path.join(addonPath, 'resources', 'simple.xml')
    user_file=os.path.join(user_dataDir, 'settings.xml')
    
    
    file = open(st_file,'r') 
    file_data= file.read()
    file.close()
    
    file = open(sm_file,'r') 
    sm_data= file.read()
    file.close()
    
    file = open(user_file,'r') 
    file_user= str(file.read())
    file.close()
    
    regex='<setting id="fp_size"(.+?)#end#'
    match_pre=re.compile(regex,re.DOTALL).findall(file_data)[0]
    
    regex='<setting id="(.+?)" label="(.+?)" type="bool" default="(.+?)"'
    match=re.compile(regex).findall(match_pre)
    
    
    
    for server,label,value in match:
        regex='<setting id="%s" value="(.+?)" />'%server
        match_sm=re.compile(regex).findall(sm_data)
        
        if len(match_sm)>0:
            if match_sm[0]!=value:
       
                file_user=file_user.replace('setting id="%s" value="%s"'%(server,value),'setting id="%s" value="%s"'%(server,match_sm[0]))
             
    
    
    ok=xbmcgui.Dialog().yesno("מעבר להגדרות סימפל",'אתה בטוח? בכל מקרה תמיד תוכל לחזור לברירת מחדל')
    if ok:
        
        file = open(user_file, 'w') 
        file.write(file_user)
        file.close()
        xbmcgui.Dialog().ok("מעבר להגדרות סימפל",'בוצע.. פתח את ההרחבה מחדש')
def uploadThis(f,myFTP):
    from os.path import basename
    fh = open(f, 'rb')
    myFTP.storbinary('STOR %s' % Addon.getSetting("db_bk_name")+'1_'+str(time.strftime("%d/%m/%Y")).replace('/','_'), fh)
    fh.close()
def do_bakcup(silent='True'):
    logging.warning('silent')
    logging.warning(silent)
    
    from zipfile import ZipFile
    import datetime,os
    from shutil import copyfile
    from os.path import basename
    if silent=='False':
        logging.warning('silent2')
        dp = xbmcgui . DialogProgress ( )
        dp.create('אנא המתן','מתחבר לשרת', '','')
        dp.update(0, 'אנא המתן','מכווץ', '' )
    
    zp_file=os.path.join(user_dataDir, 'data'+'_'+str(time.strftime("%d/%m/%Y").replace('/','_')+'.zip'))
    cacheFile = os.path.join(user_dataDir, 'cache_play.db')
    setting_file=os.path.join(user_dataDir, 'settings.xml')
    if os.path.isfile(zp_file):
        os.remove(zp_file)
    zipf = ZipFile(zp_file , mode='w')
    zipf.write(cacheFile , basename(cacheFile))
    zipf.write(setting_file , basename(setting_file))
    zipf.close()
    
    
    from os.path import basename
    if Addon.getSetting("remote_selection")=='0':
        onlyfiles=[]
        db_bk_folder=xbmc.translatePath(Addon.getSetting("remote_path"))
        dirList, onlyfiles =xbmcvfs.listdir(db_bk_folder)
      
        ct_min=0
        
            
        count=0
        for files in onlyfiles:
            f_patch_file=os.path.join(db_bk_folder,files)
            if Addon.getSetting("db_bk_name") in basename(files):
                count+=1
        
        if count>5:
            for files in onlyfiles:
                f_file=(os.path.join(db_bk_folder,files))
                if Addon.getSetting("db_bk_name") not in basename(f_file):
                  continue
                st = xbmcvfs.Stat(f_file)
                ct_date = st.st_mtime()
                logging.warning(ct_date)
                #ct_date=time.ctime(os.path.getctime(f_file))
                if ct_min==0:
                    ct_min=ct_date
                elif ct_date<ct_min:
                    ct_min=ct_date
            
            for files in onlyfiles:
                f_file=os.path.join(db_bk_folder,files)
                if Addon.getSetting("db_bk_name") not in basename(f_file):
                  continue
                st = xbmcvfs.Stat(f_file)
                ct_date = st.st_mtime()
                #ct_date=time.ctime(os.path.getctime(f_file))
               
                if ct_date==ct_min:
                   
                    xbmcvfs.delete(f_file)
                    break
        xbmcvfs.copy (zp_file,os.path.join(db_bk_folder,Addon.getSetting("db_bk_name")+'_'+str(time.strftime("%d/%m/%Y")).replace('/','_')))
        xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'בוצע גיבוי בהצלחה'.decode('utf8'))).encode('utf-8'))
    elif Addon.getSetting("remote_selection")=='1':
        if silent=='False':
            dp.update(20, 'אנא המתן','מתחבר לשרת', '' )
        import ftplib
        import os,urllib
        from datetime import datetime
        import _strptime
            
        server=Addon.getSetting("ftp_host")
        username=Addon.getSetting("ftp_user")
        password=Addon.getSetting("ftp_pass")
        try:
            myFTP = ftplib.FTP(server, username, password)
            if silent=='False':
                dp.update(40, 'אנא המתן','התחבר בהצלחה', '' )
            files = myFTP.nlst()
            found=0
            if silent=='False':
                dp.update(60, 'אנא המתן','אוסף קבצים', '' )
            for f in files:
                
               
                
                if 'kodi_backup' in f:
                    found=1
                    
            if found==0:
                myFTP.mkd('kodi_backup')
            myFTP.cwd('kodi_backup')
            files = myFTP.nlst()
           
            count=0
            ct_min=0
            for f in files:
                
                if Addon.getSetting("db_bk_name") in basename(f):
                    count+=1
            if count>5:
                for f in files:
                    if Addon.getSetting("db_bk_name") not in basename(f):
                       continue
                    try:
                        modifiedTime = myFTP.sendcmd('MDTM ' + f)
                       
                        
                        #ct_date=datetime.strptime(modifiedTime[4:], "%Y%m%d%H%M%S").strftime("%d %B %Y %H:%M:%S")
                        try:
                            ct_date = datetime.strptime(modifiedTime[4:], "%Y%m%d%H%M%S").strftime("%d %B %Y %H:%M:%S")
                        except TypeError:
                            ct_date = datetime.fromtimestamp(time.mktime(time.strptime(modifiedTime[4:], "%Y%m%d%H%M%S")))
                            ct_date = ct_date.strftime("%d %B %Y %H:%M:%S")
                        
                        if ct_min==0:
                            ct_min=ct_date
                        elif ct_date<ct_min:
                            ct_min=ct_date
                    except Exception as e:
                        logging.warning(e)
                        pass
             
                for f in files:
                    if Addon.getSetting("db_bk_name") not in basename(f):
                       continue
            
                    modifiedTime = myFTP.sendcmd('MDTM ' + f)
          
             
                    
                    #ct_date=datetime.strptime(modifiedTime[4:], "%Y%m%d%H%M%S").strftime("%d %B %Y %H:%M:%S")
                    try:
                        ct_date = datetime.strptime(modifiedTime[4:], "%Y%m%d%H%M%S").strftime("%d %B %Y %H:%M:%S")
                    except TypeError:
                        ct_date = datetime.fromtimestamp(time.mktime(time.strptime(modifiedTime[4:], "%Y%m%d%H%M%S")))
                        ct_date = ct_date.strftime("%d %B %Y %H:%M:%S")
                   
                    if ct_date==ct_min:
                    
                        
                        myFTP.delete(f)
                        break
            if silent=='False':
                dp.update(80, 'אנא המתן','מעלה לשרת', '' )
            uploadThis(zp_file,myFTP)
            
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'בוצע גיבוי בהצלחה'.decode('utf8'))).encode('utf-8'))
        except Exception as e:
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'שגיאה בגיבוי לשרת בדוק הגדרות'.decode('utf8'))).encode('utf-8'))
    else:
        resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
        listen_port=resuaddon.getSetting('port')
        selected_group_id=Addon.getSetting("bot_id")
        
        data={'type':'td_send',
                     'info':json.dumps({'@type': 'sendMessage','chat_id': selected_group_id,'input_message_content': {'@type':'inputMessageDocument','document': {'@type':'inputFileLocal','path': zp_file}},'@extra': 1 })
                     }
        event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
        xbmc.sleep(10000)
        xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'גיבוי עלה לטלגרם'.decode('utf8'))).encode('utf-8'))
    try:
        xbmc.sleep(1000)
        if os.path.isfile(zp_file):
            os.remove(zp_file)
    except:
        pass
    if silent=='False':
        dp.close()
    logging.warning('Done backing up')
def restore_backup():
    from shutil import copyfile
    import os
    if 1:#try:
        cacheFile = os.path.join(user_dataDir, 'cache_play.db')
        zp_file= os.path.join(user_dataDir, 'data.zip')
        from os.path import basename
        if Addon.getSetting("remote_selection")=='0':
           
            onlyfiles=[]
            db_bk_folder=xbmc.translatePath(Addon.getSetting("remote_path"))
            dirList, onlyfiles =xbmcvfs.listdir(db_bk_folder)
            
    
            all_n=[]
            all_f=[]
            for f in onlyfiles:
                all_n.append(basename(f))
                all_f.append(os.path.join(db_bk_folder,f))
            ret = xbmcgui.Dialog().select("בחר קובץ גיבוי", all_n)
            if ret!=-1:
                ok=xbmcgui.Dialog().yesno(("שחזור מגיבוי"),all_n[ret]+' אתה בטוח שאתה רוצה לשחזר מגיבוי זה? ')
                if ok:
                    db_name=Addon.getSetting('db_bk_name')
                    if '.db' not in all_n[ret]:
                        xbmcvfs.copy(all_f[ret],os.path.join(user_dataDir,'temp_zip'))
                        unzip(os.path.join(user_dataDir,'temp_zip'),user_dataDir)
                        xbmcvfs.delete(os.path.join(user_dataDir,'temp_zip'))
                    else:
                        xbmcvfs.copy(all_f[ret],cacheFile)
                    #xbmc.executebuiltin('Container.Update')
                    #Addon.setSetting('db_bk_name',db_name)
                    xbmcgui.Dialog().ok("שחזור מגיבוי",'[COLOR aqua][I]אל תשכח לשנות את שם הגיבוי בהגדרות. שוחזר בהצלחה[/I][/COLOR]')
            else:
               sys.exit()
        elif Addon.getSetting("remote_selection")=='1':
            dp = xbmcgui . DialogProgress ( )
            dp.create('אנא המתן','מתחבר לשרת', '','')
            dp.update(0, 'אנא המתן','מתחבר לשרת', '' )
            import ftplib
            import os,urllib
            from datetime import datetime
            server=Addon.getSetting("ftp_host")
            username=Addon.getSetting("ftp_user")
            password=Addon.getSetting("ftp_pass")
            try:
            
              myFTP = ftplib.FTP(server, username, password)
            except Exception as e:
               xbmcgui.Dialog().ok('שגיאת התחברות',str(e))
               sys.exit()
            dp.update(0, 'אנא המתן','התחבר בהצלחה', '' )
            files = myFTP.nlst()
            found=0
            for f in files:
         
                if 'kodi_backup' in f:
                    found=1
            if found==0:
            
                xbmcgui.Dialog().ok("שחזור מגיבוי",'[COLOR red][I]לא קיימים גיבויים[/I][/COLOR]')
                sys.exit()
            myFTP.cwd('kodi_backup')
            files = myFTP.nlst()
           
            count=0
            ct_min=0
            all_n=[]
            all_f=[]
            dp.update(0, 'אנא המתן','אוסף קבצים', '' )
            for f in files:

                all_n.append(basename(f))
                all_f.append(f)
            ret = xbmcgui.Dialog().select("בחר קובץ גיבוי", all_n)
            if ret!=-1:
                ok=xbmcgui.Dialog().yesno(("שחזור מגיבוי"),all_n[ret]+' אתה בטוח שאתה רוצה לשחזר מגיבוי זה? ')
                if ok:
                    
                    db_name=Addon.getSetting('db_bk_name')
                    i=cacheFile
                    dp.update(0, 'אנא המתן','מוריד קובץ', '' )
                    myFTP.retrbinary("RETR " + all_f[ret] ,open(i, 'wb').write)
                    dp.close()
                    if '.db' not in all_n[ret]:
                        myFTP.retrbinary("RETR " + all_f[ret] ,open(zp_file, 'wb').write)
                        unzip(zp_file,user_dataDir)
                    else:
                        myFTP.retrbinary("RETR " + all_f[ret] ,open(i, 'wb').write)
                    Addon.setSetting('db_bk_name',db_name)
                    xbmcgui.Dialog().ok("שחזור מגיבוי",'[COLOR aqua][I]שוחזר בהצלחה[/I][/COLOR]')
            else:
               sys.exit()
        else:
            resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
            listen_port=resuaddon.getSetting('port')
            selected_group_id=Addon.getSetting("bot_id")
            num=random.randint(1,1001)
            data={'type':'td_send',
                 'info':json.dumps({'@type': 'searchChatMessages','chat_id':(selected_group_id), 'query': '','from_message_id':0,'offset':0,'filter':{'@type': 'searchMessagesFilterDocument'},'limit':100, '@extra': num})
                 }
           
           
         
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            all_n=[]
            all_ids=[]
            for items in event['messages']:
                file_name=items['content']['document']['file_name']
                all_n.append(file_name)
                all_ids.append(str(items['content']['document']['document']['id']))
            ret = xbmcgui.Dialog().select("בחר קובץ גיבוי", all_n)
            if ret!=-1:
                ok=xbmcgui.Dialog().yesno(("שחזור מגיבוי"),all_n[ret]+' אתה בטוח שאתה רוצה לשחזר מגיבוי זה? ')
                if ok:
                    data={'type':'download_photo',
                             'info':all_ids[ret]
                             }
                    logging.warning('Sending')
                    file=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
                    logging.warning('file:'+file)
                    xbmc.sleep(100)
                    unzip(file,user_dataDir)
                    xbmcvfs.delete(file)
                    xbmcgui.Dialog().ok("שחזור מגיבוי",'[COLOR aqua][I]אל תשכח לשנות את שם הגיבוי בהגדרות. שוחזר בהצלחה[/I][/COLOR]')
        if os.path.isfile(zp_file):
            os.remove(zp_file)
    #except Exception as e:
    #    xbmcgui.Dialog().ok('תקלה','[COLOR red] בדוק את הגדרות ההרחבה [/COLOR]'+str(e))
    
    try:
        dp.close()
    except:
        pass
def backup_vik():
    import datetime
    strptime = datetime.datetime.strptime
    logging.warning('backing up')
    threading.Thread(target=do_bakcup).start()
    return '1'
def check_ftp_conn():
    import ftplib
    import os,urllib
    from datetime import datetime
    try:
        server=Addon.getSetting("ftp_host")
        username=Addon.getSetting("ftp_user")
        password=Addon.getSetting("ftp_pass")
        logging.warning(password)
        myFTP = ftplib.FTP(server, username, password)
        xbmcgui.Dialog().ok('התחברת בהצלחה','[COLOR yellow]התחברת בהצלחה[/COLOR]')
    except Exception as e:
        xbmcgui.Dialog().ok('שגיאת התחברות',str(e))
def tv_chan():
    addLink('ערוץ סדרות ילדים','מדובב',94,False,iconimage='http://www.webtechlearning.com/wp-content/uploads/2014/04/Best-Animation.jpg',fanart='https://marionettestudio.com/wp-content/uploads/2016/11/22-despicable-me-2-animation-movie.jpg',description='ערוץ סדרות ילדים'+'-KIDSSECTION-')
    dbcur.execute("SELECT * FROM mychan")

    match = dbcur.fetchall()
    for name,inc,disc in match:
        icon='https://upload.wikimedia.org/wikipedia/en/7/76/Channels_TV.jpg'
        fan='https://getchannels.com/assets/img/channels-banner.jpg'
        addLink(name.replace("%27","'"),inc.replace("%27","'"),97,False,iconimage=icon,fanart=fan,description=disc.replace("%27","'")+' ערוץ ',num_in_list='remove')
    addNolink('[COLOR khaki][I]הוסף ערוץ משלי[/I][/COLOR]','www',95,False,iconimage='http://chwilowka-online.us/wp-content/uploads/2018/04/watch-free-online-top-10-TV-shows.png',fanart='https://thevpn.guru/wp-content/uploads/2017/04/How-to-Watch-TV-Shows-on-Kodi-17-Krypton-e1491214966761.jpg')
def build_chan(url):
        from sdarot import resolve_dns,get_sdarot_ck
        import base64
        import random
        HEADERS = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                          ' (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36 Sdarot/2.5.3'
        }
        API = base64.decodestring('aHR0cHM6Ly9hcGkuc2Rhcm90Lndvcmxk')
        req,cookie_new=resolve_dns(API + '/series/search/{0}/page/{1}/perPage/100'.format(url, '0')).get()
        results = json.loads(req)
        xbmc.sleep(100)
        pg=random.randint(0,int(results['pages']['totalPages'])-1) 
        req,cookie_new=resolve_dns(API + '/series/search/{0}/page/{1}/perPage/100'.format(url, pg)).get()
        results = json.loads(req)['series']
        
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playlist.clear()
        all_links=[]
        
        results = json.loads(req)['series']
        rand_f=[]
        all_lt=[]
        
        if results:
            all_s=[]
            for s in results:
                all_s.append(s)
            
            random.shuffle(all_s)
           
            items = []
            xx=0
            for s in all_s:
               
                req ,cookie_new= resolve_dns(API + '/series/info/{0}'.format(s['id']), headers=HEADERS).get()
                req=json.loads(req)
            
                #req = requests.get(API + '/series/info/{0}'.format(s['id']), headers=HEADERS).json()
                serie = req['serie']
                ep_found=0
                se_found=0
                episodes = serie['episodes']
                try:
                    rand_season=random.randint(1,int(serie['seasons'])) 
                    rand_episode=random.randint(1,len(serie['episodes'][str(rand_season)]))
                  
                    rand_f=json.dumps((s['id'], rand_season, rand_episode))
                    token,cookie=cache.get(get_sdarot_ck,3,s['id'],unicode(rand_season),unicode(rand_episode), table='cookies')
                
                    link2=('%s?name=%s&mode=5&url=%s&data=%s&season=%s&episode=%s&original_title=%s&saved_name=%s&heb_name=%s&show_original_year=%s&eng_name=%s&isr=%s&id=%s&description=%s'%(sys.argv[0],s['heb'],urllib.quote_plus(rand_f),'0',rand_season,rand_episode,s['eng'],s['heb'],s['heb'],'0',s['eng'],'0','0','-sdarot-\n'+s['description']+'-KIDSSECTION-'))
                    listItem=xbmcgui.ListItem(s['heb'],path=link2)
                    listItem.setInfo('video', {'Title': s['heb'], 'Genre': 'Kids'})
                    
                    
                    if xx==0:
                        ok=xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
                    xx+=1
                    playlist.add(url=link2, listitem=listItem)
                except Exception as e:
                     logging.warning(e)
                     pass
                xbmc.sleep(3000)
                if xx>40:
                  break
                
                
            playlist.shuffle()
            
            
def open_ftp():
            text='''\
                כנס לאתר 
                [COLOR yellow]https://uwebweb.com/[/COLOR]
                ב Domain
                הכנס שם כלשהוא.
                הכנס מייל
                שם משתמש וסיסמא
                לחץ על 
                [COLOR yellow]Create now.[/COLOR]
                נשלח לך מייל, כנס למייל שלך
                פתח את המייל מ:
                [COLOR aqua]UWebWeb.com[/COLOR]
                לחץ על 
                [COLOR lightgreen]Verify[/COLOR]
                כעת יופיע לך חלון
                [COLOR aqua]Verify success[/COLOR]
                בתחתית החלון הזה תופיע כתובת
                זוהי כתובת שרת הFTP שלך.
                זה למעשה הHOST 
                בהגדרות ההרחבה יש להכניס את הHOST נקי
                כלומר במקום:
                http://xxxx.uwebweb.com/
                יש להכניס
                xxxx.uwebweb.com
                שם משתמש וסיסמא הם אלו שהכנסת ברישום
                זהו תהנה.
                
                
                
                
                  
                '''
            showText('הוראות פתיחת חשבון FTP', text)
            
def add_my_chan():
    from sdarot import resolve_dns
    import base64
    search_entered=''
   

    keyboard = xbmc.Keyboard(search_entered, 'הכנס שם לערוץ')
    keyboard.doModal()
    if keyboard.isConfirmed():
           search_entered = keyboard.getText()
           chan_name = search_entered
    else:
        sys.exit()
    search_entered=''
   
    API = base64.decodestring('aHR0cHM6Ly9hcGkuc2Rhcm90Lndvcmxk')
    req,cookie = resolve_dns(API + '/series/genres').get()

    req=json.loads(req)
    all_n=[]
    all_id=[]
    for genre in req['genres']:
        all_n.append(genre['name'])
        all_id.append(genre['id'])
    ret = xbmcgui.Dialog().select("בחר גאנר", all_n)
    if ret!=-1:
        chan_int=all_id[ret]
    else:
        sys.exit()
    search_entered=''
    keyboard = xbmc.Keyboard(search_entered, 'הכנס תיאור לערוץ')
    keyboard.doModal()
    if keyboard.isConfirmed():
           search_entered = keyboard.getText()
           chan_disc = search_entered
    else:
        sys.exit()
            
    dbcur.execute("INSERT INTO mychan Values ('%s', '%s', '%s');" %  (chan_name.replace("'","%27"),chan_int.replace("'","%27"),chan_disc.replace("'","%27")))
    dbcon.commit()
    xbmc.executebuiltin('Container.Refresh')
def remove_chan(name):
    dbcur.execute("DELETE  FROM mychan WHERE name = '%s'"%(name.replace("'","%27")))
      
    dbcon.commit()
    xbmc.executebuiltin('Container.Refresh')
    

def  play_custom(url):
    import base64
    from sdarot import resolve_dns,get_sdarot_ck
    HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                  ' (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36 Sdarot/2.5.3'
    }
    API = base64.decodestring('aHR0cHM6Ly9hcGkuc2Rhcm90Lndvcmxk')
    req,cookie_new = resolve_dns(API + '/series/list/{0}/page/{1}/perPage/100'.format(url, '0')).get()
    xbmc.sleep(100)
    req=json.loads(req)
    pg=random.randint(0,int(req['pages']['totalPages'])-1) 
    req,cookie_new = resolve_dns(API + '/series/list/{0}/page/{1}/perPage/100'.format(url, str(pg))).get()
    req=json.loads(req)

    items = []
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    xx=0
    for s in req['series']:
       
        req ,cookie_new= resolve_dns(API + '/series/info/{0}'.format(s['id']), headers=HEADERS).get()
        xbmc.sleep(100)
        req=json.loads(req)
        
        serie = req['serie']
        ep_found=0
        se_found=0
        episodes = serie['episodes']
        try:
            
            rand_season=random.randint(1,int(serie['seasons'])) 
            
            rand_episode=random.randint(1,len(serie['episodes'][str(rand_season)]))
          
            rand_f=json.dumps((s['id'], rand_season, rand_episode))
            token,cookie=cache.get(get_sdarot_ck,3,s['id'],unicode(rand_season),unicode(rand_episode), table='cookies')
        
            link2=('%s?name=%s&mode=161&url=%s&data=%s&season=%s&episode=%s&original_title=%s&saved_name=%s&heb_name=%s&show_original_year=%s&eng_name=%s&isr=%s&id=%s&description=%s'%(sys.argv[0],s['heb'],urllib.quote_plus(rand_f),'0',rand_season,rand_episode,s['eng'],s['heb'],s['heb'],'0',s['eng'],'0','0','-sdarot-\n'+s['description']))
            listItem=xbmcgui.ListItem(s['heb'],path=link2)
            listItem.setInfo('video', {'Title': s['heb'], 'Genre': 'Kids'})
            
            
            if xx==0:
                ok=xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
            xx+=1
            
            if xx>40:
              break
            playlist.add(url=link2, listitem=listItem)
        except Exception as e:
             logging.warning(e)
             
             pass
        xbmc.sleep(3000)
    playlist.shuffle()
def nba_solve(url):
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:67.0) Gecko/20100101 Firefox/67.0',
    'Accept': '*/*',
    'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
    'Referer': url,
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'X-Requested-With': 'XMLHttpRequest',
    'Connection': 'keep-alive',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    'TE': 'Trailers',
    }
    host=re.compile('//(.+?)/').findall(url)[0]
    

    data = {
      'r': '',
      'd': host
    }
    
    response = requests.post(url.replace('/v/','/api/source/'), headers=headers,  data=data).json()
    return response['data'][len(response['data'])-1]['file']
def nba(url,icon,fanart):
    headers = {
            
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.5',
            
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'X-Requested-With': 'XMLHttpRequest',
            'Connection': 'keep-alive',
          }
    html=requests.get(url,headers=headers).content
    regex='<option class="level-0" value="(.+?)">(.+?)<'
    match=re.compile(regex).findall(html)
    addNolink('[COLOR lightblue][I]Teams[/I][/COLOR]','www',940,False,iconimage=icon,fanart=fanart)
    
    for link,name in match:
        addDir3(name,'https://www.nbafullhd.com/?cat='+link,107,icon,fanart,name)
    addNolink('[COLOR lightblue][I]Archives[/I][/COLOR]','www',940,False,iconimage=icon,fanart=fanart)
    regex_pre='<option value="">Select Month</option>(.+?)</select>'
    m_pre=re.compile(regex_pre,re.DOTALL).findall(html)
    regex="<option value='(.+?)'>(.+?)</option>"
    '''
    match=re.compile(regex).findall(m_pre[0])
    
    
    for link,name in match:
        addDir3(name,link,107,icon,fanart,name)
    '''
def deep_nba(url,icon,fanart):
    headers = {
            
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.5',
            
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'X-Requested-With': 'XMLHttpRequest',
            'Connection': 'keep-alive',
          }
    html=requests.get(url,headers=headers).content
    regex='<div class="entry-thumbnail thumbnail-landscape">.+?<a href="(.+?)" title="(.+?)".+?data-lazy-src="(.+?)"' 
    match=re.compile(regex,re.DOTALL).findall(html)
  
    for link,title,image in match:
        title=replaceHTMLCodes(title)
        addDir3(title,link,108,image,image,title)
    regex='class="nextpostslink" rel="next" href="(.+?)"'
    match=re.compile(regex).findall(html)
    if len(match)>0:
        addDir3('[COLOR aqua][I]Next Page[/I][/COLOR]',match[0],107,icon,fanart,'[COLOR aqua][I]Next Page[/I][/COLOR]')
        
def play_nba(name,url,icon,fanart):
    headers = {
            
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.5',
            
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'X-Requested-With': 'XMLHttpRequest',
            'Connection': 'keep-alive',
          }
    logging.warning(url)
    html=requests.get(url,headers=headers).content
    regex='<p>Watch NBA(.+?)<div class="'
    m_pre=re.compile(regex,re.DOTALL).findall(html)
    
  
    regex='iframe.+?src="(.+?)"'
    m22=re.compile(regex).findall(html)
    for links in m22:
        if 'facebook' not in links:
            if 'http' not in links:
                m22[0]='http:'+links
            logging.warning(links)
            regex='//(.+?)/'
            server=re.compile(regex).findall(links)
            if len(server)>0:
                server=server[0].replace('openload','vummo').replace('letsupload','avlts')
                logging.warning(server)
                
                addLink('[COLOR yellow]'+server+'[/COLOR]', links,5,False,icon,fanart,'__NBA__'+'\n-HebDub-',original_title=name,saved_name=name)
    if len(m_pre)>0:
        regex='a href="(.+?)".+?alt="(.+?)"'
        m=re.compile(regex,re.DOTALL).findall(m_pre[0])
        for link,nn in m:
            z=requests.get(link,headers=headers).content
            regex='iframe.+?src="(.+?)"'
            m22=re.compile(regex).findall(z)
            if len(m22)>0:
                
                    if 'http' not in m22[0]:
                        m22[0]='http:'+m22[0]
                    logging.warning(m22[0])
                    regex='//(.+?)/'
                    server=re.compile(regex).findall(m22[0])
                    if len(server)>0:
                        server=server[0].replace('openload','vummo').replace('letsupload','avlts')
                        logging.warning(server)
                        
                        addLink('[COLOR yellow]'+server+'[/COLOR] - '+nn, m22[0],5,False,icon,fanart,'__NBA__'+'\n-HebDub-',original_title=name,saved_name=name)
          
def last_ep_aired(id):
    x=requests.get('https://api.themoviedb.org/3/tv/%s?api_key=34142515d9d23817496eeb4ff1d223d0&language=he'%id).json()
    season=str(x['last_episode_to_air']['season_number'])
    episode=str(x['last_episode_to_air']['episode_number'])
    name=x['last_episode_to_air']['name']
    fanart=domain_s+'image.tmdb.org/t/p/original/'+x['last_episode_to_air']['still_path']
    icon=domain_s+'image.tmdb.org/t/p/original/'+x['poster_path']
    description=x['last_episode_to_air']['overview']
    data=str(x['first_air_date'].split("-")[0])
    original_title=urllib.quote_plus(x['original_name'])
    eng_name=original_title
    show_original_year=str(x['first_air_date'].split("-")[0])
    heb_name=x['name'].decode('utf-8')
    isr='0'
    fav_search_f=Addon.getSetting("fav_search_f_tv")
    fav_servers_en=Addon.getSetting("fav_servers_en_tv")
    fav_servers=Addon.getSetting("fav_servers_tv")
    google_server= Addon.getSetting("google_server_tv")
    rapid_server=Addon.getSetting("rapid_server_tv")
    direct_server=Addon.getSetting("direct_server_tv")
    heb_server=Addon.getSetting("heb_server_tv")
        
   
    if  fav_search_f=='true' and fav_servers_en=='true' and (len(fav_servers)>0 or heb_server=='true' or google_server=='true' or rapid_server=='true' or direct_server=='true'):
    
        fav_status='true'
    else:
        fav_status='false'
    #get_sources(name,'www',icon,fanart,description,data,original_title,season,episode,id,eng_name,show_original_year,heb_name,isr,fav_status=fav_status)
    #xbmcplugin.endOfDirectory(int(sys.argv[1]))
    xbmc.executebuiltin(('ActivateWindow(10025,"plugin://plugin.video.allmoviesin/?name=%s&url=%s&iconimage=%s&fanart=%s&description=%s&data=%s&original_title=%s&id=%s&season=%s&tmdbid=%s&show_original_year=%s&heb_name=%s&isr=%s&mode=4&episode=%s&eng_name=%s&fav_status=%s",return)'%(name,url,icon,fanart,description,data,original_title,id,season,tmdbid,show_original_year,heb_name,isr,episode,eng_name,fav_status)))
    return 0
                
                
def search_torrents():
        search_entered=''
        keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש כאן')
        keyboard.doModal()
        episode='0'
        season='0'
        if keyboard.isConfirmed():
               search_entered = keyboard.getText()
               s_title=search_entered
               
               impmodule = __import__('magnet_zg')
               items=impmodule.get_links('all',s_title,s_title,"","","","",'0','0')
               for title,o_link,server,res in items:
                   regex=' - (.+?) GB'
                  
                   try:
                         size=re.compile(regex).findall(server)[0]
                         
                         
                   except:
                       
                       size='0'
                   regex='{P-(.+?)/S-(.+?)}'
        
                   seeds=re.compile(regex).findall(server)[0][1]
                   peers=re.compile(regex).findall(server)[0][0]
                    
                   seeds=seeds.replace(',','')
                   peers=peers.replace(',','')
                    
                    
                   server='- P%s/S%s -  [COLOR lightgreen]%sGB[/COLOR]-'%(peers,seeds,size)
            
                   addLink(title.replace("+"," ")+server,o_link,5,False,iconimage=' ',fanart=' ',description=title)
                   
def get_server_types(type):
    if type=='tv':
        libDir = os.path.join(addonPath, 'resources', 'report_tv.txt')
    else:
        libDir = os.path.join(addonPath, 'resources', 'report_movie.txt')
    file = open(libDir, 'r') 
    file_data= file.read()
    file.close()
    regex='Start(.+?)END'
  
    m=re.compile(regex,re.DOTALL).findall(file_data)
    all_direct=[]
    all_google=[]
    all_rapid=[]
    all_heb=[]
    for items in m:
        regex='\[(.+?)\].+?\{(.+?)\}'
        m2=re.compile(regex,re.DOTALL).findall(items)
        for sname,stype in m2:
           
            if 'direct' in stype.lower():
                all_direct.append(sname)
            if 'google' in stype.lower():
                all_google.append(sname)
            if 'rapidvideo' in stype.lower():
                all_rapid.append(sname)
    onlyfiles = [f for f in listdir(done_dir) if isfile(join(done_dir, f))]
 
        
    for items in onlyfiles:
        
       
        if items !='cache.py' and items !='general.py' and '.pyc' not in items and '.pyo' not in items and '__init__' not in items and items !='resolveurl_temp.py' and items!='cloudflare.py' and items!='Addon.py':
            impmodule = __import__(items.replace('.py',''))
            if 'subs' in impmodule.type:
                all_heb.append(items.replace('.py',''))
    onlyfiles = [f for f in listdir(done_dir) if isfile(join(done_dir, f))]

            
            
            
           
    return all_direct,all_google,all_rapid,all_heb
def login_ktuvit():
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:72.0) Gecko/20100101 Firefox/72.0',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'Content-Type': 'application/json',
        'X-Requested-With': 'XMLHttpRequest',
        'Origin': 'https://www.ktuvit.net',
        'Connection': 'keep-alive',
        'Referer': 'https://www.ktuvit.net/',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }

    data = {'request':{'Email':'hatzel6969@gmail.com','Password':'Jw1n9nPOZRAHw9aVdarvjMph2L85pKGx79oAAFTCsaE='}}

    response = requests.post('https://www.ktuvit.net/Services/MembershipService.svc/Login', headers=headers, json=data).cookies
    logging.warning(response)
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:72.0) Gecko/20100101 Firefox/72.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
    'Connection': 'keep-alive',
    'Referer': 'https://www.ktuvit.net/',
    'Upgrade-Insecure-Requests': '1',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    'TE': 'Trailers',
    }
    cookies={}
    cook=[]
    for cookie in response:
         cook.append(cookie.name+'='+cookie.value)
         cookies[cookie.name]=cookie.value
    logging.warning(cookies)
    response = requests.get('https://www.ktuvit.net/', headers=headers, cookies=cookies).cookies
    logging.warning(response)
    for cookie in response:
         cook.append(cookie.name+'='+cookie.value)
         cookies[cookie.name]=cookie.value
    return json.dumps(cookies)

def last_tv_subs(url):
    #cookies_login=login_ktuvit()
    cookies_login=json.loads(cache.get(login_ktuvit,1, table='pages'))
    headers = {
        
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
    }
    x=requests.get(url,headers=headers,cookies=cookies_login).content
    regex='<div class="col-md-12">(.+?)</span>'
    match=re.compile(regex,re.DOTALL).findall(x)
    fav_search_f=Addon.getSetting("fav_search_f_tv")
    fav_servers_en=Addon.getSetting("fav_servers_en_tv")
    fav_servers=Addon.getSetting("fav_servers_tv")
    google_server= Addon.getSetting("google_server_tv")
    rapid_server=Addon.getSetting("rapid_server_tv")
    direct_server=Addon.getSetting("direct_server_tv")
    heb_server=Addon.getSetting("heb_server_tv")
    if  fav_search_f=='true' and fav_servers_en=='true' and (len(fav_servers)>0 or heb_server=='true' or google_server=='true' or rapid_server=='true' or direct_server=='true'):
        fav_status='true'
    else:
        fav_status='false'
   
              
              
    for items in match:
        regex='<img src="(.+?)".+?<h3>(.+?)\((.+?)\)</h3>.+?<h4>עונה (.+?) פרק (.+?)</h4>.+?data-elipsis-hidden="true">(.+?)<.+?data-title="(.+?)"'
        m2=re.compile(regex,re.DOTALL).findall(items)
        if len(m2)>0:
            icon='https://www.screwzira.com'+m2[0][0]
            image=icon
            new_name=m2[0][1]
            original_title=m2[0][2]
            season=m2[0][3]
            episode=m2[0][4]
            plot=m2[0][5]
            id=m2[0][6]

            
            addDir3( new_name + '[COLOR yellow] עונה %s פרק %s '%(season,episode)+'[/COLOR]', url,4, icon,image,plot,original_title=original_title,season=season,episode=episode,eng_name=original_title,heb_name=new_name,fav_status=fav_status,id=id)
    regex='<li ><a href="(.+?)">הבא</a></li>'
    m3=re.compile(regex).findall(x)
    if len(m3)>0:
        addDir3( '[COLOR yellow][I]הדף הבא[/I][/COLOR]', 'https://www.screwzira.com'+m3[0],113, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTNmz-ZpsUi0yrgtmpDEj4_UpJ1XKGEt3f_xYXC-kgFMM-zZujsg','https://cdn4.iconfinder.com/data/icons/arrows-1-6/48/1-512.png','הדף הבא')
def get_im_data_rt(imdbid,plot_o,html_g,xxx):
    import random
    global all_data_imdb
    
    url='https://api.themoviedb.org/3/find/%s?api_key=b7cd3340a794e5a2f35e3abb820b497f&language=heb&external_source=imdb_id'%imdbid
    
    
    
    #y=requests.get(url,headers=headers).json()
    y=json.loads(urllib2.urlopen(url).read())
    
    if 'סרטים' in plot_o:
        r=y['movie_results']
    else:

        r=y['tv_results']
  
 
    if len(r)>0:
        if 'סרטים' in plot_o:
            new_name=r[0]['title']
        else:
            new_name=r[0]['name']
 
        
        icon=domain_s+'image.tmdb.org/t/p/original/'+r[0]['poster_path']
        if r[0]['backdrop_path']!=None:
            image=domain_s+'image.tmdb.org/t/p/original/'+r[0]['backdrop_path']
        else:
            image=' '
        plot=r[0]['overview']
        if 'סרטים' in plot_o:
            original_title=r[0]['original_title']
        else:
        
            original_title=r[0]['original_name']
        rating=r[0]['vote_average']
        if 'סרטים' in plot_o:
            year=str(r[0]['release_date'].split("-")[0])
        else:
            year=str(r[0]['first_air_date'].split("-")[0])
        genres_list= dict([(i['id'], i['name']) for i in html_g['genres'] \
        if i['name'] is not None])
        try:genere = u' / '.join([genres_list[x] for x in r[0]['genre_ids']])
        except:genere=''
         
        id=str(r[0]['id'])
        if 'סרטים' in plot_o:
            fav_search_f=Addon.getSetting("fav_search_f")
            fav_servers_en=Addon.getSetting("fav_servers_en")
            fav_servers=Addon.getSetting("fav_servers")
           
            google_server= Addon.getSetting("google_server")
            rapid_server=Addon.getSetting("rapid_server")
            direct_server=Addon.getSetting("direct_server")
            heb_server=Addon.getSetting("heb_server")
        else:
            fav_search_f=Addon.getSetting("fav_search_f_tv")
            fav_servers_en=Addon.getSetting("fav_servers_en_tv")
            fav_servers=Addon.getSetting("fav_servers_tv")
            google_server= Addon.getSetting("google_server_tv")
            rapid_server=Addon.getSetting("rapid_server_tv")
            direct_server=Addon.getSetting("direct_server_tv")
            heb_server=Addon.getSetting("heb_server_tv")


        if  fav_search_f=='true' and fav_servers_en=='true' and (len(fav_servers)>0 or heb_server=='true' or google_server=='true' or rapid_server=='true' or direct_server=='true'):
        
            fav_status='true'
        else:
            fav_status='false'
       
        all_data_imdb.append(( new_name , url,icon,image,plot,rating,year,genere,original_title,id,heb_name,fav_status,xxx,imdbid))
        
def get_data_imdb(m,plot_o):
    import urllib2
    global all_data_imdb
    headers = {
        
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
    }

    if 'סרטים' in plot_o:
        url_g=domain_s+'api.themoviedb.org/3/genre/movie/list?api_key=34142515d9d23817496eeb4ff1d223d0&language=he'
        html_g=html_g_movie
    else:

        url_g=domain_s+'api.themoviedb.org/3/genre/tv/list?api_key=34142515d9d23817496eeb4ff1d223d0&language=he'
        html_g=html_g_tv
    if Addon.getSetting("dp")=='true':
        dp = xbmcgui . DialogProgress ( )
        dp.create('אנא המתן','מעדכן', '','')
        dp.update(0, 'אנא המתן','מעדכן', '' )
    z=0
    #html_g=requests.get(url_g).json()
    thread=[]
    xxx=0
    for imdbid in m:
        
        thread.append(Thread(get_im_data_rt,imdbid,plot_o,html_g,xxx))
        thread[len(thread)-1].setName(imdbid)
        xxx+=1
    z=0
    for td in thread:
      td.start()
      if len(thread)>38:
        xbmc.sleep(255)
      else:
        xbmc.sleep(10)
      if Addon.getSetting("dp")=='true':
            dp.update(int(((z* 100.0)/(len(thread))) ), 'אנא המתן','מעדכן', td.name )
            z=z+1
    num_live_pre=0
    while 1:
         
         
          
         
        
        
          
          num_live=0
          still_alive=0
          for yy in range(0,len(thread)):
            
            if  thread[yy].is_alive():
 
              num_live=num_live+1
              
             
              still_alive=1
            if Addon.getSetting("dp")=='true':
                dp.update(len(thread)-num_live_pre, 'אנא המתן','מעדכן', thread[yy].name )
          num_live_pre=num_live
          if Addon.getSetting("dp")=='true':
              if dp.iscanceled(): 
                    dp.close()
                    break
          
          if still_alive==0:
            break
          xbmc.sleep(100)
    if Addon.getSetting("dp")=='true':
        dp.close()
    return all_data_imdb
def must_see(plot,url):
    o_plot=plot
    headers = {
        
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
    }
    x1=requests.get(url,headers=headers).content
    if 'סרטים' in plot:
        mode=4
        regex='data-titleid="(.+?)"'
    else:
        mode=7
        regex='<div class="ribbonize" data-tconst="(.+?)"'
        
    m=re.compile(regex).findall(x1)
    logging.warning(m)
    logging.warning(mode)
    if len(m)==0:
        regex='<div class="ribbonize" data-tconst="(.+?)"'
        m=re.compile(regex).findall(x1)
    all_data=cache.get(get_data_imdb,24,m,plot, table='pages')

    #all_data=get_data_imdb(m,plot)
    all_data=sorted(all_data, key=lambda x: x[12], reverse=False)
    for new_name , url,icon,image,plot,rating,year,genere,original_title,id,heb_name,fav_status,xxx,imdbid in all_data:
           
            
            addDir3( new_name , url,mode, icon,image,plot,rating=rating,data=year,show_original_year=year,generes=genere,original_title=original_title,id=id,eng_name=original_title,heb_name=new_name,fav_status=fav_status)
            
    
    
    regex='title_type=tv_series&start=(.+?)&'
    m=re.compile(regex,re.DOTALL).findall(x1)
    
    if len(m)==0:
        regex='<div class="desc">.+?a href="(.+?)"'
        m2=re.compile(regex,re.DOTALL).findall(x1)
        
        addDir3( '[COLOR yellow][I]הדף הבא[/I][/COLOR]', 'https://www.imdb.com'+m2[0],114, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTNmz-ZpsUi0yrgtmpDEj4_UpJ1XKGEt3f_xYXC-kgFMM-zZujsg','https://cdn4.iconfinder.com/data/icons/arrows-1-6/48/1-512.png',o_plot)
    elif len(m)>0:
        addDir3( '[COLOR yellow][I]הדף הבא[/I][/COLOR]', 'https://www.imdb.com/search/title?title_type=tv_series&start=%s&ref_=adv_nxt'%m[0],114, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTNmz-ZpsUi0yrgtmpDEj4_UpJ1XKGEt3f_xYXC-kgFMM-zZujsg','https://cdn4.iconfinder.com/data/icons/arrows-1-6/48/1-512.png',o_plot)
    return 'ok'
def check_hebits():
    username = Addon.getSetting('username_hebits')
    password = Addon.getSetting('Password_sdr_hebits')
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
        'Accept': '*/*',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'Content-Type': 'application/x-www-form-urlencoded',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        
        'Cache-Control': 'no-cache',
    }

    data = {
      'username': username,
      'password': password
    }

    tk_cook = requests.post('https://hebits.net/takeloginAjax.php', headers=headers, data=data).cookies

    if len(tk_cook)==0:
        xbmcgui.Dialog().ok('שגיאה!!!!!!','[COLOR red]שגיאת התחברות בדוק שם משתמש וסיסמא[/COLOR]')
    else:
        xbmcgui.Dialog().ok('הצלחה','[COLOR aqua][I]התחברת בהצלחה[/I][/COLOR]')
def get_torrent_file(silent_mode=False):
    import shutil
    dp = xbmcgui . DialogProgress ( )
    dp.create('אנא המתן','בודק אם נגן קיים', '','')
    dp.update(0, 'אנא המתן','בודק אם נגן קיים', '' )
    def download_file(url,path):
        local_filename =os.path.join(path, "1.zip")
        # NOTE the stream=True parameter
        r = requests.get(url, stream=True)
        total_length = r.headers.get('content-length')

        if total_length is None: # no content length header
            total_length=1
        with open(local_filename, 'wb') as f:
            dl = 0
            total_length = int(total_length)
            for chunk in r.iter_content(chunk_size=1024): 
                dl += len(chunk)
                done = int(100 * dl / total_length)
                dp.update(done, 'אנא המתן','מוריד נגן', '' )
                if chunk: # filter out keep-alive new chunks
                    f.write(chunk)
                    #f.flush() commented by recommendation from J.F.Sebastian
        return local_filename

    def unzip(file,path):
        dp.update(100, 'אנא המתן','מחלץ', '' )
        from zipfile import ZipFile
        
        
        zip_file = file
        ptp = 'Masterpenpass'
        #xbmc.executebuiltin("XBMC.Extract({0}, {1})".format(zip_file, path), True)
        
        zf=ZipFile(zip_file)
        #zf.setpassword(bytes(ptp))
        #with ZipFile(zip_file) as zf:
        zf.extractall(path)
        
    from kodipopcorntime.platform import Platform
    binary = "torrent2http"
    bin_dataDir=(os.path.join(xbmc.translatePath(Addon.getAddonInfo('profile')), 'resources', 'bin',"%s_%s" %(Platform.system, Platform.arch))).encode('utf-8')
    if Platform.system == 'windows':
        binary = "torrent2http.exe"
        url='https://github.com/DiMartinoXBMC/script.module.torrent2http/raw/master/bin/windows_x86/torrent2http.exe.zip'
        file=os.path.join(bin_dataDir,'1.zip')
    elif Platform.system == "android":
        url='https://github.com/DiMartinoXBMC/script.module.torrent2http/raw/master/bin/android_arm/torrent2http.zip'
        file=os.path.join(bin_dataDir,'1.zip')
    else:
        url='https://github.com/DiMartinoXBMC/script.module.torrent2http/raw/master/bin/linux_arm/torrent2http.zip'
        file=os.path.join(bin_dataDir,'1.zip')
    torrent_file=os.path.join(xbmc.translatePath(Addon.getAddonInfo('profile')), 'resources', 'bin', "%s_%s" %(Platform.system, Platform.arch), binary).encode('utf-8')
    
    logging.warning(torrent_file)
    logging.warning(os.path.isfile(torrent_file))
    logging.warning(os.path.exists(bin_dataDir))
    if not os.path.exists(bin_dataDir) or not os.path.isfile(torrent_file):
        if os.path.exists(bin_dataDir):
           
            shutil.rmtree(bin_dataDir)
        
        os.makedirs(bin_dataDir)
        
        download_file(url,bin_dataDir)
        unzip(file,bin_dataDir)
        os.remove(file)
    else:
        if silent_mode==False:
       
            ok=xbmcgui.Dialog().yesno(("נגן קיים"),('להוריד בכל זאת?'))
            if ok:
                shutil.rmtree(bin_dataDir)
                os.makedirs(bin_dataDir)
        
                download_file(url,bin_dataDir)
                unzip(file,bin_dataDir)
                os.remove(file)
        
    dp.close()
    if silent_mode==False:
        xbmcgui.Dialog().ok('הורדה','[COLOR aqua][I] הורד בהצלחה תהנה [/I][/COLOR]')
def remove_torrent_file():
    import shutil
    from kodipopcorntime.platform import Platform
    bin_dataDir=(os.path.join(xbmc.translatePath(Addon.getAddonInfo('profile')), 'resources', 'bin',"%s_%s" %(Platform.system, Platform.arch))).encode('utf-8')
            
    if  os.path.exists(bin_dataDir):
        ok=xbmcgui.Dialog().yesno(("מחיקת נגן טורנטים"),('בטוח? במידה ותפעיל טורנט דרך נגן ויקטורי הנגן יורד אוטומטית'))
        if ok:
            
            
            
            shutil.rmtree(bin_dataDir)
                
            xbmcgui.Dialog().ok('הסרה','[COLOR aqua][I] הוסר [/I][/COLOR]')
    else:
        xbmcgui.Dialog().ok('הסרה','[COLOR aqua][I] נגן לא קיים [/I][/COLOR]')
        
def histadarti(icon,image):
    addDir3('פרקים אחרונים'.decode('utf8'),'https://www.hitarganti.net/tv-show/',123,icon,image,'פרקים אחרונים'.decode('utf8'))
    addDir3('סדרות'.decode('utf8'),'https://www.hitarganti.net/serial/',123,icon,image,'סדרות'.decode('utf8'))
    addDir3('סרטים'.decode('utf8'),'https://www.hitarganti.net/movie/',123,icon,image,'סרטים'.decode('utf8'))
        
def n_histadarti(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
        'Accept': '*/*',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'Content-Type': 'application/x-www-form-urlencoded',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        
        'Cache-Control': 'no-cache',
    }
    x=requests.get(url,headers=headers).content
    regex='<div class="serial-post">.+?<a href="(.+?)">(.+?)<.+?<img src="(.+?)"'
    m=re.compile(regex,re.DOTALL).findall(x)
    if len(m)>0:
        for link,title,image in m:
            addDir3(title,link,124,image,image,title)
    else:
        regex='<div class="single-post">.+?href="(.+?)">(.+?)<.+?img src="(.+?)"'
        m=re.compile(regex,re.DOTALL).findall(x)
        for link,title,image in m:
            addLink(title,link,5,False,image,image,title)
    regex='a class="nextpostslink" rel="next" href="(.+?)"'
    m=re.compile(regex).findall(x)
    if len(m)>0:
        addDir3('[COLOR aqua][I]עוד תוצאות[/I][/COLOR]'.decode('utf8'),m[0],123,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTNmz-ZpsUi0yrgtmpDEj4_UpJ1XKGEt3f_xYXC-kgFMM-zZujsg','https://cdn4.iconfinder.com/data/icons/arrows-1-6/48/1-512.png','עוד תוצאות'.decode('utf8'),isr=isr)
        
def ep_histadarti(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
        'Accept': '*/*',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'Content-Type': 'application/x-www-form-urlencoded',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        
        'Cache-Control': 'no-cache',
    }
    x=requests.get(url,headers=headers).content
    regex='<div class="single-post">.+?href="(.+?)">(.+?)<.+?img src="(.+?)"'
    m=re.compile(regex,re.DOTALL).findall(x)
    for link,title,image in m:
        addLink(title,link,5,False,image,image,title)

def israeli_new():
    __IMAGES_BASE__ = "http://img.wcdn.co.il/"
    url='http://ws.vod.walla.co.il/ws-v3/mobile/android/genre/movies?id=6260&page=1&limit=500&sort=newest'
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
        'Accept': '*/*',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'Content-Type': 'application/x-www-form-urlencoded',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        
        'Cache-Control': 'no-cache',
    }
    resultJSON=requests.get(url,headers=headers).json()
    genreItems = resultJSON["events"]
    totalResults = resultJSON["genre"]["amount"]
    for item in genreItems:
            if item["parentControl"] :
                continue
            itemName = item["title"]
            if item.has_key("media"):
                 media=item["media"]
            itemId = str(item["id"])
            typeName = item["typeName"]
            about = item["about"]
            duration = str(item.get("duration", 0))
            if media["types"].has_key("type_29"):  
                iconImage = __IMAGES_BASE__ + media["types"]["type_29"]["file"]+'.jpg'
            else:
                iconImage = 'DefaultFolder.png'     
            addLink(itemName,"walla_item_id="+ itemId,5,False,iconImage,iconImage,about)
            #common.addVideoLink("UTF-8",itemName, "item_id="+ itemId ,5, iconImage,elementId=__NAME__, sum=about,duration=duration, year=item.get("relaseDate"))
def doco_cat(iconimage,fanart):
    
    addDir3('[COLOR aqua][I]דוקו יוטיוב[/I][/COLOR]'.decode('utf8'),'https://www.youtube.com/results?sp=EgIYAg%253D%253D&search_query=%D7%A2%D7%A8%D7%95%D7%A5+8+%D7%A1%D7%A8%D7%98%D7%99%D7%9D+%D7%93%D7%95%D7%A7%D7%95%D7%9E%D7%A0%D7%98%D7%A8%D7%99%D7%9D&page=1',117,iconimage,fanart,'דוקו יוטיוב'.decode('utf8'))
    addDir3('[COLOR gray][I]דוקו כאן[/I][/COLOR]'.decode('utf8'),'https://www.kan.org.il/program/getMoreProgram.aspx?count=1&catId=1076',127,iconimage,fanart,'דוקו כאן'.decode('utf8'))
    addDir3('[COLOR red][I]דוקו רשת[/I][/COLOR]'.decode('utf8'),'https://www.kan.org.il/program/getMoreProgram.aspx?count=1&catId=1076',128,iconimage,fanart,'דוקו כאן'.decode('utf8'))
    addDir3('[COLOR pink][I]דוקו קשת[/I][/COLOR]'.decode('utf8'),'https://www.kan.org.il/program/getMoreProgram.aspx?count=1&catId=1076',129,iconimage,fanart,'דוקו כאן'.decode('utf8'))
    
    url='http://10tv.nana10.co.il/category/?CategoryID=600356'
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
        'Accept': '*/*',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'Content-Type': 'application/x-www-form-urlencoded',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        
        'Cache-Control': 'no-cache',
    }
    result=requests.get(url,headers=headers).content
    regex='<a sectionid="(.+?)".+?>(.+?)<'
    m=re.compile(regex).findall(result)
    for link,title in m:
        addDir3(' דוקו 10 -'+title.decode('utf8'),link,126,iconimage,fanart,'דוקו 10'.decode('utf8'))
    
def get_doco_list(url):
    
    url='http://common.nana10.co.il/SectionVOD/GetSectionVOD.ashx?PageSize=150&FetchVideo=1&PageNumber=1&SectionID='+url
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
        'Accept': '*/*',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'Content-Type': 'application/x-www-form-urlencoded',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        
        'Cache-Control': 'no-cache',
    }
    
    result=requests.get(url,headers=headers).content
    regex='\(\{(.+?)\}\)'
    m=re.compile(regex,re.DOTALL).findall(result)
    r_json=json.loads('{'+m[0]+'}')
    for items in r_json['HeadlineList']:
        if len(items['ThumbPicPath'])>2:
            img='http://f.nanafiles.co.il'+items['ThumbPicPath']
        elif len(items['PicPath'])>2:
            img='http://f.nanafiles.co.il'+items['PicPath']
        else:
            img='http://f.nanafiles.co.il//upload/mediastock/img/693/0/%s/%s.jpg'%(str(items['MediaStockImageID'])[:3],str(items['MediaStockImageID']))

        addLink(items['Title'],items['LinkHref'],5,False,img,img,items['SEODescription'])
        
def get_doco_kan(url):
    page=1
    m_pre=['1','2']
    while (len(m_pre))>0:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
            'Accept': '*/*',
            'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Requested-With': 'XMLHttpRequest',
            'Connection': 'keep-alive',
            'Pragma': 'no-cache',
            
            'Cache-Control': 'no-cache',
        }
        
        result=requests.get(url,headers=headers).content
        regex='<li class="program_list_item w-clearfix">(.+?)</li>'
        m_pre=re.compile(regex,re.DOTALL).findall(result)

        for items in m_pre:
            regex='background-image\: url\(\'(.+?)\'.+?<iframe.+?src="(.+?)".+?<h2 class="content_title">(.+?)<.+?<p>(.+?)<'
            m=re.compile(regex,re.DOTALL).findall(items)
            for img,link,title,plot in m:
                title=title.replace('\n','').replace('\r','').strip()
                plot=plot.replace('\n','').replace('\r','').strip()
                addLink(title,link,5,False,img,img,plot)
        page+=1
        url='https://www.kan.org.il/program/getMoreProgram.aspx?count=%s&catId=1076'%str(page)
    
    
def get_doco_reshet():
    all_links=[]
    url='https://reshet.tv/news/documentary'
    headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
            'Accept': '*/*',
            'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Requested-With': 'XMLHttpRequest',
            'Connection': 'keep-alive',
            'Pragma': 'no-cache',
            
            'Cache-Control': 'no-cache',
        }
        
    html=requests.get(url,headers=headers).content
    data_query = re.compile('initial_data = \{(.*?)\};').findall(html)
    result = json.loads('{' + data_query[0] + '}')
   
    for grid in result['items']:
            z=result['items'][grid]
        
            
            name=z['gridView']['titleForGrid']
            
            if  z['video']!=None:
                link=z['video']['src']
                if link==None:
                    continue
                if link not in all_links:
                    all_links.append(link)
                    icon=z['video']['poster']
                    infos=z['postContent']
                    
                    addLink(name,link,5,False,icon,icon,infos)
    url='https://reshet.tv/news/documentary/page/2/'
    html=requests.get(url,headers=headers).content
    data_query = re.compile('initial_data = \{(.*?)\};').findall(html)
    result = json.loads('{' + data_query[0] + '}')
   
    for grid in result['items']:
            z=result['items'][grid]
       
            
            name=z['gridView']['titleForGrid']
            
            if  z['video']!=None:
                 link=z['video']['src']
                 if link==None:
                    continue
                 if link not in all_links:
                    all_links.append(link)
                    icon=z['video']['poster']
                    infos=z['postContent']
                   
                    addLink(name,link,5,False,icon,icon,infos)
    
    logging.warning('H3')
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
def GetJson(url):
    html = requests.get(url, headers={"User-Agent": 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0'}).content
    if html == "":
        return None
    resultJSON = json.loads(html)
    if resultJSON is None or len(resultJSON) < 1:
        return None
    if resultJSON.has_key("root"):
        return resultJSON["root"]
    else:
        return resultJSON
def GetLabelColor(text, keyColor=None, bold=False, color=None):
    if not color:
        if keyColor=='prColor':
            color='orange'
        else:
            color='yellow'
        
        
    if bold :
        text = '[B]{0}[/B]'.format(text)
    return text if color == 'none' else '[COLOR {0}]{1}[/COLOR]'.format(color, text)
def getDisplayName(title, subtitle, programNameFormat, bold=False):
	if programNameFormat == 0:
		displayName = ' {0} - {1} '.format(GetLabelColor(title, keyColor="prColor", bold=bold) , GetLabelColor(subtitle, keyColor="chColor"))
	elif programNameFormat == 1:
		displayName = ' {0} - {1} '.format(GetLabelColor(subtitle, keyColor="chColor") , GetLabelColor(title, keyColor="prColor", bold=bold))
	return displayName
def get_doco_keshet():
    baseUrl = 'http://www.mako.co.il'
    prms = GetJson('http://www.mako.co.il/mako-vod-more/docu_tv?type=service&device=desktop&strto=true')
    
    for serie in prms['moreVOD']['items']:
        
            
            title = serie.get("title", "").strip().encode("utf-8")
            subtitle = serie.get("subtitle", "").strip().encode("utf-8")
            url = serie.get("url", "")
            if url == "":
                url = serie.get("link", "")
            url = "{0}{1}".format(baseUrl, url)
            if "VOD-" in url:
                
                title = getDisplayName(title, subtitle, 0, bold=False) if subtitle != "" else GetLabelColor(title, keyColor="prColor", bold=False)
            else:
                title = GetLabelColor(title, keyColor="prColor", bold=True)
            icon = serie["picI"]
            description = serie.get("brief", "").strip().encode("utf-8")
            if serie.has_key("plot"):
                description = "{0} - {1}".format(description, serie["plot"].strip().encode("utf-8"))
            addLink(title,url,5,False,icon,icon,description)
                
    logging.warning('H4')
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
def moridim(url):
    
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:68.0) Gecko/20100101 Firefox/68.0',
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'X-Requested-With': 'XMLHttpRequest',
    'Connection': 'keep-alive',
    'Referer': 'https://moridim.xyz/%D7%A1%D7%A8%D7%98%D7%99%D7%9D.html',
    'TE': 'Trailers',
    }

    data = {
      'type': 'movies',
      'index': url,
      'order': 'lastupdate',
      'sort': 'DESC',
      'limit': '100'
    }

    response = requests.post('https://moridim.xyz/ajax/fetch.php', headers=headers, data=data).json()
    for items in response:
        for it in items:
            items[it]=str(items[it]).encode('utf8')
        video_data={}
        video_data['title']=items['hebName']
        video_data['poster']='https://moridim.xyz/'+items['image']
        video_data['plot']='[COLOR yellow]'+items['qualities']+'[/COLOR]\n'+items['plot']
        video_data['icon']='https://moridim.xyz/'+items['image']
        video_data['genre']=items['genres']
        video_data['year']=items['year']
        addDir3( items['hebName'], 'https://moridim.xyz/'+items['url'],4,'https://moridim.xyz/'+items['image'],'https://moridim.xyz/'+items['image'],'[COLOR yellow]'+items['qualities']+'[/COLOR]\n'+items['plot'],original_title=items['engName'],id='moridim',eng_name=items['engName'],heb_name=items['hebName'],video_info=video_data,data=items['year'])
    addDir3('[COLOR blue][B][I]הדף הבא[/I][/B][/COLOR]', str(int(url)+100),130,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTNmz-ZpsUi0yrgtmpDEj4_UpJ1XKGEt3f_xYXC-kgFMM-zZujsg','https://cdn4.iconfinder.com/data/icons/arrows-1-6/48/1-512.png','[COLOR blue][B][I]הדף הבא[/I][/B][/COLOR]')
def get_actor_oscar(url):
     
    headers = {
        
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
    }
    x1=requests.get(url,headers=headers).content
    regex='div class="lister-item-image">.+?<img alt="(.+?)".+?src="(.+?)".+?/title/(.+?)/'
    m=re.compile(regex,re.DOTALL).findall(x1)
    all_imdb={}
    m1=[]
    for title,img,imdb in m:
        if imdb in m1:
            m1.append(imdb)
            all_imdb[imdb]['name']=all_imdb[imdb]['name']+'$$$$$$'+title
            all_imdb[imdb]['img']=all_imdb[imdb]['img']+'$$$$$$'+img
            all_imdb[imdb]['done']=1
        else:
        
            m1.append(imdb)
            all_imdb[imdb]={}
            all_imdb[imdb]['name']=title
            all_imdb[imdb]['img']=img
            all_imdb[imdb]['done']=0
    all_data=cache.get(get_data_imdb,24,m1,'סרטים', table='pages')

    #all_data=get_data_imdb(m,plot)
    all_data=sorted(all_data, key=lambda x: x[5], reverse=True)
    
    for new_name , url,icon,image,plot,rating,year,genere,original_title,id,heb_name,fav_status,xxx,imdbid in all_data:
            add_p=''
            add_img=icon
            if imdbid in all_imdb:
                if '$$$$$$' in all_imdb[imdbid]['name']:
                
                    if all_imdb[imdbid]['done']==1:
                        index=1
                        add_p='[COLOR yellow]Oscar Winner - '+all_imdb[imdbid]['name'].split('$$$$$$')[index]+'[/COLOR]\n'
                        add_img=all_imdb[imdbid]['img'].split('$$$$$$')[index]
                        all_imdb[imdbid]['done']=0
                        
                    else:
                        index=0
                        add_p='[COLOR yellow]Oscar Winner - '+all_imdb[imdbid]['name'].split('$$$$$$')[index]+'[/COLOR]\n'
                        add_img=all_imdb[imdbid]['img'].split('$$$$$$')[index]
                        all_imdb[imdbid]['done']=1
                else:
                    add_p='[COLOR yellow]Oscar Winner - '+all_imdb[imdbid]['name']+'[/COLOR]\n'
                    add_img=all_imdb[imdbid]['img']
            addDir3( new_name , url,4, add_img,image,add_p+plot,rating=rating,data=year,show_original_year=year,generes=genere,original_title=original_title,id=id,eng_name=original_title,heb_name=new_name,fav_status=fav_status)
            
    
    
    regex='next-page" href="(.+?)"'
    m=re.compile(regex).findall(x1)
  
    if len(m)>0:
      
        addDir3( '[COLOR yellow][I]הדף הבא[/I][/COLOR]', 'https://www.imdb.com'+m[0],134, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTNmz-ZpsUi0yrgtmpDEj4_UpJ1XKGEt3f_xYXC-kgFMM-zZujsg','https://cdn4.iconfinder.com/data/icons/arrows-1-6/48/1-512.png','סרטים')
   
    return 'ok'

def movie_wall(new_imdb=False):
    cacheFile2 = os.path.join(user_dataDir, 'movie_wall.db')
    start_time=time.time()
    if new_imdb==False:
        dp = xbmcgui . DialogProgress ( )
        dp.create('אנא המתן','מעדכן קיר', '','')
        dp.update(0, 'אנא המתן','מעדכן קיר', '' )
 
    import datetime
    
    now = datetime.datetime.now()
    selected_year=int(now.year)-1
    url=''
    o_url=url
    selected_year_pre=''
    keyboard = xbmc.Keyboard(selected_year_pre, 'הכנס שנה')
    
    keyboard.doModal()
    if keyboard.isConfirmed():
        selected_year_pre = keyboard.getText()
        if selected_year_pre.isdigit():
            selected_year=int(selected_year_pre)
            modein='5'
        else:
            xbmcgui.Dialog().ok('Error occurred','[COLOR aqua][I]שנה לא תקינה[/I][/COLOR]')
            if new_imdb==False:
                dp.close()
            return 0
    keyboard = xbmc.Keyboard('1', 'מספר עמודים לסרוק')
    max_page_pre=0
    keyboard.doModal()
    if keyboard.isConfirmed():
        max_page_pre = keyboard.getText()
        if max_page_pre.isdigit():
            max_page=int(max_page_pre)
           
        else:
            xbmcgui.Dialog().ok('Error occurred','[COLOR aqua][I]שנה לא תקינה[/I][/COLOR]')
            if new_imdb==False:
                dp.close()
            return 0
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    logging.warning('last')
    dbcon2 = database.connect(cacheFile2)
    dbcur2 = dbcon2.cursor()
    dbcur2.execute("CREATE TABLE IF NOT EXISTS %s ( ""new_name TEXT,""url TEXT,""mode TEXT,""icon TEXT,""fan TEXT,""plot TEXT,""year TEXT,""original_name TEXT,""id TEXT,""rating TEXT,""new_name2 TEXT,""year2 TEXT,""genere TEXT,""trailer TEXT,""imdb TEXT);"% 'latestsubs')
    headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive',
            'Host': 'www.dvdsreleasedates.com',
            'Pragma': 'no-cache',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
        }
    url_g=domain_s+'api.themoviedb.org/3/genre/movie/list?api_key=34142515d9d23817496eeb4ff1d223d0&language=he'
    html_g=html_g_movie
    #html_g=requests.get(url_g).json()
    for page in range(0,max_page):
        
        if 'opensubtitles.org' not in url:
          
          x='https://www.opensubtitles.org/en/search/sublanguageid-heb/searchonlymovies-on/movieyearsign-%s/movieyear-%s/sort-5/asc-0/offset-%s'%(modein,str(selected_year),str(page*40))
          
        else:
          x=url
        headers = {
                                    
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        }
        logging.warning(x)
        try:
            html=requests.get(x,headers=headers,timeout=10).content
        except:
            xbmcgui.Dialog().ok('Error occurred','[COLOR aqua][I]שגיאה נסה שוב[/I][/COLOR]')
            return 0
        regex='http://www.imdb.com/title/(.+?)/'
        match=re.compile(regex).findall(html)
        all_imdb=[]
        dbcur2.execute("SELECT  * FROM latestsubs")
        
        match2 = dbcur2.fetchall()
        all_db_imdb=[]
        
        for new_name,url,mode,icon,fan,plot,year,original_name,id,rating,new_name,year,genere,trailer,imdb in match2:
            all_db_imdb.append(imdb)
        count=0
        for imdb in match:
           if imdb not in all_db_imdb:
             count+=1
        if count>10 and not new_imdb:
           xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'איטי רק בפעם הראשונה סורי... '+str(count) )).encode('utf-8'))
        whats_new=[]
        whats_new_images=[]
        fav_search_f=Addon.getSetting("fav_search_f")
        fav_servers_en=Addon.getSetting("fav_servers_en")
        fav_servers=Addon.getSetting("fav_servers")

        google_server= Addon.getSetting("google_server")
        rapid_server=Addon.getSetting("rapid_server")
        direct_server=Addon.getSetting("direct_server")
        heb_server=Addon.getSetting("heb_server")

            
       
        all_strm_data=[]
        zz=0
        for imdb in match:
  
           if new_imdb==False:
                if dp.iscanceled(): 
                    dp.close()
                    break
           if imdb not in all_imdb:
            all_imdb.append(imdb)
            if imdb in all_db_imdb:
                dbcur2.execute("SELECT * FROM latestsubs WHERE  imdb='%s'"%imdb)
                match2 = dbcur2.fetchone()
                new_name,url,mode,icon,fan,plot,year,original_name,id,rating,new_name,year,genere,trailer,imdb=match2
                if not new_imdb:
                    if  mode==4 and fav_search_f=='true' and fav_servers_en=='true' and (len(fav_servers)>0 or heb_server=='true' or google_server=='true' or rapid_server=='true' or direct_server=='true'):
                    
                        fav_status='true'
                    else:
                        fav_status='false'
                    #addDir3(new_name.replace("%27","'"),url,int(mode),icon,fan,plot.replace("%27","'"),data=year,original_title=original_name.replace("%27","'"),id=id,rating=rating,heb_name=new_name.replace("%27","'"),show_original_year=year,isr='0',generes=genere,trailer=trailer,fav_status=fav_status)
                    all_strm_data.append((original_name.replace("%27","'")+'.'+year,get_rest_data(new_name.replace("%27","'"),url,int(mode),icon,fan,plot.replace("%27","'"),data=year,original_title=original_name.replace("%27","'"),id=id,rating=rating,heb_name=new_name.replace("%27","'"),show_original_year=year,isr='0',generes=genere,trailer=trailer,fav_status=fav_status)))
                    if new_imdb==False:
                        elapsed_time = time.time() - start_time
                        dp.update(int(((zz* 100.0)/(len(match))) ), 'עמוד %s אנא המתן '%str(page)+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),new_name, original_name)
            else:
                
                    
                    
                    url=domain_s+'api.themoviedb.org/3/find/%s?api_key=34142515d9d23817496eeb4ff1d223d0&external_source=imdb_id&language=heb'%imdb
                    html=requests.get(url).json()
                    for data in html['movie_results']:
                     if 'vote_average' in data:
                       rating=data['vote_average']
                     else:
                      rating=0
                     if 'first_air_date' in data:
                       year=str(data['first_air_date'].split("-")[0])
                     else:
                        if 'release_date' in data:
                            year=str(data['release_date'].split("-")[0])
                        else:
                            year=' '
                     if data['overview']==None:
                       plot=' '
                     else:
                       plot=data['overview']
                     if 'title' not in data:
                       new_name=data['name']
                     else:
                       new_name=data['title']
                     if 'original_title' in data:
                       original_name=data['original_title']
                       mode=4
                       
                       id=str(data['id'])
                      
                     else:
                       original_name=data['original_name']
                       id=str(data['id'])
                       mode=7
                     if data['poster_path']==None:
                      icon=' '
                     else:
                       icon=data['poster_path']
                     if 'backdrop_path' in data:
                         if data['backdrop_path']==None:
                          fan=' '
                         else:
                          fan=data['backdrop_path']
                     else:
                        fan=html['backdrop_path']
                     if plot==None:
                       plot=' '
                     if 'http' not in fan:
                       fan=domain_s+'image.tmdb.org/t/p/original/'+fan
                     if 'http' not in icon:
                       icon=domain_s+'image.tmdb.org/t/p/original/'+icon
                     genres_list= dict([(i['id'], i['name']) for i in html_g['genres'] \
                            if i['name'] is not None])
                     try:genere = u' / '.join([genres_list[x] for x in data['genre_ids']])
                     except:genere=''

                     trailer = "plugin://plugin.video.allmoviesin?mode=25&url=www&id=%s" % id
                     try:
                        dbcur2.execute("INSERT INTO latestsubs Values ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s','%s','%s','%s','%s');" %  (new_name.replace("'",'%27'),url,mode,icon,fan,plot.replace("'",'%27'),year,original_name.replace("'",'%27'),id,rating,new_name.replace("'",'%27'),year,genere,trailer,imdb))
                     except:
                        pass
                     whats_new.append((new_name,url,icon,fan,plot.replace("'",'%27'),year,original_name,id))
                     if len(whats_new_images)<19:
                        whats_new_images.append(icon)
                     if not new_imdb:
                        if  mode==4 and fav_search_f=='true' and fav_servers_en=='true' and (len(fav_servers)>0 or heb_server=='true' or google_server=='true' or rapid_server=='true' or direct_server=='true'):
                            fav_status='true'
                        else:
                            fav_status='false'
                        #addDir3(new_name,url,mode,icon,fan,plot,data=year,original_title=original_name,id=id,rating=rating,heb_name=new_name,show_original_year=year,isr='0',generes=genere,trailer=trailer,fav_status=fav_status)
                        all_strm_data.append((original_name.replace("%27","'")+'.'+year,get_rest_data(new_name.replace("%27","'"),url,int(mode),icon,fan,plot.replace("%27","'"),data=year,original_title=original_name.replace("%27","'"),id=id,rating=rating,heb_name=new_name.replace("%27","'"),show_original_year=year,isr='0',generes=genere,trailer=trailer,fav_status=fav_status)))
                     
                        elapsed_time = time.time() - start_time
                        dp.update(int(((zz* 100.0)/(len(match))) ), 'עמוד %s אנא המתן '%str(page)+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),new_name, original_name)
            zz+=1
    try:
        dbcon2.commit()
    except:
       pass
  
 
    import xbmcvfs
    path=Addon.getSetting("strm")
    if path == '':
      path = xbmcgui.Dialog().browse(0,"בחר תקייה", 'files','',False,False,'')
      Addon.setSetting("strm",path)
    zz=0
    
    for name,data in all_strm_data:
        
        if new_imdb==False:
            elapsed_time = time.time() - start_time
            dp.update(int(((zz* 100.0)/(len(all_strm_data))) ), 'מכין קבצים'+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),name, '')
        zz+=1
      
        
        filename = str(path) + '/' + str(name)+'.strm'
        if not  os.path.exists(filename):
        
            strmFile = xbmcvfs.File(filename, "w")
            sysaddon = sys.argv[0]
            cont=(data.replace(' ','%20'))
            strmFile.write(str(cont)+'\n')
            strmFile.close()
    if new_imdb==False:
        dp.close()
def Source2DB(type,action,addpath):
    import hashlib
    m = hashlib.md5()
    m.update(addpath)
    AddonName = Addon.getAddonInfo("name")
    import glob
    filelist = glob.glob(xbmc.translatePath(os.path.join('special://home/userdata/Database','MyVideos*.db')))
    if filelist != []:
        for f in filelist:
            databaseFile=f
    else:
        return False

    print "*** {0}: Wall.Update.Setting: DB {1} {2}".format(AddonName,action, type)
    
    q_add = "('%s','movies','metadata.themoviedb.org','%s',2147483647,0,'<settings><setting id=\"RatingS\" value=\"TMDb\" /><setting id=\"certprefix\" value=\"Rated \" /><setting id=\"fanart\" value=\"true\" /><setting id=\"imdbanyway\" value=\"false\" /><setting id=\"keeporiginaltitle\" value=\"false\" /><setting id=\"language\" value=\"he\" /><setting id=\"tmdbcertcountry\" value=\"us\" /><setting id=\"trailer\" value=\"true\" /></settings>',0,0,NULL,NULL)"%(addpath,str(m.hexdigest()))
    q_add="('%s','movies','metadata.themoviedb.org','',2147483647,0,'<settings><setting id=\"RatingS\" value=\"TMDb\" /><setting id=\"certprefix\" value=\"Rated \" /><setting id=\"fanart\" value=\"true\" /><setting id=\"keeporiginaltitle\" value=\"false\" /><setting id=\"language\" value=\""%addpath+"he"+"\" /><setting id=\"tmdbcertcountry\" value=\"us\" /><setting id=\"trailer\" value=\"true\" /></settings>',0,0,NULL,NULL)"
    dbcon = database.connect(databaseFile)
    dbcur = dbcon.cursor()
    if action=="add":
        
            q = "INSERT OR REPLACE INTO path (strPath,strContent,strScraper,strHash,scanRecursive,useFolderNames,strSettings,noUpdate,exclude,dateAdded,idParentPath) VALUES "+ q_add
            dbcur.execute("DELETE FROM path WHERE strPath LIKE '%{0}%'".format(addpath))
            dbcur.execute(q)
            print "*** {0}: Wall.Update.Setting: DB Add Source".format(AddonName)
        
    elif action=="remove":
            dbcur.execute("SELECT idPath FROM path WHERE strPath='%s'"%addpath)
     
            match = dbcur.fetchone()
            if match!=None:
                dbcur.execute("DELETE FROM files WHERE idPath = '{0}'".format(match[0]))
                dbcur.execute("DELETE FROM movie WHERE c23 = '{0}'".format(match[0]))
                
                dbcur.execute("DELETE FROM path WHERE strPath LIKE '%{0}%'".format(addpath))
                print "*** {0}: Wall.Update.Setting: DB Remove Source".format(AddonName)
       
    dbcon.commit()
    return
def Source2XML(xml_file,type,action,addpath):
    import xml.etree.ElementTree as ET
    AddonName = Addon.getAddonInfo("name")
    tree = ET.parse(xml_file)
    root = tree.getroot()
    sources = root.find('video')

    for source in sources.findall('source'):
        xml_name = source.find("name").text
        xml_path = source.find("path").text

        if type=="movies" and xml_name == 'Movies Victory.Wall':
            if action=="add":
                return False
            elif action=="remove":
                sources.remove(source)
                tree.write(xml_file)
                print "*** {0}: Wall.Update.Setting: XML Remove Source".format(AddonName)
                return True
        
    if action=="add":
        new_source = ET.SubElement(sources, 'source')
        new_name = ET.SubElement(new_source, 'name')
        if type=="movies":
            new_name.text = 'Movies Victory.Wall'
        
        new_path = ET.SubElement(new_source, 'path')
        new_path.attrib['pathversion'] = "1"
        new_path.text = addpath
        tree.write(xml_file)
        print "*** {0}: Wall.Update.Setting: XML Add Source".format(AddonName)
        return True
    return False
def movie_wall_new(silent=False):
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0',
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Accept-Language': 'en-US,en;q=0.5',
    'Referer': 'https://www.screwzira.com/Search.aspx',
    'Content-Type': 'application/json',
    'X-Requested-With': 'XMLHttpRequest',
    'Connection': 'keep-alive',
    }
    start_time=time.time()
    if silent==False:
        dp = xbmcgui . DialogProgress ( )
        dp.create('אנא המתן','מעדכן קיר', '','')
        dp.update(0, 'אנא המתן','מעדכן קיר', '' )
    else:
        xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'מעדכן קיר סרטים'.decode('utf8'))).encode('utf-8'))
    fav_search_f=Addon.getSetting("fav_search_f")
    fav_servers_en=Addon.getSetting("fav_servers_en")
    fav_servers=Addon.getSetting("fav_servers")

    google_server= Addon.getSetting("google_server")
    rapid_server=Addon.getSetting("rapid_server")
    direct_server=Addon.getSetting("direct_server")
    heb_server=Addon.getSetting("heb_server")


   
    if   fav_search_f=='true' and fav_servers_en=='true' and (len(fav_servers)>0 or heb_server=='true' or google_server=='true' or rapid_server=='true' or direct_server=='true'):
        fav_status='true'
    else:
        fav_status='false'
    max_page=int(Addon.getSetting("no_pages"))
    year_s=int(Addon.getSetting("year_s"))
    year_e=int(Addon.getSetting("year_e"))
    count=0
    all_strm_data=[]
    victory_player=False
    if Addon.getSetting("wall_player")=='0':
        victory_player=True
    pages=[]
    m_id=Addon.getSetting("metaliq_version")
    new=1
    master_count=0
    for year in range(year_s,year_e+1):
        for page in range(1,max_page+1):
            data = {'request':{'FilmName':'','Actors':[],'Studios':None,'Directors':[],'Genres':[],'Countries':[],'Languages':[],'Year':year,'Rating':[],'Page':page,'SearchType':0,'WithSubsOnly':'true'}}
            
            response = requests.post('https://www.screwzira.com/Services/ContentProvider.svc/SearchPage_search', headers=headers,json=data).json()
            
            
            
            
            zz=0
            response_j=json.loads(response['d'])
            
            if len(response_j['Films'])==0:
                continue
          
            for items in response_j['Films']:
             
                name=items['HebName']
                url=' '
                mode='4'
                iconimage='https://www.screwzira.com/Content/Films/%s/Images/thumb.jpg'%items['FolderID']
                fanart=iconimage
                description=items['Summary']
                data=str(items['ReleaseDate'])
                original_title=items['EngName']
                tmdbid=''
                eng_name=original_title
                show_original_year=data
                heb_name=name
                generes=items['Genres']
              
                id_pre=re.compile('imdb.com/title/(.+?)(?:/|$)').findall(items['IMDB_Link'])
                if len(id_pre)>0:
                    id=id_pre[0]
                else:
                    id=original_title+'.'+data
                if silent==False:
                    elapsed_time = time.time() - start_time
                    dp.update(int(((zz* 100.0)/(len(response_j['Films']))) ), 'עמוד %s אנא המתן '%str(page)+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),name, original_title)
                count+=1
                if victory_player:
                    all_strm_data.append((items['IMDB_Link'],id,get_rest_data(name,url,mode,iconimage,fanart,description,data=data,original_title=original_title,id=id,eng_name=eng_name,show_original_year=show_original_year,heb_name=heb_name,generes=generes,fav_status='false')+'&new_windows_only=true',page))
                    
                else:
                    all_strm_data.append((items['IMDB_Link'],id,'plugin://plugin.video.%s/movies/play/imdb/%s/library'%(m_id,id),page))
                    pages.append(page)
                zz+=1
                if silent==False:
                    if dp.iscanceled(): 
                        dp.close()
                        break
    
        path=os.path.join(user_dataDir,'strm_files')
        if not os.path.exists(path):
            os.makedirs(path)
         
        zz=0
        count=0
        for id,name,data,page in all_strm_data:
            
            if silent==False:
                elapsed_time = time.time() - start_time
                dp.update(int(((zz* 100.0)/(len(all_strm_data))) ), 'מכין קבצים'+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),name, '')
            zz+=1
          
            
            filename = str(path) + '/' + str(name)+'.strm'
            nfo = str(path) + '/' + str(name)+'.nfo'
            
            if not  os.path.exists(filename):
                count+=1
                master_count+=1
                strmFile = xbmcvfs.File(filename, "w")
          
                cont=(data.replace(' ','%20'))
                strmFile.write(str(cont)+'\n')
                strmFile.close()
                
                strmFile = xbmcvfs.File(nfo, "w")
                strmFile.write(str(id)+'\n')
                strmFile.close()
        new=count
    libraryFolderMovies='special://userdata/addon_data/plugin.video.allmoviesin/strm_files/'
    xml_file = xbmc.translatePath(os.path.join('special://profile/','sources.xml'))
    
    if not os.path.exists(xml_file):
        logging.warning('Missing xml')
        from shutil import copyfile
        copyfile(os.path.join(addonPath, 'resources','sources.xml'),xml_file)
    isXmlMoviesChanged =Source2XML(xml_file, "movies", 'add', libraryFolderMovies)
    if isXmlMoviesChanged:
        Source2DB("movies",'add',libraryFolderMovies)
    
    if master_count>0:

        if silent==True:
       
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', ('סה"כ סרטים: %s עידכון קיר סרטים הסתיים'%(str((master_count)))).decode('utf8'))).encode('utf-8'))
        while xbmc.getCondVisibility('Library.IsScanningVideo') == True:
                xbmc.sleep(10000)
        #xbmc.executebuiltin('UpdateLibrary(video,{0})'.format(libraryFolderMovies))
        xbmc.executebuiltin('XBMC.UpdateLibrary(video)')
    else:
        if silent==True:
       
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', ('אין סרטים חדשים').decode('utf8'))).encode('utf-8'))
    if silent==False:
        dp.close()
    logging.warning('Done Wall Update')
def RemoveFolder(Folder):
    import shutil
    try:
        Folder=xbmc.translatePath(Folder)
        if os.path.isdir(Folder):
                
                shutil.rmtree(Folder)
                os.makedirs(Folder)
                
        else:
                os.makedirs(Folder)
    except:
        pass
def remove_wall():
    libraryFolderMovies='special://userdata/addon_data/plugin.video.allmoviesin/strm_files/'
    xml_file = xbmc.translatePath(os.path.join('special://profile/','sources.xml'))
    if not os.path.exists(xml_file):
        logging.warning('Missing xml')
        from shutil import copyfile
        copyfile(os.path.join(addonPath, 'resources','sources.xml'),xml_file)
    isXmlMoviesChanged =Source2XML(xml_file, "movies", 'remove', libraryFolderMovies)
    
    Source2DB("movies",'remove',libraryFolderMovies)
    RemoveFolder(libraryFolderMovies)
    xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', ('הוסר הקיר, יום טוב.').decode('utf8'))).encode('utf-8'))
def clear_rd():
    Addon.setSetting('rd.client_id','')
    Addon.setSetting('rd.auth','')
    Addon.setSetting('rd.refresh','')
    Addon.setSetting('rd.secret','')
    xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', ('אישור נמחק').decode('utf8'))).encode('utf-8'))
def re_enable_rd():
    clear_rd()
    
    import real_debrid
    rd = real_debrid.RealDebrid()
    rd.auth()
    rd = real_debrid.RealDebrid()
    rd_domains=(rd.getRelevantHosters())
def fix_18(icon,fan):
    from youtube_ext import get_youtube_link2
   
    url= get_youtube_link2('https://www.youtube.com/watch?v=_S-Z_5vIJ1w')
    addLink('סרטון הדרכה',url,5,False,iconimage=icon,fanart=fan,description='סרטון הדרכה')
    addNolink('פתח הורדה','www',140,False,iconimage=icon,fanart=fan)
def run_page():
    url='https://www.toptutorials.co.uk/android/'
    url_win='http://mirrors.kodi.tv/releases/windows/win32/'
    osWin = xbmc.getCondVisibility('system.platform.windows')
    osOsx = xbmc.getCondVisibility('system.platform.osx')
    osLinux = xbmc.getCondVisibility('system.platform.linux')
    osAndroid = xbmc.getCondVisibility('System.Platform.Android')
   

    if osOsx:    
        # ___ Open the url with the default web browser
        xbmc.executebuiltin("System.Exec(open "+url+")")
    elif osWin:
        logging.warning('Run')
        # ___ Open the url with the default web browser
        xbmc.executebuiltin("System.Exec(cmd.exe /c start "+url_win+")")
    elif osLinux and not osAndroid:
        # ___ Need the xdk-utils package
        xbmc.executebuiltin("System.Exec(xdg-open "+url+")") 
    elif osAndroid:
        # ___ Open media with standard android web browser
        xbmc.executebuiltin("StartAndroidActivity(com.android.browser,android.intent.action.VIEW,,"+url+")")
        
        # ___ Open media with Mozilla Firefox
        xbmc.executebuiltin("StartAndroidActivity(org.mozilla.firefox,android.intent.action.VIEW,,"+url+")")                    
        
        # ___ Open media with Chrome
        xbmc.executebuiltin("StartAndroidActivity(com.android.chrome,,,"+url+")") 
        
        
def close_ok():
    logging.warning('Closing OK')
    for x in range(0,200):
        xbmc.executebuiltin('Dialog.Close(okdialog, true)')
        xbmc.sleep(100)
def get_token():
    AccessKey = "#~rFo*%&I0#0i?JOM-0KTo,MgF.ufiL:z!y>lh,/Oo=hnO!6T|{S&<dj+Hl7M2§8#~rFo*%&I0#0i?JOM-0KTo,MgF.ufiL:z!y>lh,/Oo=hnO!6T|{S&<dj+Hl7M2§8#~rFo*%&I0#0i?JOM-0KTo,MgF.ufiL:z!y>lh,/Oo=hnO!6T|{S&<dj+Hl7M2§8"
                 
    sb2=[]

    sb2.append(AccessKey)
    salt=str(random.randint(1,900))
    sb2.append(salt)
    
    import  hashlib

    sign= hashlib.md5(''.join(sb2)).hexdigest()
    from datetime import datetime
    t=datetime.utcnow()
    current_time = t.strftime("%Y-%m-%d %H:%M:%S")
    
    a='{"salt":"%s","sign":"%s","timesamp":"%s"}'%(salt,sign,str(current_time))
    
    return str(a).encode('base64').replace('\n','')
    
    
def live_tv():
    #taken from New WOW sports live apk

    wow_host="flysohigh.xyz"
    headers={
            'Connection': 'keep-alive',

            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'crow/2.3',
            'content-type': 'application/x-www-form-urlencoded',
            'Accept-Encoding': 'utf-8',
            'Accept-Language': 'en-US',
            'X-Requested-With': 'com.wowsports3'}
    url='https://%s/data_4w/data_3w/streams.php'%wow_host
    data=get_token()
    a=(urllib.quote(str(data)))
    #a="eyJzYWx0IjoiNTQ4Iiwic2lnbiI6IjkxMjA5MDE4MTRhMThjNWFkMjQ5OWRjMGU3YmUxNDljIiwidGltZXNhbXAiOiIyMDIwLTAxLTE5IDA2OjMyOjI5In0="
    url_pre=requests.get(url+'?&token='+a,headers=headers).url
    logging.warning(url+'?&token='+a)
    logging.warning(url_pre)
    x,cook=cloudflare_request(url_pre+'?&token='+a,headers=headers)
    #logging.warning(x)
    regex="<tr onclick.+?window\.location\='(.+?)'.+?<h5 style='.+?'>(.+?)<(.+?)</tr>"
    mm=re.compile(regex,re.DOTALL).findall(x)
    for lk,nm,res in mm:
        if 'Live' in res:
            plot='Live'
        else:
            plot=' '
        icon='https://www.mdr.de/sport/fussball1810_v-variantBig16x9_w-576_zc-915c23fa.jpg?version=47364'
        name=nm
        link=lk+'$$$$'+(json.dumps(cook)).encode('base64')
        addLink(name,'wow_sport%%%'+link,5,False,iconimage=icon,fanart=icon,description=plot)
def live_tv_old():
    #taken from WOW sports live apk
    headers={
    'Cache-Control': 'max-age=0',
    'Data-Agent': 'The Stream',

    'Connection': 'Keep-Alive',
    'Accept-Encoding': 'utf-8',
    'User-Agent': 'okhttp/3.8.1'}
    url='http://wowsportslive.com/the_stream/the_stream/api/get_posts/?api_key=cda11uT8cBLzm6a1YvsiUWOEgrFowk95K2DM3tHAPRCX4ypGjN&page=1&count=600'
    x=requests.get(url,headers=headers).json()
    for items in x['posts']:
        plot=items['channel_description']
        icon='http://wowsportslive.com/the_stream/the_stream/upload/'+items['channel_image']
        name=items['channel_name']
        link=items['channel_url']
        addLink(name,link,5,False,iconimage=icon,fanart=icon,description=plot)

def trakt_liked(url,iconImage,fanart):
    responce=call_trakt(url)
   
            
    for items in responce:
        url=items['list']['user']['username']+'$$$$$$$$$$$'+items['list']['ids']['slug']
        addDir3(items['list']['name'],url,31,iconImage,fanart,items['list']['description'])
def quote(s, safe=""):
    
    return orig_quote(s.encode("utf-8"), safe.encode("utf-8"))
def world_chan():
    
    cat_id=None
    user_agent = "Dalvik/2.1.0 (Linux; U; Android 5.1.1; AFTS Build/LVY48F)"
    token_url = "http://tvtap.net/tvtap1/index_new.php?case=get_channel_link_with_token_tvtap"
    list_url = "http://tvtap.net/tvtap1/index_new.php?case=get_all_channels"
    list_items = []
    r = requests.post(list_url, headers={"app-token": "9120163167c05aed85f30bf88495bd89"}, data={"username": "603803577"}, timeout=15)
    
    ch = r.json()
    
    for c in ch["msg"]["channels"]:
        
            image = "http://tvtap.net/tvtap1/{0}|User-Agent={1}".format(quote(c.get("img"), "/"), quote(user_agent))
            addLink(c["channel_name"],'tvtap$$$$'+c["pk_id"],5,False,iconimage=image,fanart=image,description=c["channel_name"])
            
def today_rls():
    dbcur_trk.execute("SELECT  * FROM AllData4")
    match2 = dbcur_trk.fetchall()

    today=time.strftime("%d-%m-%Y")
    all_n=[]
    logging.warning(today)
    if match2!=None:
        for items in match2:
            data_ep,dates,fanart,color,id,j,k,next,plot=items
            dates=json.loads(dates)
            if len(dates)>1:
                logging.warning(dates[2])
               
                if str(today) in dates[2]:
                    url=domain_s+'api.themoviedb.org/3/tv/%s?api_key=34142515d9d23817496eeb4ff1d223d0&language=he&append_to_response=name'%(id)
                    logging.warning(url)
                    html=requests.get(url).json()
                    all_n.append(' * ' + html['name'])
                
    if len(all_n)>0:
        msg='''\
        [B][I]פרקים חדשים יצאו היום ב:[/I][/B]
        %s

        '''%'\n'.join(all_n)
        TextBox_help(' פרקים חדשים '+str(today), msg,img2='https://misspokeperson5.files.wordpress.com/2013/09/conquer-the-day.jpg')
        
        #xbmcgui.Dialog().ok('פרקים חדשים','פרקים חדשים יצאו היום ב: '+'\n'.join(all_n))
def one_click(icon,image):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:66.0) Gecko/20100101 Firefox/66.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        
        'Content-Type': 'application/x-www-form-urlencoded',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
    }
    x=requests.get('https://itsmine.space/',headers=headers).content
    regex='data-category="(.+?)".+?row movie-slider-items movie-slider-style-2">(.+?)<'
    m=re.compile(regex).findall(x)
    for url,type in m:
        addDir3(type,url,145,icon,image,type)
    addDir3('[COLOR aqua][I]חיפוש[/COLOR][/I]',url,146,icon,image,'[COLOR aqua][I]חיפוש[/COLOR][/I]')
def one_click_next(url,data):
    try:
        page=str(int(data))
    except:
        page='0'
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:66.0) Gecko/20100101 Firefox/66.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        
        'Content-Type': 'application/x-www-form-urlencoded',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
    }
    logging.warning(url)
    if 'כל הסרטים' in url or 'data-scroll' in url:
        url=''
        o_url='data-scroll'
    else:
        o_url=url
    url='https://itsmine.space/wp-admin/admin-ajax.php?action=alm_query_posts&query_type=standard&post_id=0&slug=home&canonical_url=https//itsmine.space/&cache_logged_in=false&repeater=default&theme_repeater=null&acf=&nextpage=&cta=&comments=&users=&post_type%5B%5D=post&sticky_posts=&post_format=&category={0}&science-fiction&category__not_in=&tag=&tag__not_in=&taxonomy=&taxonomy_terms=&taxonomy_operator=&taxonomy_relation=&meta_key=&meta_value=&meta_compare=&meta_relation=&meta_type=&author=&year=&month=&day=&post_status=&order=DESC&orderby=date&post__in=&post__not_in=&exclude=&search=&custom_args=&posts_per_page=100&offset=4&preloaded=true&preloaded_amount=false&seo_start_page=1&paging=false&previous_post=&lang='.format(url)
    
    
    x=requests.get(url+'&page='+page,headers=headers).json()['html'].split('<div id=')
    logging.warning(len(x))
    for items in x:
        name_b=False
        regex='<img src="(.+?)".+?<div class="mbl showonmobilef"><a itemprop="url" href="(.+?)"><div>(.+?)</div><div>(.+?)</div>'
        m=re.compile(regex,re.DOTALL).findall(items)
        if len(m)==0:
            regex='<img src="(.+?)".+?<div class="mbl showonmobilef"><a itemprop="url" href="(.+?)"><div>(.+?)</div></a></div>(.+?)</div>'
            m=re.compile(regex,re.DOTALL).findall(items)
            name_b=True
        for img,url,name,eng_name in m:
            if name_b:
                eng_name=' '
            name=replaceHTMLCodes(name)
            
            
            addLink(name,url,5,False,img,img,eng_name,original_title=eng_name,id='get_sratim',eng_name=eng_name,heb_name=name)
    try:
        if 'כל הסרטים' in o_url or 'data-scroll' in o_url:
            
            o_url2=''
        else:
            o_url2=o_url
        url='https://itsmine.space/wp-admin/admin-ajax.php?action=alm_query_posts&query_type=standard&post_id=0&slug=home&canonical_url=https//itsmine.space/&cache_logged_in=false&repeater=default&theme_repeater=null&acf=&nextpage=&cta=&comments=&users=&post_type%5B%5D=post&sticky_posts=&post_format=&category={0}&science-fiction&category__not_in=&tag=&tag__not_in=&taxonomy=&taxonomy_terms=&taxonomy_operator=&taxonomy_relation=&meta_key=&meta_value=&meta_compare=&meta_relation=&meta_type=&author=&year=&month=&day=&post_status=&order=DESC&orderby=date&post__in=&post__not_in=&exclude=&search=&custom_args=&posts_per_page=100&offset=4&preloaded=true&preloaded_amount=false&seo_start_page=1&paging=false&previous_post=&lang='.format(o_url2)
        
        logging.warning(url)
        x=requests.get(url+'&page='+str(int(page)+1),headers=headers).json()['html'].split('<div id=')
        addDir3('[COLOR aqua][I]עמוד הבא[/COLOR][/I]',o_url,145,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTNmz-ZpsUi0yrgtmpDEj4_UpJ1XKGEt3f_xYXC-kgFMM-zZujsg','https://cdn4.iconfinder.com/data/icons/arrows-1-6/48/1-512.png','[COLOR aqua][I]עמוד הבא[/COLOR][/I]',data=str(int(page)+1))
    except Exception as e:
        logging.warning('Error next page')
        logging.warning(e)
        pass
def search_one():
    search_entered=''

    
    keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש כאן')
    keyboard.doModal()
    if keyboard.isConfirmed():
           search_entered = keyboard.getText()
           
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:66.0) Gecko/20100101 Firefox/66.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        
        'Content-Type': 'application/x-www-form-urlencoded',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
    }
    data = {
      'action': 'ajaxsearchpro_search',
      'aspp': search_entered,
      'asid': '1',
      'asp_inst_id': '1_1',
      'options': 'current_page_id=5844&qtranslate_lang=0&asp_gen%5B%5D=title&asp_gen%5B%5D=content&asp_gen%5B%5D=excerpt&customset%5B%5D=post&aspf%5Byear_1%5D='
    }

    response = requests.post('https://itsmine.space/wp-admin/admin-ajax.php', headers=headers, data=data).content
    logging.warning(response)
    regex="imgsrc='(.+?)'.+?class=\"asp_res_url searchres\" href='(.+?)'>(.+?)<"
    m=re.compile(regex,re.DOTALL).findall(response)
    for img,url,o_name in m:
        o_name=o_name.strip()
        if '/' in o_name:
            
            name=o_name.split('/')[0]
            eng_name=o_name.split('/')[1]
        else:
            name=o_name
            eng_name=' '
        addLink(name,url,5,False,img,img,eng_name,original_title=eng_name,id='get_sratim',eng_name=eng_name,heb_name=name)
def tor_click(url,data,icon,image):
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:66.0) Gecko/20100101 Firefox/66.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        
        'Content-Type': 'application/x-www-form-urlencoded',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
    }
 
   
    
    
    x=requests.get('https://zooqle.com/mov/',headers=headers).content
    regex_p='>Movie genres:</li>(.+?)</ul>'
    m2=re.compile(regex_p,re.DOTALL).findall(x)
    
    regex='<a role="menuitem" class="small" tabindex="-1" href="(.+?)">(.+?)<'
    m=re.compile(regex).findall(m2[0])
    for url,type in m:
        addDir3(type,'https://zooqle.com'+url,148,icon,image,type)
        
        
        
def tor_click_next(url,data,icon,image):
    try:
        page=str(int(data))
    except:
        page='1'
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:66.0) Gecko/20100101 Firefox/66.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        
        'Content-Type': 'application/x-www-form-urlencoded',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
    }
    params = (
        ('pg', page),
        ('tg', '0'),
        ('v', 't'),
        ('age', 'any'),
        ('s', 'nt'),
        ('sd', 'd'),
    )
    o_url=url
    x = requests.get(url, headers=headers, params=params).content
    regex_p='<tr>(.+?)</tr>'
    m2=re.compile(regex_p,re.DOTALL).findall(x)
    logging.warning(len(m2))
    for items in m2:
       
        regex='<td class="smaller text-muted3".+?a href="(.+?)".+?src="(.+?)".+?a href=".+?">(.+?)<.+?div class="mov_descr">(.+?)<.+?"badge badge-green badge-sm trans80 ">(.+?)<'
        m=re.compile(regex,re.DOTALL).findall(items)
       
        for url,img,name,plot,q in m:
            
            if '(' in name:
                reg='\((.+?)\)'
                year=re.compile(reg).findall(name)[0]
                name=name.split('(')[0].strip()
            else:
                year='0'
            video_data={}
            video_data['title']=name
            video_data['plot']='[COLOR yellow]Max Q : '+q+'[/COLOR]\n'+plot
            
            video_data['year']=year
            addLink(name,'https://zooqle.com'+url,5,False,'https://zooqle.com'+img,'https://zooqle.com'+img,'[COLOR yellow]Max Q : '+q+'[/COLOR]\n'+plot,original_title=name,id='get_id',eng_name=name,heb_name=name,data=year,video_info=json.dumps(video_data))
            
    addDir3('[COLOR aqua][I]עמוד הבא[/COLOR][/I]',o_url,148,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTNmz-ZpsUi0yrgtmpDEj4_UpJ1XKGEt3f_xYXC-kgFMM-zZujsg','https://cdn4.iconfinder.com/data/icons/arrows-1-6/48/1-512.png','[COLOR aqua][I]עמוד הבא[/COLOR][/I]',data=str(int(page)+1))
def update_collections():
    collection_cacheFile = os.path.join(tmdb_data_dir, 'collection_data.db')
    dbcon_tmdb = database.connect(collection_cacheFile)
    dbcur_tmdb = dbcon_tmdb.cursor()
    dbcur_tmdb.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""id TEXT,""icon TEXT,""fanart TEXT,""plot TEXT,""lang TEXT);"% 'collection')

    try:
        dbcur_tmdb.execute("VACUUM 'collection';")
        dbcur_tmdb.execute("PRAGMA auto_vacuum;")
        dbcur_tmdb.execute("PRAGMA JOURNAL_MODE=MEMORY ;")
        dbcur_tmdb.execute("PRAGMA temp_store=MEMORY ;")
    except:
     pass
    dbcon_tmdb.commit()
    
    import gzip
    from pen_addons import download_file
    from datetime import date, timedelta
    yesterday = date.today() - timedelta(days=1)
    dd=yesterday.strftime("%m_%d_%Y")
    #dd=time.strftime("%m_%d_%Y")
    logging.warning(dd)
    url='http://files.tmdb.org/p/exports/collection_ids_%s.json.gz'%dd
    logging.warning(url)
    download_file(url,user_dataDir)

    with gzip.open(os.path.join(user_dataDir,'fixed_list.txt'), 'rb') as f:
      file_content = (f.read())
    ff='['+file_content.replace('\n',",")+']'
   
    j_file=json.loads(ff.replace(',]',']'))
    zzz=0
    start_time=time.time()
    dp = xbmcgui . DialogProgress ( )
    dp.create('אנא המתן','מחפש מקורות', '','')
    dbcur_tmdb.execute("select id from collection")
    match = dbcur_tmdb.fetchall()
    all_ids=[]
    for ids in match:
        all_ids.append(str(ids[0]))
        
   
    inner_count=0
    for item in j_file:
        
        try:
           if str(item['id']) not in all_ids:
           
            elapsed_time = time.time() - start_time
            
            
            url='https://api.themoviedb.org/3/collection/%s?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&language=heb'%(item['id'])
            
            x=requests.get(url).json()
            if x['poster_path']==None:
                x['poster_path']=''
            if x['backdrop_path']==None:
                x['backdrop_path']=''
            if len(x['parts'])==0:
                continue
            dbcur_tmdb.execute("INSERT INTO collection Values ('%s', '%s', '%s', '%s', '%s','%s');" %  (x['name'].replace("'","%27"),x['id'],x['poster_path'].replace("'","%27"),x['backdrop_path'].replace("'","%27"),x['overview'].replace("'","%27"),x['parts'][0]['original_language']))
            dp.update(int(((zzz* 100.0)/(len(j_file))) ), ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),x['name'], str(zzz)+'/'+str(len(j_file)))
            
            if dp.iscanceled():
                     break
            inner_count+=1
            if inner_count>100:
                inner_count=0
                dbcon_tmdb.commit()
           zzz+=1
        except Exception as e:
            xbmcgui.Dialog().ok('Error occurred',str(item['id'])+' ' +item['name']+'_'+str(e))
            break
                 
    dp.close()
    dbcon_tmdb.commit()
    dbcur_tmdb.close()
    dbcon_tmdb.close()
def collections(page):

    collection_cacheFile = os.path.join(tmdb_data_dir, 'collection_data.db')
    dbcon_tmdb = database.connect(collection_cacheFile)
    dbcur_tmdb = dbcon_tmdb.cursor()
    dbcur_tmdb.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""id TEXT,""icon TEXT,""fanart TEXT,""plot TEXT,""lang TEXT);"% 'collection')
    dbcon_tmdb.commit()
    if Addon.getSetting("collection_dp")=='true':
        dp = xbmcgui . DialogProgress ( )
        dp.create('אנא המתן','מחפש מקורות', '','')
    amount_per_page=Addon.getSetting("collection_size")
    dbcur_tmdb.execute("select * from collection where lang='en' LIMIT %s OFFSET %s;"%(amount_per_page,str(int(page)*100)))
    match = dbcur_tmdb.fetchall()
    zzz=0
    start_time=time.time()
    for name,id,icon,fanart,plot,lang in match:
        if Addon.getSetting("collection_dp")=='true':
            elapsed_time = time.time() - start_time
            if Addon.getSetting("collection_dp")=='true':
                dp.update(int(((zzz* 100.0)/(len(match))) ), ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),name, str(zzz)+'/'+str(len(match)))
            zzz+=1
            if dp.iscanceled():
                     break
        addDir3(name.replace('%27',"'"),id,150,domain_s+'image.tmdb.org/t/p/original/'+icon,domain_s+'image.tmdb.org/t/p/original/'+fanart,plot)
    if Addon.getSetting("collection_dp")=='true':
        dp.close()
    dbcur_tmdb.close()
    dbcon_tmdb.close()
    addDir3('[COLOR aqua][I]עמוד הבא[/COLOR][/I]',str(int(page)+1),149,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTNmz-ZpsUi0yrgtmpDEj4_UpJ1XKGEt3f_xYXC-kgFMM-zZujsg','https://cdn4.iconfinder.com/data/icons/arrows-1-6/48/1-512.png','[COLOR aqua][I]עמוד הבא[/COLOR][/I]')
def cache_genered(url):
    if 'tv' in url:
       url_g=domain_s+'api.themoviedb.org/3/genre/tv/list?api_key=34142515d9d23817496eeb4ff1d223d0&language=he'
     
    else:
      url_g=domain_s+'api.themoviedb.org/3/genre/movie/list?api_key=34142515d9d23817496eeb4ff1d223d0&language=he'
    html_g=requests.get(url_g).json()
    return html_g
def collection_detials(url):
    url='https://api.themoviedb.org/3/collection/%s?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&language=heb'%url
    x=requests.get(url).json()
    #html_g=cache.get(cache_genered,72,'movie', table='poster')
    if 'tv' in url:
        html_g=html_g_tv
    else:
        html_g=html_g_movie
    
    for items in x['parts']:
        new_name=items['title']
        if items['poster_path']==None:
            items['poster_path']=''
        if items['backdrop_path']==None:
            items['backdrop_path']=''
                
        icon=domain_s+'image.tmdb.org/t/p/original/'+items['poster_path']
        fan=domain_s+'image.tmdb.org/t/p/original/'+items['backdrop_path']
        if 'release_date' in items:
            year=str(items['release_date'].split("-")[0]) 
        else:
            year=''
        original_name=items['original_title']
        
            
        id=str(items['id'])
        rating=items['vote_average']
        isr='0'
        genres_list= dict([(i['id'], i['name']) for i in html_g['genres'] \
                        if i['name'] is not None])
        try:genere = u' / '.join([genres_list[x] for x in items['genre_ids']])
        except:genere=''
        plot=items['overview']
        addDir3(new_name,url,4,icon,fan,plot,data=year,original_title=original_name,id=id,rating=rating,heb_name=new_name,show_original_year=year,isr=isr,generes=genere)
        
        
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_YEAR)
def prev_search(url,icon,fan):
    cacheFile = os.path.join(user_dataDir, 'cache_play.db')
    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""type TEXT);" % 'search_history')
    dbcon.commit()
    dbcur.execute("SELECT * FROM search_history WHERE  type='%s'"%(url))
     
    match = dbcur.fetchall()
    if url=='movie':
        link='http://api.themoviedb.org/3/search/movie?api_key=34142515d9d23817496eeb4ff1d223d0&query=%s&language=he&append_to_response=origin_country&page=1'
        
    else:
        link='http://api.themoviedb.org/3/search/tv?api_key=34142515d9d23817496eeb4ff1d223d0&query=%s&language=he&page=1'
    for items,type in match:
        items=items.replace("%27","'")
        if url=='tv':
            addDir3(items.decode('utf8'),link%items,3,icon,fan,'חיפוש'.decode('utf8'),season='1',episode='1')
        else:
            addDir3(items.decode('utf8'),link%items,3,icon,fan,'חיפוש'.decode('utf8'))
    dbcur.close()
    dbcon.close()
    
def remove_search(name,url):
    logging.warning('Removing:'+name)
    cacheFile = os.path.join(user_dataDir, 'cache_play.db')
    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("DELETE FROM search_history where name='%s' and type='%s';" % (name.replace("'","%27"),url))
    logging.warning(("DELETE FROM search_history where name='%s' and type='%s';" % (name.replace("'","%27"),url)))
    dbcon.commit()
    
    dbcur.close()
    dbcon.close()
    xbmc.executebuiltin('Container.Refresh')
    
def check_q(name,url,year,id,check_ok=False):
    import subs
    global susb_data
    
    name=name.replace('%20',' ').replace('%27',"'").replace('%3a',':')
    dp = xbmcgui . DialogProgress ( )
    dp.create('אנא המתן','בודק איכות ומקורות', '','')
    dp.update(0, 'אנא המתן','בודק איכות ומקורות', '' )
        
    susb_data={}
    thread=[]
    thread.append(Thread(check_movie_subs,name,name,'%20','%20',year,id))
    thread[len(thread)-1].setName(eng_name+' '+episode)
    thread[0].start()
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
    'Accept': '*/*',
    'Accept-Language': 'en-US,en;q=0.5',
    'Connection': 'keep-alive',
    
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    }

    params = (
        ('q', name+' (%s)'%year),
    )
    logging.warning('Checkq')
    logging.warning(name)
    dp.update(0, 'אנא המתן','שולח שאלה', '' )
    response = requests.get('https://www.dvdsreleasedates.com/livesearch.php', headers=headers, params=params).content
    logging.warning(response)
    regex='<a href=\'(.+?)\'><span class="lsbold">(.+?) \((.+?)\)</span></a>'
    m=re.compile(regex).findall(response)
    txt_f=[]
    found=0
    
    unknow=0
    if len (m)==0:
        dp.update(0, 'אנא המתן','שולח בקשה שנייה', '' )
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Connection': 'keep-alive',
           
            'Upgrade-Insecure-Requests': '1',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
        }

        data = {
          'searchStr': name+' (%s)'%year
        }

        response = requests.post('https://www.dvdsreleasedates.com/search/', headers=headers,  data=data).content
        regex="<td class='dvdcell'><a href='(.+?)'><img class='movieimg'.+?title='(.+?)'"
        m=re.compile(regex).findall(response)
        logging.warning('m')
        logging.warning(m)
        if len(m)==0:
            unknow=1
        ff=0
        nlk=''
        for lk ,nm in m:
            dp.update(0, 'אנא המתן','בודק', nm )
            logging.warning(name.lower() )
            logging.warning(nm.lower() )
            if 1:#name.lower().strip().decode('utf8') in nm.lower().strip().decode('utf8'):
                ff=1
                nlk=lk
                break
        logging.warning(ff)
        if ff==0:
            m=[]
        else:
            m=[]
            m.append((nlk,nm,year))
    svn=name
    tet_txt=''
    for lk,nm,yr in m:
        dp.update(0, 'אנא המתן','המשך בדיקה', nm )
        if 1:#nm.lower()==name.lower() and yr==year:
            x=requests.get('https://www.dvdsreleasedates.com'+lk,headers=base_header).content
            
            regex="<div class='disccellinfo'><b>(.+?)</b>.+?Release Date</span> <span class='(.+?)<"
                   
            m2=re.compile(regex,re.DOTALL).findall(x)
            for ty,whda in m2:
                wh=whda.split('>')[0]
                da=whda.split('>')[1]
                
                if 'future' in wh:
                    color='red'
                else:
                    color='lightgreen'
                    found=1
                
                #txt_f.append(('[COLOR lighblue]'+ty+'[/COLOR] - [COLOR %s][I]'%color+da+'[/COLOR]'))
                txt_f.append(('[COLOR lightblue]'+ty.strip()+'[/COLOR] - [COLOR %s]'%color+da.strip()+'[/COLOR]'))
                tet_txt=da.strip()
                svn=nm
    dp.update(0, 'אנא המתן','ממתין לבדיקת כתוביות', '' )
    while thread[0].isAlive():
        xbmc.sleep(100)
    dp.close()
    sub1=False
    if susb_data[name]:
        add_s=' -  [COLOR green][B]יש כתוביות[/B][/COLOR]'
        sub1=True
    else:
        add_s=' -  [COLOR red][B] אין כתוביות [/B][/COLOR]'
    if len(txt_f)==0 :
        unknow=1
    if check_ok==False:
        if len(txt_f)>0 :
            #contact(title='תאריכי יציאה' ,msg='\n'.join(txt_f))
            #xbmcgui.Window(10000).setProperty('GEN-DOWNLOADED', '\n'.join(txt_f))
            xbmc.executebuiltin('ActivateWindow(%d)' % 10147)
            window = xbmcgui.Window(10147)
            xbmc.sleep(100)
            if found==0:
                add_t=' לא יצא עדיין '+svn
            else:
                add_t=' שוחרר '+svn
            window.getControl(1).setLabel(add_t+add_s)
            window.getControl(5).setText('\n'.join(txt_f)+'\n\n'+add_s)
            window.close()
        else:
            unknow=1
        if unknow==1:
            xbmc.executebuiltin('ActivateWindow(%d)' % 10147)
            window = xbmcgui.Window(10147)
            xbmc.sleep(100)
            
            window.getControl(1).setLabel(svn+add_s)
            window.getControl(5).setText('לא ידוע... סורי'+'\n\n'+add_s)
            window.close()
    else:
        logging.warning('found:'+str(found))
        res=False
        if found==1  :
            res=True
        if unknow==1:
            res=True
       
        return res,sub1,tet_txt,unknow
def clear_all(name):
    name=name.replace(':','').replace("'",'').replace(',','').replace('?','').replace('  ',' ').replace('/','')
    return name
def get_all_jen_data(all_his_links_pre):
    all_his_links_pre=json.loads(all_his_links_pre)
    all_n=[]
    if Addon.getSetting("jen_dp")=='true':
        dp = xbmcgui . DialogProgress ( )
        dp.create('אנא המתן','מעדכן', '','')
        dp.update(0, 'אנא המתן','מעדכן', '' )
    all_data={}
    zzz=0
    all_res=0
    abs_count=0
    for name,link,year,type,resu,name1,index_d in all_his_links_pre:
        all_res+=1
        if Addon.getSetting("rdsource")=='false' and type=='RD':
            continue
       
        name=clear_all(name)
        if (name) not in all_n:
            
            if abs_count==int(Addon.getSetting("jen_am")):
                break
            abs_count+=1
            png=' '
            fan=' '
            plot=' '
            name_heb=name
            genere=' '
            
            if year!='0':
                x=requests.get('http://api.themoviedb.org/3/search/movie?api_key=34142515d9d23817496eeb4ff1d223d0&query=%s&year=%s&language=he&page=1'%(name,year)).json()
                
            else:
                x=requests.get('http://api.themoviedb.org/3/search/movie?api_key=34142515d9d23817496eeb4ff1d223d0&query=%s&language=he&page=1'%(name)).json()
            tmdb=''
            if len(x['results'])>0:
                res=x['results'][0]
                tmdb=res['id']
                try:genere = u' / '.join([genres_list[x] for x in res['genre_ids']])
                except:genere=' '
                name_heb=res['title']
                if Addon.getSetting("jen_dp")=='true':
                    dp.update(int(((zzz* 100.0)/(int(Addon.getSetting("jen_am")))) ), 'אנא המתן','מעדכן', name_heb )
                if res['poster_path']!=None:
                    png=domain_s+'image.tmdb.org/t/p/original/'+res['poster_path']
                if res['backdrop_path']!=None:
                    fan=domain_s+'image.tmdb.org/t/p/original/'+res['backdrop_path']
                plot=res['overview']
            else:
                if Addon.getSetting("jen_dp")=='true':
                    dp.update(int(((zzz* 100.0)/(int(Addon.getSetting("jen_am")))) ), 'אנא המתן','מעדכן', name )
            zzz+=1
            
            all_n.append(name)
            all_data[name]={}
            all_data[name]['name_heb']=name_heb
            all_data[name]['link']=link
            all_data[name]['year']=year
            all_data[name]['type']=type
            
            all_data[name]['png']=png
            all_data[name]['fan']=fan
            all_data[name]['plot']=plot
            all_data[name]['genere']=genere
            all_data[name]['res']=resu
            all_data[name]['name1']=name1
            all_data[name]['tmdb']=tmdb
        else:
        
            all_data[name]['link']=all_data[name]['link']+'$$$'+link
        if Addon.getSetting("jen_dp")=='true':
            if dp.iscanceled():
                dp.close()
    return all_data,all_res
def check_link(name,link,year,type,index_d):
    global all_ok,all_broken
    if name=='BROKEN_LINK':
                return
    name1,match_s,res,check=server_data(link,name)
    if check:
        all_ok.append((name,link,year,type,res,name1,index_d))
    else:
        all_broken.append((name,link,year,type,res,name1,index_d))
def clean_data():
        global all_ok,all_broken
        dp = xbmcgui . DialogProgress ( )
        dp.create('אנא המתן','מעדכן', '','')
        dp.update(0, 'אנא המתן','מעדכן', '' )
        tmdb_cacheFile = os.path.join(done_dir,'cache_f', 'jen_db.db')
        tmdb_clean_cacheFile = os.path.join(done_dir,'cache_f', 'clean_jen_db.db')
        dbcon_tmdb = database.connect(tmdb_cacheFile)
        dbcur_tmdb = dbcon_tmdb.cursor()
        dbcur_tmdb.execute("DELETE  from tmdb_data where link like '%openload%' or link like '%streamcherry%' or link like '%vidoza%' or link like '%vidlox%'")
        dbcon_tmdb.commit()
        dbcur_tmdb.execute("SELECT * FROM tmdb_data ")
        
        
        
        
        dbcon_tmdb2 = database.connect(tmdb_clean_cacheFile)
        dbcur_tmdb2 = dbcon_tmdb2.cursor()
        dbcur_tmdb2.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""year TEXT,""type TEXT,""res TEXT,""clean_name TEXT,""index_d TEXT);"% 'tmdb_data')
        zzz=0
        dbcon_tmdb2.commit()
        dbcur_tmdb2.execute("DELETE FROM tmdb_data")
        dbcon_tmdb2.commit()
        
        all_his_links_pre = dbcur_tmdb.fetchall()
        all_ok=[]
        all_broken=[]
        zzz=0
        count_page=0
        count_bad=0
        count_trd=0
        break_all=0
        thread=[]
        total=0
        for name,link,year,type,index_d in all_his_links_pre:
            
        
            thread.append(Thread(check_link,name,link,year,type,index_d))
            thread[len(thread)-1].setName(name)
            count_trd+=1
            total+=1
            if dp.iscanceled():
               dp.close()
               break
            if count_trd>50:
                for trd in thread:
                
            
                    trd.start()
                count_trd=0
                dp.update(int(((total* 100.0)/(len(all_his_links_pre))) ), 'אנא המתן','מתחיל TRD', '' )
                while(1):
                    still_alive=0
                    count_alive=0
                    for trd in thread:
                    
                       
                        if trd.isAlive():
                            still_alive=1
                            count_alive+=1
                    if still_alive==0:
                        #break_all=1
                        thread=[]
                        break
                    xbmc.sleep(100)
                    dp.update(int(((total* 100.0)/(len(all_his_links_pre))) ), 'אנא המתן','רץ', str(count_alive)+'/'+str(len(thread))+', T:'+str(total)+'/'+str(len(all_his_links_pre)) )
                if break_all==1:
                    break
                for name,link,year,type,res,name1,index_d in all_ok:
                    dbcur_tmdb2.execute("INSERT INTO tmdb_data Values ('%s', '%s', '%s', '%s', '%s', '%s', '%s');" %  (name.replace('.',' ').replace("'","%27").lower(),link.replace("'","27"),str(year).replace("'","%27"),type,res.replace('p',''),name1.replace("'","%27"),str(zzz)))
                    zzz+=1
                for name,link,year,type,res,name1,index_d in all_broken:
                    dbcur_tmdb.execute("UPDATE tmdb_data SET name='BROKEN_LINK' WHERE link = '%s'"%(link))
                
                all_broken=[]
                all_ok=[]
                dbcon_tmdb.commit()
                dbcon_tmdb2.commit()
        
        dbcon_tmdb.commit()
        dbcon_tmdb2.commit()
        dbcur_tmdb.close()
        dbcon_tmdb.close()
        
        dbcur_tmdb2.close()
        dbcon_tmdb2.close()
        
        
        
        dp.close()
def all_jen(page,next_page):
    selected_year='0'
    if page=='0':
        num_st='0'
    elif '-' in page:
        logging.warning(page)
        if 'years' in page:
            selected_year=page.split('-')[1]
            num_st=page.split('-')[2]
            page=page.split('-')[0]
        else:
            num_st=page.split('-')[1]
            page=page.split('-')[0]
        
    else:
        num_st=page
    ord_by=Addon.getSetting('jen_ord')
    if ord_by=='0':
        ord='index_d'
    else:
        ord='year'
    if Addon.getSetting("jen_dp")=='true':
        dp = xbmcgui . DialogProgress ( )
        dp.create('אנא המתן','מעדכן', '','')
        dp.update(0, 'אנא המתן','מעדכן', '' )
    tmdb_cacheFile = os.path.join(done_dir,'cache_f', 'clean_jen_db.db')
    dbcon_tmdb = database.connect(tmdb_cacheFile)
    dbcur_tmdb = dbcon_tmdb.cursor()
    
    dbcur_tmdb.execute("SELECT rowid FROM tmdb_data")
    all_res_total=dbcur_tmdb.fetchall()
    '''
    x=1
    for rowid in all_res_total:
        
        dbcur_tmdb.execute("UPDATE tmdb_data SET index_d='%s' WHERE rowid = %s"%(str(x),rowid[0]))
        x+=1
    '''
    dbcon_tmdb.commit()
    
    if page=='search':
        search_entered=''
                       
                        
        keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש כאן')
        keyboard.doModal()
        if keyboard.isConfirmed():
               search_entered = keyboard.getText()
               dbcur_tmdb.execute("SELECT * FROM tmdb_data where name like '%{0}%'  order by year DESC ".format(search_entered))
    elif page=='4K':
        dbcur_tmdb.execute("SELECT DISTINCT name FROM tmdb_data where res='2160'")
        all_res_total=dbcur_tmdb.fetchall()
        dbcur_tmdb.execute("SELECT * FROM tmdb_data  where res='2160' order by %s DESC limit 2000 offset "%ord+(num_st))
        
        
    elif 'years' in page:
        if selected_year=='0':
            dbcur_tmdb.execute("SELECT DISTINCT year FROM tmdb_data ")
            all_years_pre=dbcur_tmdb.fetchall()
            all_years=[]
            for year in all_years_pre:
                 all_years.append(int(year[0]))
            
            newList = sorted(all_years,reverse=True)
            newList_2=[]
            for items in newList:
                newList_2.append(str(items))
            ret = xbmcgui.Dialog().select("בחר", newList_2)
            if ret!=-1:
                dbcur_tmdb.execute("SELECT DISTINCT name FROM tmdb_data where year='%s'"%newList_2[ret])
                all_res_total=dbcur_tmdb.fetchall()
                dbcur_tmdb.execute("SELECT * FROM tmdb_data  where year='%s' order by %s DESC limit 2000 offset %s"%(newList_2[ret],ord,num_st))
                selected_year=newList_2[ret]
            else:
                sys.exit()
        else:
            dbcur_tmdb.execute("SELECT DISTINCT name FROM tmdb_data where year='%s'"%selected_year)
            all_res_total=dbcur_tmdb.fetchall()
            dbcur_tmdb.execute("SELECT * FROM tmdb_data  where year='%s' order by index_d DESC limit 2000 offset %s"%(selected_year,num_st))
            
    else:
    
        dbcur_tmdb.execute("SELECT DISTINCT name FROM tmdb_data")
        all_res_total=dbcur_tmdb.fetchall()
        #dbcur_tmdb.execute("SELECT * FROM tmdb_data where (link not like '%http://dl8.f2m.io/%' or link like '%$$$%') order by year DESC limit 2000 offset "+(num_st))
        dbcur_tmdb.execute("SELECT * FROM tmdb_data  order by %s DESC limit 2000 offset "%ord+(num_st))
    all_his_links_pre = dbcur_tmdb.fetchall()
    all_data={}
    all_n=[]
 
    url_g=domain_s+'api.themoviedb.org/3/genre/movie/list?api_key=34142515d9d23817496eeb4ff1d223d0&language=he'
    html_g=html_g_movie
    #html_g=requests.get(url_g).json()
        
    genres_list= dict([(i['id'], i['name']) for i in html_g['genres'] \
                    if i['name'] is not None])
    
    all_res=str(len(all_res_total)-(int(next_page)*int(Addon.getSetting("jen_am"))))
    
    max_page=str((len(all_res_total)/int(Addon.getSetting("jen_am"))) -int(next_page))
    #get_all_jen_data(json.dumps(all_his_links_pre))
    all_data,all_res_new=cache.get(get_all_jen_data,9999,json.dumps(all_his_links_pre), table='posters')
    

    
    for items in all_data:
        link=all_data[items]['link']
        yr=all_data[items]['year']
        nm=all_data[items]['name_heb']
        sv_name=all_data[items]['name1']
        tmdb=all_data[items]['tmdb']
        regex='//(.+?)/'
        m=re.compile(regex).findall(link)
        add_p=','.join(m)
        trailer = "plugin://plugin.video.allmoviesin?mode=25&url=www&id=%s&tv_movie=%s" % (tmdb,'movie')
        addLink( nm.replace('.',' '), link,5,False,all_data[items]['png'],all_data[items]['fan'],add_p+'\n'+all_data[items]['plot'],data=yr,saved_name=sv_name,original_title=items,show_original_year=yr,generes=all_data[items]['genere'],heb_name=sv_name,trailer=trailer)
    if Addon.getSetting("jen_dp")=='true':
        dp.close()
    dbcur_tmdb.close()
    dbcon_tmdb.close()
    if page!='4K' or page!='years':
        if 'years' in page:
            added=selected_year+'-'
        else:
            added=''
        addDir3(('[COLOR aqua][I]עמוד %s מתוך %s (%s תוצאות)[/I][/COLOR]'%(str(int(next_page)+2),str(max_page),str(all_res))).decode('utf8'),page+'-'+added+str(all_res_new),154,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTNmz-ZpsUi0yrgtmpDEj4_UpJ1XKGEt3f_xYXC-kgFMM-zZujsg','https://cdn4.iconfinder.com/data/icons/arrows-1-6/48/1-512.png','עוד תוצאות'.decode('utf8'),data=str(int(next_page)+1))
        addLink( '[COLOR khaki][I]חזור לראשי[/I][/COLOR]'.decode('utf8'), 'www',103,False,'http://bellaharling.com/wp-content/uploads/2015/01/007485-blue-metallic-orb-icon-arrows-arrow-undo.png','https://media.istockphoto.com/vectors/arrow-back-icon-vector-id473334504?k=6&m=473334504&s=612x612&w=0&h=oJPHGtAcfiMgjJ8QLhTX03Hy9osSo2wRQfG2WTaCS3E=','חזור לראשי'.decode('utf8'),shortcut=True)
        
    elif page!='search' :
        addDir3(('[COLOR aqua][I]עמוד %s מתוך %s (%s תוצאות)[/I][/COLOR]'%(str(int(next_page)+2),str(max_page),str(all_res))).decode('utf8'),page+'-'+str(all_res_new),154,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTNmz-ZpsUi0yrgtmpDEj4_UpJ1XKGEt3f_xYXC-kgFMM-zZujsg','https://cdn4.iconfinder.com/data/icons/arrows-1-6/48/1-512.png','עוד תוצאות'.decode('utf8'),data=str(int(next_page)+1))
        addLink( '[COLOR khaki][I]חזור לראשי[/I][/COLOR]'.decode('utf8'), 'www',103,False,'http://bellaharling.com/wp-content/uploads/2015/01/007485-blue-metallic-orb-icon-arrows-arrow-undo.png','https://media.istockphoto.com/vectors/arrow-back-icon-vector-id473334504?k=6&m=473334504&s=612x612&w=0&h=oJPHGtAcfiMgjJ8QLhTX03Hy9osSo2wRQfG2WTaCS3E=','חזור לראשי'.decode('utf8'),shortcut=True)
def one_click_rf_ca(type,page):
    all_data=[]
    num_pg=int(Addon.getSetting("on_ck_num"))
    if 'search' in type:
            if 'movie' in type:
                   
                    if 'search_movies' in type :
                        search_entered=''
                       
                        
                        keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש כאן')
                        keyboard.doModal()
                        if keyboard.isConfirmed():
                               search_entered = keyboard.getText()
                               url='http://redflixtv.me/api/search?api_secret_key=ssgx54x49bkv2xk7mkghksfz&q=%s&page=1'%(search_entered)
                               
                        else:
                            return '0'
                        
            elif 'search_tv' in type:
                        search_entered=''
                       
                        
                        keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש כאן')
                        keyboard.doModal()
                        if keyboard.isConfirmed():
                               search_entered = keyboard.getText()
                               url='http://redflixtv.me/api/search?api_secret_key=ssgx54x49bkv2xk7mkghksfz&q=%s&page=1'%(search_entered)
                        else:
                            return '0'
                        
            headers={
                    'Connection': 'Keep-Alive',

                    'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 6.0.1; LS)'}
            x=requests.get(url,headers=headers).json()
            logging.warning(len(x))
            if 'search' in type:
                if 'movie' in type:
                    n_items=x['movie']
                else:
                    n_items=x['tvseries']
            else:
                n_items=x
            
            for items in n_items:
            
                if 'movie' in type:
                    all_data.append((items['title'],'redflixtv.me/movie/'+items['videos_id'],items['thumbnail_url'],items['poster_url'],items['description'],items['release'],items['title'],items['release']))
                else:
                    all_data.append((items['title'],items['videos_id'],items['thumbnail_url'],items['poster_url'],items['description'],items['release'],items['title'],items['release']))
            return all_data,'1'
    else:
            for f_page in range(int(page),num_pg+int(page)):
                logging.warning('f_page:'+str(f_page))
                if 'movie' in type:
                   
                    
                        url='http://redflixtv.me/api/get_movies?api_secret_key=ssgx54x49bkv2xk7mkghksfz&&page='+str(f_page)
                    
                else:
                   
                   
                        url='http://redflixtv.me/api/get_tvseries?api_secret_key=ssgx54x49bkv2xk7mkghksfz&&page='+str(f_page)
                        logging.warning(url)
                headers={
                        'Connection': 'Keep-Alive',

                        'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 6.0.1; LS)'}
                x=requests.get(url,headers=headers).json()
                logging.warning(len(x))
                
                n_items=x
                for items in n_items:
                    
                    if 'movie' in type:
                        all_data.append((items['title'],'redflixtv.me/movie/'+items['videos_id'],items['thumbnail_url'],items['poster_url'],items['description'],items['release'],items['title'],items['release']))
                    else:
                        all_data.append((items['title'],items['videos_id'],items['thumbnail_url'],items['poster_url'],items['description'],items['release'],items['title'],items['release']))
            return all_data,f_page
def one_click_rf(type,page):
    if 'search'  not in type:
        if 'movie' in type:
                if page=='1':
                    addDir3('[COLOR lightblue][I]חיפוש (באנגלית)[/COLOR][/I]','search_movies',155,' ',' ','[COLOR aqua][I]עמוד הבא[/COLOR][/I]',data='1')
        else:
            if page=='1':
                addDir3('[COLOR lightblue][I]חיפוש (באנגלית)[/COLOR][/I]','search_tv',155,' ',' ','[COLOR aqua][I]עמוד הבא[/COLOR][/I]',data='1')
        
    if 'search'  in type:
        time_to_save_db=0
    else:
        time_to_save_db=24
    
    all_data,f_page=cache.get(one_click_rf_ca,time_to_save_db,type,page, table='posters')
    
    for name,url,icon,fanart,plot,data,original_title,year in all_data:
        if 'movie' in type:
            addLink(name,url,5,False,icon,fanart,plot,data=data,original_title=original_title,show_original_year=year)
        else:
            addDir3(name,url,156,icon,fanart,plot,data=data,original_title=original_title,show_original_year=year)
    if 'search' not in type:
        addDir3('[COLOR aqua][I]עמוד הבא[/COLOR][/I]',type,155,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTNmz-ZpsUi0yrgtmpDEj4_UpJ1XKGEt3f_xYXC-kgFMM-zZujsg','https://cdn4.iconfinder.com/data/icons/arrows-1-6/48/1-512.png','[COLOR aqua][I]עמוד הבא[/COLOR][/I]',data=str(int(f_page)+1))
        addLink( '[COLOR khaki][I]חזור לראשי[/I][/COLOR]'.decode('utf8'), 'www',103,False,'http://bellaharling.com/wp-content/uploads/2015/01/007485-blue-metallic-orb-icon-arrows-arrow-undo.png','https://media.istockphoto.com/vectors/arrow-back-icon-vector-id473334504?k=6&m=473334504&s=612x612&w=0&h=oJPHGtAcfiMgjJ8QLhTX03Hy9osSo2wRQfG2WTaCS3E=','חזור לראשי'.decode('utf8'),shortcut=True)
def one_click_rf_tv(name,url,icon,fan,data):
    url='http://redflixtv.me/api/get_single_details?api_secret_key=ssgx54x49bkv2xk7mkghksfz&type=tvseries&id='+url
        
    headers={
            'Connection': 'Keep-Alive',

            'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 6.0.1; LS)'}
    x=requests.get(url,headers=headers).json()
    season=0
    season_pre=1
    
    for items in x['season']:
        season=items['seasons_name'].split('[')[0]
        if season!=season_pre:
            addNolink('[COLOR lightblue][I]עונה '+items['seasons_name'].split('[')[0]+'[/I][/COLOR]','www',99999,False,iconimage=icon,fanart=fan)
            in_episode=1
            for se in items['episodes']:
                
                addLink('פרק '+str(in_episode),'redflixtv.me/tv/'+se['file_url'],5,False,icon,se['image_url'],' ',data=data,original_title=name,show_original_year=data,season=season.strip(),episode=str(in_episode))
                in_episode+=1
        season_pre=season
        
def sync_trk():
    #tv
    all_tv_prog=progress_trakt('users/me/watched/shows?extended=full')
    
    dbcur.execute("SELECT  * FROM Lastepisode WHERE  type='tv' ")
   
    match_tv = dbcur.fetchall()
   
    
    new_tv={}
    all_local_mv={}
    new_tv_far={}
    for item in match_tv:
      
      
      name,url,icon,image,plot,year,original_title,season,episode,id,eng_name,show_original_year,heb_name,isr,tv_movie=item
     
      all_local_mv[id]={}
      all_local_mv[id]['icon']=icon
      all_local_mv[id]['fan']=image
      all_local_mv[id]['plot']=plot
      all_local_mv[id]['year']=year
      all_local_mv[id]['original_title']=original_title
      all_local_mv[id]['title']=name
      all_local_mv[id]['season']=season
      all_local_mv[id]['episode']=episode
      all_local_mv[id]['eng_name']=eng_name
      all_local_mv[id]['heb_name']=heb_name
      
      all_local_mv[id]['type']='tv'
      if id not in all_tv_prog:
        new_tv[id]={}
        new_tv[id]['item']=(all_local_mv[id])
        
        new_tv[id]['change_reason']='New'
       
        new_tv[id]['local']=''
        new_tv[id]['trk']=''
      else:
        if season!=all_tv_prog[id]['season']:
            if id not in new_tv:
                new_tv[id]={}
                new_tv[id]['change_reason']=''
            new_tv[id]['item']=(all_tv_prog[id])
            new_tv[id]['change_reason']=new_tv[id]['change_reason']+'$$$$season'
            
            new_tv[id]['local']=season
            new_tv[id]['trk']=all_tv_prog[id]['season']
        if episode!=all_tv_prog[id]['episode']:
            if id not in new_tv:
                new_tv[id]={}
                new_tv[id]['change_reason']=''
            new_tv[id]['item']=(all_tv_prog[id])
            
            new_tv[id]['change_reason']=new_tv[id]['change_reason']+'$$$$episode'
            new_tv[id]['local']=episode
            new_tv[id]['trk']=all_tv_prog[id]['episode']
    for id in all_tv_prog:
      if id not in all_local_mv:
        new_tv_far[id]={}
        new_tv_far[id]['item']=(all_tv_prog[id])
        new_tv_far[id]['change_reason']='New'

        new_tv_far[id]['local']=''
        new_tv_far[id]['trk']=''
      else:
        if all_tv_prog[id]['season']!=all_local_mv[id]['season']:
            if id not in new_tv_far:
                new_tv_far[id]={}
                new_tv_far[id]['change_reason']=''
            new_tv_far[id]['item']=(all_local_mv[id])
            new_tv_far[id]['change_reason']=new_tv_far[id]['change_reason']+'$$$$season'
            
            new_tv_far[id]['local']=all_local_mv[id]['season']
            new_tv_far[id]['trk']=all_tv_prog[id]['season']
        if all_tv_prog[id]['episode']!=all_local_mv[id]['episode']:
            if id not in new_tv_far:
                new_tv_far[id]={}
                new_tv_far[id]['change_reason']=''
            new_tv_far[id]['item']=(all_local_mv[id])
            
            new_tv_far[id]['change_reason']=new_tv_far[id]['change_reason']+'$$$$episode'
            new_tv_far[id]['local']=all_local_mv[id]['episode']
            new_tv_far[id]['trk']=all_tv_prog[id]['episode']
    not_on_trk=[]
    not_on_local=[]
    for id in new_tv:
        if new_tv[id]['change_reason']=='New':
            not_on_trk.append(clean_name(all_local_mv[id]['original_title'],1)+' S%sE%s'%(all_local_mv[id]['season'],all_local_mv[id]['episode'])+'-'+all_local_mv[id]['year'])
    for id in new_tv_far:
        if new_tv_far[id]['change_reason']=='New':
            not_on_local.append(clean_name(all_tv_prog[id]['original_title'],1)+' S%sE%s'%(all_tv_prog[id]['season'],all_tv_prog[id]['episode'])+'-'+all_tv_prog[id]['year'])
    

            
            
    #movie
    all_mv_prog=get_trk_data('users/me/watched/movies')
    
    dbcur.execute("SELECT * FROM AllData WHERE  type='movie'")
    match_tv = dbcur.fetchall()


    new_mv={}
    all_local_mv={}
    new_mv_far={}
    for item in match_tv:
      
      
      name,url,icon,image,plot,year,original_title,season,episode,id,eng_name,show_original_year,heb_name,isr,tv_movie=item
     
      all_local_mv[id]={}
      all_local_mv[id]['icon']=icon
      all_local_mv[id]['fan']=image
      all_local_mv[id]['plot']=plot
      all_local_mv[id]['year']=year
      all_local_mv[id]['original_title']=original_title
      all_local_mv[id]['title']=name
      all_local_mv[id]['season']=season
      all_local_mv[id]['episode']=episode
      all_local_mv[id]['eng_name']=eng_name
      all_local_mv[id]['heb_name']=heb_name
      
      all_local_mv[id]['type']='tv'
      if id not in all_mv_prog:
        new_mv[id]={}
        new_mv[id]['item']=(all_local_mv[id])
        
        new_mv[id]['change_reason']='New'
       
        new_mv[id]['local']=''
        new_mv[id]['trk']=''
    for id in all_mv_prog:
      if id not in all_local_mv:
        new_mv_far[id]={}
        new_mv_far[id]['item']=(all_mv_prog[id])
        new_mv_far[id]['change_reason']='New'

        new_mv_far[id]['local']=''
        new_mv_far[id]['trk']=''
    not_on_trk_mv=[]
    not_on_local_mv=[]
    for id in new_mv:
        if new_mv[id]['change_reason']=='New':
            not_on_trk_mv.append(clean_name(all_local_mv[id]['original_title'],1)+'-'+all_local_mv[id]['year'])
    for id in new_mv_far:
        if new_mv_far[id]['change_reason']=='New':
            not_on_local_mv.append(clean_name(all_mv_prog[id]['original_title'],1)+'-'+all_mv_prog[id]['year'])
    msg='[COLOR yellow][I]סדרות[/I][/COLOR]\n[COLOR lightblue]לא נמצא בTRAKT'+'\n----------------\n'+'\n'.join(not_on_trk)+'[/COLOR]\n\n[COLOR khaki]קיים רק בTRAKT ולא במקומי'+'\n----------------\n'+'\n'.join(not_on_local)+'[/COLOR]'
    msg=msg+'\n\n[COLOR yellow][I]סרטים[/I][/COLOR]\n[COLOR lightblue]לא נמצא בTRAKT'+'\n----------------\n'+'\n'.join(not_on_trk_mv)+'[/COLOR]\n\n[COLOR khaki]קיים רק בTRAKT ולא במקומי'+'\n----------------\n'+'\n'.join(not_on_local_mv)+'[/COLOR]'
    ok=TrkBox_help('שינויים', msg)
    if ok:
        for id in new_tv_far:
           if new_tv_far[id]['change_reason']=='New':
            name=new_tv_far[id]['item']['title']
            url='www'
            icon=new_tv_far[id]['item']['icon']
            image=new_tv_far[id]['item']['fan']
            plot=new_tv_far[id]['item']['plot']
            year=new_tv_far[id]['item']['year']
            original_title=new_tv_far[id]['item']['original_title']
            season=new_tv_far[id]['item']['season']
            episode=new_tv_far[id]['item']['episode']
            eng_name=new_tv_far[id]['item']['eng_name']
            show_original_year=new_tv_far[id]['item']['year']
            heb_name=new_tv_far[id]['item']['heb_name']
            isr='0'
            tv_movie='tv'
            dbcur.execute("INSERT INTO Lastepisode Values ('%s', '%s', '%s', '%s','%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s','%s','%s','%s');" %  (name.replace("'","%27"),url,icon,image,plot.replace("'","%27"),year,original_title.replace("'","%27").replace(" ","%20"),season,episode,id,eng_name.replace("'","%27"),show_original_year,heb_name.replace("'","%27"),isr,tv_movie))
            dbcon.commit()
            
            
        for id in new_mv_far:
           if new_mv_far[id]['change_reason']=='New':
            name=new_mv_far[id]['item']['title']
            url='www'
            icon=new_mv_far[id]['item']['icon']
            image=new_mv_far[id]['item']['fan']
            plot=new_mv_far[id]['item']['plot']
            year=new_mv_far[id]['item']['year']
            original_title=new_mv_far[id]['item']['original_title']
            season=new_mv_far[id]['item']['season']
            episode=new_mv_far[id]['item']['episode']
            eng_name=new_mv_far[id]['item']['eng_name']
            show_original_year=new_mv_far[id]['item']['year']
            heb_name=new_mv_far[id]['item']['heb_name']
            isr='0'
            tv_movie='movie'
            dbcur.execute("INSERT INTO AllData Values ('%s', '%s', '%s', '%s','%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s','%s','%s','%s');" %  (name.replace("'","%27"),url,icon,image,plot.replace("'","%27"),year,original_title.replace("'","%27").replace(" ","%20"),season,episode,id,eng_name.replace("'","%27"),show_original_year,heb_name.replace("'","%27"),isr,tv_movie))
            dbcon.commit()
          
        for id in new_mv:
          if new_mv[id]['change_reason']=='New':
            i = (post_trakt('/sync/history',data= {"movies": [{"ids": {"tmdb": id}}]}))
        for id in new_tv:
          if new_tv[id]['change_reason']=='New':
            season=new_tv[id]['item']['season']
            episode=new_tv[id]['item']['episode']
            season_t, episode_t = int('%01d' % int(season)), int('%01d' % int(episode))
            i = (post_trakt('/sync/watchlist', data={"shows": [{"seasons": [{"episodes": [{"number": episode_t}], "number": season_t}], "ids": {"tmdb": id}}]}))
   
            
            i = (post_trakt('/sync/history', data={"shows": [{"seasons": [{"episodes": [{"number": episode_t}], "number": season_t}], "ids": {"tmdb": id}}]}))
            
        xbmcgui.Dialog().ok('סינכרון','[COLOR aqua][I] הסנכרון הושלם [/I][/COLOR]')
def get_html_data(url):
    html=requests.get(url).json()
    return html
def was_i():
    addNolink('[COLOR red][I][B]מחיקת היסטוריה[/B][/I][/COLOR]','www',162,False,iconimage='https://keepingitclean.ca/images/social/keep-it-clean-social-sharing.jpg',fanart='https://the-clean-show.us.messefrankfurt.com/content/dam/messefrankfurt-usa/the-clean-show/2021/images/kv/Cleanshow%20websideheader_tropfen_2560x1440px_01.jpg')
    dbcur.execute("SELECT * FROM playback")
    dbcon.commit()
    match = dbcur.fetchall()
    if Addon.getSetting("was_progress")=='true':
        dp = xbmcgui . DialogProgress ( )
        dp.create('אנא המתן','מחפש מקורות', '','')
        dp.update(0, 'אנא המתן','מחפש מקורות', '' )
    zzz=0
    tmdbKey='653bb8af90162bd98fc7ee32bcbbfb3d'
    for name,tmdb,season,episode,playtime,totaltime,free in match:
      if float(totaltime)==0:
        continue
      if (int((float(playtime)*100)/float(totaltime)))<95:
        try:
        
            a=int(tmdb)
            
        except:
            if 'tt' in free:
             url=domain_s+'api.themoviedb.org/3/find/%s?api_key=34142515d9d23817496eeb4ff1d223d0&external_source=imdb_id&language=heb'%free
             html_im=requests.get(url).json()
             logging.warning(free)
             logging.warning(html_im)
             
             if season=='0':
                 if len(html_im['movie_results'])>0:
                    tmdb=str(html_im['movie_results'][0]['id'])
             else:
                if len(html_im['tv_results'])>0:
                    tmdb=str(html_im['tv_results'][0]['id'])
             try:
        
                a=int(tmdb)
                
             except:
                continue
            else:
                continue
        if season!='0' and season!='' and season!='':
          url_t='http://api.themoviedb.org/3/tv/%s/season/%s/episode/%s?api_key=653bb8af90162bd98fc7ee32bcbbfb3d&language=he&append_to_response=external_ids'%(tmdb,season,episode)
          html_t=cache.get(get_html_data,9999,url_t, table='ps_backup')
          if 'status_code' in html_t:
            continue
          if 'still_path' in html_t:
            if html_t['still_path']==None:
                html_t['still_path']=''
          else:
            html_t['still_path']=''
          fan=domain_s+'image.tmdb.org/t/p/original/'+html_t['still_path']
          
          plot= '[COLOR yellow] %s '%str(int((float(playtime)*100)/float(totaltime)))+'%[/COLOR]\n'+html_t['overview']
          url2='http://api.themoviedb.org/3/tv/%s?api_key=%s&language=he&append_to_response=external_ids'%(tmdb,tmdbKey)
          html=cache.get(get_html_data,9999,url2, table='ps_backup')
          if 'poster_path' in html:
              if html['poster_path']==None:
                html['poster_path']=''
          else:
            html['poster_path']=''
          icon=domain_s+'image.tmdb.org/t/p/original/'+html['poster_path']
          new_name=html['name']+ ' S%sE%s '%(season,episode)
          url='www'
          if 'air_date' in html_t:
           if html_t['air_date']!=None:
             
             year=str(html_t['air_date'].split("-")[0])
           else:
            year='0'
          else:
            year='0'
          original_name=html['original_name']
          rating=html['vote_average']
          heb_name=html['name']
          isr='0'
          genres_list=[]
          if 'genres' in html:
            for g in html['genres']:
                  genres_list.append(g['name'])
            
            try:genere = u' / '.join(genres_list)
            except:genere=''
          trailer = "plugin://plugin.video.allmoviesin?mode=25&url=www&id=%s&tv_movie=%s" % (tmdb,'tv')
          addDir3(new_name,url,4,icon,fan,plot,data=year,original_title=original_name,id=tmdb,rating=rating,heb_name=heb_name,show_original_year=year,isr=isr,generes=genere,trailer=trailer,season=season,episode=episode,hist='true')
        
        else:
          url_t='http://api.themoviedb.org/3/movie/%s?api_key=34142515d9d23817496eeb4ff1d223d0&language=he'%tmdb
          
          
          logging.warning(url_t)
          html=cache.get(get_html_data,9999,url_t, table='ps_backup')
          if 'status_code' in html:
            continue
          if 'backdrop_path' in html:
              if html['backdrop_path']==None:
                html['backdrop_path']=''
          else:
            html['backdrop_path']=''
          fan=domain_s+'image.tmdb.org/t/p/original/'+html['backdrop_path']
          
          plot= '[COLOR yellow] %s '%str(int((float(playtime)*100)/float(totaltime)))+'%[/COLOR]\n'+html['overview']
          if 'poster_path' in html:
              if html['poster_path']==None:
                html['poster_path']=''
          else:
            html['poster_path']=''
          icon=domain_s+'image.tmdb.org/t/p/original/'+html['poster_path']
          new_name=html['title']
          url='www'
          if 'release_date' in html:
           if html['release_date']!=None:
             
             year=str(html['release_date'].split("-")[0])
           else:
            year='0'
          else:
            year='0'
          original_title=html['original_title']
          rating=html['vote_average']
          heb_name=html['title']
          isr='0'
          genres_list=[]
          if 'genres' in html:
            for g in html['genres']:
                  genres_list.append(g['name'])
            
            try:genere = u' / '.join(genres_list)
            except:genere=''
          trailer = "plugin://plugin.video.allmoviesin?mode=25&url=www&id=%s&tv_movie=%s" % (tmdb,'tv')
          addDir3(new_name,url,4,icon,fan,plot,data=year,original_title=original_title,id=tmdb,rating=rating,heb_name=heb_name,show_original_year=year,isr=isr,generes=genere,trailer=trailer,hist='true',season='0',episode='0')
        if Addon.getSetting("was_progress")=='true':
            dp.update(int(((zzz* 100.0)/(len(match))) ), 'אנא המתן','טוען', new_name )
            zzz+=1
            if dp.iscanceled():
               dp.close()
               break
    if Addon.getSetting("was_progress")=='true':
        dp.close()
        
        
def remove_was_i(name,id,season,episode):
        dbcur.execute("DELETE  FROM playback   where tmdb='%s' and season='%s' and episode='%s'"%(id,str(season).replace('%20','0').replace(' ','0'),str(episode).replace('%20','0').replace(' ','0')))
        logging.warning(' Remove DATA')
        logging.warning("SELECT * FROM playback where tmdb='%s' and season='%s' and episode='%s'"%(id,str(season).replace('%20','0').replace(' ','0'),str(episode).replace('%20','0').replace(' ','0')))
        dbcon.commit()
        xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'הוסר...'.decode('utf8')+name)).encode('utf-8'))
        xbmc.executebuiltin('Container.Refresh')

def real_4k(url,icon,fan):
    if url=='www':
        url='https://www.4kfox.com/more/1/1'
    x=requests.get(url,headers=base_header).content
    regex='<div class="post thumb-border">(.+?)fa fa-play-circle'
    m=re.compile(regex,re.DOTALL).findall(x)
    headers = {
    'Connection': 'keep-alive',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'utf-8',
    'Accept-Language': 'en-US,en;q=0.9',
    }
    
    for items in m:
        regex="data-original='(.+?)'"
        icon_pre=re.compile(regex).findall(items)
        if len(icon_pre)>0:
            icon=icon_pre[0]
            fan=icon
        regex='title=\'(.+?)\'.+?href="(.+?)"'
        m2=re.compile(regex,re.DOTALL).findall(items)
        logging.warning(items)
        logging.warning(m2[0][0])
        lk='https://www.4kfox.com'+m2[0][1]
        nm=m2[0][0].replace('\n','').replace('\r','').replace('\t','').replace('(','').replace(')','').strip().split(';')[1]
        
        
        addLink(nm,lk,5,False,iconimage=icon,fanart=fan,description=nm)
    regex='<li class="current">.+?href=".+?href="(.+?)"'
    m=re.compile(regex,re.DOTALL).findall(x)
    if len(m)>0:
        addDir3('[COLOR aqua][I]עמוד הבא[/COLOR][/I]','https://www.4kfox.com'+m[0],160,icon,fan,'[COLOR aqua][I]עמוד הבא[/COLOR][/I]')
def simple_play(name,url,iconimage,fanart,description,data,season,episode,original_title,saved_name,heb_name,show_original_year,eng_name,isr,prev_name,id):
    from run import get_links
    logging.warning(url)
    if 'redflixtv.me' in url:
        url,id,nm=get_refl(original_title,url,data)
        check_last_ep(season,episode,name,url,iconimage,fanart,description,original_title,id,eng_name,show_original_year,nm,isr)
        
    url=url.strip().replace('\n','').replace('\t','').replace('\r','')
    ff_link=url
    if '$$$' in url:
       links=url.split('$$$')
       sour_pre=''
       sour=''
       all_s=[]
       for lk in links:
           regex='\[\[(.+?)\]\]'
           match=re.compile(regex).findall(str(lk))
           if len(match)==0:
             regex='//(.+?)/'
             
             match_ser=re.compile(regex).findall(str(lk))
             if len(match_ser)>0:
                 match=[]
                 match.append((sour,match_ser[0]))
             else:
                match=[]
                match.append((sour,'Direct'))
           else:
                regex='\[\[(.+?)\]\].+?//(.+?)/'
                match=re.compile(regex).findall(str(lk))
                if len(match)==0:
                    regex='\[\[(.+?)\]\]'
                    sour=re.compile(regex).findall(str(lk))[0]
                    match=[]
                    match.append((sour,'Direct'))
           
           for sour,ty in match:
                sour=sour.replace('openload','vummo')
                ty=ty.replace('tv4kids','streamango').replace('.tk','.com')
                if 'sratim' in ty:
                    ty='str'
                all_s.append('[COLOR lightblue][B]'+sour+'[/B][/COLOR] - [COLOR yellow][I]'+ty.replace('letsupload','avlts')+'[/I][/COLOR]')
                
       #logging.warning(all_s)
       
       ret = xbmcgui.Dialog().select("בחר", all_s)
       if ret!=-1:
         #logging.warning(links)
         #logging.warning(ret)
         ff_link=links[ret]
         regex='\[\[(.+?)\]\]'
         match2=re.compile(regex).findall(links[ret])
         if len(match2)>0:
           if 'http' in ff_link:
            ff_link=ff_link.replace(match2[0],'').replace('[','').replace(']','')
           else:
            ff_link=ff_link.replace(match2[0],'')
         else:
            try:
                if 'http' in ff_link:
                    ff_link=ff_link.replace(match2[0],'').replace('[','').replace(']','')
                else:
                    ff_link=ff_link.replace(match2[0],'')
            except:
                pass
         url=ff_link.strip()
       else:
         sys.exit()
    if 'tv4kids' in url:
        
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
            'Accept': 'video/webm,video/ogg,video/*;q=0.9,application/ogg;q=0.7,audio/*;q=0.6,*/*;q=0.5',
            'Accept-Language': 'en-US,en;q=0.5',
           
            'Connection': 'keep-alive',
            'Referer': url,
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
        }
        head=urllib.urlencode(headers)
        url=url+"|"+head
    regex='\[\[(.+?)\]\]'
    match=re.compile(regex).findall(str(url))
    ff_link=url
     
     #logging.warning(ff_link)
    if len(match)>0:
        for items in match:
           ff_link=ff_link.replace(items,'').replace('[','').replace(']','')
    url=ff_link.strip()
    url=url.replace('[[]]','')
    link=get_links(url)
    logging.warning(link)
    listItem = xbmcgui.ListItem(name, path=link) 
    #listItem.setInfo(type='Video', infoLabels=video_data)
    ok=xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)

def save_log():
   try:
    db_bk_folder=xbmc.translatePath(Addon.getSetting("remote_path"))
    nameSelect=[]
    logSelect=[]
    import glob
    folder = xbmc.translatePath('special://logpath')
    xbmc.log(folder)
    for file in glob.glob(folder+'/*.log'):
        try:nameSelect.append(file.rsplit('\\', 1)[1].upper())
        except:nameSelect.append(file.rsplit('/', 1)[1].upper())
        logSelect.append(file)
    count=0
    for fi in logSelect:
        xbmcvfs.copy (fi,os.path.join(db_bk_folder,nameSelect[count]))
        count+=1
    xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'נשמר בהצלחה'.decode('utf8'))).encode('utf-8'))
   except Exception as e:
    import linecache
    exc_type, exc_obj, tb = sys.exc_info()
    f = tb.tb_frame
    lineno = tb.tb_lineno
    filename = f.f_code.co_filename
    linecache.checkcache(filename)
    line = linecache.getline(filename, lineno, f.f_globals)

    logging.warning('ERROR IN DP:'+str(lineno)+str(e))
    logging.warning('inline:'+line)
    xbmcgui.Dialog().ok('Error occurred',str(lineno)+','+str(e))
    #xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory Err', str(lineno)+','+str(e))))
params=get_params()

for items in params:
   params[items]=params[items].replace(" ","%20")
ok=False
timmer=0

while(ok==False):
    try:
        
        dbcur.execute("SELECT * FROM AllData")
        dbcon.commit()
        ok=True
    except:
        logging.warning('LOCKED:'+str(timmer))
        xbmc.sleep(100)
        timmer+=1
    if (timmer>100):
        break

url=None
name=None
mode=None
iconimage=None
fanart=None
description=' '
original_title=' '
fast_link=''
data=0
id=' '
saved_name=' '
prev_name=' '
isr=0
season="%20"
episode="%20"
show_original_year=0
heb_name=' '
tmdbid=' '
eng_name=' '
dates=' '
data1='[]'
fav_status='false'
only_torrent='no'
only_heb_servers='0'
new_windows_only=False
meliq='false'
tv_movie='movie'
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        tv_movie=(params["tv_movie"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"].encode('utf-8'))
except:
        pass
try:        
        data=urllib.unquote_plus(params["data"])
except:
        pass
try:        
        original_title=(params["original_title"])
except:
        pass
try:        
        id=(params["id"])
except:
        pass
try:        
        season=(params["season"])
except:
        pass
try:        
        episode=(params["episode"])
except:
        pass
try:        
        tmdbid=(params["tmdbid"])
except:
        pass
try:        
        eng_name=(params["eng_name"])
except:
        pass
try:        
        show_original_year=(params["show_original_year"])
except:
        pass
try:        
        heb_name=urllib.unquote_plus(params["heb_name"])
except:
        pass
try:        
        isr=int(params["isr"])
except:
        pass
try:        
        saved_name=clean_name(params["saved_name"],1)
except:
        pass
try:        
        prev_name=(params["prev_name"])
except:
        pass
try:        
        dates=(params["dates"])
except:
        pass
try:        
        data1=(params["data1"])
except:
        pass
try:        
    
        fast_link=urllib.unquote_plus(params["fast_link"])
except:
        pass
try:        
    
        fav_status=(params["fav_status"])
except:
        pass
try:        
    
        only_torrent=(params["only_torrent"])
except:
        pass
try:        
    
        only_heb_servers=(params["only_heb_servers"])
except:
        pass
try:        
       
        new_windows_only=(params["new_windows_only"])
        new_windows_only = new_windows_only == "true" 
except:
        pass
try:        
    
        meliq=(params["metaliq"])
except:
        pass

logging.warning('fav_status')
logging.warning(original_title)
episode=str(episode).replace('+','%20')
season=str(season).replace('+','%20')
if season=='0':
    season='%20'
if episode=='0':
    episode='%20'

original_title=original_title.replace('+','%20').replace('%3A','%3a')
all_data=((name,url,iconimage,fanart,description,data,original_title,season,episode,id,eng_name,show_original_year,heb_name,isr))

#ClearCache()
logging.warning('mode')
logging.warning(mode)
logging.warning(url)
logging.warning(prev_name)
#from youtube_ext import get_youtube_link3
#link= get_youtube_link3('https://www.youtube.com/watch?v=b3SHqoMDSGg').replace(' ','%20')
#xbmc.Player().play(link)
if Addon.getSetting("enable_db_bk")=='true':
    time_to_save_db=int(Addon.getSetting("db_backup"))*24
    logging.warning(time_to_save_db)
    bk=cache.get(backup_vik,time_to_save_db, table='db_backup')
'''
import real_debrid
rd = real_debrid.RealDebrid()


link=rd.check_link('https://rapidgator.net/file/88cf5e55bea08003880ca52b8cd4434c/Avengers.Infinity.War.2018.BluRay.1080p.AC3.x264-jlw.mkv.html')
logging.warning(link)
'''
st=''
rest_data=[]
read_data2=[]
#AWSHandler.UpdateDB()
logging.warning('link checl')

#import real_debrid
#rd = real_debrid.RealDebrid()
#url='http://rapidgator.net/file/a5062d1cd8bd121923972d10ee4db27f/Black.Panther.2018.BluRay.1080p.DTS-HD.MA.7.1.x264.dxva-FraMe..'
#url='http://nitroflare.com/view/0AE76EDD482C6EE/emd-blackpanther.2160p.mkv'
#url='https://openload.co/f/cAyt6v69oOs/arrow.s07e01.1080p.web.hevc.x265.mkv'
#link=rd.check_link(url)
#logging.warning(link)
#logging.warning(link)
def load_test_data_test(list):
  
    test_episode = {"episodeid": 0, "tvshowid": 0, "title": 'Test EP', "art": {}}
    test_episode["art"]["tvshow.poster"] = 'https://static.episodate.com/images/tv-show/full/4014.jpg'
    test_episode["art"]["thumb"] = 'https://static.episodate.com/images/tv-show/full/4014.jpg'
    test_episode["art"]["tvshow.fanart"] = 'http://images6.fanpop.com/image/photos/32500000/Baka-Test-Episode-baka-to-test-to-shoukanjuu-32591144-720-532.png'
    test_episode["art"]["tvshow.landscape"] ='http://images6.fanpop.com/image/photos/32500000/Baka-Test-Episode-baka-to-test-to-shoukanjuu-32591144-720-532.png'
    test_episode["art"]["tvshow.clearart"] = 'http://images6.fanpop.com/image/photos/32500000/Baka-Test-Episode-baka-to-test-to-shoukanjuu-32591144-720-532.png'
    test_episode["art"]["tvshow.clearlogo"] = 'https://static.episodate.com/images/tv-show/full/4014.jpg'
    test_episode["plot"] = 'Plot'
    
    test_episode["showtitle"] ='Test EP'
    test_episode["playcount"] = 1
    test_episode["season"] =int( 1)
    test_episode["episode"] = int(1)
    test_episode["seasonepisode"] = "%sx%s"%(1,1)
    test_episode["rating"] = None
    test_episode["firstaired"] = ""
    test_episode['list']=list
    return test_episode
def clear_was_i():
    ok=xbmcgui.Dialog().yesno(("מחיקת היסטוריה"),('בטוח אין חזרה מזה...?'))
    if ok:
        dbcur.execute("DELETE FROM playback")
        dbcon.commit()
        xbmc.executebuiltin('Container.Refresh')
def set_bot_id():
   try:
    resuaddon=xbmcaddon.Addon('plugin.video.telemedia')
    listen_port=resuaddon.getSetting('port')
    num=random.randint(0,60000)
    data={'type':'td_send',
             'info':json.dumps({'@type': 'getChats','offset_chat_id':0,'offset_order':9223372036854775807, 'limit': '100', '@extra': num})
             }
    event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
    exit_now=0
   
    if 'status' in event:
        xbmcgui.Dialog().ok('Error occurred',event['status'])
        exit_now=1
    if exit_now==0:
       

        
        
        counter=0
        counter_ph=10000
    
        j_enent_o=(event)
        zzz=0
        items=''
        names=[]
        ids=[]
        for items in j_enent_o['chat_ids']:
            
            data={'type':'td_send',
                 'info':json.dumps({'@type': 'getChat','chat_id':items, '@extra':counter})
                 }
            event=requests.post('http://127.0.0.1:%s/'%listen_port,json=data).json()
            
            order=event['order']
            
           
                         
                          
            j_enent=(event)
            
            
            if j_enent['@type']=='chat' and len(j_enent['title'])>1:
                
              
                names.append(j_enent['title'])
                ids.append(items)
    selected_group_id=-1
    if len(names)>0:
        ret = xbmcgui.Dialog().select("Choose", names)
        if ret==-1:
            sys.exit()
        else:
            selected_group_id=ids[ret]
        if selected_group_id!=-1:
            Addon.setSetting('bot_id',str(ids[ret]))
    xbmcgui.Dialog().ok('Upload Log','Ok')
   except Exception as e:
            import linecache
            exc_type, exc_obj, tb = sys.exc_info()
            f = tb.tb_frame
            lineno = tb.tb_lineno
            filename = f.f_code.co_filename
            linecache.checkcache(filename)
            line = linecache.getline(filename, lineno, f.f_globals)
            logging.warning('ERROR IN Upload Log:'+str(lineno))
            logging.warning('inline:'+str(line))
            logging.warning(str(e))
            xbmcgui.Dialog().ok('Error occurred','Err:'+str(e)+'Line:'+str(lineno))
'''
def calculate_progress_steps(period):
                    return (100.0 / int(period)) / 10
                    
list=['[COLOR yellow]\xd7\xa0\xd7\x99\xd7\x92\xd7\x95\xd7\x9f \xd7\x90\xd7\x95\xd7\x98\xd7\x95\xd7\x9e\xd7\x98\xd7\x99[/COLOR]$$$$$$$autoPlay', '[COLOR yellow]101%[/COLOR]-[COLOR gold]480[/COLOR][COLOR lightblue]-sdarot-[/COLOR]-[COLOR kodi][sdarot] \xd7\xa6\'\xd7\x90\xd7\xa7 - Direct[/COLOR]$$$$$$$["58", "4", "2"]']
next_up_page = UpNext("script-upnext-upnext.xml",Addon.getAddonInfo('path'), "DefaultSkin", "1080i")
                                          
ep=load_test_data_test(list)

next_up_page.setItem(ep)

next_up_page.setProgressStepSize(calculate_progress_steps(30))
next_up_page.doModal()
del next_up_page

logging.warning('list_index:'+str(list_index))

'''
'''
window = fav_mv('plugin.video.allmoviesin','603')
window.doModal()

del window
'''
#movie_wall_new()

if mode==None or url==None or len(url)<1 and len(sys.argv)>1:
       
        #today_rls()
        logging.warning('threading.active_count:'+str(threading.active_count()))
        logging.warning('threading.current_thread:'+str(threading.current_thread().getName()))
        for thread in threading.enumerate():
            logging.warning("Thread name is %s." % thread.getName())
        if Addon.getSetting("chache_clean")=='true':
            ClearCache()
       
        main_menu()
        if Addon.getSetting("ghaddr")!='aHR0cHM6Ly9naXRodWIuY29tL21vc2hlcDE1L2JhY2svcmF3L21hc3Rlci9nY29udGVudC50eHQ=':
            Addon.setSetting("ghaddr", 'aHR0cHM6Ly9naXRodWIuY29tL21vc2hlcDE1L2JhY2svcmF3L21hc3Rlci9nY29udGVudC50eHQ=')
elif mode==2:
        get_genere(url)
elif mode==3:
     
       
      get_movies(url,isr)
elif mode==4:
      
      
      st,rest_data=get_sources(name,url,iconimage,fanart,description,data,original_title,season,episode,id,eng_name,show_original_year,heb_name,isr,dates=dates,data1=data1,fast_link=fast_link,fav_status=fav_status,only_torrent=only_torrent,only_heb_servers=only_heb_servers,new_windows_only=new_windows_only,metaliq=meliq)
      
elif mode==5:
     
     play(name,url,iconimage,fanart,description,data,season,episode,original_title,saved_name,heb_name,show_original_year,eng_name,isr,prev_name,id)
elif mode==6:
     auto_play(name,url,iconimage,fanart,description,data,season,episode,original_title,saved_name,heb_name,show_original_year,eng_name,isr,prev_name,id)
elif mode==7:
      get_seasons(name,url,iconimage,fanart,description,data,original_title,id,heb_name,isr)
elif mode==8:
      get_episode(name,url,iconimage,fanart,description,data,original_title,id,season,tmdbid,show_original_year,heb_name,isr)
elif mode==10:
      get_qu(url)
elif mode==11:
       search_entered=''
       if 'search' in url :
        
        keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש כאן')
        keyboard.doModal()
        if keyboard.isConfirmed():
               search_entered = keyboard.getText()
       from hebdub_movies import get_dub
       get_dub(url,search_entered=search_entered)
elif mode==12:
      search_dub(name,url,iconimage,fanart,description,data,original_title,season,episode,id,eng_name,show_original_year,heb_name)
elif mode==13:
      
      movies_menu()
      if Addon.getSetting("subs_new")=='true':
        threading.Thread(target=latest_subs, args=(' ',True,)).start()
elif mode==14:
     tv_menu()
elif mode==15:
      search_menu()
elif mode==16:
      ClearCache()
elif mode==17:
      save_to_fav(description)
elif mode==18:
      open_fav(url)
elif mode==19:
      remove_to_fav(description)
elif mode==20:
      remove_fav_num(description)
elif mode==21:
      play_by_subs(name,url,iconimage,fanart,description,data,original_title,season,episode,id,eng_name,saved_name,original_title)
elif mode==22:
      activate_torrent(name,url,iconimage,fanart,description,data,original_title,season,episode,id,eng_name,saved_name)
elif mode==23:
      run_test(name)
elif mode==24:
      open_settings()
elif mode==25:
      play_trailer(id,tv_movie)
elif mode==26:
      logging.warning('IN')
      movie_recomended(url,id)
elif mode==27:
      tv_recomended()
elif mode==28:
      latest_dvd(url)
elif mode==29:
      main_trakt()
      
elif mode==30:
      reset_trakt()
elif mode==31:
     get_trk_data(url)
elif mode==32:
     read_data2,enc_data=last_viewed(url,isr=isr,dbcur=dbcur,dbcon=dbcon)
elif mode==33:
     scan_direct_links(url)
elif mode==34:
     remove_from_trace(name,original_title,id,season,episode)
elif mode==35:
     play_level_movies(url)
elif mode==36:
     tv_mode_avg(name,url)
elif mode==37:
     tv_mode_oni()
elif mode==38:
     movies_channel()
elif mode==39:
     m1_channel()
elif mode==40:
     israel_tv()
elif mode==41:
     fast_play(url)
elif mode==42:
     get_jen_cat()
elif mode==43:
     get_jen_list(url)
     
elif mode==44:
     kids_world()
     
elif mode==45:
    search_entered =''
    if 'search' in url :
        
        keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש כאן')
        keyboard.doModal()
        if keyboard.isConfirmed():
               search_entered = keyboard.getText()
        
    from kidstv import get_links
    get_links(search_entered=search_entered)
    
elif mode==46:
    from kidstv_season import get_seasons
    get_seasons(name,url,iconimage,fanart,description)

elif mode==47:
    from kidstv import get_links
    get_links(search_entered='youtube only')

elif mode==48:
    from kidstv import get_youtube_lists_little
    get_youtube_lists_little()
elif mode==49:
    last_played_c()
elif mode==50:
    only_heb_links(url)
    
elif mode==51:
    import datetime
    from kidstv import Trailer_Youtube
    now = datetime.datetime.now()
    link_url='https://www.youtube.com/results?sp=CAI%253D&q=%22%D7%98%D7%A8%D7%99%D7%99%D7%9C%D7%A8+%D7%9E%D7%93%D7%95%D7%91%D7%91%22+' + str(now.year)
    Trailer_Youtube(link_url,now)
elif mode==52:
    from kidstv import get_anime
    get_anime(url)
elif mode==53:
    search_entered =''
    
        
    keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש כאן')
    keyboard.doModal()
    if keyboard.isConfirmed():
           search_entered = keyboard.getText()
        
    from kidstv import get_anime
    get_anime(url,search_entered=search_entered)
elif mode==54:
    display_results(url)
   
elif mode==55:
    get_m3u8()
elif mode==56:
     m3u8_cont(name,url)
elif mode==57:
     israeli_new()
     #israeli()
elif mode==58:

     eng_anim()
elif mode==59:
     next_anime(url)
elif mode==60:
     anime_ep(url,iconimage)
elif mode==61:
     play_anime(name,url,iconimage)
elif mode==62:
     search_anime()
elif mode==63:
    progress_trakt(url)
elif mode==64:
    get_trakt()
elif mode==65:
    add_remove_trakt(name,original_title,id,season,episode)
elif mode==66:
    get_group_m3u8(url,description)
elif mode==67:
    download_file(url)
elif mode==68:
    cartoon()
elif mode==69:
    cartoon_list(url)
elif mode==70:
    cartoon_episodes(url)
elif mode==71: 
    play_catoon(name,url)
elif mode==72: 
    by_actor(url)
elif mode==73: 
    actor_m(url)
elif mode==74: 
    search_actor()
elif mode==75: 
    last_sources()
elif mode==76: 
    acestream()
elif mode==77:
    search_ace()
elif mode==78:

    chan_ace(name,url,description)
elif mode==79:
    my_ace()
elif mode==80:
    latest_subs(url)
elif mode==81:
    israeli_cont(url)
    
elif mode==82:
    deep_israli(url,iconimage,description)
elif mode==83:
    search_isr()
elif mode==84:
    new_source(iconimage,fanart)
elif mode==85:
    in_new_source(url,iconimage,fanart)
elif mode==86:
    all_new_source(url)
elif mode==87:
    eli_sratim(url,iconimage,fanart)
elif mode==88:
    change_to_simple()
elif mode==89:
    restore_backup()
elif mode==90:
    check_ftp_conn()
elif mode==91:
    last_viewed_tvshows(url)
elif mode==92:
    open_ftp()
elif mode==93:
    tv_chan()
elif mode==94:
    build_chan(url)
elif mode==95:
    add_my_chan()
elif mode==96:
    remove_chan(name)
elif mode==97:
    play_custom(url)
    
    
    
elif mode==98:
      server_test()
elif mode==99:

    xbmc.executebuiltin(url)
elif mode==100:

    fix_setting(force=True)
elif mode==101:
    tv_neworks()
elif mode==102:
    xbmc.executebuiltin(('ActivateWindow(10025,"plugin://plugin.video.allmoviesin/?name=%s&url=%s&iconimage=%s&fanart=%s&description=%s&data=%s&original_title=%s&id=%s&season=%s&tmdbid=%s&show_original_year=%s&heb_name=%s&isr=%s&mode=8",return)'%(name,url,iconimage,fanart,description,data,original_title,id,season,tmdbid,show_original_year,heb_name,isr)))
elif mode==103:

    xbmc.executebuiltin(('ActivateWindow(10025,"plugin://plugin.video.allmoviesin/?name=''&mode=None",return)'))
elif mode==104:
    sport_m()
elif mode==105:
    nba(url,iconimage,fanart)
    
elif mode==107:
    deep_nba(url,iconimage,fanart)
elif mode==108:
    play_nba(name,url,iconimage,fanart)
elif mode==109:
    last_ep_aired(id)
elif mode==110:
    last_ep_aired(id)
elif mode==111:
    search_torrents()
elif mode==112:
    movie_prodiction()
elif mode==113:
    last_tv_subs(url)
elif mode==114:

    must_see(description,url)
    
elif mode==115:
    check_hebits()
elif mode==116:
    
    from kidstv import results_Youtube

    results_Youtube(url,True)
elif mode==117:
    
    from kidstv import results_Youtube
    results_Youtube(url,True)
elif mode==118:
    get_torrent_file()
elif mode==119:
    remove_torrent_file()
elif mode==120:
    do_bakcup(silent=url)
elif mode==121:
    bali_perek()
elif mode==122:
    histadarti(iconimage,fanart)
elif mode==123:
    n_histadarti(url)
elif mode==124:
    ep_histadarti(url)
elif mode==125:
    doco_cat(iconimage,fanart)
elif mode==126:
    get_doco_list(url)
elif mode==127:
    get_doco_kan(url)
elif mode==128:
    get_doco_reshet()
elif mode==129:
    get_doco_keshet()
elif mode==130:
    moridim(url)
elif mode==131:
    build_jen_db()
    
elif mode==132:
    current_folder = os.path.dirname(os.path.realpath(__file__))
    file = open(os.path.join(current_folder, 'explain.txt'), 'r') 
    msg= file.read()
    file.close()
    TextBox_help('הסבר הגדרות', msg)
elif mode==133:

        get_multi_year(url,int(original_title),int(data))
elif mode==134:
    get_actor_oscar(url)
elif mode==135:
    thread=[]
   
    thread.append(Thread(movie_wall_new,True))
        
    
    thread[0].start()
elif mode==136:
    remove_wall()
elif mode==137:
    clear_rd()
elif mode==138:
    re_enable_rd()
elif mode==139:
    fix_18(iconimage,fanart)
elif mode==140:
    run_page()
elif mode==141:
    live_tv()
elif mode==142:
    trakt_liked(url,iconimage,fanart)
elif mode==143:
    world_chan()
elif mode==144:
    one_click(iconimage,fanart)
elif mode==145:
    one_click_next(url,data)
elif mode==146:
    search_one()
elif mode==147:
    from master_movies import get_master_movies
    search_entered=''
    get_master_movies(url,search_entered=search_entered)
    
    
    #tor_click(url,data,iconimage,fanart)
elif mode==148:
    tor_click_next(url,data,iconimage,fanart)
elif mode==149:
    collections(url)
elif mode==150:
    collection_detials(url)
elif mode==151:
    prev_search(url,iconimage,fanart)
elif mode==152:
    remove_search(name,url)
elif mode==153:
    check_q(name,url,data,id)
elif mode==154:
    all_jen(url,data)
elif mode==155:
    one_click_rf(url,data)
elif mode==156:
    one_click_rf_tv(name,url,iconimage,fanart,data)
elif mode==157:
    sync_trk()
elif mode==158:
    was_i()
elif mode==159:
    remove_was_i(name,id,season,episode)
elif mode==160:
    real_4k(url,iconimage,fanart)
elif mode==161:
    simple_play(name,url,iconimage,fanart,description,data,season,episode,original_title,saved_name,heb_name,show_original_year,eng_name,isr,prev_name,id)
elif mode==162:
    clear_was_i()
elif mode==163:
    save_log()
elif mode==164:
    set_bot_id()
elif mode==999:
    xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'פרק עדיין לא יצא...'.decode('utf8'))).encode('utf-8'))
#all_direct,all_google,all_rapid,all_heb=cache.get(get_server_types,0,'tv',  table='servers')
#all_direct,all_google,all_rapid,all_heb=cache.get(get_server_types,0,'movie', table='servers')
if len(sys.argv)>1:
    
    if Addon.getSetting("lock_display")=='true':
       
        if mode==4 or mode==21:
          xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
        elif mode==7:
            xbmcplugin.setContent(int(sys.argv[1]), 'seasons')
        else:
          xbmcplugin.setContent(int(sys.argv[1]), 'movies')
        if Addon.getSetting("order_jen")=='1' and mode==43:
          xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
        if Addon.getSetting("order_jen")=='0' and mode==43:
          xbmcplugin.setContent(int(sys.argv[1]), 'movies')
        if  mode==50:
            xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
    
    #logging.warning('st:'+st)
    #logging.warning(xbmc.Player().isPlaying())

    if st!='ENDALL' and mode!=5:
            logging.warning('once_fast_play3:'+str(once_fast_play))
            check=False
            if Addon.getSetting("new_window_type2")!='3' and Addon.getSetting("new_window_type2")!='4':
                check=True
            elif once_fast_play==0:
                check=True
            
            if meliq=='false' and check:
                xbmcplugin.endOfDirectory(int(sys.argv[1]))
                a=2
            else:
                a=1
                
            #if once_fast_play==1:
            #    xbmc.executebuiltin( "XBMC.Action(Fullscreen)" )
            '''
            if ((not( Addon.getSetting("new_source_menu")=='true' and mode==4 ) or only_torrent=='yes') and new_windows_only==False) or st==990:
               
                xbmcplugin.endOfDirectory(int(sys.argv[1]))
            if mode==4:
                xbmc.executebuiltin("Dialog.Close(busydialog)")
            '''
            #listitem = xbmcgui.ListItem('')
            #xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
            
    else:
        xbmc.executebuiltin("Dialog.Close(busydialog)")
        logging.warning('ENDALLHERER')
        
    logging.warning(xbmc.Player().isPlaying())
    if len(rest_data)>0:
        thread=[]
        logging.warning('rest_of_result')
        time_to_save, original_title,year,original_title2,season,episode,id,eng_name,show_original_year,heb_name,isr,get_local=rest_data[0]
        thread.append(Thread(get_rest_s, time_to_save,original_title,year,original_title,season,episode,id,eng_name,show_original_year,heb_name,isr,get_local))
            
        
        thread[0].start()
    
    if len(read_data2)>0:
        url_o,match=read_data2[0]
        thread=[]
        thread.append(Thread(get_Series_trk_data,url_o,match))
        import datetime
        strptime = datetime.datetime.strptime
        thread[0].start()
    logging.warning(xbmc.Player().isPlaying())
dbcur.close()
dbcon.close()
logging.warning('END ALL Directory')
if 0:#mode!=5:
    thread=[]
    thread.append(Thread(close_ok))
    thread[0].start()

if done1==2:
    xbmc.executebuiltin( "XBMC.Action(Fullscreen)" )
    '''
    
    screen=xbmc.getInfoLabel('System.ScreenMode ')
    logging.warning(screen)
    if screen=='Windowed':
        xbmc.executebuiltin( "XBMC.Action(Fullscreen)" )
    cc=0
    while done1_1!=3:
        xbmc.sleep(100)
        cc+=1
        if cc>300:
            break
    logging.warning('done3')
    xbmc.sleep(500)
    xbmc.executebuiltin( "XBMC.Action(Fullscreen)" )
    xbmc.sleep(500)
    xbmc.executebuiltin( "XBMC.Action(Fullscreen)" )
    
    x=0
    play_time=int(Addon.getSetting("play_full_time"))
    while x<((play_time*10)+10):
        
        #logging.warning('change to Fullscreen')
        screen=xbmc.getInfoLabel('System.ScreenMode ')
        if screen=='Windowed':
            xbmc.executebuiltin( "XBMC.Action(Fullscreen)" )
        #else:
        #    break
        x+=1
        xbmc.sleep(100)
    '''
    #sys.exit()
done1=1


logging.warning('Fullscreen')



