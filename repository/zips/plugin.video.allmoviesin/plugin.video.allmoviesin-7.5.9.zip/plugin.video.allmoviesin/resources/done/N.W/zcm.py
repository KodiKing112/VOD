# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache,urlparse

global global_var,stop_all#global
global_var=[]
stop_all=0
global progress
progress=''
rating=['External','Openload']
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['movie','tv']

import urllib2,urllib,logging,base64,json

color=all_colors[77]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    all_links=[]
    base_link = 'http://zocine.com/'
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
    'Accept': '*/*',
    'Accept-Language': 'en-US,en;q=0.5',
    'Referer': 'http://zocine.com/',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'X-Requested-With': 'XMLHttpRequest',
    'Connection': 'keep-alive',
    }
 
    progress='Cloud'
    x,cook=cloudflare_request('http://zocine.com/home',headers=headers)
    
    


  
    if tv_movie=='movie':
      search_string=clean_name(original_title,1)
    else:
      search_string=clean_name(original_title,1)+' s'+season_n+'e'+episode_n
    data = [
      ('query', search_string),
    ]
    progress='requests'
    p = requests.post('http://zocine.com/engine/ajax/search.php',headers=cook[1], cookies=cook[0], data=data).content
 
   
   
    progress='Regex'
    media_url_f = re.compile('<a href="(.+?)"><span class="searchheading">(.+?)<').findall(p)
    
    for media_url,media_title in media_url_f:
        if stop_all==1:
            break
        if base_link not in media_url:
           media_url = base_link + media_url

        if original_title.lower() in clean_name(media_title,1).lower() :
            if tv_movie=='movie':
              check=False
              if show_original_year in media_title:                                                           
                check=True
            else:
           
              
                check=True
 
            if check: 
               
                progress='requests2'
                x=requests.get(media_url,headers=cook[1], cookies=cook[0]).content
                regex='<div class="tab-pane fade"(.+?)</div>'
                match_pre=re.compile(regex,re.DOTALL).findall(x)
                count=0
                for items in match_pre:
                    progress=' Links - '+str(count)
                    count+=1
                    regex='<a href="(.+?)"(.+?)</a'
                    match=re.compile(regex,re.DOTALL).findall(items)
                    
                  
                    
                    for links,dis in match:
                      if stop_all==1:
                        break
                      
                      parsed = urlparse.urlparse(links)
                      links=urlparse.parse_qs(parsed.query)
                      
                      if 'url' in (links):
                          links=links['url'][0].decode('base64')
                          if 'goo.gl' in links:
                             links=requests.get(links,headers=headers).url
                          if 'youtube' not in links and 'hqq' not in links and 'videospider' not in links and 'facebook' not in links and 'watch' in dis.lower(): 
                            progress=' Check - '+str(count)
                            name1,match_s,res,check=server_data(links,original_title)
                            
                                  
                            if check :
                                all_links.append((name1,links,match_s,res))
                                global_var=all_links
                regex='<iframe src="(.+?)"'
                match=re.compile(regex,re.DOTALL).findall(x)
                count=0
                for links in match:
                          progress=' Links2 - '+str(count)
                          count+=1
                          if stop_all==1:
                            break
                          if 'goo.gl' in links:
                             links=requests.get(links,headers=headers).url
                             
                      
                          
                          if 'videospider' in links:
                                headers = {
                                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
                                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                                    'Accept-Language': 'en-US,en;q=0.5',
                                    'Referer': media_url,
                                    'Connection': 'keep-alive',
                                    'Upgrade-Insecure-Requests': '1',
                                    'TE': 'Trailers',
                                }
                                parsed = urlparse.urlparse(links)
                                params = (
                                    ('key', urlparse.parse_qs(parsed.query)['key']),
                                    ('video_id', urlparse.parse_qs(parsed.query)['video_id']),
                                )
            
                                response = requests.get('https://videospider.in/getvideo', headers=headers, params=params)
                                
                                regex='<iframe src="(.+?)"'
                                match=re.compile(regex).findall(response.content)
                                if len(match)==0:
                                     f_url=response.url
                                else:
                                     f_url=match[0]
                                progress=' Check '+str(count)
                                name1,match_s,res,check=server_data(f_url,original_title)
                         
                               
                                if check :
                                
                                    all_links.append((name1,f_url,match_s,res))
                                    global_var=all_links
                          if 'youtube' not in links and 'hqq' not in links and 'videospider' not in links and 'facebook' not in links and 'hqq' not in match: 
                            progress=' Check2 '
                            name1,match_s,res,check=server_data(links,original_title)
                                
                                  
                            if check :
                                all_links.append((name1,links,match_s,res))
                                global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var