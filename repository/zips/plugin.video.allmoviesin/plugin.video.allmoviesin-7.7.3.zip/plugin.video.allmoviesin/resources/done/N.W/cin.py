# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time

global global_var,stop_all#global
global_var=[]
global progress
progress=''
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,all_colors,domain_s
type=['tv']

import urllib2,urllib,logging,base64,json

color=all_colors[11]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
        global global_var,stop_all,progress
        progress=' Start '
        start_time=time.time()
        try:
          import resolveurl
        except:
          import resolveurl_temp as resolveurl
        title=urllib.unquote_plus(original_title)
        all_links=[]
        headers = {
            #'Host': 'www1.swatchseries.to',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Referer': domain_s+'www1.swatchseries.to/',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
        }
        progress=' Requests '
        if tv_movie=='tv':
            
            html = requests.get(domain_s+'www1.swatchseries.to/search/%s'%urllib.quote_plus(title), headers=headers).content
  
            regex='<a href="(.+?)" title="(.+?)" target="_blank"><strong>'
            progress='Regex'
            match=re.compile(regex).findall(html)

            count=0
            for link,name in match:
              progress=' Links - '+str(count)
              count+=1
              if stop_all==1:
                break
              precent=similar(list(name.lower()),list(title.lower()))
              
              if int(precent)>90:
         
                yy=requests.get(link, headers=headers).content
                regex_p='span itemprop="name">Season %s</span>(.+?)</ul>'%season
                match_p=re.compile(regex_p,re.DOTALL).findall(yy)
        
                
                for item in match_p:
                  progress=' Links2 - '+str(count)
                  if stop_all==1:
                    break
                  regex='itemprop="episode".+?"episodenumber" content="%s".+?content="(.+?)"'%episode
                  match2=re.compile(regex,re.DOTALL).findall(item)
                  
                  zz=requests.get(match2[0], headers=headers).content
                       
                  regex_3=domain_s+'www1.swatchseries.to/.+?.html\?r=(.+?)"'
             
                  match3=re.compile(regex_3).findall(zz)
               
                  for all_l in match3:
                    progress=' Links3 - '+str(count)
                    if stop_all==1:
                        break
                    f_link=all_l.decode('base64')
                    
                    if not resolveurl.HostedMediaFile(f_link).valid_url(): 
                        continue
                    name1,match_s,res,check=server_data(f_link,original_title)
                    if check:
                      all_links.append((name1.replace("%20"," "),f_link,match_s,res))
                      
                   
                      global_var=all_links
        elapsed_time = time.time() - start_time
        progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
        return all_links
        