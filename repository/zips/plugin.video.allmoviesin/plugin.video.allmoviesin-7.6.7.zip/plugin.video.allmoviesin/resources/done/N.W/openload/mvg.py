# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,client,all_colors
type=['movie']

import urllib2,urllib,logging,base64,json
color=all_colors[46]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
        global global_var,stop_all,progress
        progress='Start'
        start_time=time.time()
        all_links=[]
        url='http://www.1moviesgold.com/?s='+clean_name(original_title,1).replace(' ','+')+'+'+show_original_year
        progress='Cloud'
        html,cook=cloudflare_request(url)
        regex_pre='<div class="title">(.+?)</div>'
        progress='Regex'
        match_pre=re.compile(regex_pre,re.DOTALL).findall(html)
        count=0
        for items in match_pre:
            
            progress='Links-'+str(count)
            count+=1
            
            if stop_all==1:
                    break
            regex='href="(.+?)">(.+?)<'
            progress='Regex-'+str(count)
            match=re.compile(regex).findall(items)
            for link,name_in in match:
              
              if stop_all==1:
                    break
              if 'Dubbed' not in name_in:
                link=link.replace('https:','http:')
                x,cook=cloudflare_request(link)
                
                regex_in='</table>.+?<a href="(.+?)" target="_blank" rel="nofollow noopener">'
                match_in=re.compile(regex_in,re.DOTALL).findall(x)
                
                y,cook=cloudflare_request(match_in[0])
                regex_in='<iframe src="(.+?)"'
                match_in=re.compile(regex_in,re.IGNORECASE).findall(y)
                print match_in
                
                for f_links in match_in:
                 
                 try:
                  if stop_all==1:
                    break
                  if 'hqq.' not in f_links:
                    if "watchvideo17.us" in f_links:
                        print f_links
                        zz,cook=cloudflare_request(f_links)
                        regex='file:"(.+?)"'
                        match_inn=re.compile(regex).findall(zz)
                        for links_in in match_inn:
                            if stop_all==1:
                                break
                            all_links.append((original_title.replace("%20"," "),links_in,'Direct',' '))
                            global_var=all_links
                    else:
                       progress='Check-'+str(count)
                       name1,match_s,res,check=server_data(f_links,original_title)
                       if check:
                          all_links.append((name1.replace("%20"," "),f_links,match_s,res))
                          global_var=all_links
                 except:
                    pass
                regex='<a href="(.+?)">Download</'
                progress='Regex2-'+str(count)
                match_in=re.compile(regex,re.IGNORECASE).findall(y)
                if len (match_in)>0:
                        progress='Check2-'+str(count)
                        print match_in[0]
                        name1,match_s,res,check=server_data(match_in[0],original_title)
                        if check:
                          all_links.append((name1.replace("%20"," "),match_in[0],match_s,res))
                          global_var=all_links
        elapsed_time = time.time() - start_time
        progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
        return global_var 
            
        
        