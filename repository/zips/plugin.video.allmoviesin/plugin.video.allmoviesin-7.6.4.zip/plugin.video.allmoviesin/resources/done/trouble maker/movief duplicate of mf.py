import requests,re
import unjuice

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,all_colors,domain_s

type=['movie']
import urllib2,urllib,logging,base64,json
color=all_colors[43]
def get_links(tv_movie,original_title,name,season_n,episode_n,season_o,episode_o,show_original_year,id):
    global global_var,stop_all
    all_links=[]
    sUrl=domain_s+'moviefull-hd.org/search/'+(clean_name(original_title,1).replace(' ','+')+'+'+show_original_year)
    headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'utf8',
          

            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'}


    r= requests.get(sUrl,headers=headers).content 
    page = re.findall('id="main-col">(.+?)</section></div>', r, re.DOTALL)[0]
    Regex = re.compile('''-title.+?href=['"]([^'"]+)['"]>([^<]+)</a></div>''', re.DOTALL).findall(page)

    for item_url, name in Regex:
        if stop_all==1:
                break

        if  clean_name(original_title,1).lower() in name.lower() and show_original_year in name:
               
    
            headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36',
                           'Referer': item_url}
            r= requests.get(item_url, headers=headers).content
            regex='title" content="(.+?)"'
            name1=re.compile(regex).findall(r)[0]
            link = re.compile('''<iframe.+?src=['"]([^'"]+)['"]''', re.DOTALL).findall(r)[0]
            count = 0

            html = requests.get(link, headers=headers).content
            juice = unjuice.run(str(html))
            
            links = re.findall('sources:(\[\{.+?\}\])', juice, re.DOTALL)[0]
            links = json.loads(links)
            
            for i in links:
                if stop_all==1:
                   break
                url = i['file']
                qual = i['label']
                count += 1
                all_links.append((name1,url + '|Referer='+link,'Direct',qual))
                global_var=all_links
   
    return global_var