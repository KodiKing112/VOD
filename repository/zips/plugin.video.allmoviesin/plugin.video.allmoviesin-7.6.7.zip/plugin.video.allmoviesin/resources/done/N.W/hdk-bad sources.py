# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time,cache

global global_var,stop_all#global
global_var=[]
stop_all=0

rating=['External','Openload']

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,client
type=['movie']

import urllib2,urllib,logging,base64,json
try:
  import resolveurl
except:
  import resolveurl_temp as resolveurl
color=all_colors[99]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    if tv_movie=='movie':
      
      imdbid_data=domain_s+'api.themoviedb.org/3/movie/%s?api_key=34142515d9d23817496eeb4ff1d223d0'%id
      
      x=requests.get(imdbid_data).json()
      imdbid=x['imdb_id']
      
    else:
       imdbid_data=domain_s+'api.themoviedb.org/3/tv/%s?api_key=34142515d9d23817496eeb4ff1d223d0&append_to_response=external_ids'%id
      
       x=requests.get(imdbid_data).json()
       imdbid=x['external_ids']['imdb_id']
      

    all_links=[]
    base_link = 'https://hackimdb.com'
    search_link = '/title/&%s'
    url = base_link + search_link % imdbid
    sources = []
    r,cook = cloudflare_request(url)
   
    match = re.compile('<iframe.+?src=".+?rapidvideo(.+?)"').findall(r)
    print url
    for url in match: 
        
        if stop_all==1:
           break
        url = 'https://www.rapidvideo' + url
        
        
        
        
        name1,match_s,res,check=server_data(url,original_title)
                    
                      
        if check :
            all_links.append((name1,url,match_s,res))
            global_var=all_links
    return global_var