# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache,urlparse
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
rating=['External','Openload']

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,client
type=['tv','movie']

import urllib2,urllib,logging,base64,json

color=all_colors[103]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    all_links=[]
    base_link = 'https://ww1.putlockerfree.sc'
    if tv_movie=='tv':
        http = base_link + '/tv_series/%s-season-%s/' % (clean_name(original_title,1).replace(' ','-'),season)
        url = http + 'watching.html/'
        url = 'url="' + url + '"&episode="' + episode + '"'
        match = re.compile('url="(.+?)"&episode="(.+?)"').findall(url)
       
        for url, episode in match:
            
            
            episode = episode
            progress='request'
            
            r,token = cloudflare_request(url.replace('https','http'))
            r=requests.get(url.replace('https','http'),headers=token[1],cookies=token[0]).url
       
            r,token = cloudflare_request(r.replace('https','http')+'watching.html/')
            
            '''
            regex='id="mv-info.+? href="(.+?)"'
            progress='Regex'
            m2=re.compile(regex,re.DOTALL).findall(r)[0]
            r = client.request(m2)
            '''
         
            match2 = re.compile('<a title="Episode ' + episode + ':.+?" data-.+?="(.+?)"').findall(r)
            
            for url in match2:
                
               
                if stop_all==1:
                    break
                if '2160' in url: quality = '4K'
                elif '1080' in url: quality = '1080p'
                elif '720' in url: quality = 'HD'
                elif '480' in url: quality = 'SD'
                else: quality = 'SD'
                
                if 'streamvid' in url:
                    url_o=url
                    x=client.request(url)
                    
                    regex='<div id="video_player">(.+?)</script>'
                    m=re.compile(regex,re.DOTALL).findall(x)
                    if len(m)>0:
                        juice = unjuice.run(str(m[0]))
                      
                        links = re.findall('sources:(\[\{.+?\}\])', juice, re.DOTALL)[0]
                        links = json.loads(links)
                        for i in links:
                            if stop_all==1:
                                break
                            url = i['file']
                            qual = i['label']
                            
                            all_links.append((original_title,url+ '|Referer='+url_o,'direct',qual.replace('HD','720')))
                            global_var=all_links
                else:
                    progress='Check'
                    name1,match_s,res,check=server_data(url,original_title)
                    
                    if res==' ':
                        res=quality
                    if check :
                    
                        all_links.append((name1,url,match_s,res))
                        global_var=all_links
    else:
        http='http://www1.putlockerfree.sc/films/%s-%s/'%(clean_name(original_title,1).replace(' ','-'),show_original_year)
        url = http + 'watching.html/'
        progress='request2'
        r,token = cloudflare_request(url)
        progress='Regex2'
        match = re.compile('episode-id=".+?" data-.+?="(.+?)"').findall(r)
       
        for url in match: 
            if stop_all==1:
                    break
            if '2160' in url: quality = '4K'
            elif '1080' in url: quality = '1080p'
            elif '720' in url: quality = 'HD'
            elif '480' in url: quality = 'SD'
            else: quality = 'SD'
            if 'streamvid' in url:
                url_o=url
                x=client.request(url)
                regex='<div id="video_player">(.+?)</script>'
                m=re.compile(regex,re.DOTALL).findall(x)
                juice = unjuice.run(str(m[0]))
              
                links = re.findall('sources:(\[\{.+?\}\])', juice, re.DOTALL)[0]
                links = json.loads(links)
                for i in links:
                    if stop_all==1:
                        break
                    url = i['file']
                    qual = i['label']
                    
                    all_links.append((original_title,url+ '|Referer='+url_o,'direct',qual.replace('HD','720')))
                    global_var=all_links
            else:
                progress='Check2'
                name1,match_s,res,check=server_data(url,original_title)
                            
                if res==' ':
                    res=quality
                if check :
                    all_links.append((name1,url,match_s,res))
                    global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var