
import requests,time,PTN
import unjuice

global global_var,stop_all#global
global_var=[]
global progress
progress=''
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,cloudflare_request,all_colors,base_header

type=['tv','movie']
import urllib2,urllib,logging,base64,json
color=all_colors[13]


def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress=' Start '
    start_time=time.time()
    all_links=[]
    all_lk=[]
    if tv_movie=='tv':
        search_str=clean_name(original_title,1).lower()+'%20'+season
    else:
        search_str=clean_name(original_title,1).lower()+'%20'+show_original_year
        
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
        'Accept': 'text/html, */*; q=0.01',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'TE': 'Trailers',
    }

    response = requests.get('https://putlocker.style/get-search/'+search_str, headers=headers).content
    regex='href="(.+?)"'
    m=re.compile(regex).findall(response)
    
    x=requests.get('https://putlocker.style'+m[0], headers=base_header).content
    
    if tv_movie=='tv':
        regex='<a data-ep-id="(.+?)".+?href="(.+?)" title="Episode %s:'%episode_n
        m=re.compile(regex).findall(x)
    
        
    
   
    #y=requests.get('https://putlocker.style'+m[0], headers=headers).content
    regex="data.PlayerReports.m_id = '(.+?)'"
    id=re.compile(regex).findall(x)[0]
    
    if tv_movie=='tv':
        ep=m[0][0]
        lk=m[0][1]
    else:
        lk=m[0]+'-watch-online.html'
        ep='0'

    yy=requests.get('https://putlocker.style/user/servers/%s?ep=%s'%(id,ep),headers=base_header).content
    regex='data-value="(.+?)"'
    mm=re.compile(regex).findall(yy)
    for ser in mm:
        if stop_all==1:
                break
        time.sleep(0.1)
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
            'X-Requested-With': 'XMLHttpRequest',
            'Connection': 'keep-alive',
            'Referer': 'https://putlocker.style'+lk,
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
        }
        milli_sec = int(round(time.time() * 1000))
        params = (
            ('server', ser),
            ('_', milli_sec),
        )
        
        
        
        response = requests.get('https://putlocker.style'+lk, headers=headers, params=params).json()
        
        for items in response:
            if stop_all==1:
                break
            if 'res' in items:
                res=items['res']
            elif 'max' in items:
                res=items['max']
            else:
                res=' '
            if 'src' in items:
                lk_fin=items['src']
                if lk_fin not in all_lk:
                    all_lk.append(lk_fin)
                    all_links.append((clean_name(original_title,1),lk_fin,'Direct',str(res)))
                    global_var=all_links
            elif 'file' in items:
                lk_fin=items['file']
                if lk_fin not in all_lk:
                    all_lk.append(lk_fin)
                    all_links.append((clean_name(original_title,1),lk_fin,'Direct',str(res)))
                    global_var=all_links
            elif 'link' in response:
                lk_fin=response['link']
                if lk_fin not in all_lk:
                    all_lk.append(lk_fin)
                    name1,match_s,res,check=server_data(lk_fin,original_title)
                        
                    if check:
                          all_links.append((name1.replace("%20"," "),lk_fin,match_s,res))
                    
                          global_var=all_links
            
  
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return all_links
    