# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time,urlparse

global global_var,stop_all#global
global_var=[]
stop_all=0
rating=['SSS','7M/s']

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['movie']

import urllib2,urllib,logging,base64,json
color=all_colors[103]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
        global global_var,stop_all

        all_links=[]
        headers={'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 7.0; S16 Build/NRD90M)',
        'Host': 'e-movies.online',
        'Connection': 'Keep-Alive',
        'Accept-Encoding': 'utf-8'}
        x=requests.get('http://e-movies.online/hijriyah/muharram.php?aina=%s&javemu=false&syawwal=com.emoviedev.emovieplay'%clean_name(original_title,1).replace(' ','+'),headers=headers).content
        
        print x
        for result in  x['kalbe']:
            
            if clean_name(original_title,1).lower() in result['unmee'].lower() and show_original_year in result['unmee']:
              
                y=requests.get('http://e-movies.online/hijriyah/muharram.php?ismun=%s&javemu=false&syawwal=com.emoviedev.emovieplay'%result['unid'],headers=headers).json()
                r= y['kalbe'][0]['trailurl']
                nam1,srv,res,check=server_data(r,original_title)
                          
                if check:
                    all_links.append((nam1.replace("%20"," "),r,srv,res))
                    global_var=all_links
                   
        return global_var