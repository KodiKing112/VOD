# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
rating=['External','Openload']

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,client,base_header
type=['movie']

import urllib2,urllib,logging,base64,json

color=all_colors[109]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    all_links=[]
    base_link = 'http://qqmovies.co'
    search = '/search?q='
    search_id = clean_name(original_title,1)
    
    start_url = '%s%s%s' %(base_link,search,search_id.replace(' ','+'))



    

    headers = base_header
    progress='requests'
    print start_url
    OPEN = requests.get(start_url,headers=headers).content
    
    progress='Regex'
    Regex = re.compile('div class="movie-title">.+?a href="(.+?)">(.+?)<',re.DOTALL).findall(OPEN)
    count=0
    for item_url,name in Regex:
        
        if stop_all==1:
            break
        progress='requests-'+str(count)
        count+=1
        OPEN2 = requests.get(item_url,headers=headers).content
        progress='Regex-'+str(count)
        Regex2 = re.compile('Release: </strong>(.+?)-',re.DOTALL).findall(OPEN2)
        
        for release in Regex2:
            if stop_all==1:
                break
            release=release.replace(' ','').replace('\r','').replace('\n','')

            



            if not show_original_year == release:

                continue

            if search_id.lower() in name.lower():
                progress='requests2-'+str(count)
                OPEN = requests.get(item_url,headers=headers,timeout=10).content
                progress='Regex2-'+str(count)
                quality_r = re.compile('Quality.+?class="label label-primary">(.+?)<',re.DOTALL).findall(OPEN)

                for quality in quality_r:

                    if "1080" in quality:
                      o_res="1080"
                    elif "720" in quality:
                      o_res="720"
                    elif "480" in quality:
                       o_res="480"
                    else:
                       o_res=' '

                

               

              
                progress='Regex3-'+str(count)
                Regex = re.compile('<div class="movie-payer">.+?src="(.+?)"',re.DOTALL).findall(OPEN)

                for link in Regex:
                    if stop_all==1:
                        break
                    if 'http' not in link:

                        link = 'http:'+link
                    link=requests.get(link).url
                    progress='Check-'+str(count)
                    name2,match_s,res,check=server_data(link,original_title)
                    if res==' ':
                      res=o_res
                   
                    if check:

                        all_links.append((name2,link,match_s,res))
                        
                        global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return all_links

    