# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['movie']

import urllib2,urllib,logging,base64,json
color=all_colors[33]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    import urlparse
    progress='Start'
    start_time=time.time()
    all_links=[]

    url=domain_s+'www.icefilms-info.com/search?q='+(clean_name(original_title,1).replace(' ','+')+'+'+show_original_year)
  
    headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'utf8',
          

            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'}
    html=requests.get(url,headers=headers).content
    regex_pre='<li class="list-item">(.+?)</li'
    progress='Regex'
    match_pre=re.compile(regex_pre,re.DOTALL).findall(html)
    count=0
    
    for items in match_pre:
      
       progress='Links-'+str(count)
       count+=1
       if stop_all==1:
            break
       regex='<a href="(.+?)".+?class="title">(.+?)<'
       match=re.compile(regex,re.DOTALL).findall(items)
       
       for link,name_in in match:
          progress='Links2-'+str(count)
          if stop_all==1:
                break
          if clean_name(original_title,1).lower() in name_in.lower() and show_original_year in name_in:
             
             y=requests.get(link,headers=headers).content
             regex_p='<ul class="streams">(.+?)</ul'
             m_pre=re.compile(regex_p,re.DOTALL).findall(y)
             
             regex_in='<a href="(.+?)" target="_blank"'
             match_in=re.compile(regex_in).findall(m_pre[0])
             
             for links_in in match_in:
               progress='Links3-'+str(count)
               if stop_all==1:
                    break
               if 1:#try:
                
                    if 'linkth.is' in links_in:
                        r=requests.get(links_in,headers=headers).content
                        regex='redirect = "(.+?)"'
                        match=re.compile(regex).findall(r)
                        nam1,srv,res,check=server_data(match[0],original_title)
                       
                        if check:
                            all_links.append((nam1.replace("%20"," "),match[0],srv,res))
                            global_var=all_links
                    elif 'whateverdomain' in links_in:
                        headers = {
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
                            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                            'Accept-Language': 'en-US,en;q=0.5',
                            'Connection': 'keep-alive',
                            'Upgrade-Insecure-Requests': '1',
                        }
                        parsed = urlparse.urlparse(links_in)
                        params = (
                            ('id',urlparse.parse_qs(parsed.query)['id']),
                        )

                        response = requests.get('http://www.whateverdomain.net/openload/player.php', headers=headers, params=params).content
                        regex='iframe src="(.+?)"'
                        match=re.compile(regex).findall(response.replace('&quot;','"'))
                        progress='Check-'+str(count)
                        name1,match_s,res,check=server_data(match[0],original_title)
                        if check :
                            all_links.append((name1,match[0],match_s,res))
                            global_var=all_links
                    elif 'videospider' in links_in:
                        headers = {
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
                            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                            'Accept-Language': 'en-US,en;q=0.5',
                            'Referer': link,
                            'Connection': 'keep-alive',
                            'Upgrade-Insecure-Requests': '1',
                            'TE': 'Trailers',
                        }
                        parsed = urlparse.urlparse(links_in)
                        params = (
                            ('key', urlparse.parse_qs(parsed.query)['key']),
                            ('video_id', urlparse.parse_qs(parsed.query)['video_id']),
                        )
                        progress='requests-'+str(count)
                        response = requests.get('https://videospider.in/getvideo', headers=headers, params=params)
                        
                        regex='<iframe src="(.+?)"'
                        match=re.compile(regex).findall(response.content)
                        if len(match)==0:
                             f_url=response.url
                        else:
                             f_url=match[0]
                        progress='Check2-'+str(count)
                        name1,match_s,res,check=server_data(f_url,original_title)
                        if check :
                            all_links.append((name1,f_url,match_s,res))
                            global_var=all_links
                    elif 'api.odb' in links_in:
                        response=requests.get(links_in).content
                        regex='<iframe src="(.+?)"'
                        match=re.compile(regex).findall(response)
                        progress='Check3-'+str(count)
                        name1,match_s,res,check=server_data(match[0],original_title)
                        if check :
                            all_links.append((name1,match[0],match_s,res))
                            global_var=all_links
                        
                    else:
                        r=requests.get(links_in,timeout=5).url
                        progress='Check4-'+str(count)
                        
                        nam1,srv,res,check=server_data(r,original_title)
                        
                        if check:
                            all_links.append((nam1.replace("%20"," "),r,srv,res))
                            global_var=all_links
               #except Exception as e:
                 
               #  pass
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return all_links
    