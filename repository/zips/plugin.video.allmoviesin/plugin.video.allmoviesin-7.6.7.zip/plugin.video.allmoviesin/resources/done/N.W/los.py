# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
rating=['External','Openload']

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,client,base_header
type=['movie']

import urllib2,urllib,logging,base64,json

color=all_colors[1]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    all_links=[]
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0',
    'Accept': '*/*',
    'Accept-Language': 'en-US,en;q=0.5',
    
    
    'Connection': 'keep-alive',
    'TE': 'Trailers',
    }
    '''
    
    progress='requests'
    html=requests.get('http://www.losmovies.us/',headers=headers).content
    regex='ype":"SearchAction","target":"(.+?)"'
    progress='Regex'
    base_u=re.compile(regex).findall(html)[0].replace('{search_term}','')
    '''
    url='https://www.losmovies.us/?keywords=%s&type=%s'%(clean_name(original_title,1).lower().replace(' ','+'),tv_movie)

    progress='requests2'

    x=requests.get(url,headers=headers).content

    regex='<div class="showRow showRowImage showRowImage"><a href="(.+?)".+?<h4 class="showRow showRowName showRowText">(.+?)<'
    progress='Regex2'
    m=re.compile(regex,re.DOTALL).findall(x)
    count=0
    print m
    for link,title in m:
        progress='Links-'+str(count)
        count+=1
        if title.lower()!=clean_name(original_title,1).lower():
            continue
       
        y=requests.get(link,headers=headers).content
        if tv_movie=='tv':
            r='Season %s Serie %s<(.+?)</table>'%(season,episode)
 
            y=re.compile(r,re.DOTALL).findall(y)
            if len (y)==0:
                continue
            y=y[0]
            
            
        regex='https://www.losmovies.us/external/(.+?)"'
        progress='Regex-'+str(count)
        m=re.compile(regex,re.DOTALL).findall(y)
  
        for links in m:
            links=links.decode('base64')
            progress='Links2-'+str(count)
            if 'entervideo' in links:
                y=requests.get(links,headers=headers).content
                regex='source src="(.+?)"'
                f_link=re.compile(regex).findall(y)
               
                if len(f_link)>0:
                    names=f_link[0].split('/')

                    name1=names[len(names)-1]
                    if "1080" in name1:
                        res="1080"
                    elif "720" in name1:
                        res="720"
                    elif "480" in name1:
                        res="720"
                    elif "hd" in name1.lower():
                        res="HD"
                    else:
                       res=' '
                    headers2 = {
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'en-US,en;q=0.5',
                    'Cache-Control': 'no-cache',
                    'Connection': 'keep-alive',
                    'Host': 'entervideo.net',
                    'Pragma': 'no-cache',
                    'Referer':links,
                    'Upgrade-Insecure-Requests': '1',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
                    }
                    head=urllib.urlencode(headers2)
                    try_head = requests.get(f_link[0],headers=headers2, stream=True,verify=False,timeout=10)
                    f_size2='0.0 GB'
       
                    if 'Content-Length' in try_head.headers:
                       if int(try_head.headers['Content-Length'])>(1024*1024):
                        f_size2=str(round(float(try_head.headers['Content-Length'])/(1024*1024*1024), 2))+' GB'
                    if f_size2!='0.0 GB':
                        s_name='Direct'+' - '+f_size2
                    else:
                        s_name='Direct'
                    all_links.append((name1,f_link[0]+"|"+head,s_name,res))
                    global_var=all_links
            elif 'gomostream.com' in links:
                f_link=requests.get(links,headers=headers).url
                progress='Check-'+str(count)
                name2,match_s,res,check=server_data(f_link,original_title)
           
                if check:

                    all_links.append((name2,f_link,match_s,res))
                    
                    global_var=all_links
            else:
                progress='Check2-'+str(count)
                name2,match_s,res,check=server_data(links,original_title)
           
                if check:

                    all_links.append((name2,links,match_s,res))
                    
                    global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var
    