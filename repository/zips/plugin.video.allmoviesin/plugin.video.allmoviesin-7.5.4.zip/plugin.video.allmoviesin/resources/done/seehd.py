# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['tv','movie']

import urllib2,urllib,logging,base64,json

color=all_colors[60]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
  global global_var,stop_all,progress

  progress='Start'
  start_time=time.time()
  all_links=[]
  url=domain_s+'www.seehd.pl/?s=%s'%(original_title.lower().replace('%20','+').replace('%3a','').replace(' ','+'))

  progress='Cloud'
  x,cook=cloudflare_request('http://www.seehd.pl/?s=the+maze+runner+se')
  head=cook[1]

  if tv_movie=='tv':
    
    progress='requests'
    x=requests.get(url.strip(),cookies=cook[0],headers=head).content
  
   
    
  else:
    url=domain_s+'www.seehd.pl/?s=%s'%(original_title.lower().replace('%20','+').replace('%3a','').replace(' ','+'))
    
    progress='requests'
    x=requests.get(url.strip(),cookies=cook[0],headers=head).content
  if 'jschl-answer' in x:
    progress='Cloud2'
    x,cook=cloudflare_request('http://www.seehd.pl/?s=the+maze+runner+se',safe=True)
    if tv_movie=='tv':
    
        progress='requests2'
        x=requests.get(url.strip(),cookies=cook[0],headers=head).content
  
   
    
    else:
        url=domain_s+'www.seehd.pl/?s=%s'%(original_title.lower().replace('%20','+').replace('%3a','').replace(' ','+'))
        progress='requests2'
        x=requests.get(url.strip(),cookies=cook[0],headers=head).content
  regex='<a href="(.+?)"><h2 class="thumb_title">(.+?)</h2>'
  
  progress='Regex'
  match=re.compile(regex).findall(x)
  count=0
 
  for link,name in match:
    progress='Links-'+str(count)
    count+=1
    if stop_all==1:
      break
    if tv_movie=='tv':
      s_title='Season %s Episode %sEEE'% (season,episode)
      s_title2='S%sE%s'% (season_n,episode_n)
    else:
      s_title=name+'EEE'
      s_title2=name+'EEE'
   
    if original_title.lower().replace('%20',' ').replace('%3a','').replace('the','').strip() in name.lower() and ((s_title.lower() in name.lower()+'eee') or (s_title2.lower() in name.lower())):
      progress='requests-'+str(count)
  
      x=requests.get(link,cookies=cook[0],headers=head).content
      regex='<iframe.+?src=(?:"|\')(.+?)(?:"|\')'
      match=re.compile(regex).findall(x)
    
      for link in match:
        if stop_all==1:
          break
        if '24hd.club' in link:
            continue
        progress='Check-'+str(count)
        
        
        if '24hd.be' in link:
            ids=link.split('/')
            id=ids[len(ids)-1]
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0',
                'Accept': '*/*',
                'Accept-Language': 'en-US,en;q=0.5',
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'X-Requested-With': 'XMLHttpRequest',
                'Origin': 'https://24hd.be',
                'Connection': 'keep-alive',
                'Referer': 'https://24hd.be/api/source/'+id,
                'Pragma': 'no-cache',
                'Cache-Control': 'no-cache',
            }

            data = {
              'r': '',
              'd': '24hd.be'
            }
            xx=requests.post('https://24hd.be/api/source/'+id,headers=headers,data=data).json()
            
            for items in xx['data']:
               
                all_links.append((original_title.replace("%20"," "),items['file'],'Direct',items['label'].replace('p','')))
                global_var=all_links
             
        else:
            name1,match_s,res,check=server_data(link,original_title)
            if check:
              all_links.append((name1.replace("%20"," "),link,match_s,res))
              global_var=all_links
  elapsed_time = time.time() - start_time
  progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
  return all_links
  