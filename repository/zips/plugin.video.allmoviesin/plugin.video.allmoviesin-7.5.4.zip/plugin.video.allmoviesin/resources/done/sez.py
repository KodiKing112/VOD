# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time

global global_var,stop_all#global
global_var=[]
global progress
progress=''
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,all_colors,domain_s,base_header

type=['tv']

import urllib2,urllib,logging,base64,json

color=all_colors[11]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
        global global_var,stop_all,progress
        from jsunpack import unpack
        all_links=[]
        base_url='https://sezonlukdizi.vip'
        progress=' Start '
        start_time=time.time()
        url='https://sezonlukdizi.vip/js/series1.js?v=3'
        x=requests.get(url,headers=base_header).content
        f_x=x.replace('var dizi=','').replace('];',']').decode('utf-8','ignore').encode("utf-8").replace('{d:','{"d":').replace(',t:',',"t":').replace(',id:',',"id":').replace(',u:',',"u":').replace(',k:',',"k":').strip()
        
        x=json.loads(f_x)
        all_l=[]
        for items in x:
            
            if clean_name(original_title,1).lower()==items['d'].lower():
                
                y=requests.get(base_url+items['u'],headers=base_header).content
                regex='data-id="(.+?)" data-dizi="(.+?)"'
                m=re.compile(regex).findall(y)
                new_u=base_url+'/%s/%s-sezon-%s-bolum.html'%(m[0][1],season,episode)
        
                z=requests.get(new_u,headers=base_header).content
                
               
                regex='<div data-id="(.+?)"'
                m2=re.compile(regex,re.DOTALL).findall(z)
                
                headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0',
                    'Accept': 'application/json, text/javascript, */*; q=0.01',
                    'Accept-Language': 'en-US,en;q=0.5',
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'X-Requested-With': 'XMLHttpRequest',
                    'Origin': 'https://sezonlukdizi.vip',
                    'Connection': 'keep-alive',
                    'Referer': new_u,
                    'Pragma': 'no-cache',
                    'Cache-Control': 'no-cache',
                }

                data = {
                  'bid': m2[0],
                  'dil': '1'
                }

                response = requests.post('https://sezonlukdizi.vip/ajax/dataAlternatif.asp', headers=headers, data=data).json()
                
            
                for items in response['data']:
                        items_in=items['id']
                        
                       
                        headers = {
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0',
                            'Accept': '*/*',
                            'Accept-Language': 'en-US,en;q=0.5',
                            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                            'X-Requested-With': 'XMLHttpRequest',
                            'Origin': 'https://sezonlukdizi.vip',
                            'Connection': 'keep-alive',
                            'Referer': new_u,
                            'Pragma': 'no-cache',
                            'Cache-Control': 'no-cache',
                        }

                        
                        

                        data = {
                          'id': items_in
                        }

                        response = requests.post('https://sezonlukdizi.vip/ajax/dataEmbed.asp', headers=headers, data=data).content
              
                        regex='src="(.+?)"'
                        link=re.compile(regex).findall(response)[0]
          
                        if 'vshare.io' in link:
                            headers = {
                                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:68.0) Gecko/20100101 Firefox/68.0',
                                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                                'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
                                'Connection': 'keep-alive',
                                'Referer': new_u,
                                'Upgrade-Insecure-Requests': '1',
                                'Pragma': 'no-cache',
                                'Cache-Control': 'no-cache',
                            }

                            response = requests.get('http:'+link, headers=headers).content
                           
                            regex="eval(.+?)\)\)\n"
                            
                            m3=re.compile(regex,re.DOTALL).findall(response)
                           
                            if len(m3)==0:
                                continue
                            res_h=unpack(m3[0])
                            regex='=\[(.+?)\]'
                            m4=re.compile(regex).findall(res_h)
                            j_m4=json.loads('['+m4[0]+']')
                          
                            key_value=re.compile('parseInt\(value\)-(.+?)\)',re.DOTALL).findall(res_h)[0]
                            all_n=[]
                            for item_in_key in j_m4:
                                all_n.append(chr(int(item_in_key)-int(key_value)))
                            src_txt= ''.join(all_n)
                            regex='src="(.+?)".+?res="(.+?)"'
                            m5=re.compile(regex).findall(src_txt)
                            for link_in,q in m5:
                                if link_in not in all_l:
                                    all_l.append(link_in)
                                    try_head=requests.head(link_in,headers=base_header)
                                    s_name='Direct'
                                    if 'Content-Length' in try_head.headers:
              
                                        if int(try_head.headers['Content-Length'])>(1024*1024):
                                            f_size2=str(round(float(try_head.headers['Content-Length'])/(1024*1024*1024), 2))+' GB'
                                        if f_size2!='0.0 GB':
                                            s_name='Direct'+' - '+f_size2
                                        else:
                                            s_name='Direct'
                                    all_links.append((original_title,link_in,s_name,q))                
                            
                                    global_var=all_links
                        if 'rapid.asp' in link:
                            x=requests.get(base_url+link,headers=base_header).content
                            regex='src="(.+?)"'
                            m_link=re.compile(regex).findall(x)
                            if len(m_link)==0:
                                continue
                            m_link=m_link[0]
                            name1,match_s,res,check=server_data(m_link,original_title)
                            
                            if check:
                                all_links.append((name1.replace("%20"," "),m_link,match_s,res))                
                                        
                                global_var=all_links
                        else:
                            name1,match_s,res,check=server_data(link,original_title)
                            
                            if check:
                                all_links.append((name1.replace("%20"," "),link,match_s,res))                
                                        
                                global_var=all_links
        elapsed_time = time.time() - start_time
        progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
        return all_links
        