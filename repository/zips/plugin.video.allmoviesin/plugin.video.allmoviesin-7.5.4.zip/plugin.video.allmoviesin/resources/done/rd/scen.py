# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time,cache,urlparse

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,rd_domains,client,parseDOM
type=['movie','tv','rd']

import urllib2,urllib,logging,base64,json
try:
    import xbmc
    local=False
except:
    local=True
color=all_colors[93]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    all_links=[]
    base_link = 'http://scene-rls.net/'
    search_link = '/?s=%s'
    search_link_2 = '/?s=%s&submit=Find'
    title =clean_name(original_title,1)
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Accept-Language': 'en-US,en;q=0.5',
    
    'X-Requested-With': 'XMLHttpRequest',
    'Alt-Used': 'search.rlsbb.ru:443',
    'Connection': 'keep-alive',
    'TE': 'Trailers',
    }
    r,cook=cloudflare_request(base_link,headers=headers)
    if tv_movie=='tv':
        query = '%s S%sE%s' % (title, season_n, episode_n) 
    else:
        query ='%s %s' % (title, show_original_year)
    if tv_movie=='tv':
       hdlr = 'S%sE%s' % (season_n, episode_n)
    else:
       hdlr = show_original_year

    url = search_link % urllib.quote_plus(query)
    url = urlparse.urljoin(base_link, url)

    r = requests.get(url,headers=cook[1],cookies=cook[0]).content

    posts = parseDOM(r, 'div', attrs={'class': 'postHeader'})

    for post in posts:
        
        if stop_all==1:
            break
        regex='href="(.+?)" title="(.+?)"'
        match=re.compile(regex).findall(post)
        for link,title in match:
           if stop_all==1:
            break
           
           if clean_name(original_title,1).lower() in title.lower():
                x =  requests.get(link,headers=cook[1],cookies=cook[0]).content
                regex='<a target="_blank" href="(.+?)"'
                match_in=re.compile(regex).findall(x)
               
                for url in match_in:
                    if stop_all==1:
                        break
                    host = url.replace("\\", "")
                    host2 = host.strip('"')
                    host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(host2.strip().lower()).netloc)[0]
                
                    if host not in rd_domains:
                        continue
                    if '.iso' in url or '.rar' in url or '.zip' in url:
                        continue
                    names=url.split('/')
                    name1=names[len(names)-1]
                    if '1080' in name1:
                          res='1080'
                    elif '720' in name1:
                          res='720'
                    elif '480' in name1:
                          res='480'
                    elif '360' in name1:
                          res='360'
                    else:
                          res='720'
                    if local:
                        check1=True
                        check=True
                    else:
                        name1,match_s,res,check=server_data(url,original_title,direct='rd')
                  
                        if clean_name(original_title,1).lower() in name1.lower().replace('.',' '):
                            check1=True
                        else:
                            check1=False
                    
                        
                        
                        
                    if check and check1:
                       
                            all_links.append((name1,url,host,res))
                            global_var=all_links
    return global_var