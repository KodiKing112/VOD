# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,base_header
type=['movie']

import urllib2,urllib,logging,base64,json

color=all_colors[110]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress

    progress='Start'
    start_time=time.time()
    all_links=[]
    base_link = 'https://iwaatch.com/'
    search_link = 'https://iwaatch.com/?q=%s'
    url=search_link%clean_name(original_title,1).replace('-','%20').replace(' ','%20')
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
        'Accept': 'text/html, */*; q=0.01',
        'Accept-Language': 'en-US,en;q=0.5',
      
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'TE': 'Trailers',
    }

    progress='requests'
  
    
    params = (
        ('page', 'moviesearch'),
        ('q', 'rampage'),
    )

    response = requests.get('https://iwaatch.com/api/api.php', headers=headers, params=params).content
   
    #response = requests.get(url, headers=headers).content
    regex='a href="(.+?)".+?<img src=\'.+?\'>(.+?)<'
    progress='Regex'
    match2=re.compile(regex,re.DOTALL).findall(response)
    count=0
    
    for link_in,title_in in match2:
       
       progress='Links-'+str(count)
       count+=1
       if clean_name(original_title,1).lower() in title_in.lower():
        x=requests.get(link_in, headers=headers).content
        
        regex='<span class="download-q">(.+?)</span>'
        m=re.compile(regex,re.DOTALL).findall(x)
        regex="a href='(.+?)'>(.+?)<"
        match3=re.compile(regex,re.DOTALL).findall(m[0])
        headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:66.0) Gecko/20100101 Firefox/66.0',
        'Accept': 'video/webm,video/ogg,video/*;q=0.9,application/ogg;q=0.7,audio/*;q=0.6,*/*;q=0.5',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'Referer': link_in,

        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        }
       
        for url,q in match3:
            head=urllib.urlencode(headers)
            print url
            progress='Links2-'+str(count)
            try_head = requests.get(url,headers=headers, stream=True,verify=False,timeout=10)
            f_size2='0.0 GB'

            if 'Content-Length' in try_head.headers:
               if int(try_head.headers['Content-Length'])>(1024*1024):
                f_size2=str(round(float(try_head.headers['Content-Length'])/(1024*1024*1024), 2))+' GB'
            if f_size2!='0.0 GB':
                s_name='Direct'+' - '+f_size2
            else:
                s_name='Direct'
            url=url+"|"+head
            all_links.append((original_title,url,s_name,q))
            global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var