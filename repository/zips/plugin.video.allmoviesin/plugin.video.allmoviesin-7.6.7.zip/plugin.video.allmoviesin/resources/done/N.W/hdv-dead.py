# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time,cache

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['movie','tv']

import urllib2,urllib,logging,base64,json
try:
  import resolveurl
except:
  import resolveurl_temp as resolveurl
color=all_colors[87]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all

    import cfscrape
    all_links=[]
    base_link = 'https://hdvix.com'
    search_id = clean_name(original_title,1).lower()                                      
    if tv_movie=='movie':
      start_url = '%s/?s=%s' %(base_link,search_id.replace(' ','+'))         
    else:
      start_url = '%s/?s=%s' %(base_link,search_id.replace(' ','+')+'+season')         
                      
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    }
    
    html = requests.get(start_url,headers=headers).content            
    match = re.compile('class="thumb".+?title="(.+?)".+?href="(.+?)">',re.DOTALL).findall(html) 

    for name, item_url in match:
        if stop_all==1:
            break
    
        check=False
        if tv_movie=='movie':
          if show_original_year in name:                                                           
            check=True
        else:
       
          if 'Seasons %s^'%season in name+'^':
            check=True
        
        if check:
         
            if clean_name(search_id,1).lower() in clean_name(name,1).lower(): 
                if tv_movie=='tv':
                   item_url=item_url+'?ep='+episode
                OPEN = requests.get(item_url,headers=headers).content
               
                Endlinks1 = re.compile('class="screen fluid-width-video-wrapper">.+?src="(.+?)"',re.DOTALL).findall(OPEN)
                
                for nxpg in Endlinks1:       
                    if stop_all==1:
                        break
                    name1,match_s,res,check=server_data(nxpg,original_title)
                        
                          
                    if check :
                        all_links.append((name1,nxpg,match_s,res))
                        global_var=all_links
    return global_var
                   
                           