# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['movie']

import urllib2,urllib,logging,base64,json
color=all_colors[49]

def decode_base64(data):
    import base64
    """Decode base64, padding being optional.

    :param data: Base64 data as an ASCII byte string
    :returns: The decoded byte string.

    """
    missing_padding = len(data) % 4
    if missing_padding != 0:
        data += b'='* (4 - missing_padding)
    return base64.decodestring(data)
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    all_links=[]
    if season!=None and season!="%20":
       url2='http://api.themoviedb.org/3/tv/%s?api_key=%s&language=he&append_to_response=external_ids'%(id,'653bb8af90162bd98fc7ee32bcbbfb3d')
    else:
     
       url2='http://api.themoviedb.org/3/movie/%s?api_key=%s&language=he&append_to_response=external_ids'%(id,'653bb8af90162bd98fc7ee32bcbbfb3d')
    try:
        imdb_id=requests.get(url2).json()['external_ids']['imdb_id']
    except:
        return 0
    if tv_movie=='tv':
       url=domain_s+'api.odb.to/embed?imdb_id=%s&s=%s&e=%s'%(imdb_id,season,episode)
    else:
       url=domain_s+'api.odb.to/embed?imdb_id='+imdb_id
       url2='http://enthus1ast.com/movie/'+imdb_id
    progress='requests'
    #html=requests.get(url).content
 
    #regex='<iframe.+?src="(.+?)"'
    progress='Regex'
    #match=re.compile(regex).findall(html)
    progress='Check'
    #name1,match_s,res,check=server_data(match[0],original_title)
    check=False
    if check :
        all_links.append((name1,match[0],match_s,res))
        global_var=all_links
    if tv_movie=='movie':
        headers = {
            'Pragma': 'no-cache',
            'Accept-Encoding': 'utf-8',
            'Accept-Language': 'en-US,en;q=0.9',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive',
            }   
        progress='requests2'
        html,cook=cloudflare_request(url2)

        regex="uptobox.com</td><td><a href='.+?file=(.+?)'"
        progress='Regex2'
        match=re.compile(regex).findall(html)
        count=0
        for links in match:
            if stop_all==1:
                    break
            x=decode_base64(links.split('&')[0])
            progress='Check-'+str(count)
            count+=1
            name1,match_s,res,check=server_data(x,original_title)
            if check :
                all_links.append((name1,x,match_s,res))
                global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var
    