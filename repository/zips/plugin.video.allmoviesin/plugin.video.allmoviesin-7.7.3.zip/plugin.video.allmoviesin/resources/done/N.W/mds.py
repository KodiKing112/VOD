# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,urlparse
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
rating=['SSS','7M/s']
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,fix_q,base_header
type=['movie']

import urllib2,urllib,logging,base64,json
color=all_colors[79]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
        global global_var,stop_all,progress
        progress='Start'
        start_time=time.time()
        all_links=[]
        progress='requests'
        x=requests.get('https://mediastorebd.com/?s='+clean_name(original_title,1).replace(' ','+'),headers=base_header).content
        print 'https://mediastorebd.com/?s='+clean_name(original_title,1).replace(' ','+')
        regex='<div class="thumbnail animation-2">.+?a href="(.+?)"'
        progress='Regex'
        m=re.compile(regex,re.DOTALL).findall(x)
        count=0
        for link in m:
            print link
            progress='Links-'+str(count)
            count+=1
            y=requests.get(link,headers=base_header).content
            regex="<tr id='link-.+?'>.+?<a href='(.+?)' target='_blank'>Download</a></td><td><strong class='quality'>(.+?)</strong></td><td>(.+?)<"
            n=re.compile(regex,re.DOTALL).findall(y)
            for lk,q,lan in n:
                progress='Links2-'+str(count)
                if 'english' in lan.lower():
                    xx=requests.get(lk,headers=base_header).url
                    progress='Check-'+str(count)
                    name1,match_s,res,check=server_data(xx,original_title)
                            
                    res1=str(fix_q(q))
                    if check :
                          all_links.append((name1,xx,match_s,res1))
                          global_var=all_links
        elapsed_time = time.time() - start_time
        progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
        return global_var
                    