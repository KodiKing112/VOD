# -*- coding: utf-8 -*-
import requests
import unjuice,time
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,all_colors
type=['movie','subs']

import urllib2,urllib,logging,base64,json
color=all_colors[65]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress

    progress='Start'
    start_time=time.time()
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:66.0) Gecko/20100101 Firefox/66.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        
        'Content-Type': 'application/x-www-form-urlencoded',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
    }
    ur=Addon.getSetting("sratim_url")
    true_one_click_url=requests.get('https://'+ur,headers=headers).url.replace('https://','')
    if true_one_click_url!=ur:
        Addon.setSetting('sratim_url',true_one_click_url)
        
    if tv_movie=='movie':
        all_links=[]
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0',
            'Accept': 'text/plain, */*; q=0.01',
            'Accept-Language': 'en-US,en;q=0.5',
            'Referer': domain_s+'itsmine.space/',
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'X-Requested-With': 'XMLHttpRequest',
            'Connection': 'keep-alive',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
        }

        data = [
          ('action', 'ajaxsearchpro_search'),
          ('aspp', name),
          ('asid', '1'),
          ('asp_inst_id', '1_1'),
          ('options', 'current_page_id=5844&qtranslate_lang=0&asp_gen%5B%5D=title&asp_gen%5B%5D=content&asp_gen%5B%5D=excerpt&customset%5B%5D=post'),
        ]
        progress='requests'
        response = requests.post('https://'+true_one_click_url+'/wp-admin/admin-ajax.php', headers=headers,  data=data).content
        regex='"asp_res_url.+?href=\'(.+?)\'>(.+?)<'
        
        progress='Regex'
        match=re.compile(regex,re.DOTALL).findall(response)

      
        if len(match)>0:
            for link,name_in in match:
             
              if clean_name(original_title,1).lower() in name_in.lower() and name in name_in:
                progress='requests'
                html=requests.get(link).content
                
                regex='svq_playlist_data.push\((.+?)\)'
                progress='Regex'
                match2=re.compile(regex).findall(html)
                
                if len (match2)==0:
                  regex='<video id="wp_mep_.+? src="(.+?)"'
                  progress='Regex2'
                  match2=re.compile(regex).findall(html)
                  regex_t='/(.+?).mp4'
                  progress='Regex3'
                  match_t=re.compile(regex_t).findall(match2[0])
                  headers={'Accept':'video/webm,video/ogg,video/*;q=0.9,application/ogg;q=0.7,audio/*;q=0.6,*/*;q=0.5',
                        'Accept-Language':'en-US,en;q=0.5',
                        'Cache-Control':'no-cache',
                        'Connection':'keep-alive',
                        #'Host':'server2.sratim-il.com',
                        'Pragma':'no-cache',

                        #'Referer':'http://www.sratim-il.cf/newsite/%s/'%match_t[0],
                        'User-Agent':'Mozilla/5.0 (Windows NT 6.1; W…) Gecko/20100101 Firefox/59.0'}
                  head=urllib.urlencode(headers)

                  all_links.append((name.decode('utf8') + ' תרגום מובנה'.decode('utf8'),match2[0]+"|"+head,'SERETIL','1080'))
                  global_var=all_links
                else:
                    for m in json.loads(match2[0]):
                      if stop_all==1:
                        break
                      for data in m['svq_video']:
                        if stop_all==1:
                            break
                        regex_t='/(.+?).mp4'
                        progress='Regex2'
                        match_t=re.compile(regex_t).findall(data['svq_url'])
                        headers={'Accept':'video/webm,video/ogg,video/*;q=0.9,application/ogg;q=0.7,audio/*;q=0.6,*/*;q=0.5',
                                'Accept-Language':'en-US,en;q=0.5',
                                'Cache-Control':'no-cache',
                                'Connection':'keep-alive',
                                #'Host':'server2.sratim-il.com',
                                'Pragma':'no-cache',

                                #'Referer':'http://www.sratim-il.cf/newsite/%s/'%match_t[0],
                                'User-Agent':'Mozilla/5.0 (Windows NT 6.1; W…) Gecko/20100101 Firefox/59.0'}
                        head=urllib.urlencode(headers)

                        all_links.append((name + ' תרגום מובנה',data['svq_url']+"|"+head,'SERETIL',data['svq_label']))
                        global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var
    