# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache

global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,base_header
type=['movie','tv']

import urllib2,urllib,logging,base64,json

color=all_colors[108]

def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    if tv_movie=='movie':
        search_url=clean_name(original_title,1)
    else:
        search_url=clean_name(original_title,1).replace(' ','+')+'+season+'+season
    all_links=[]
    url='http://spacemov.cc/search-query/%s/'%search_url
    x,cook=cloudflare_request(url,headers=base_header)
    print url
    html=requests.get(url,headers=cook[1],cookies=cook[0]).content
    regex='<div class="ml-item".+?<a href="(.+?)" class="ml-mask jt".+?title="(.+?)"'
    m_pre=re.compile(regex,re.DOTALL).findall(html)

    for link,title_p in m_pre:
        print title_p
        if tv_movie=='tv':
            if clean_name(original_title,1).lower() not in  title_p.lower() :
                    continue
        else:
            if title_p.lower()!=clean_name(original_title,1).lower():
                    continue
        r=requests.get(link+ 'watching/?ep=1',headers=cook[1],cookies=cook[0]).content
        r = re.compile('a title="(.+?)" data-svv.+?="(.+?)"').findall(r)
    
        for title, url in r:
            if stop_all==1:
                break
            if tv_movie=='tv' and 'Episode %s:'%episode_n not in title:
                continue
            
            if 'HD' in title:
                res = '1080'
            elif 'CAM' in title:
                continue
            else:
                res = '480'
            if 'vidcloud' in url:
                        if 'http' not in url:
                            url='http:'+url
                        headers = {
                            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
                            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                            'Accept-Language': 'en-US,en;q=0.5',
                            'Referer': link,
                            'Connection': 'keep-alive',
                            'Upgrade-Insecure-Requests': '1',
                            'Pragma': 'no-cache',
                            'Cache-Control': 'no-cache',
                            'TE': 'Trailers',
                        }
                        x=requests.get(url,headers=headers).content
                       
                        regex="sources.+?file: '(.+?)'"
                        
                        url=re.compile(regex).findall(x)
                        if len(url)>0:
                          url=url[0]
                        else:
                          regex='player.setup.+?file: "(.+?)"'
                        
                          url=re.compile(regex,re.DOTALL).findall(x)[0]
                        headers = {
                            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
                            'Accept': '*/*',
                            'Accept-Language': 'en-US,en;q=0.5',
                            'Referer': 'https://vidcloud.icu/',
                            'Origin': 'https://vidcloud.icu',
                            'Connection': 'keep-alive',
                            'Pragma': 'no-cache',
                            'Cache-Control': 'no-cache',
                        }
                        head=urllib.urlencode(headers)
                            

                        url=url+"|"+head
                   
                        name1,match_s,res,check=server_data(url,original_title)
                        all_links.append((name1,url,match_s,res))
                        global_var=all_links
            if 'putload' in url:
                x=requests.get(url,headers=base_header).content
                       
                regex="<script type='text/javascript'>(.+?)</script"
                m2=re.compile(regex,re.DOTALL).findall(x)[0]
                try:
                    from jsunpack import unpack
                    data=unpack(m2)
                    data = re.findall('sources:(\[\{.+?\}\])',data, re.DOTALL)[0]
                               
                    try:
                        data = json.loads(data)
                    except:
                        data=data.replace('file','"file"').replace('label','"label"')
                        data = json.loads(data)
                    data = [(i['file']) for i in data if data]
                except:
                    regex='src: "(.+?)"'
                    link=re.compile(regex).findall(x)[0]
                    data=[link]
                for link_in in data:
                
                    if stop_all==1:
                        break
                    if '.jpg' not in link_in and '.vtt' not in link_in:
                        all_links.append((original_title,link_in.replace('"',''),'Direct',res))
                        global_var=all_links
    return global_var