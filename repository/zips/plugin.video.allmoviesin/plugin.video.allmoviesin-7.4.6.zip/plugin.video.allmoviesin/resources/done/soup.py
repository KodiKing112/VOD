# -*- coding: utf-8 -*-
import requests
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
global progress
progress=''
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,all_colors,base_header
type=['tv','movie']

import urllib2,urllib,logging,base64,json
color=all_colors[68]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    all_links=[]
    progress='requests'
    html=requests.get('https://soap2day.to/search/keyword/'+clean_name(original_title,1).replace(' ','%20'),headers=base_header).content

    if tv_movie=='tv':
        regex='<div class="panel-heading">Related TVs</div>(.+?)<h4>Directors includes'
    else:
        regex='<div class="panel-heading">Related Movies</div>(.+?)<h4>Directors includes'
    
    progress='Regex'
    m=re.compile(regex,re.DOTALL).findall(html)
    
    progress='requests2'
    
    regex='<h5><a href=(?:"|\')(.+?)(?:"|\')>(.+?)<'
    m2=re.compile(regex).findall(m[0])
    
    for lk,nm in m2:
        n_link='https://soap2day.to'+lk
       
        
        if nm.lower()==clean_name(original_title,1).lower():
          
            y=requests.get(n_link,headers=base_header).content
            if tv_movie=='tv':
                regex='<h4>Season%s : <(.+?)<p class="col-sm-12 col-lg-12">'%season
                m3=re.compile(regex,re.DOTALL).findall(y)
            else:
                m3=['1']
            if len(m3)>0:
                
                if tv_movie=='tv':
                    regex='<a href="/episode_(.+?).html">(.+?).'
                    m4=re.compile(regex).findall(m3[0])
                    found=0
                    for lk,ep_nm in m4:
                        if ep_nm==episode:
                            m4= [lk]
                            found=1
                            break
                else:
                    regex='/movie_(.+?).html'
                    m4=re.compile(regex).findall(n_link)
                    found=1
                
                if len(m4)>0 and found==1:
                    
                   
                    headers= {
                        'sec-fetch-mode': 'cors',
                        'origin': 'https://soap2day.to',
                        'accept-encoding': 'utf-8',
                        'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
                        'x-requested-with': 'XMLHttpRequest',
                        #'cookie': '__cfduid=df09e4650b7053bd29e4ad4d9418402511570698086; PHPSESSID=cje8tb88h7022pji6v1q8j7pd5; _ga=GA1.2.1333451827.1570698073; _gid=GA1.2.278998214.1570698073; _gat_gtag_UA_108733136_1=1; glx_pp_13706_201813106={"loaded_time":1570708737,"unload_time":1570708765}',
                        'pragma': 'no-cache',
                        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36',
                        'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                        'accept': 'application/json, text/javascript, */*; q=0.01',
                        'cache-control': 'no-cache',
                        'authority': 'soap2day.to',
                        'referer': 'https://soap2day.to/episode_%s.html'%m4[0],
                        'sec-fetch-site': 'same-origin',
                    }

                    data = {
                      'pass': m4[0]
                    }
                    if tv_movie=='tv':
                        response = requests.post('https://soap2day.to/home/index/GetEInfoAjax', headers=headers, data=data).json()
                    else:
                        response = requests.post('https://soap2day.to/home/index/GetMInfoAjax', headers=headers, data=data).json()
                    
                    f_lk=json.loads(response)['val']
                    try:
                        try_head = requests.head(f_lk,headers=base_header, stream=True,verify=False,timeout=15)
                  
                        f_size2='0.0 GB'
                        s_name='Direct'
                        if 'Content-Length' in try_head.headers:
                          
                            if int(try_head.headers['Content-Length'])>(1024*1024):
                                f_size2=str(round(float(try_head.headers['Content-Length'])/(1024*1024*1024), 2))+' GB'
                            if f_size2!='0.0 GB':
                                s_name='Direct'+' - '+f_size2
                            else:
                                s_name='Direct'
                             
                        all_links.append((clean_name(original_title,1),f_lk,s_name,'720'))
                        global_var=all_links
                    except Exception as e:
                          
                          pass
                    
                    
                    
                
    

    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var
    