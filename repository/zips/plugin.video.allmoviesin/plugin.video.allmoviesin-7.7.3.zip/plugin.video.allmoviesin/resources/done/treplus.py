##taken from theater plus apk
import requests,time,PTN
import unjuice
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,cloudflare_request,all_colors,base_header,res_q


import urllib2,urllib,logging,base64,json
color=all_colors[17]
type=['movie','tv']
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
        global global_var,stop_all,progress
        all_links=[]
        start_time=time.time()
        
        search_str=clean_name(original_title,1).lower()
       
        headers={'Cache-Control': 'max-age=0',
                'Data-Agent': 'The Stream',

                'Connection': 'Keep-Alive',
                'Accept-Encoding': 'utf-8',
                'User-Agent': 'okhttp/3.8.1'}
        url='http://theaterplus.xyz/api/get_search_results/?api_key=new11uT8cBLzm6a1YvsiUWOEgrFowk95K2DM3tHAPRCX4ypGjN&search=%s&count=100'%search_str
        x=requests.get(url,headers=headers).json()
        logging.warning( 'treplus')
        logging.warning( search_str)
        for items in x['posts']:
            logging.warning( items)
            if tv_movie=='tv':
            
                if 'Season %s - Episode %s'%(season,episode) not in items['channel_name']:
                    continue
           
            if 'Hindi' in items['channel_name'] or 'Hindi' in items['category_name']:
                continue
            res=res_q(items['channel_name'])
            link=items['channel_url']
            try_head = requests.head(link,headers=base_header, stream=True,verify=False,timeout=15)
            f_size2='0.0 GB'
            if 'Content-Length' in try_head.headers:
               
                if int(try_head.headers['Content-Length'])>(1024*1024):
                    f_size2=str(round(float(try_head.headers['Content-Length'])/(1024*1024*1024), 2))+' GB'
                if f_size2!='0.0 GB':
                    s_name='Google'+' - '+f_size2
                else:
                    s_name='Google'
                    
            all_links.append((original_title,link,s_name,res))
            global_var=all_links
                