import requests,re,json
import unjuice

global global_var,stop_all#global
global_var=[]

stop_all=0
from general import clean_name,check_link,server_data,replaceHTMLCodes,all_colors,domain_s,base_header

type=['movie','tv']
import urllib2,urllib,logging
color=all_colors[19]
def get_links(tv_movie,original_title,name,season_n,episode_n,season_o,episode_o,show_original_year,id):
    global global_var,stop_all
    all_links=[]
    print 'in'
    search_url='https://www.moviesjoy.net/search/%s.html'%(clean_name(original_title,1).replace(' ','+'))
    html=requests.get(search_url,headers=base_header).content
    regex='<div class="flw-item">.+?title="(.+?)".+?<a href="(.+?)"'
    m=re.compile(regex,re.DOTALL).findall(html)
    for title,link in m:
        check=False
        if tv_movie=='tv':
            if 'Season '+season_o in title:
                check=True
        else:
            check=True
        if clean_name(original_title,1).lower() in title.lower() and check:
            n_link=link.replace('.html','')+'/watching.html'
            x=requests.get(n_link,headers=base_header).content
            regex='id: "(.+?)",.+?movie_id: "(.+?)"'
            m2=re.compile(regex,re.DOTALL).findall(x)
        
            headers = {
                'Pragma': 'no-cache',
                'Accept-Encoding': 'utf-8',
                'Accept-Language': 'en-US,en;q=0.9',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
                'Accept': 'application/json, text/javascript, */*; q=0.01',
                'Referer': n_link,
                'X-Requested-With': 'XMLHttpRequest',
                'Connection': 'keep-alive',
                'Cache-Control': 'no-cache',
            }

            response = requests.get('https://www.moviesjoy.net/ajax/v4_movie_episodes/%s/%s'%(str(m2[0][0]),m2[0][1]), headers=headers).json()
            
            regex='<li (.+?)</li>'
            m_pre=re.compile(regex,re.DOTALL).findall(response['html'])
            
            
            if tv_movie=='tv':
                found=''
                for items in m_pre:
                    if 'title="Episode %s:'%episode_n in items:
                      found=items
                      
                      regex='data-index=.+?data-server="(.+?)".+?data-id="(.+?)"'
                      m3=re.compile(regex,re.DOTALL).findall(found)
                
  
               
                      for id2,id1 in m3:
                    
                        response = requests.get('https://www.moviesjoy.net/ajax/movie_sources/%s-%s'%(id1,id2), headers=headers).content
               
                        if 'playlist' in response:
                            response=json.loads(response)
                            for items in response['playlist'][0]['sources']:
                                name1,match_s,res,check=server_data(items['file'],original_title)
                                            
                                     
                                if check :
                                    all_links.append((name1,items['file'],match_s,items['label']))
                                    global_var=all_links
                            
            else:
                regex='li data-index=.+?data-server="(.+?)".+?data-id="(.+?)"'
                found=response['html']
                
                
                m3=re.compile(regex,re.DOTALL).findall(found)
                
      
                
                for id2,id1 in m3:
                
                    response = requests.get('https://www.moviesjoy.net/ajax/movie_sources/%s-%s'%(id1,id2), headers=headers).content
                   
                    if 'playlist' in response:
                        response=json.loads(response)
                        for items in response['playlist'][0]['sources']:
                            name1,match_s,res,check=server_data(items['file'],original_title)
                                        
                                 
                            if check :
                                all_links.append((name1,items['file'],match_s,items['label']))
                                global_var=all_links
              
    return all_links

