# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache

global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,base_header
type=['movie']

import urllib2,urllib,logging,base64,json

color=all_colors[2]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    search_url=clean_name(original_title,1)
    
    all_links=[]
    
    headers = {
    'origin': 'https://repelisgo.com',
    'accept-encoding': 'utf-8',
    'accept-language': 'en-US,en;q=0.9',
    'authorization': 'Basic',
   
    'pragma': 'no-cache',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
    'content-type': 'application/json;charset=UTF-8',
    'accept': 'application/json, text/plain, */*',
    'cache-control': 'no-cache',
    'authority': 'repelisgo.io',
    #'referer': 'https://repelisgo.io/search?term=tomb%20radier',
    }

    data = '{"query":"\\n        query($term: String!, $first: Int!) {\\n          results: allMovies (search: $term, first: $first) {\\n            id\\n            slug\\n            title\\n            duration\\n            rating\\n            releaseDate\\n            poster\\n          }\\n        }\\n      ","variables":{"term":"%s","first":8}}'%search_url

    response = requests.post('https://repelisgo.com/graph', headers=headers, data=data).json()
    for items in response['data']['results']:
    
     
        if show_original_year in items['releaseDate'] and search_url.lower() in items['title'].lower():
            new_link='https://repelisgo.io/pelicula/'+items["slug"]+'-'+items["id"]
            y=requests.get(new_link,headers=base_header).content
            regex='window.__NUXT__=(.+?)};'
            m=re.compile(regex).findall(y)
            re_json=json.loads(m[0]+'}')
            once=0
            for it in re_json['data'][0]['movie']['mirrors']:
                if  it['audio']=='en':
                    #import cfscrape
                    #scraper = cfscrape.create_scraper()
                    headers = {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0',
                        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                        'Accept-Language': 'en-US,en;q=0.5',
                        'Connection': 'keep-alive',
                        'Upgrade-Insecure-Requests': '1',
                    }
                    if once==0:
                        tk,cook=cloudflare_request('https://repelisgo.com'+it['url'],headers=headers)
                        once=1
    
                    f_link=requests.get('https://repelisgo.com'+it['url'],headers=cook[1],cookies=cook[0],stream=True).url
                    headers = {
                        'authority': 'repelisgo.com',
                        'pragma': 'no-cache',
                        'cache-control': 'no-cache',
                        'upgrade-insecure-requests': '1',
                        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36',
                        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
                        'referer': f_link,
                        'accept-encoding': 'gzip, deflate, br',
                        'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
                        
                    }
                    #f_link=requests.get(f_link,headers=headers,cookies=cook[0]).url
                    if 1:#try:
                        if 'repelisgo.com' in f_link :
                            
                            f_link,cook=cloudflare_request(f_link,headers=headers,safe=True,get_url=True)
                            
                        if 'src='  in f_link:
                            f_link=urllib.unquote_plus(f_link.split('src=')[1])
                            if 'mp4&' in f_link:
                                f_link=f_link.split('mp4&')[0]+'mp4'
                            
                        name1,match_s,res,check=server_data(f_link,original_title)
                           
                                
                        
                        if check :
                            if it['quality']=='poor':
                                res='480'
                            if it['quality']=='high':
                                res='1080'
                            all_links.append((name1,f_link,match_s,res))
                            global_var=all_links
                    #except:
                    #  pass
    return global_var
            
            
