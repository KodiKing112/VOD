# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['tv','movie']
rating=['SSS','5M/s']
import urllib2,urllib,logging,base64,json
color=all_colors[48]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    all_links=[]
    if tv_movie=='tv':
      
      url=domain_s+'www.thenetnaija.com/search?t=%s&folder=videos'%(original_title.replace("Marvel's ",'').replace("%20","+")+'+s'+season_n+'e'+episode_n)
    else:
      url=domain_s+'www.thenetnaija.com/search?t=%s&folder=videos'%(original_title.replace("%20","+")+'+'+show_original_year)
    
    headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',

    'Pragma': 'no-cache',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
    }
    url=url.replace(" ","+")
    progress='requests'
    html=requests.get(url,headers=headers).content

    regex='<h3 class="result-title"><a href="(.+?)">(.+?)</h3'
    progress='Regex'
    match=re.compile(regex,re.DOTALL).findall(html.replace('<em>','').replace('</em>','').replace('  ',' '))
    count=0
    for link,name in match:
       
        progress='Links-'+str(count)
        count+=1
        if stop_all==1:
             break
        check=False
        if tv_movie=='tv':
         if 's'+season_n+'e'+episode_n in name.lower():
           check=True
        else:
           check=True

        if clean_name(original_title,1).lower() in name.lower() and check==True:
          progress='requests-'+str(count)
          x=requests.get(link,headers=headers).content
      
          regex='alt="Download Now".+?<a href="(.+?)"'
          progress='Regex-'+str(count)
          match2=re.compile(regex,re.DOTALL).findall(x)
          if len(match2)==0:
            regex='> Download<.+?href="(.+?)"'
            progress='Regex2-'+str(count)
            match2=re.compile(regex,re.DOTALL).findall(x)
          
          regex_n='Source:</strong>(.+?)<'
          progress='Regex3-'+str(count)
          name1=re.compile(regex_n).findall(x)
          progress='requests2-'+str(count)
        
          y=requests.get(match2[0],headers=headers).content
       
          regex='Direct Download.+?onclick="this.select.+?value="(.+?)"'
          progress='Regex4-'+str(count)
          match3=re.compile(regex,re.DOTALL).findall(y)
        
          if len(name1)==0:
            regex_t='<h1 class="path">(.+?)<'
            name1=re.compile(regex_t).findall(y)[0].replace('(NetNaija.com)','')
          else:
            name1=name1[0]
          if "1080" in name1:
              res="1080"
          elif "720" in name1:
              res="720"
          elif "480" in name1:
              res="720"
          elif "hd" in name1.lower():
              res="HD"
          else:
             res=' '
          
          name2,match_s,res,check=server_data(match3[0],original_title)
                
         
          if 1:
              all_links.append((name1.replace('.mp4','').strip(),match3[0],match_s.replace('www.downloadbetter.com','Direct'),res))
              global_var=all_links
          
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var
    