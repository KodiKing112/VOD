
# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,all_colors,cloudflare_request
type=['tv','movie']

import urllib2,urllib,logging,base64,json
try:
  import resolveurl
except:
  import resolveurl_temp as resolveurl
color=all_colors[14]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
        global global_var,stop_all
        x,cook=cloudflare_request('https://www7.the123movieshub.net')
        title=original_title

        if tv_movie=='tv':
          link=domain_s+'www7.the123movieshub.net/film/%s-season-%s/watching.html?ep=%s'%(title.lower().replace('%20','-').replace('%3a','').replace(' ','-'),season,episode)
          regex='Episode %s - .+?" player-data="(.+?)"'%episode
          f_link=link
        else:
         
          headers = {
                #'Host': 'cmovies.io',
                'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
                'Accept': 'application/json, text/javascript, */*; q=0.01',
                'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
                'Referer': domain_s+'cmovies.io/film/the-maze-runner-nbb',
                'X-Requested-With': 'XMLHttpRequest',
                'Connection': 'keep-alive',
                'Pragma': 'no-cache',
                'Cache-Control': 'no-cache',
                }

          params = (
                ('keyword', title.lower().replace('%3a','').replace('%20','+').replace(' ','+')),
                   )

          response = requests.get('https://www7.the123movieshub.net/movie/search/'+title.lower().replace('%3a','').replace('%20','+').replace(' ','+'), headers=headers,cookies=cook[0], params=params).content

         

          regex='<div class="ml-item">.+?<a href="(.+?)" data-url="(.+?)".+?<h2>(.+?)</h2>'
          match=re.compile(regex,re.DOTALL).findall(response)
          f_link=''
          
          for lk,lk2,title in match:
              headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
                    'Accept': '*/*',
                    'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
                    'Referer': 'https://www7.the123movieshub.net/movie/search/'+title.lower().replace('%3a','').replace('%20','+').replace(' ','+'),
                    'X-Requested-With': 'XMLHttpRequest',
                    'Connection': 'keep-alive',
                    'Pragma': 'no-cache',
                    'Cache-Control': 'no-cache',
                    'TE': 'Trailers',
                }

              response,cook2 = cloudflare_request('https://www7.the123movieshub.net'+lk2, headers=headers)
             
              regex='<div class="jt-info">(.+?)<'
              year=re.compile(regex).findall(response)[0]
              
              if year==show_original_year and clean_name(original_title,1).lower() in title.lower():
                f_link=lk
                break
          
          
          
        
          
          tt=requests.get(domain_s+'www7.the123movieshub.net'+f_link+'/watching.html',cookies=cook[0],headers=cook[1]).content

          regex_l="var page_url = '(.+?)'"
          match_ll=re.compile(regex_l).findall(tt)
          print tt
          episode=match_ll[0].split('=')[1]
          link=domain_s+'www7.the123movieshub.net'+f_link+'/watching.html'+match_ll[0]
          
          regex='player-data="(.+?)"'
 
        x=requests.get(link,cookies=cook[0],headers=cook[1]).content
       
        
        response2=re.compile(regex).findall(x)

        all_links=[]
        all_links_in=[]
       
        for links in response2:
          if stop_all==1:
               break
          try:
              if 'vidcloud.icu' in links:
                    if 'http' not in links:
                        links='http:'+links
                    headers = {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
                        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                        'Accept-Language': 'en-US,en;q=0.5',
                        'Referer': link,
                        'Connection': 'keep-alive',
                        'Upgrade-Insecure-Requests': '1',
                        'Pragma': 'no-cache',
                        'Cache-Control': 'no-cache',
                        'TE': 'Trailers',
                    }
                    x=requests.get(links,headers=headers).content
                   
                    regex="sources.+?file: '(.+?)'"
                    
                    url=re.compile(regex).findall(x)
                    if len(url)>0:
                      url=url[0]
                    else:
                      regex='player.setup.+?file: "(.+?)"'
                    
                      url=re.compile(regex,re.DOTALL).findall(x)[0]
                    headers = {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
                        'Accept': '*/*',
                        'Accept-Language': 'en-US,en;q=0.5',
                        'Referer': 'https://vidcloud.icu/',
                        'Origin': 'https://vidcloud.icu',
                        'Connection': 'keep-alive',
                        'Pragma': 'no-cache',
                        'Cache-Control': 'no-cache',
                    }
                    head=urllib.urlencode(headers)
                        

                    url=url+"|"+head
               
                    name1,match_s,res,check=server_data(url,original_title)
                    all_links.append((name1,url,match_s,res))
                    global_var=all_links
              elif 'vidnode.net' in links:
      
               zz=requests.get('https:'+links).content
         
               regex_l="sources.+?file.+?'(.+?)'"
               match_l=re.compile(regex_l).findall(zz)
               
               for ll in match_l:
                 if stop_all==1:
                    break
                 if 'google' not in ll:
            
                  #regex_l='//(.+?)/'
                  #match_l=re.compile(regex_l).findall(ll)
   
                  link_n=get_redirect(ll)
           
                  links_name=link_n.split('/')
                  
                  name1=links_name[len(links_name)-1].replace('.mp4','').replace('.mkv','').replace('.avi','')
                  if clean_name(original_title,1).replace(" ",".") not in name1:
                    name1=clean_name(original_title,1)
                  all_links.append((name1,link_n,'CMOVIES','HD'))
                  global_var=all_links
               
               regex_l='window.location = "(.+?)"'
               match_l22=re.compile(regex_l).findall(zz)
              
               
               for ll in match_l22:
                if stop_all==1:
                    break
                resolvable=resolveurl.HostedMediaFile(ll).valid_url()
                if stop_all==1:
                       break
                if resolvable:
                   
                   yy=requests.get(ll)
                   link_ok=check_link(yy)
                   if link_ok:
                   
                       regex='og:title" content="(.+?)"'
                       match_n=re.compile(regex).findall(yy.content)
                       if len( match_n)==0:
                            regex='<Title>(.+?)</Title>'
                            match_n=re.compile(regex,re.IGNORECASE).findall(yy.content)
                       if len(match_n)==0:
                         regex='name="fname" value="(.+?)"'
                         match_n=re.compile(regex,re.DOTALL).findall(yy.content)
                       if len(match_n)==0:
                         regex='<title>(.+?)</title>'
                         match_n=re.compile(regex,re.DOTALL).findall(yy.content)
                       regex_l='//(.+?)/'
                       match_l=re.compile(regex_l).findall(ll)
                       srv=match_l[0]
                       if len(match_n)>0 and 'thevideo' not in ll:
                           match_n[0]=match_n[0].replace('\n','').replace('  ',' ').replace('\t','').replace('\r','')
                           info=(PTN.parse(match_n[0]))
                           nam1=match_n[0].replace('%20',' ')
                           if 'resolution' in info:
                              res=info['resolution']
                           else:
                              res='720'
                       else:
                         nam1=original_title.replace('%20',' ')
                         res=' '
                       if ll not in all_links_in:
                         all_links_in.append(ll)
                         all_links.append((nam1,ll,match_l[0],res))
                         global_var=all_links
               regex_l=' "Download Video",.+?"(.+?)"'
               match_l=re.compile(regex_l,re.DOTALL).findall(zz)
               if len(match_l)==0:
                   regex_l='id="embedvideo" src="(.+?)"'
                   match_l=re.compile(regex_l,re.DOTALL).findall(zz)
               tt=requests.get(match_l[0]).content
               
               regex_l='href="(.+?)" target=\'_blank\''
               match_l22=re.compile(regex_l).findall(tt)
           
    
               for ll in match_l22:
                if stop_all==1:
                    break
                resolvable=resolveurl.HostedMediaFile(ll).valid_url()

                if resolvable:
               
           
                   
                   yy=requests.get(ll,timeout=10)
                   link_ok=check_link(yy)
                   if link_ok:
                     
                       regex='og:title" content="(.+?)"'
                       match_n=re.compile(regex).findall(yy.content)
                       if len( match_n)==0:
                            regex='<Title>(.+?)</Title>'
                            match_n=re.compile(regex,re.IGNORECASE).findall(yy.content)
                       if len(match_n)==0:
                         regex='name="fname" value="(.+?)"'
                         match_n=re.compile(regex,re.DOTALL).findall(yy.content)
                       if len(match_n)==0:
                         regex='<title>(.+?)</title>'
                         match_n=re.compile(regex,re.DOTALL).findall(yy.content)
                       regex_l='//(.+?)/'
                       match_l=re.compile(regex_l).findall(ll)
                       srv=match_l[0]
                       if len(match_n)>0 and 'thevideo' not in ll:
                           match_n[0]=match_n[0].replace('\n','').replace('  ',' ').replace('\t','').replace('\r','')
                           info=(PTN.parse(match_n[0]))
                           nam1=match_n[0].replace('%20',' ')
                           if 'resolution' in info:
                              res=info['resolution']
                           else:
                              res='720'
                       else:
                         nam1=original_title.replace('%20',' ')
                         res=' '
                       
                       if ll not in all_links_in:
                         all_links_in.append(ll)
                         all_links.append((nam1,ll,match_l[0],res))
                         global_var=all_links
                        
              else:
               
               resolvable=resolveurl.HostedMediaFile(links).valid_url()
          
               if resolvable:
                   
                   yy=requests.get(links)
                   link_ok=check_link(yy)
                   if link_ok:
                   
                       regex='og:title" content="(.+?)"'
                       match_n=re.compile(regex).findall(yy.content)
                       if len( match_n)==0:
                            regex='<Title>(.+?)</Title>'
                            match_n=re.compile(regex,re.IGNORECASE).findall(yy.content)
                       if len(match_n)==0:
                         regex='name="fname" value="(.+?)"'
                         match_n=re.compile(regex,re.DOTALL).findall(yy.content)
                       if len(match_n)==0:
                         regex='<title>(.+?)</title>'
                         match_n=re.compile(regex,re.DOTALL).findall(yy.content)
                       regex_l='//(.+?)/'
                       match_l=re.compile(regex_l).findall(links)
                       srv=match_l[0]
                       if len(match_n)>0 and 'thevideo' not in links:
                           match_n[0]=match_n[0].replace('\n','').replace('  ',' ').replace('\t','').replace('\r','')
                           info=(PTN.parse(match_n[0]))
                           nam1=match_n[0].replace('%20',' ')
                           if 'resolution' in info:
                              res=info['resolution']
                           else:
                              res='720'
                       else:
                         nam1=original_title.replace('%20',' ')
                         res=' '
                       if links not in all_links_in:
                         all_links_in.append(links)
                         all_links.append((nam1,links,match_l[0],res))
                         global_var=all_links
          except:
            pass
        return global_var