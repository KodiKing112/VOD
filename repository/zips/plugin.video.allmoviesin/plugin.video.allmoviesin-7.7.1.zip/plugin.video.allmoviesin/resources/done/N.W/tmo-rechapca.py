# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time,cache

global global_var,stop_all#global
global_var=[]
stop_all=0

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,base_header
type=['movie','tv']

import urllib2,urllib,logging,base64,json
try:
  import resolveurl
except:
  import resolveurl_temp as resolveurl
color=all_colors[100]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all

    
    all_links=[]
    x=requests.get('https://www1.two-movies.name/search/?search_query=%s&criteria=all'%clean_name(original_title,1).replace(' ','+'),headers=base_header).content
    regex='<div class="filmDiv" id="filmsSearch(.+?)/a></div>'
    match=re.compile(regex,re.DOTALL).findall(x)
    print match
    for items in match:
        regex='a href="(.+?)".+?class="filmname">(.+?)<.+?<a class="filmyar" href=".+?">(.+?)<'
        match_in=re.compile(regex,re.DOTALL).findall(items)
        print match_in
        for link,name,year in match_in:
            if clean_name(original_title,1).lower() in name.lower() and show_original_year in year:
              y=requests.get('https://www1.two-movies.name'+link,headers=base_header).content
              regex='<div class="movieLinks(.+?)</div'
              match_pre=re.compile(regex,re.DOTALL).findall(y)
             
              for items_in in match_pre:
                regex='href="(.+?)"'
                mat=re.compile(regex).findall(items_in)[0]
                print 'https://www1.two-movies.name'+mat
                headers = {
                    'authority': 'www1.two-movies.name',
                    'pragma': 'no-cache',
                    'cache-control': 'no-cache',
                    'upgrade-insecure-requests': '1',
                    'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36',
                    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
                    'referer': 'https://www1.two-movies.name'+mat+'?not_now',
                    'accept-encoding': 'utf-8',
                    'accept-language': 'he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7',
                 
                }

                params = (
                    ('not_now', ''),
                )

                z = requests.get('https://www1.two-movies.name'+mat, headers=headers, params=params).content
                regex="var hash = '(.+?)'"
                hash=re.compile(regex).findall(z)[0]
                headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'en-US,en;q=0.5',
                    'Referer': 'https://www1.two-movies.name'+mat,
                    'content-type': 'application/x-www-form-urlencoded',
                    'origin': 'https://www1.two-movies.name',
                    'Connection': 'keep-alive',
                    'Pragma': 'no-cache',
                    'Cache-Control': 'no-cache',
                    'TE': 'Trailers',
                }

                data = {
                  'hash': hash,
                  'confirm_continue': 'I understand, I want to continue'
                }

                z = requests.post('https://www1.two-movies.name'+mat, headers=headers, data=data).content
                    
                #z=requests.get('https://www1.two-movies.name'+mat,headers=headers).content
                regex='iframe src="(.+?)"'
                
                f_link=re.compile(regex).findall(z)[0]
                if 'http' not in f_link:
                  f_link='http:'+f_link
                print f_link
                name1,match_s,res,check=server_data(f_link,original_title)
                        
                
                if check :
                    all_links.append((name1,f_link,match_s,res))
                    global_var=all_links
              