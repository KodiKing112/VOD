# -*- coding: utf-8 -*-
import requests,re,PTN
import unjuice,time,cache

global global_var,stop_all#global
global_var=[]
stop_all=0

rating=['External','Openload']

from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors,client,base_header
type=['movie','tv']

import urllib2,urllib,logging,base64,json
try:
  import resolveurl
except:
  import resolveurl_temp as resolveurl
color=all_colors[106]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all
    all_links=[]
    html=requests.get('https://www2.streamcouch.com/search?q='+clean_name(original_title,1).replace(" ","+"),headers=base_header).content
    regex='<li itemprop="itemListElement"(.+?)   </li>'
    match_pre=re.compile(regex,re.DOTALL).findall(html)
    print match_pre
    for items in match_pre:
        regex='<div class="name" itemprop="name">(.+?)<.+?<meta itemprop="url" content="(.+?)"'
        match=re.compile(regex,re.DOTALL).findall(items)
        
        nam,link=match[0]
        
        if clean_name(original_title,1).lower() in nam.lower() and show_original_year in nam:
            
            y=requests.get(link,headers=base_header).content
            if tv_movie=='tv':
                regex='itemprop="name">Season %s<.+?<span itemprop="name">EP %s:</span>(.+?)  </li>'%(season,episode)
                m2=re.compile(regex,re.DOTALL).findall(y)
                print m2
                if len(m2)>0:
                    regex='<a href="(.+?)"'
                    links=re.compile(regex,re.DOTALL).findall(m2[0])
                else:
                  return all_links
                
            else:
                regex='<a class="clearfix" href="(.+?)"'
                links=re.compile(regex).findall(y)
            for link in links:
                z=requests.get(link,headers=base_header).url
                name2,match_s,res,check=server_data(z,original_title)
                if check:
                    all_links.append((name2,z,match_s,res))
                    
                    global_var=all_links
    return all_links
    
    