# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,cache
import dns,socket,ssl
global progress
progress=''
global global_var,stop_all#global
global_var=[]
stop_all=0
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['movie','subs']

import urllib2,urllib,logging,base64,json

color=all_colors[95]

import httplib
def MyResolver(host):
  resolver = dns.resolver.Resolver()
  dns_addr='8.8.8.8'
  resolver.nameservers = [dns_addr]
  answer = resolver.query(host,'A')

  return answer.rrset.items[0].address
class MyHTTPConnection(httplib.HTTPConnection):
  def connect(self):
    self.sock = socket.create_connection((MyResolver(self.host),self.port),self.timeout)
class MyHTTPSConnection(httplib.HTTPSConnection):
  def connect(self):
    sock = socket.create_connection((MyResolver(self.host), self.port), self.timeout)
    self.sock = ssl.wrap_socket(sock, self.key_file, self.cert_file)

class MyHTTPHandler(urllib2.HTTPHandler):
  def http_open(self,req):
    return self.do_open(MyHTTPConnection,req)

class MyHTTPSHandler(urllib2.HTTPSHandler):
  def https_open(self,req):
    return self.do_open(MyHTTPSConnection,req)
from urllib3.util import connection
_orig_create_connection = connection.create_connection
def patched_create_connection(address, *args, **kwargs):
    """Wrap urllib3's create_connection to resolve the name elsewhere"""
    # resolve hostname to an ip address; use your own
    # resolver here, as otherwise the system resolver will be used.
    host, port = address
    hostname =  MyResolver(host)


    return _orig_create_connection((hostname, port), *args, **kwargs)


connection.create_connection = patched_create_connection
class resolve_dns():
    
    def __init__(self,url,headers={},cookies={},data={}):
        self.url=url
        self.headers=headers
        self.cookies=cookies
        self.data=data
    def get(self):
        import requests
        
        import cookielib
        
        
        handlers = [MyHTTPHandler,MyHTTPSHandler]
        cookjar = cookielib.CookieJar()
        #for cook in self.cookies:
            
        #    cookjar.set_cookie(makeCookie(cook, self.cookies[cook]))
        handlers += [urllib2.HTTPHandler(), urllib2.HTTPSHandler(), urllib2.HTTPCookieProcessor(cookjar)]
        
        opener = urllib2.build_opener(*handlers)
        opener.addheaders.append(('Set-Cookie', urllib.urlencode(self.cookies)))
        
        self.headers['Cookie']=urllib.urlencode(self.cookies).replace('&',';')
        logging.warning(self.headers['Cookie'])
        request = urllib2.Request(self.url,  headers=self.headers,data=urllib.urlencode(self.data))
        
        request.get_method = lambda: 'GET'
        #html = opener.open(request).read()
        html=requests.get(self.url,  headers=self.headers,data=urllib.urlencode(self.data))
        cookie_new=html.cookies
        #cookie_new={}
        #for cook in cookjar:
        #  cookie_new[cook.name]=cook.value
        return html.content,cookie_new

    def post(self):
        import cookielib
        

        handlers = [MyHTTPHandler,MyHTTPSHandler]
        cookjar = cookielib.CookieJar()
        handlers += [urllib2.HTTPHandler(), urllib2.HTTPSHandler(), urllib2.HTTPCookieProcessor(cookjar)]
        
        opener = urllib2.build_opener(*handlers)
        opener.addheaders.append(('Set-Cookie', urllib.urlencode(self.cookies)))

        
        

        request = urllib2.Request(self.url,  headers=self.headers,data=urllib.urlencode(self.data))

        request.get_method = lambda: 'POST'
      

        #html = opener.open(request).read()
        logging.warning(self.data)
        html=requests.post(self.url,  headers=self.headers,data=(self.data))
        logging.warning(html.content)
        cookie_new=html.cookies
        #cookie_new={}
        #for cook in cookjar:
        #  cookie_new[cook.name]=cook.value
        return html.content,cookie_new
    def image(self):
        import cookielib
        

        handlers = [MyHTTPHandler,MyHTTPSHandler]
        cookjar = cookielib.CookieJar()
        handlers += [urllib2.HTTPHandler(), urllib2.HTTPSHandler(), urllib2.HTTPCookieProcessor(cookjar)]
        
        opener = urllib2.build_opener(*handlers)
        opener.addheaders.append(('Set-Cookie', urllib.urlencode(self.cookies)))

        
        

        request = urllib2.Request(self.url,  headers=self.headers,data=urllib.urlencode(self.data))

        request.get_method = lambda: 'POST'
      

        html = opener.open(request)
        localFile = open('desktop.jpg', 'wb')
        localFile.write(html.read())
        localFile.close()

def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
    global global_var,stop_all,progress
    progress='Start'
    start_time=time.time()
    all_links=[]
    
    headers = {
    'User-Agent': 'MOVIX-KODI',
    'Accept': '*/*',
    'Accept-Language': 'en-US,en;q=0.5',
   
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'X-Requested-With': 'XMLHttpRequest',
    'Connection': 'keep-alive',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    }
    progress='Requests'
    x,cookie=resolve_dns("http://movix.live/?s="+clean_name(original_title,1).replace(' ','+'),headers=headers).get()
   
    regex_pre='<div data-movie-id="(.+?)<p class'
    progress='Regex'
    match_pre=re.compile(regex_pre,re.DOTALL).findall(x)
    count=0
    for item in match_pre:
        progress='Links-'+str(count)
        count+=1
        if stop_all==1:
                    break
        regex='<a href="(.+?)".+?<h2>(.+?)</h.+?rel="tag">(.+?)<'
        progress='Regex-'+str(count)
        match=re.compile(regex,re.DOTALL).findall(item)
        
        for link_pre,title,year in match:
            progress='Links2-'+str(count)
            if stop_all==1:
                    break
            if clean_name(original_title,1).lower() in title.lower() and show_original_year in year:
                progress='requests-'+str(count)
                y,cook=resolve_dns(link_pre,headers=headers).get()
                regex_pre='<iframe src="(.+?)"'
                progress='Regex2-'+str(count)
                match_in=re.compile(regex_pre).findall(y)
                for link in match_in:
                    progress='Check-'+str(count)
                    name1,match_s,res,check=server_data(link,original_title)
              
                   
                    if check :
                        all_links.append((name1,link,match_s,res))
                        global_var=all_links
            regex='btn-group btn-group-justified embed-selector"(.+?)<script>'
            match_in_pre=re.compile(regex,re.DOTALL).findall(y)
            
            for items in match_in_pre:
                
                if stop_all==1:
                    break
                regex_pre='a href="(.+?)"'
                match_in=re.compile(regex_pre).findall(items)
                for link in match_in:
                    if stop_all==1:
                        break
                    progress='Check2-'+str(count)
                    name1,match_s,res,check=server_data(link,original_title)
                   
                   
               
                    if check :
                        all_links.append((name1,link,match_s,res))
                        global_var=all_links
    elapsed_time = time.time() - start_time
    progress=' Done '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
    return global_var
                