# -*- coding: utf-8 -*-
import requests,xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,sys,logging
__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'
__addon__ = xbmcaddon.Addon()
__cwd__ = xbmc.translatePath(__addon__.getAddonInfo('path')).decode("utf-8")
Addon = xbmcaddon.Addon()
from os import listdir
from os.path import isfile, join
import time
import threading,json
global break_jump
break_jump=0
addonPath = xbmc.translatePath(Addon.getAddonInfo("path")).decode("utf-8")
user_dataDir = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
if not os.path.exists(user_dataDir):
     os.makedirs(user_dataDir)
lang=xbmc.getLanguage(0)
from resources.modules.public import addNolink,addDir3,addLink,lang,user_dataDir
from resources.modules.trakt import progress_trakt,get_trakt,get_trk_data,trakt_liked
from  resources.modules import cache
from resources.modules.general import fix_q,post_trakt
from resources.modules import real_debrid
class Thread(threading.Thread):
    def __init__(self, target, *args):
       
        self._target = target
        self._args = args
        
        
        threading.Thread.__init__(self)
        
    def run(self):
        
        self._target(*self._args)
def get_params():
        param=[]
        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     


def get_genere(link):
  
   images={}
   html=requests.get(link).json()
   aa=[]
   image='https://wordsfromjalynn.files.wordpress.com/2014/12/movie-genres-1.png'
   for data in html['genres']:
     if '/movie' in link:
       new_link='http://api.themoviedb.org/3/genre/%s/movies?api_key=34142515d9d23817496eeb4ff1d223d0&language=%s&page=1'%(str(data['id']),lang)
     else:
       new_link='http://api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&sort_by=popularity.desc&with_genres=%s&language=%s&page=1'%(str(data['id']),lang)
     
     
     aa.append(addDir3(data['name'],new_link,14,image,image,data['name']))
   xbmcplugin .addDirectoryItems(int(sys.argv[1]),aa,len(aa))
def read_site_html(url_link):
    import requests
    '''
    req = urllib2.Request(url_link)
    req.add_header('User-agent',__USERAGENT__)# 'Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30')
    html = urllib2.urlopen(req).read()
    '''
    html=requests.get(url_link)
    return html
def tv_show_menu():
    all=[]
    #Popular
    aa=addDir3('Popular','http://api.themoviedb.org/3/tv/popular?api_key=34142515d9d23817496eeb4ff1d223d0&language=%s&page=1'%lang,14,'https://www.designmantic.com/blog/wp-content/uploads/2018/01/Best-Tv-show-logos-718x300.jpg','https://image.businessinsider.com/5d5ea69fcd97841fea3d3b36?width=1100&format=jpeg&auto=webp','TMDB')
    all.append(aa)
    
    aa=addDir3('On_the_air','https://api.themoviedb.org/3/tv/on_the_air?api_key=34142515d9d23817496eeb4ff1d223d0&language=%s&page=1'%lang,14,'https://i.pinimg.com/236x/1c/49/8f/1c498f196ef8818d3d01223b72678fc4--divergent-movie-poster-divergent-.jpg','https://i.pinimg.com/236x/1c/49/8f/1c498f196ef8818d3d01223b72678fc4--divergent-movie-poster-divergent-.jpg','TMDB')
    all.append(aa)
    #Genre
    aa=addDir3('Genre','http://api.themoviedb.org/3/genre/tv/list?api_key=34142515d9d23817496eeb4ff1d223d0&language=%s&page=1'%lang,18,'http://www.logotypes101.com/logos/994/F920BB739F9F1041441FF1574D9D70FC/youtube_tv_shows.png','https://consequenceofsound.net/wp-content/uploads/2019/11/CoS_2010sDecades-TVShows.jpg?quality=80','TMDB')
    all.append(aa)
    #Years
    aa=addDir3('Years','tv_years&page=1',14,'https://pmcvariety.files.wordpress.com/2018/07/tv-time-logo.jpg?w=1000&h=563&crop=1','https://d2yhzr6tx8qnba.cloudfront.net/images/db/9/b6/58e2db43d1b69.jpeg','TMDB')
    all.append(aa)
    aa=addDir3('Networks','tv_years&page=1',101,'http://www.slate.com/content/dam/slate/articles/arts/tv_club/2015/12/151223_TV_ThinkstockPhotos-466978453.jpg.CROP.promo-xlarge2.jpg','https://images.pond5.com/tv-networks-logos-loop-footage-042898083_prevstill.jpeg','TMDB')
    all.append(aa)

    #Search tv
    aa=addDir3('Search','http://api.themoviedb.org/3/search/tv?api_key=34142515d9d23817496eeb4ff1d223d0&query=%s&language=he&page=1',14,'http://img.wcdn.co.il/f_auto,w_700,t_18/1/0/7/2/1072572-46.jpg','http://f.frogi.co.il/news/640x300/010170efc8f.jpg','TMDB')
    all.append(aa)
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all,len(all))
def tv_neworks():
    all_d=[]
    if Addon.getSetting("order_networks")=='0':
        order_by='popularity.desc'
    elif Addon.getSetting("order_networks")=='2':
        order_by='vote_average.desc'
    elif Addon.getSetting("order_networks")=='1':
        order_by='first_air_date.desc'
    aa=addDir3('[COLOR lightblue]Disney+[/COLOR]'.decode('utf8'),'https://'+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=2739&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://lumiere-a.akamaihd.net/v1/images/image_308e48ed.png','https://allears.net/wp-content/uploads/2018/11/wonderful-world-of-animation-disneys-hollywood-studios.jpg','Disney'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR blue]Apple TV+[/COLOR]'.decode('utf8'),'https://'+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=2552&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://ksassets.timeincuk.net/wp/uploads/sites/55/2019/03/Apple-TV-screengrab-920x584.png','https://www.apple.com/newsroom/videos/apple-tv-plus-/posters/Apple-TV-app_571x321.jpg.large.jpg','Apple'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR red]NetFlix[/COLOR]'.decode('utf8'),'https://'+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=213&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://art.pixilart.com/705ba833f935409.png','https://i.ytimg.com/vi/fJ8WffxB2Pg/maxresdefault.jpg','NetFlix'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR gray]HBO[/COLOR]'.decode('utf8'),'https://'+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=49&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://filmschoolrejects.com/wp-content/uploads/2018/01/hbo-logo.jpg','https://www.hbo.com/content/dam/hbodata/brand/hbo-static-1920.jpg','HBO'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR lightblue]CBS[/COLOR]'.decode('utf8'),'https://'+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=16&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://cdn.freebiesupply.com/logos/large/2x/cbs-logo-png-transparent.png','https://tvseriesfinale.com/wp-content/uploads/2014/10/cbs40-590x221.jpg','HBO'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR purple]SyFy[/COLOR]'.decode('utf8'),'https://'+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=77&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'http://cdn.collider.com/wp-content/uploads/syfy-logo1.jpg','https://imagesvc.timeincapp.com/v3/mm/image?url=https%3A%2F%2Fewedit.files.wordpress.com%2F2017%2F05%2Fdefault.jpg&w=1100&c=sc&poi=face&q=85','SyFy'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR lightgreen]The CW[/COLOR]'.decode('utf8'),'https://'+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=71&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://www.broadcastingcable.com/.image/t_share/MTU0Njg3Mjc5MDY1OTk5MzQy/tv-network-logo-cw-resized-bc.jpg','https://i2.wp.com/nerdbastards.com/wp-content/uploads/2016/02/The-CW-Banner.jpg','The CW'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR silver]ABC[/COLOR]'.decode('utf8'),'https://'+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=2&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'http://logok.org/wp-content/uploads/2014/03/abc-gold-logo-880x660.png','https://i.ytimg.com/vi/xSOp4HJTxH4/maxresdefault.jpg','ABC'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR yellow]NBC[/COLOR]'.decode('utf8'),'https://'+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=6&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://designobserver.com/media/images/mondrian/39684-NBC_logo_m.jpg','https://www.nbcstore.com/media/catalog/product/cache/1/image/1000x/040ec09b1e35df139433887a97daa66f/n/b/nbc_logo_black_totebagrollover.jpg','NBC'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR gold]AMAZON[/COLOR]'.decode('utf8'),'https://'+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=1024&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'http://g-ec2.images-amazon.com/images/G/01/social/api-share/amazon_logo_500500._V323939215_.png','https://cdn.images.express.co.uk/img/dynamic/59/590x/Amazon-Fire-TV-Amazon-Fire-TV-users-Amazon-Fire-TV-stream-Amazon-Fire-TV-Free-Dive-TV-channel-Amazon-Fire-TV-news-Amazon-1010042.jpg?r=1535541629130','AMAZON'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR green]hulu[/COLOR]'.decode('utf8'),'https://'+'api.themoviedb.org/3/discover/tv?api_key=34142515d9d23817496eeb4ff1d223d0&with_networks=453&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://i1.wp.com/thetalkinggeek.com/wp-content/uploads/2012/03/hulu_logo_spiced-up.png?resize=300%2C225&ssl=1','https://www.google.com/url?sa=i&rct=j&q=&esrc=s&source=images&cd=&cad=rja&uact=8&ved=2ahUKEwi677r77IbeAhURNhoKHeXyB-AQjRx6BAgBEAU&url=https%3A%2F%2Fwww.hulu.com%2F&psig=AOvVaw0xW2rhsh4UPsbe8wPjrul1&ust=1539638077261645','hulu'.decode('utf8'))
    all_d.append(aa)
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def main_menu():
    all_d=[]
    aa=addDir3('Movie World','www',2,'https://cdn1.vectorstock.com/i/1000x1000/22/75/logo-slate-board-for-shooting-movies-vector-4692275.jpg','https://townsquare.media/site/295/files/2019/12/2020-movies-collage.jpg?w=980&q=75','Movies')
    all_d.append(aa)
    aa=addDir3('TV World','www',3,'https://image.shutterstock.com/image-vector/tv-television-electronic-media-logo-260nw-1138807478.jpg','https://cdn.mos.cms.futurecdn.net/qCD39X4DjbpgxD7ZFW63eG.jpg','TV')
    all_d.append(aa)
    aa=addDir3('Trakt','www',114,'https://troypoint.com/wp-content/uploads/2018/07/trakt-tv-setup.png','https://bestdroidplayer.com/wp-content/uploads/2019/06/trakt-what-is-how-use-on-kodi.png','TV')
    all_d.append(aa)
    aa=addDir3('Search','www',5,'https://cdn2.vectorstock.com/i/1000x1000/24/01/seo-search-engine-optimization-logo-vector-24722401.jpg','https://searchengineland.com/figz/wp-content/seloads/2017/12/compare-seo-ss-1920-800x450.jpg','Search')
    all_d.append(aa)
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def movie_world():
    all_d=[]
    aa=addDir3('In Theaters','http://api.themoviedb.org/3/movie/now_playing?api_key=34142515d9d23817496eeb4ff1d223d0&language=%s&page=1'%lang,14,'https://image.freepik.com/free-vector/click-movie-logo-vector_18099-274.jpg','https://images.cdn1.stockunlimited.net/preview1300/cinema-background-with-movie-objects_1823387.jpg','Tmdb')
    all_d.append(aa)
    'Popular Movies'
    aa=addDir3('Popular Movies','http://api.themoviedb.org/3/movie/popular?api_key=34142515d9d23817496eeb4ff1d223d0&language=%s&page=1'%lang,14,'https://i.gifer.com/XfzE.gif','https://www.newszii.com/wp-content/uploads/2018/08/Most-Popular-Action-Movies.png','Tmdb')
    all_d.append(aa)

    #Genre
    aa=addDir3('Genre','http://api.themoviedb.org/3/genre/movie/list?api_key=34142515d9d23817496eeb4ff1d223d0&language=%s&page=1'%lang,18,'https://st3.depositphotos.com/10665628/19019/v/1600/depositphotos_190192058-stock-illustration-cinema-genre-cinematography-seamless-pattern.jpg','https://s.studiobinder.com/wp-content/uploads/2019/09/Movie-Genres-Types-of-Movies-List-of-Genres-and-Categories-Header-StudioBinder.jpg','Tmdb')
    all_d.append(aa)
    #Years
    aa=addDir3('Years','movie_years&page=1',14,'https://cdn.dribbble.com/users/2432597/screenshots/6945317/tejas-40-years-dribble_2x.jpg','https://i.pinimg.com/originals/e4/03/91/e4039182cd17c48c8f9cead44cda7df3.jpg','Tmdb')
    all_d.append(aa)
    aa=addDir3('Studio','movie_years&page=1',112,'https://cdn-static.denofgeek.com/sites/denofgeek/files/styles/main_wide/public/2016/04/movlic_studios_1.jpg?itok=ih8Z7wOk','https://cdn-static.denofgeek.com/sites/denofgeek/files/styles/main_wide/public/2016/04/movlic_studios_1.jpg?itok=ih8Z7wOk','Tmdb')
    all_d.append(aa)
    
    #Search movie
    aa=addDir3('Search movie','http://api.themoviedb.org/3/search/movie?api_key=34142515d9d23817496eeb4ff1d223d0&query=%s&language=he&append_to_response=origin_country&page=1',14,'https://cellcomtv.cellcom.co.il/globalassets/cellcomtv/content/sratim/pets-secret-life/480x543-template.jpg','http://www.videomotion.co.il/wp-content/uploads/whatwedo-Pic-small.jpg','Tmdb')
    all_d.append(aa)
    
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))

def movie_prodiction():
    all_d=[]
    if Addon.getSetting("order_networks")=='0':
        order_by='popularity.desc'
    elif Addon.getSetting("order_networks")=='2':
        order_by='vote_average.desc'
    elif Addon.getSetting("order_networks")=='1':
        order_by='first_air_date.desc'
    
    
    aa=addDir3('[COLOR red]Marvel[/COLOR]'.decode('utf8'),'https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=7505&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://yt3.ggpht.com/a-/AN66SAwQlZAow0EBMi2-tFht-HvmozkqAXlkejVc4A=s900-mo-c-c0xffffffff-rj-k-no','https://images-na.ssl-images-amazon.com/images/I/91YWN2-mI6L._SL1500_.jpg','Marvel'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR lightblue]DC Studios[/COLOR]'.decode('utf8'),'https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=9993&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://pmcvariety.files.wordpress.com/2013/09/dc-comics-logo.jpg?w=1000&h=563&crop=1','http://www.goldenspiralmedia.com/wp-content/uploads/2016/03/DC_Comics.jpg','DC Studios'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR lightgreen]Lucasfilm[/COLOR]'.decode('utf8'),'https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=1&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://fontmeme.com/images/lucasfilm-logo.png','https://i.ytimg.com/vi/wdYaG3o3bgE/maxresdefault.jpg','Lucasfilm'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR yellow]Warner Bros.[/COLOR]'.decode('utf8'),'https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=174&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'http://looking.la/wp-content/uploads/2017/10/warner-bros.png','https://cdn.arstechnica.net/wp-content/uploads/2016/09/warner.jpg','SyFy'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR blue]Walt Disney Pictures[/COLOR]'.decode('utf8'),'https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=2&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://i.ytimg.com/vi/9wDrIrdMh6o/hqdefault.jpg','https://vignette.wikia.nocookie.net/logopedia/images/7/78/Walt_Disney_Pictures_2008_logo.jpg/revision/latest?cb=20160720144950','Walt Disney Pictures'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR skyblue]Pixar[/COLOR]'.decode('utf8'),'https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=3&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://elestoque.org/wp-content/uploads/2017/12/Pixar-lamp.png','https://wallpapercave.com/wp/GysuwJ2.jpg','Pixar'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR deepskyblue]Paramount[/COLOR]'.decode('utf8'),'https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=4&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://upload.wikimedia.org/wikipedia/en/thumb/4/4d/Paramount_Pictures_2010.svg/1200px-Paramount_Pictures_2010.svg.png','https://vignette.wikia.nocookie.net/logopedia/images/a/a1/Paramount_Pictures_logo_with_new_Viacom_byline.jpg/revision/latest?cb=20120311200405&format=original','Paramount'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR burlywood]Columbia Pictures[/COLOR]'.decode('utf8'),'https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=5&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://static.tvtropes.org/pmwiki/pub/images/lady_columbia.jpg','https://vignette.wikia.nocookie.net/marveldatabase/images/1/1c/Columbia_Pictures_%28logo%29.jpg/revision/latest/scale-to-width-down/1000?cb=20141130063022','Columbia Pictures'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR powderblue]DreamWorks[/COLOR]'.decode('utf8'),'https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=7&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://www.dreamworksanimation.com/share.jpg','https://www.verdict.co.uk/wp-content/uploads/2017/11/DA-hero-final-final.jpg','DreamWorks'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR lightsaltegray]Miramax[/COLOR]'.decode('utf8'),'https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=14&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://vignette.wikia.nocookie.net/disney/images/8/8b/1000px-Miramax_1987_Print_Logo.png/revision/latest?cb=20140902041428','https://i.ytimg.com/vi/4keXxB94PJ0/maxresdefault.jpg','Miramax'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR gold]20th Century Fox[/COLOR]'.decode('utf8'),'https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=25&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://pmcdeadline2.files.wordpress.com/2017/03/20th-century-fox-cinemacon1.jpg?w=446&h=299&crop=1','https://vignette.wikia.nocookie.net/simpsons/images/8/80/TCFTV_logo_%282013-%3F%29.jpg/revision/latest?cb=20140730182820','20th Century Fox'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR bisque]Sony Pictures[/COLOR]'.decode('utf8'),'https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=34&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://upload.wikimedia.org/wikipedia/commons/thumb/6/63/Sony_Pictures_Television_logo.svg/1200px-Sony_Pictures_Television_logo.svg.png','https://vignette.wikia.nocookie.net/logopedia/images/2/20/Sony_Pictures_Digital.png/revision/latest?cb=20140813002921','Sony Pictures'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR navy]Lions Gate Films[/COLOR]'.decode('utf8'),'https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=35&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'http://image.wikifoundry.com/image/1/QXHyOWmjvPRXhjC98B9Lpw53003/GW217H162','https://vignette.wikia.nocookie.net/fanon/images/f/fe/Lionsgate.jpg/revision/latest?cb=20141102103150','Lions Gate Films'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR beige]Orion Pictures[/COLOR]'.decode('utf8'),'https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=41&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://i.ytimg.com/vi/43OehM_rz8o/hqdefault.jpg','https://i.ytimg.com/vi/g58B0aSIB2Y/maxresdefault.jpg','Lions Gate Films'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR yellow]MGM[/COLOR]'.decode('utf8'),'https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=21&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://pbs.twimg.com/profile_images/958755066789294080/L9BklGz__400x400.jpg','https://assets.entrepreneur.com/content/3x2/2000/20150818171949-metro-goldwun-mayer-trade-mark.jpeg','MGM'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR gray]New Line Cinema[/COLOR]'.decode('utf8'),'https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=12&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://upload.wikimedia.org/wikipedia/en/thumb/0/04/New_Line_Cinema.svg/1200px-New_Line_Cinema.svg.png','https://vignette.wikia.nocookie.net/theideas/images/a/aa/New_Line_Cinema_logo.png/revision/latest?cb=20180210122847','New Line Cinema'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR darkblue]Gracie Films[/COLOR]'.decode('utf8'),'https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=18&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://i.ytimg.com/vi/q_slAJmZBeQ/hqdefault.jpg','https://i.ytimg.com/vi/yGofbuJTb4g/maxresdefault.jpg','Gracie Films'.decode('utf8'))
    all_d.append(aa)
    aa=addDir3('[COLOR goldenrod]Imagine Entertainment[/COLOR]'.decode('utf8'),'https://'+'api.themoviedb.org/3/discover/movie?api_key=34142515d9d23817496eeb4ff1d223d0&with_companies=23&language=he&sort_by={0}&timezone=America%2FNew_York&include_null_first_air_dates=false&page=1'.format(order_by),14,'https://s3.amazonaws.com/fs.goanimate.com/files/thumbnails/movie/2813/1661813/9297975L.jpg','https://www.24spoilers.com/wp-content/uploads/2004/06/Imagine-Entertainment-logo.jpg','Imagine Entertainment'.decode('utf8'))
    all_d.append(aa)
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def main_trakt():
   all_d=[]
   aa=addDir3('Lists','www',116,'https://kodi.expert/wp-content/uploads/2018/05/trakt-logo.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','רשימות')
   all_d.append(aa)
   aa=addDir3('Progress','users/me/watched/shows?extended=full',115,'https://kodi.expert/wp-content/uploads/2018/05/trakt-logo.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','התקדמות')
   all_d.append(aa)
   aa=addDir3('Episodes watchlist','sync/watchlist/episodes?extended=full',115,'https://kodi.expert/wp-content/uploads/2018/05/trakt-logo.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','התקדמות')
   all_d.append(aa)
   aa=addDir3('Series watchlist','users/me/watchlist/episodes?extended=full',117,'https://kodi.expert/wp-content/uploads/2018/05/trakt-logo.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','אוסף')
   all_d.append(aa)
   aa=addDir3('TV Collection','users/me/collection/shows',117,'https://kodi.expert/wp-content/uploads/2018/05/trakt-logo.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','אוסף')
   all_d.append(aa)
   aa=addDir3('Shows watchlist','users/me/watchlist/shows',117,'https://kodi.expert/wp-content/uploads/2018/05/trakt-logo.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','אוסף')
   all_d.append(aa)
   aa=addDir3('Movies watchlist','users/me/watchlist/movies',117,'https://kodi.expert/wp-content/uploads/2018/05/trakt-logo.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','אוסף')
   all_d.append(aa)
   aa=addDir3('Watched movies','users/me/watched/movies',117,'https://kodi.expert/wp-content/uploads/2018/05/trakt-logo.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','אוסף')
   all_d.append(aa)
   aa=addDir3('Watched shows','users/me/watched/shows',117,'https://kodi.expert/wp-content/uploads/2018/05/trakt-logo.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','אוסף')
   all_d.append(aa)
   aa=addDir3('Movies Collection','users/me/collection/movies',117,'https://kodi.expert/wp-content/uploads/2018/05/trakt-logo.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','collection')
   all_d.append(aa)
   aa=addDir3('Liked lists','users/likes/lists',118,'https://kodi.expert/wp-content/uploads/2018/05/trakt-logo.png','https://seo-michael.co.uk/content/images/2016/08/trakt.jpg','Watched shows')
   all_d.append(aa)
   xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def c_get_sources(name,url,iconimage,fanart,description,data,original_title,id,season,episode,show_original_year):
   try:
    source_dir = os.path.join(addonPath, 'resources', 'sources')
    dp = xbmcgui . DialogProgress ( )
    dp.create('Please wait','Searching', '','')
    dp.update(0, 'Please wait','Searching', '' )
    sys.path.append( source_dir)
    onlyfiles = [f for f in listdir(source_dir) if isfile(join(source_dir, f))]
    start_time = time.time()
    if season!=None and season!="%20":
          tv_movie='tv'
    else:
          tv_movie='movie'
          
    if len(episode)==1:
      episode_n="0"+episode
    else:
       episode_n=episode
    if len(season)==1:
      season_n="0"+season
    else:
      season_n=season
    all_sources=[]
    thread=[]
    for items in onlyfiles:
       if 'pyo' not in items and 'init' not in items:
        impmodule = __import__(items.replace('.py',''))
        all_sources.append((items,impmodule))
        
        impmodule.global_var=[]
        thread.append(Thread(impmodule.get_links,tv_movie,original_title,season_n,episode_n,season,episode,show_original_year,id))
        thread[len(thread)-1].setName(items.replace('.py',''))
        thread[len(thread)-1].start()
    tt={}
    for i in range (0,(len(thread)+50)): 
      tt[i]="red"
    if len(thread)>0:
      while 1:
        num_live=0
         
          
         
        elapsed_time = time.time() - start_time
        
            
         
              
        num_live=0
        string_dp=''
        string_dp2=''
        still_alive=0
        count_2160=0
        count_1080=0
        count_720=0
        count_480=0
        count_rest=0
        count_alive=0
        all_alive={}
        for yy in range(0,len(thread)):
            all_alive[thread[yy].name]=thread[yy].is_alive()
            
            #logging.warning(thread[yy].name+' Alive: '+str(thread[yy].is_alive()))
            if not thread[yy].is_alive():
              num_live=num_live+1
              tt[yy]="lightgreen"
              
              #logging.warning('Dead:'+thread[yy].name)
              #string_dp2=string_dp2+',[COLOR red]O:'+thread[yy].name+'[/COLOR]'
            else:
              
              
              if string_dp2=='':
                string_dp2=thread[yy].name
              else:
                count_alive+=1
                string_dp2=string_dp2+','+thread[yy].name
              still_alive=1
              tt[yy]="red"
        f_result={}
        for name1,items in all_sources:
            f_result[name1]={}
            f_result[name1]['links']=items.global_var
        living=[]
        for items in all_alive:
             if all_alive[items]:
               living.append(items)
        if count_alive>10:
            
            string_dp2='Remaining: '+str(count_alive)+' - '+random.choice (living)
        count_found=0
        for data in f_result:
            if len (f_result[data]['links'])>0:
                   count_found+=1
                   
            if 'links' in f_result[data] and len (f_result[data]['links'])>0:
                 
                for links_in in f_result[data]['links']:
                    
                     
                     
                     name1,links,server,res=links_in
                     new_res=0
                     if '2160' in res:
                       count_2160+=1
                       new_res=2160
                     if '1080' in res:
                       count_1080+=1
                       new_res=1080
                     elif '720' in res:
                       count_720+=1
                       new_res=720
                     elif '480' in res:
                       count_480+=1
                       new_res=480
                     else:
                       count_rest+=1
                     
                all_s_in=(f_result,int(((num_live* 100.0)/(len(thread))) ),string_dp2.replace('Remaining: ',''),2,string_dp)
            
                global_result="4K: [COLOR yellow]%s[/COLOR] 1080: [COLOR khaki]%s[/COLOR] 720: [COLOR gold]%s[/COLOR] 480: [COLOR silver]%s[/COLOR] Rest: [COLOR burlywood]%s[/COLOR]"%(count_2160,count_1080,count_720,count_480,count_rest)
            
                total=count_1080+count_720+count_480+count_rest
                string_dp="4K: [COLOR yellow]%s[/COLOR] 1080: [COLOR khaki]%s[/COLOR] 720: [COLOR gold]%s[/COLOR] 480: [COLOR silver]%s[/COLOR] Rest: [COLOR burlywood]%s[/COLOR]  T: [COLOR darksalmon]%s[/COLOR] "%(count_2160,count_1080,count_720,count_480,count_rest,total)
              
                  
                     
                  

                  
                  
            dp.update(int(((num_live* 100.0)/(len(thread))) ), ' Please Wait '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),string_dp, string_dp2)
                  
            
        
        if dp.iscanceled() or still_alive==0:
          
          for name1,items in all_sources:
                items.stop_all=1
          num_live2=0
          for threads in thread:
            all_s_in=(f_result,int(((num_live2* 100.0)/(len(thread))) ),'Closing',2,threads.name)
            
            elapsed_time = time.time() - start_time
            dp.update(int(((num_live2* 100.0)/(len(thread))) ), ' Please Wait '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'Closing', threads.name)
            if threads.is_alive():
                 
                 
                 threads._Thread__stop()
            num_live2+=1
           
          break
        xbmc.sleep(100)
    all_lk2=[]
    all_mag={}
    hash_index={}
    page_index=0
    all_mag[0]=[]
    counter_hash=0
    rd = real_debrid.RealDebrid()
    for name_f in f_result:
             
            for name,link,server,quality in f_result[name_f]['links']:
                    
                    dp.update(0, ' Please wait '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'Updating links , check cached', name)
                    if link not in all_lk2:
                        all_lk2.append(link)
                        if 'magnet' in link:
                            try:
                                #hash = str(re.findall(r'btih:(.*?)&', link)[0].lower())
                                hash=link.split('btih:')[1]
                                if '&' in hash:
                                    hash=hash.split('&')[0]
                            except:
                                hash =link.split('btih:')[1]
                            #logging.warning(link)
                            #logging.warning(hash)
                            
                            all_mag[page_index].append(hash)
                            hash_index[hash.lower()]=link
                            counter_hash+=1
                            if counter_hash>150:
                                page_index+=1
                                all_mag[page_index]=[]
                                counter_hash=0
            
            all_hased=[]
            
            
            
            for items in all_mag:

                if len(all_mag[items])>0 :
         
                    hashCheck = rd.checkHash(all_mag[items])
                    
                    for hash in hashCheck:
                        
                        elapsed_time = time.time() - start_time
                        dp.update(0, ' Please wait '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),'Updating links , check cached', hash)
                      
                        if 'rd' in hashCheck[hash]:
                           if len(hashCheck[hash]['rd'])>0:
                                all_hased.append(hash)
    
    all_ok=[]
    for items in all_hased:
        
            
        all_ok.append(hash_index[items.lower()])
    dp.close()
    return f_result,all_ok
   except Exception as e:
    import linecache
    exc_type, exc_obj, tb = sys.exc_info()
    f = tb.tb_frame
    lineno = tb.tb_lineno
    filename = f.f_code.co_filename
    linecache.checkcache(filename)
    line = linecache.getline(filename, lineno, f.f_globals)
    logging.warning('ERROR IN NEXTUP IN:'+str(lineno))
    logging.warning('inline:'+line)
    logging.warning('Error:'+str(e))
    xbmc.executebuiltin((u'Notification(%s,%s)' % ('Error', 'inLine:'+str(lineno))))
    dp.close()
    pass
def get_sources(name,url,iconimage,fanart,description,data,original_title,id,season,episode,show_original_year):
    time_to_save=int(Addon.getSetting("save_time"))
    #match_a,all_ok= c_get_sources( name,url,iconimage,fanart,description,data,original_title,id,season,episode,show_original_year)
    match_a,all_ok= cache.get(c_get_sources, time_to_save, name,url,iconimage,fanart,description,data,original_title,id,season,episode,show_original_year,table='pages')

    all_data=[]
    for items in match_a:
        for name,lk,data,quality in match_a[items]['links']:
           if lk in all_ok:
            all_data.append((name,lk,data,fix_q(quality),quality,items.replace('magnet_','').replace('.py',''),))
    all_data=sorted(all_data, key=lambda x: x[3], reverse=False)
    all_2160=[]
    all_1080=[]
    all_720=[]
    all_rest=[]
    for name,lk,data,fix,quality,source in all_data:
        if fix==1:
            all_2160.append((name,lk,data,fix,quality,source))
        elif fix==2:
            all_1080.append((name,lk,data,fix,quality,source))
        elif fix==3:
            all_720.append((name,lk,data,fix,quality,source))
        else:
            all_rest.append((name,lk,data,fix,quality,source))
    
    all_2160=sorted(all_2160, key=lambda x: x[2], reverse=True)
    all_1080=sorted(all_1080, key=lambda x: x[2], reverse=True)
    all_720=sorted(all_720, key=lambda x: x[2], reverse=True)
    all_rest=sorted(all_rest, key=lambda x: x[2], reverse=True)
    all_data=all_2160+all_1080+all_720+all_rest
    for name,lk,data,fix,quality,source in all_data:
            color='white'
            if '2160' in quality or '4k' in quality.lower():
                color='yellow'
            elif '1080' in quality:
                color='lightblue'
            elif '720' in quality:
                color='lightgreen'
            if '5.1' in name:
                sound='-[COLOR khaki]5.1[/COLOR]-'
            elif '7.1' in name:
                sound='-[COLOR khaki]7.1[/COLOR]-'
            else:
                sound=''
            addLink('[COLOR %s]%s-[/COLOR]%s[COLOR bisque][I]%s[/I][/COLOR]-%s'%(color,quality,sound,data+'GB',source,), lk,6,False, iconimage,fanart,'[COLOR lightblue][B]'+name+'[/B][/COLOR]\n'+description,data=data,tmdb=id,season=season,episode=episode,original_title=original_title,year=show_original_year)
def ClearCache():
  
    logging.warning('Clear')
    cache.clear(['cookies', 'pages','posters'])
    xbmc.executebuiltin((u'Notification(%s,%s)' % ('Shadow', 'Cleared')))
def post_trk(id,season,episode):
    if len(id)>1 and id!='%20':
         if season!=None and season!="%20":
           '''
           logging.warning('tv')
           logging.warning(imdb_id)
           url_pre='http://thetvdb.com/api/GetSeriesByRemoteID.php?imdbid=%s&language=en'%imdb_id.replace('tt','')
           html2=requests.get(url_pre).content
           pre_tvdb = str(html2).split('<seriesid>')
           if len(pre_tvdb) > 1:
                tvdb = str(pre_tvdb[1]).split('</seriesid>')
           logging.warning(tvdb)
           '''
           season_t, episode_t = int('%01d' % int(season)), int('%01d' % int(episode))
           
           i = (post_trakt('/sync/history', data={"shows": [{"seasons": [{"episodes": [{"number": episode_t}], "number": season_t}], "ids": {"tmdb": id}}]}))
           logging.warning('TRK')
           logging.warning(i)
         else:
           
           i = (post_trakt('/sync/history',data= {"movies": [{"ids": {"tmdb": id}}]}))
         logging.warning('Watched Resoponce:')
         logging.warning(i)
def jump_seek(id,season,episode):
    global break_jump
    time_to_save_trk=int(Addon.getSetting("time_to_save"))
    logging.warning('Waiting for jump')
    logging.warning(xbmc.Player().isPlaying())
    timeout=0
    break_jump=1
    done=0
    while timeout<200:
        timeout+=1
        if break_jump==0:
            break
        if xbmc.Player().isPlaying():
            break
        xbmc.sleep(100)
    while xbmc.Player().isPlaying():
        if break_jump==0:
            break
        try:
        
            vidtime = xbmc.Player().getTime()
        except Exception as e:
            vidtime=0
            pass
        #logging.warning('Waiting for Vid2:'+str(vidtime))
        if vidtime>0:
            try:
               if done==0:
                g_timer=xbmc.Player().getTime()
                g_item_total_time=xbmc.Player().getTotalTime()
                avg=(g_timer*100)/g_item_total_time
                if (avg>time_to_save_trk):
                    logging.warning('Got precentage')
                    post_trk(id,season,episode)
                    done=1
            except Exception as e:
                logging.warning('Takt Err:'+str(e))
                pass
        xbmc.sleep(100)
    logging.warning('Waiting for Vid3:'+str(xbmc.Player().isPlaying()))
def play_link(name,url,iconimage,fanart,description,data,original_title,id,season,episode,show_original_year):
    global break_jump
    break_jump=0
    tmdbKey = '653bb8af90162bd98fc7ee32bcbbfb3d'
    rd = real_debrid.RealDebrid()
    link=rd.singleMagnetToLink(url)
    logging.warning('season:'+str(season))
    
    video_data={}
    if season!=None and season!="%20":
       video_data['TVshowtitle']=show_original_year
       video_data['mediatype']='tvshow'
       url2='http://api.themoviedb.org/3/tv/%s?api_key=%s&append_to_response=external_ids'%(id,tmdbKey)
    else:
       video_data['mediatype']='movie'
       url2='http://api.themoviedb.org/3/movie/%s?api_key=%s&append_to_response=external_ids'%(id,tmdbKey)
    try:
        imdb_id=requests.get(url2,timeout=10).json()['external_ids']['imdb_id']
    except:
        imdb_id=" "
    video_data['title']=original_title
    video_data['icon']=iconimage
    video_data['original_title']=name
    video_data['plot']=description
    video_data['year']=show_original_year
    video_data['season']=season
    video_data['episode']=episode
    video_data['poster']=fanart
    video_data['imdb']=imdb_id
    video_data['code']=imdb_id
    video_data['IMDBNumber']=imdb_id
    logging.warning(link)
    listItem = xbmcgui.ListItem(video_data['title'], path=link) 
    listItem.setInfo(type='Video', infoLabels=video_data)
    ok=xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
    if id!='%20':
            
            if season!=None and season!="%20":
               '''
               logging.warning('tv')
               logging.warning(imdb_id)
               url_pre='http://thetvdb.com/api/GetSeriesByRemoteID.php?imdbid=%s&language=en'%imdb_id.replace('tt','')
               html2=requests.get(url_pre).content
               pre_tvdb = str(html2).split('<seriesid>')
               if len(pre_tvdb) > 1:
                    tvdb = str(pre_tvdb[1]).split('</seriesid>')
               logging.warning(tvdb)
               '''
               season_t, episode_t = int('%01d' % int(season)), int('%01d' % int(episode))
               
               i = (post_trakt('/sync/watchlist', data={"shows": [{"seasons": [{"episodes": [{"number": episode_t}], "number": season_t}], "ids": {"tmdb": id}}]}))
            else:
               
               i = (post_trakt('/sync/watchlist',data= {"movies": [{"ids": {"tmdb": id}}]}))
            logging.warning('Trakt Resoponce:')
            logging.warning(i)
    
    thread=[]
        
    thread.append(Thread(jump_seek,id,season,episode))
        
    
    thread[0].start()
def clear_rd():
    Addon.setSetting('rd.client_id','')
    Addon.setSetting('rd.auth','')
    Addon.setSetting('rd.refresh','')
    Addon.setSetting('rd.secret','')
    xbmc.executebuiltin((u'Notification(%s,%s)' % ('Shadow', ('Cleared').decode('utf8'))).encode('utf-8'))
def re_enable_rd():
    clear_rd()

    rd = real_debrid.RealDebrid()
    rd.auth()
    xbmc.executebuiltin((u'Notification(%s,%s)' % ('Shadow', ('OK').decode('utf8'))).encode('utf-8'))
def add_remove_trakt(name,original_title,id,season,episode):

    if original_title=='add':
        if name=='tv':
         
           season_t, episode_t = int('%01d' % int(season)), int('%01d' % int(episode))
           
           i = (post_trakt('/sync/history', data={"shows": [{"seasons": [{"episodes": [{"number": episode_t}], "number": season_t}], "ids": {"tmdb": id}}]}))
        else:
          
           i = (post_trakt('/sync/history',data= {"movies": [{"ids": {"tmdb": id}}]}))
    elif original_title=='remove':
        if name=='tv':
         
           season_t, episode_t = int('%01d' % int(season)), int('%01d' % int(episode))
           
           i = (post_trakt('/sync/history/remove', data={"shows": [{"seasons": [{"episodes": [{"number": episode_t}], "number": season_t}], "ids": {"tmdb": id}}]}))
        else:
         
           i = (post_trakt('/sync/history/remove',data= {"movies": [{"ids": {"tmdb": id}}]}))
    if 'added' in i:
       xbmc.executebuiltin((u'Notification(%s,%s)' % ('Shadow', 'Marked as watched'.encode('utf-8'))))
    elif 'deleted' in i:
       xbmc.executebuiltin((u'Notification(%s,%s)' % ('Shadow', 'Watched removed'.encode('utf-8'))))
    else:
      xbmc.executebuiltin((u'Notification(%s,%s)' % ('Shadow', 'Error'.encode('utf-8'))))
    #xbmc.executebuiltin('Container.Refresh')
    
params=get_params()

url=None
name=None
mode=None
iconimage=None
fanart=None
description=None
data=None
original_title=None
id='0'
season='0'
episode='0'
show_original_year='0'
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
try:        
        data=(params["data"])
except:
        pass
try:        
        original_title=urllib.unquote_plus(params["original_title"])
except:
        pass
        
try:        
        id=(params["id"])
except:
        pass
try:        
        season=(params["season"])
except:
        pass
try:        
        episode=(params["episode"])
except:
        pass
try:        
        show_original_year=(params["show_original_year"])
except:
        pass
        
logging.warning('mode:'+str(mode))
logging.warning(id)
logging.warning(url)

if mode==None or url==None or len(url)<1:
        main_menu()
elif mode==2:
    movie_world()
elif mode==3:
    tv_show_menu()
elif mode==5:
    get_sources()
elif mode==6:
    play_link(name,url,iconimage,fanart,description,data,original_title,id,season,episode,show_original_year)
elif mode==14:
    from resources.modules.tmdb import get_movies
    get_movies(url)
elif mode==15:
    #logging.warning(name)
    #logging.warning(original_title)
    #sys.exit()
    get_sources(name,url,iconimage,fanart,description,data,original_title,id,season,episode,show_original_year)
elif mode==16:
    
    from resources.modules.tmdb import get_seasons
    get_seasons(name,url,iconimage,fanart,description,data,original_title,id)
elif mode==18:
    get_genere(url)
elif mode==19:
    from resources.modules.tmdb import get_episode
    get_episode(name,url,iconimage,fanart,description,data,original_title,id,season,id,show_original_year)

elif mode==35:
    
    ClearCache()
elif mode==65:
    add_remove_trakt(name,original_title,id,season,episode)
elif mode==101:
    tv_neworks()
elif mode==112:
    movie_prodiction()

elif mode==114:
    main_trakt()
elif mode==115:
    progress_trakt(url)
elif mode==116:
    get_trakt()
elif mode==117:
     get_trk_data(url)
elif mode==118:
    trakt_liked(url,iconimage,fanart)
elif mode==137:
    clear_rd()
elif mode==138:
    re_enable_rd()
xbmcplugin.setContent(int(sys.argv[1]), 'movies')

xbmcplugin.endOfDirectory(int(sys.argv[1]))

