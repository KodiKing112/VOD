

# -*- coding: utf-8 -*-
import requests,PTN
import unjuice,time,urlparse

global global_var,stop_all#global
global_var=[]
stop_all=0
rating=['SSS','7M/s']
import Addon
if Addon.getSetting("regex_mode")=='1':
    import regex  as re
else:
    import re
from general import clean_name,check_link,server_data,replaceHTMLCodes,domain_s,similar,cloudflare_request,all_colors
type=['tv','movie']

import urllib2,urllib,logging,base64,json
color=all_colors[102]
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id):
        global global_var,stop_all

        all_links=[]
        
        all_links_in=[]
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
            
        }
        if tv_movie=='tv':
            url='https://www1.putlocker.digital/search/'+clean_name(original_title,1).replace(' ','%20')+'%20season%20'+season
        else:
           url='https://www1.putlocker.digital/search/'+clean_name(original_title,1).replace(' ','%20')+'%20'+show_original_year
        
        x=requests.get(url,headers=headers).content
        regex='data-id="(.+?)".+?data-href="(.+?)".+?data-name="(.+?)"'
        match=re.compile(regex,re.DOTALL).findall(x)
        
      
        for id,link,name in match:
            
            if clean_name(original_title,1).lower() in name.lower():
                y=requests.get('https://www1.putlocker.digital'+link,headers=headers).content
                if tv_movie=='movie':
                    regex='<div id="watchBoxView">.+?href="(.+?)"'
                    match2=re.compile(regex,re.DOTALL).findall(y)
                else:
                    regex='<a data-ep-id="(.+?)" href="(.+?)".+?title="(.+?)"'
                    match2=re.compile(regex,re.DOTALL).findall(y)
              
                for data in match2:
                    if tv_movie=='tv':
                        id,link,title=data
                        check=False
                    else:
                       title='999'
                       link=data
                       check=True
                    
                    if 'Season %s Episode %s'%(season,episode_n) in title or check:
                        
                        headers = {
                            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
                            'Accept': 'text/html, */*; q=0.01',
                            'Accept-Language': 'en-US,en;q=0.5',
                            'Referer': 'https://www1.putlocker.digital'+link,
                            'X-Requested-With': 'XMLHttpRequest',
                            'Connection': 'keep-alive',
                            'Pragma': 'no-cache',
                            'Cache-Control': 'no-cache',
                            'TE': 'Trailers',
                        }
                        if tv_movie=='tv':
                            params = (
                                ('ep', id),
                            )
                        else:
                             params = (
                                ('ep', '0'),
                            )
                        response = requests.get('https://www1.putlocker.digital/user/servers/'+id, headers=headers, params=params).content
                        
                        regex='data-server="(.+?)"'
                        match=re.compile(regex).findall(response)
                        for num in match:
                            
                            headers = {
                                'pragma': 'no-cache',
                                
                                'accept-encoding': 'utf-8',
                                'accept-language': 'he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7',
                                'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36',
                                'accept': 'application/json, text/javascript, */*; q=0.01',
                                'cache-control': 'no-cache',
                                'authority': 'putlocker.cam',
                                'x-requested-with': 'XMLHttpRequest',
                                'referer': 'https://www1.putlocker.digital'+link,
                            }

                            params = (
                                ('number', num),
                                ('r', '0.43251677933326005'),
                                ('_', str(time.time())),
                            )

                            response = requests.get('https://www1.putlocker.digital'+link, headers=headers, params=params).json()
                            
                            for items in response:
                                if 'label' in items:
                                    res=items['label']
                                else:
                                    res=''
                                if 'file' in items and items['file'] not in all_links_in:
                                    
                                    all_links_in.append(items['file'])
                                    all_links.append((original_title.replace("%20"," "),items['file'],'Direct',res))
                                    global_var=all_links
        return   global_var